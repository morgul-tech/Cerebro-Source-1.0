import copy, hashlib, json, re, zipfile
from pathlib import Path

ROOT = Path(r"D:\Cerebro\Temp\P1476_C900")
SNAPSHOT = ROOT / "overlay_snapshot.json"
MANIFEST = ROOT / "CURRENT_BOOT_APPLICABILITY_MANIFEST_GENERIC_UNBOUND_WORKER.json"
RESULTS = ROOT / "TEST_RESULTS.json"
ZIP = ROOT / "P1476_C900_STEP03_MANIFEST_CANDIDATE.zip"

CONTEXT_TAGS = {
    "WORKER", "WORKER_BOOT", "BOOT",
    "ALL_CEREBRO_SESSIONS", "ALL_CEREBRO_BOOTS",
    "ALL_CEREBRO_WORKFORCE_BOOTS",
}
COLUMNS = [
    "OVERLAY_ID","SCOPE","REQUIREMENT","STATE","AUTHORITY_CLASS",
    "BASIS","APPLIES_TO","EFFECTIVE_FROM_SHARED_REVISION",
    "SUPERSEDES","SOURCE_PROMOTION_TARGET","NOTES",
]

def sha(obj):
    raw=json.dumps(obj, ensure_ascii=False, separators=(",",":"), sort_keys=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def normalize_cells(cells):
    c=list(cells)+[""]*11
    return [str(x) for x in c[:11]]

def tokens(s):
    return [x.strip() for x in re.split(r"[;|,]", s or "") if x.strip()]
def decision(state, applies):
    if not state.startswith("ACTIVE_"):
        return "EXCLUDED_HISTORICAL"
    ts=tokens(applies)
    if not ts:
        return "UNKNOWN"
    return "APPLICABLE" if any(t in CONTEXT_TAGS for t in ts) else "NOT_APPLICABLE"

snap=json.loads(SNAPSHOT.read_text(encoding="utf-8"))
all_rows=[]
for item in snap["rows"]:
    row=int(item["row"])
    cells=normalize_cells(item.get("cells",[]))
    if row==1:
        continue
    if not cells[0]:
        continue
    rec=dict(zip(COLUMNS,cells))
    dec=decision(rec["STATE"], rec["APPLIES_TO"])
    all_rows.append({
        "provider_row":row,
        "overlay_id":rec["OVERLAY_ID"],
        "state":rec["STATE"],
        "effective_from_shared_revision":rec["EFFECTIVE_FROM_SHARED_REVISION"],
        "applies_to":tokens(rec["APPLIES_TO"]),
        "supersedes_raw":rec["SUPERSEDES"],
        "supersedes_ids":sorted(set(re.findall(r"PSO-[A-Za-z0-9_.-]+", rec["SUPERSEDES"] or ""))),
        "decision":dec,
        "required_consume":dec=="APPLICABLE",
        "row_sha256":sha({"row":row,"cells":cells}),
    })

provider_rows=[{"row":int(x["row"]),"cells":normalize_cells(x.get("cells",[]))} for x in snap["rows"]]
snapshot_sha=sha(provider_rows)
applicable=[x["overlay_id"] for x in all_rows if x["decision"]=="APPLICABLE"]
counts={k:sum(1 for x in all_rows if x["decision"]==k) for k in ["APPLICABLE","NOT_APPLICABLE","UNKNOWN","EXCLUDED_HISTORICAL"]}
manifest={
    "schema":"cerebro.boot.current-applicability-manifest/v0.1-candidate",
    "candidate_id":"P1476_C900_GENERIC_UNBOUND_WORKER_STEP03",
    "effect":"NONE_ISOLATED_CANDIDATE",
    "provider_binding":{
        "spreadsheet_id":snap["provider"]["spreadsheet_id"],
        "sheet":snap["provider"]["sheet"],
        "range":snap["provider"]["range"],
        "frontier_row":snap["provider"]["frontier_row"],
        "snapshot_sha256":snapshot_sha,
        "data_rows":len(all_rows),
    },
    "boot_full_binding":{
        "provider_id":"1ImzuaW0XL444L31wpLx5YYGwX6BNXYUIRZ_A-YV387U",
        "version":"1.9",
        "sha256":"11915cc2e3bd0cb3ea54d0d47995ccf1ad90068767b91de77d40d517ea82dd12",
        "step03":"LOAD_CURRENT_PRE_SOURCE_OVERLAY_AND_CONSUME_ALL_ACTIVE_APPLICABLE_ROWS",
        "step03_extra_receipt_required":False,
    },
    "context":{
        "profile_requested":"WORKER","profile_effective":"NONE","workform":"GENERIC",
        "role_requested":"WORKER","bound":False,"project":"NONE","assignment":"NONE",
        "claim_created":False,"boot_phase":"STEP_03",
        "selector_tags":sorted(CONTEXT_TAGS),
    },
    "classification_contract":{
        "active_rule":"STATE starts with ACTIVE_",
        "applicability_rule":"ACTIVE row APPLIES_TO token intersects selector_tags",
        "missing_applies_to":"UNKNOWN_FAIL_CLOSED",
        "non_active_rule":"EXCLUDED_HISTORICAL",
        "active_supersession_rule":"retain ACTIVE row; record supersedes metadata; do not silently delete another ACTIVE row",
        "withdrawn_gate":"PM8469: separate canonical manifest-consumer receipt is NOT a mandatory BootFull STEP03 gate",
    },
    "counts":counts,
    "applicable_ids":applicable,
    "candidate_consumed_ids":applicable,
    "rows":all_rows,
    "failed_attempt_basis":{
        "attempt_id":"20ae11d1734243ab8490eda1ad3eb21b",
        "receipt_id":"1heiDvoUvuF6H_tW1Z88xRMFWmLalXQYN",
        "immutable":True,
        "first_nonpass":"STEP_03",
    },
}
MANIFEST.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
def validate(m):
    errors=[]
    rows=m.get("rows",[])
    ids=[x.get("overlay_id") for x in rows]
    if len(ids)!=len(set(ids)): errors.append("DUPLICATE_OVERLAY_ID")
    if m["provider_binding"]["snapshot_sha256"]!=snapshot_sha: errors.append("SNAPSHOT_DIGEST_MISMATCH")
    if m["provider_binding"]["data_rows"]!=len(all_rows): errors.append("DATA_ROW_COUNT_MISMATCH")
    by_id={x["overlay_id"]:x for x in all_rows}
    if set(ids)!=set(by_id): errors.append("ROW_MEMBERSHIP_MISMATCH")
    for x in rows:
        src=by_id.get(x.get("overlay_id"))
        if not src: continue
        for k in ["provider_row","state","effective_from_shared_revision","applies_to","supersedes_raw","supersedes_ids","decision","required_consume","row_sha256"]:
            if x.get(k)!=src.get(k): errors.append("ROW_FIELD_MISMATCH:"+str(x.get("overlay_id"))+":"+k)
    expected=[x["overlay_id"] for x in all_rows if x["decision"]=="APPLICABLE"]
    if m.get("applicable_ids")!=expected: errors.append("APPLICABLE_ID_SET_MISMATCH")
    if m.get("candidate_consumed_ids")!=expected: errors.append("CONSUMPTION_INCOMPLETE")
    if m["counts"].get("UNKNOWN")!=0: errors.append("UNKNOWN_APPLICABILITY")
    if m["boot_full_binding"].get("step03_extra_receipt_required") is not False: errors.append("WITHDRAWN_EXTRA_GATE_REINTRODUCED")
    return errors

tests=[]
def run(name, obj, expect_pass):
    errs=validate(obj)
    passed=(not errs) if expect_pass else bool(errs)
    tests.append({"name":name,"expected":"PASS" if expect_pass else "FAIL_CLOSED","observed_errors":errs,"test_pass":passed})

run("positive_current_generic_unbound", copy.deepcopy(manifest), True)
m=copy.deepcopy(manifest); m["rows"]=[x for x in m["rows"] if x["overlay_id"]!=applicable[0]]; run("negative_missing_applicable_row",m,False)
m=copy.deepcopy(manifest); m["provider_binding"]["snapshot_sha256"]="0"*64; run("negative_stale_snapshot_digest",m,False)
m=copy.deepcopy(manifest); m["rows"].append(copy.deepcopy(m["rows"][0])); run("negative_duplicate_overlay_id",m,False)
hist=next(x for x in all_rows if x["decision"]=="EXCLUDED_HISTORICAL")
m=copy.deepcopy(manifest); next(x for x in m["rows"] if x["overlay_id"]==hist["overlay_id"])["decision"]="APPLICABLE"; run("negative_historical_promoted_current",m,False)
m=copy.deepcopy(manifest); m["boot_full_binding"]["step03_extra_receipt_required"]=True; run("negative_withdrawn_extra_receipt_gate",m,False)

result={"schema":"cerebro.boot.applicability-manifest-tests/v0.1","tests":tests,"pass_count":sum(t["test_pass"] for t in tests),"total":len(tests),"all_pass":all(t["test_pass"] for t in tests),"manifest_sha256":hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),"snapshot_sha256":snapshot_sha}
RESULTS.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
with zipfile.ZipFile(ZIP,"w",zipfile.ZIP_DEFLATED) as z:
    for p in [SNAPSHOT,MANIFEST,RESULTS,Path(__file__)]:
        z.write(p,arcname=p.name)
print(json.dumps({"manifest":str(MANIFEST),"manifest_sha256":result["manifest_sha256"],"snapshot_sha256":snapshot_sha,"counts":counts,"tests":f"{result['pass_count']}/{result['total']}","zip":str(ZIP),"zip_sha256":hashlib.sha256(ZIP.read_bytes()).hexdigest(),"zip_bytes":ZIP.stat().st_size},separators=(",",":")))
