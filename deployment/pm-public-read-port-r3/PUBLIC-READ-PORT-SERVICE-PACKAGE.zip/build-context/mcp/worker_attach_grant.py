"""Server-held standing Human grant for native WORKER role attachment.

The grant is provisioned in the deployment environment and can be revoked there.
The caller supplies only an existing birth reference and a destination label; the
server checks its own birth state and signs the resulting overlay privately.
"""

from __future__ import annotations

import copy
import hashlib
import re
from typing import Any


class WorkerAttachGrantError(ValueError):
    pass


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise WorkerAttachGrantError(reason)


def validate_standing_grant(grant: Any, identity: Any) -> dict[str, Any]:
    required = {
        "schema", "grant_id", "issuer_principal_ref", "tenant_ref", "workspace_ref",
        "scope", "revision", "current", "revoked",
    }
    _require(isinstance(grant, dict) and set(grant) == required,
             "standing-worker-grant-fields-invalid")
    _require(grant["schema"] == "cerebro-standing-worker-grant/v1",
             "standing-worker-grant-schema-invalid")
    _require(isinstance(grant["grant_id"], str) and bool(grant["grant_id"].strip()),
             "standing-worker-grant-id-required")
    _require(grant["scope"] == "WORKER_ATTACH" and
             type(grant["revision"]) is int and grant["revision"] > 0 and
             grant["current"] is True and grant["revoked"] is False,
             "standing-worker-grant-not-current")
    _require(grant["issuer_principal_ref"] == identity.principal_ref and
             grant["tenant_ref"] == identity.tenant_ref and
             grant["workspace_ref"] == identity.workspace_ref,
             "standing-worker-grant-principal-or-workspace-mismatch")
    return copy.deepcopy(grant)


def verify_native_boot_origin(state: Any, *, generation_ref: str,
                              source_revision: str, verified_source: Any) -> None:
    adoption = state.get('worker_method_adoption') if isinstance(state, dict) else None
    if adoption is not None:
        from worker_method_adoption import validate_adoption
        validate_adoption(state)
    _require(isinstance(state, dict) and state.get("generation_ref") == generation_ref and
             state.get("lifecycle") == "READY_UNBOUND" and state.get("revision") == (adoption['revision'] if adoption else 2),
             "standing-worker-native-ready-birth-required")
    _require((adoption['new_source'] if adoption else state.get("source_revision")) == source_revision and
             isinstance(verified_source, dict) and
             verified_source.get("source_revision") == source_revision,
             "standing-worker-source-not-current")
    method = state.get("civilization_method_attestation")
    _require(isinstance(method, dict) and
             (adoption['new_method_fingerprint'] if adoption else method.get("method_fingerprint")) == verified_source.get("method_fingerprint"),
             "standing-worker-method-mismatch")
    receipt = state.get("ready_unbound_receipt")
    _require(isinstance(receipt, dict) and
             receipt.get("receipt_ref") == "READY_" + generation_ref and
             isinstance(receipt.get("receipt_fingerprint"), str) and
             re.fullmatch(r"[0-9a-f]{64}", receipt["receipt_fingerprint"]) is not None,
             "standing-worker-native-birth-receipt-required")
    canaries = state.get("generic_capability_canaries")
    _require(isinstance(canaries, list) and
             {c.get("canary_ref") for c in canaries if isinstance(c, dict)} == {
                 "AUTHENTICATED_TRANSITION_SCOPE", "CURRENT_SOURCE_AND_METHOD",
                 "STATE_CREATE_READBACK",
             } and all(isinstance(c, dict) and c.get("result") == "PASS" for c in canaries),
             "standing-worker-native-birth-canaries-required")


def worker_overlay_payload(*, generation_ref: str, source_revision: str,
                           destination_ref: str, expected_revision: int,
                           grant: dict[str, Any], adopted: bool = False, adopted_revision: int | None = None) -> dict[str, Any]:
    _require(re.fullmatch(r"CEREBRO-BOOT-[A-Z0-9-]{8,96}", generation_ref) is not None,
             "standing-worker-birth-ref-invalid")
    _require(re.fullmatch(r"[A-Z][A-Z0-9_]{0,31}", destination_ref) is not None,
             "standing-worker-destination-invalid")
    _require(type(expected_revision) is int and expected_revision == (adopted_revision if adopted_revision is not None else (3 if adopted else 2)) and expected_revision >= 2,
             "standing-worker-expected-revision-invalid")
    suffix = hashlib.sha256((grant["grant_id"] + ":" + generation_ref).encode()).hexdigest()[:12].upper()
    return {
        "generation_ref": generation_ref,
        "expected_revision": expected_revision,
        "overlay_ref": "WORKER-OVERLAY-" + suffix,
        "actor_ref": destination_ref + "_" + suffix,
        "role": "WORKER",
        "actor_generation_ref": "WORKER-" + destination_ref + "-" + generation_ref,
        "source_revision": source_revision,
    }
