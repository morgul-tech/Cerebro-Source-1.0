"""Narrow typed payload in EXISTING project owner heads/revisions/receipts.

No new tables or delegated database identity. All transactions use the verified
caller's tenant/workspace/principal. Installation must add the reserved-schema
RLS attenuation; an unappointed application writer is never an issuer.
"""
import json
from contextlib import contextmanager
from pm_owner_atomic import _row
from actor_admission_model import SCHEMA,AGGREGATE,blank,canonical,digest,need,AdmissionRefused

class AdmissionCommitUnknown(AdmissionRefused):pass

class ProjectAdmissionStore:
    def __init__(self,state_port):self.state=state_port
    @contextmanager
    def transaction(self,who,project_ref,*,write,mode,final_guard=None):
        completed=False
        try:
          with self.state._transaction(tenant_ref=who['tenant_ref'],workspace_ref=who['workspace_ref'],
             principal_ref=who['principal_ref'],read_only=not write,repeatable_read=not write,
             passthrough_errors=(AdmissionRefused,)) as c:
            access={'project_ref':project_ref,'principal_ref':who['principal_ref'],'mode':mode}
            c.execute("SELECT set_config('cerebro.actor_admission_access',%s,true)",(canonical(access).decode(),))
            c.execute("SET LOCAL statement_timeout='5s'")
            c.execute("SET LOCAL lock_timeout='3s'")
            if write:
                c.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))',
                          (canonical([who['tenant_ref'],who['workspace_ref'],project_ref,AGGREGATE]).decode(),))
            yield c
            if write and final_guard is not None:final_guard(c)
            completed=True
        except Exception:
            if write and completed:raise AdmissionCommitUnknown('COMMIT_OUTCOME_UNKNOWN_READ_SAME_OPERATION_NO_REPLAY') from None
            raise

    def load(self,c,who,project_ref,*,lock=False):
        c.execute('''SELECT *,now() AS server_now FROM cerebro_owner_state_heads WHERE tenant_ref=%s
            AND workspace_ref=%s AND project_ref=%s AND owner='project' AND aggregate_ref=%s'''+
            (' FOR UPDATE' if lock else ''),(who['tenant_ref'],who['workspace_ref'],project_ref,AGGREGATE))
        row=_row(c)
        if row is None:return {'revision':0,'fingerprint':digest(blank()),'payload':blank()}
        payload=row['state_payload']
        if type(payload)is str:payload=json.loads(payload)
        need(row['state_schema']==SCHEMA and type(payload)is dict and payload.get('schema')==SCHEMA
             and digest(payload)==row['state_fingerprint'],'ADMISSION_OWNER_STATE_INTEGRITY')
        return {'revision':row['owner_revision'],'fingerprint':row['state_fingerprint'],'payload':payload}

    def prior(self,c,who,operation_ref,request_fingerprint):
        c.execute('''SELECT request_fingerprint,commit_payload FROM cerebro_owner_state_commit_receipts
            WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s AND consumer_ref=%s
            AND session_ref=%s AND event_id=%s''',tuple(who[k] for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref','session_ref'))+(operation_ref,))
        row=_row(c)
        if row is None:return None
        need(row['request_fingerprint']==request_fingerprint,'SAME_OPERATION_CHANGED_BYTES')
        return json.loads(row['commit_payload']) if type(row['commit_payload'])is str else row['commit_payload']

    def save(self,c,who,project_ref,before,payload,operation_ref,request_fingerprint):
        need(len(canonical(payload))<=1048576,'OWNER_ADMISSION_AGGREGATE_BOUND')
        revision=before['revision']+1;fp=digest(payload);state_ref='actor-admission:'+fp
        values=(state_ref,revision,SCHEMA,canonical(payload).decode(),fp,operation_ref,
                who['tenant_ref'],who['workspace_ref'],project_ref,AGGREGATE)
        if before['revision']==0:
            c.execute('''INSERT INTO cerebro_owner_state_heads(current_state_ref,owner_revision,state_schema,
                state_payload,state_fingerprint,last_event_ref,tenant_ref,workspace_ref,project_ref,aggregate_ref,owner)
                VALUES(%s,%s,%s,%s::jsonb,%s,%s,%s,%s,%s,%s,'project') ON CONFLICT DO NOTHING RETURNING owner_revision''',values)
        else:
            c.execute('''UPDATE cerebro_owner_state_heads SET current_state_ref=%s,owner_revision=%s,state_schema=%s,
                state_payload=%s::jsonb,state_fingerprint=%s,last_event_ref=%s,updated_at=now()
                WHERE tenant_ref=%s AND workspace_ref=%s AND project_ref=%s AND aggregate_ref=%s AND owner='project'
                AND owner_revision=%s AND state_fingerprint=%s RETURNING owner_revision''',
                values+(before['revision'],before['fingerprint']))
        need(_row(c) is not None,'OWNER_CAS_CONFLICT_RELOAD_NO_REPLAY')
        input_ref=None if before['revision']==0 else 'actor-admission:'+before['fingerprint']
        effect_ref=None if before['revision']==0 else 'actor-admission-change:'+request_fingerprint
        effect_fp=None if before['revision']==0 else request_fingerprint
        c.execute('''INSERT INTO cerebro_owner_state_revisions(tenant_ref,workspace_ref,principal_ref,consumer_ref,
            session_ref,project_ref,owner,aggregate_ref,owner_revision,event_id,idempotency_key,input_state_ref,
            input_state_fingerprint,output_state_ref,output_state_fingerprint,owner_effect_candidate_ref,
            owner_effect_candidate_fingerprint,state_schema,state_payload)
            VALUES(%s,%s,%s,%s,%s,%s,'project',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)''',
            tuple(who[k] for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref','session_ref'))+
            (project_ref,AGGREGATE,revision,operation_ref,operation_ref,input_ref,
             None if before['revision']==0 else before['fingerprint'],state_ref,fp,effect_ref,effect_fp,SCHEMA,canonical(payload).decode()))
        receipt={'schema':'cerebro-actor-admission-owner-result/v1','operation_ref':operation_ref,
                 'project_ref':project_ref,'revision':revision,'fingerprint':fp,'authority':'SELECTED_OWNER_RECORD_ONLY'}
        c.execute('''INSERT INTO cerebro_owner_state_commit_receipts(tenant_ref,workspace_ref,principal_ref,consumer_ref,
            session_ref,project_ref,owner,aggregate_ref,event_id,idempotency_key,request_fingerprint,commit_kind,commit_ref,
            owner_revision_before,owner_revision_after,input_state_ref,input_state_fingerprint,output_state_ref,
            output_state_fingerprint,owner_effect_candidate_ref,owner_effect_candidate_fingerprint,commit_payload,commit_fingerprint)
            VALUES(%s,%s,%s,%s,%s,%s,'project',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s)''',
            tuple(who[k] for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref','session_ref'))+
            (project_ref,AGGREGATE,operation_ref,operation_ref,request_fingerprint,
             'INITIALIZE' if before['revision']==0 else 'OWNER_EFFECT','actor-admission-commit:'+digest([who,operation_ref]),
             before['revision'],revision,input_ref,None if before['revision']==0 else before['fingerprint'],state_ref,fp,
             effect_ref,effect_fp,canonical(receipt).decode(),digest(receipt)))
        return receipt
