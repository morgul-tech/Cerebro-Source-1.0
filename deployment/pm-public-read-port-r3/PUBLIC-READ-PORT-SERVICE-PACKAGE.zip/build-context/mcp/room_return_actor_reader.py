"""Installer-admitted intended-actor reads of existing accepted ROOM_RETURNs.

No service lease, state transition, dispatch, business completion or wake occurs.
The current request session is a host fence, not signed per-chat identity.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Mapping

from pm_owner_atomic import _row
from room_return_d1_outbox import (RoomReturnProducerBinding, RoomReturnRefused,
    REF, MAX_MATERIAL, _need, _sha, _canonical)


def _stamp(value):
    _need(type(value) is str and len(value) <= 64, 'ROOM_ACTOR_TIME_INVALID')
    try:
        stamp = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError:
        raise RoomReturnRefused('ROOM_ACTOR_TIME_INVALID') from None
    _need(stamp.tzinfo is not None, 'ROOM_ACTOR_TIME_INVALID')
    return stamp


@dataclass(frozen=True)
class RoomReturnActorIdentity:
    tenant_ref: str
    workspace_ref: str
    project_ref: str
    principal_ref: str
    consumer_ref: str
    session_ref: str
    session_binding_id: str

    @classmethod
    def from_mapping(cls, value):
        _need(type(value) is dict and set(value) == set(cls.__dataclass_fields__),
              'ROOM_ACTOR_IDENTITY_FIELDS')
        from room_return_d1_outbox import _principal_ref_valid
        for key, item in value.items():
            valid = _principal_ref_valid(item) if key == 'principal_ref' else (
                type(item) is str and REF.fullmatch(item) is not None)
            _need(valid, 'ROOM_ACTOR_IDENTITY_INVALID')
        return cls(**value)


@dataclass(frozen=True)
class RoomReturnActorReadBinding:
    read_ref: str
    producer_binding: RoomReturnProducerBinding
    reader: RoomReturnActorIdentity
    receiver_assignment_ref: str
    attempt_ref: str
    artifact_ref: str
    not_before: str
    expires_at: str

    @classmethod
    def from_mapping(cls, value):
        _need(type(value) is dict and set(value) == set(cls.__dataclass_fields__),
              'ROOM_ACTOR_BINDING_FIELDS')
        producer = RoomReturnProducerBinding.from_mapping(value['producer_binding'])
        reader = RoomReturnActorIdentity.from_mapping(value['reader'])
        _need((producer.tenant_ref,producer.workspace_ref,producer.project_ref) ==
              (reader.tenant_ref,reader.workspace_ref,reader.project_ref), 'ROOM_ACTOR_CROSS_SCOPE')
        for key in ('read_ref','receiver_assignment_ref','attempt_ref'):
            _need(type(value[key]) is str and REF.fullmatch(value[key]) is not None,
                  'ROOM_ACTOR_BINDING_REFERENCE')
        _need(type(value['artifact_ref']) is str and 0 < len(value['artifact_ref'].encode('utf-8')) <= 512
              and not any(c in value['artifact_ref'] for c in '\r\n\x00'), 'ROOM_ACTOR_ARTIFACT_REFERENCE')
        start, end = _stamp(value['not_before']), _stamp(value['expires_at'])
        _need(0 < (end-start).total_seconds() <= 86400, 'ROOM_ACTOR_FINITE_READ_WINDOW')
        return cls(**{**value,'producer_binding':producer,'reader':reader})


# Only these exact immutable owner fields are installed as the transaction-local
# RLS read attenuation in 0013; no service identity is substituted.
ROW_BINDING_FIELDS = {
    'tenant_ref':'tenant_ref','workspace_ref':'workspace_ref','project_ref':'project_ref',
    'owner_ref':'owner_ref','assignment_ref':'assignment_ref','route_owner_ref':'transport_owner_ref',
    'route_ref':'route_ref','receiver_ref':'receiver_ref','recipient_ref':'recipient_ref',
    'task_ref':'task_ref','material_revision':'material_revision','source_original_ref':'original_ref',
    'expected_action':'expected_action','parent_sha256':'parent_sha256',
    'material_sha256':'material_sha256','envelope_sha256':'envelope_sha256',
    'producer_principal_ref':'principal_ref','producer_consumer_ref':'consumer_ref',
    'producer_session_ref':'session_ref','producer_session_binding_id':'session_binding_id',
    'binding_revision':'binding_revision',
}


def _scope(binding):
    return {field:getattr(binding.producer_binding, attr) for field,attr in ROW_BINDING_FIELDS.items()}


class RoomReturnActorReader:
    def __init__(self, state_port, bindings, *, authorization_guard=None):
        _need(callable(getattr(state_port,'_transaction',None)), 'ROOM_ACTOR_STATE_PORT_REQUIRED')
        _need(type(bindings) is tuple and 1 <= len(bindings) <= 8
              and all(type(b) is RoomReturnActorReadBinding for b in bindings), 'ROOM_ACTOR_BINDINGS_BOUND')
        _need(len({b.read_ref for b in bindings}) == len(bindings), 'ROOM_ACTOR_DUPLICATE_READ_REF')
        _need(len({b.producer_binding for b in bindings}) == len(bindings), 'ROOM_ACTOR_MULTIPLE_CARRIERS')
        self._state, self._bindings = state_port, bindings
        _need(authorization_guard is None or callable(authorization_guard), 'ROOM_ACTOR_AUTHORIZATION_GUARD')
        self._authorization_guard = authorization_guard

    @staticmethod
    def _matches(binding, identity, session):
        r = binding.reader
        return (identity.tenant_ref,identity.workspace_ref,identity.principal_ref,identity.consumer_ref,
                session.get('session_ref')) == (r.tenant_ref,r.workspace_ref,r.principal_ref,
                r.consumer_ref,r.session_ref)

    def read(self, args, context):
        _need(type(args) is dict and (set(args) == {'op'} and args['op'] == 'list_accepted'
              or set(args) == {'op','message_id'} and args['op'] == 'read_exact'), 'ROOM_ACTOR_READ_FIELDS')
        if 'message_id' in args:
            from bk11_service_custody import MID
            _need(type(args['message_id']) is str and MID.fullmatch(args['message_id']) is not None,
                  'ROOM_ACTOR_MESSAGE_ID')
        ident = context.identity
        ident.validate()
        _need('project_state:read' in ident.state_scopes, 'ROOM_ACTOR_READ_SCOPE_REQUIRED')
        session = context.transport_session()
        _need(type(session) is dict, 'ROOM_ACTOR_CURRENT_SESSION_REQUIRED')
        bindings = [b for b in self._bindings if self._matches(b,ident,session)]
        _need(bindings, 'ROOM_ACTOR_NOT_ADMITTED')
        results = []
        with self._state._transaction(tenant_ref=ident.tenant_ref,workspace_ref=ident.workspace_ref,
                principal_ref=ident.principal_ref,read_only=True,repeatable_read=True,
                passthrough_errors=(RoomReturnRefused,)) as c:
            c.execute('SELECT now() AS server_now')
            now = _row(c)['server_now']
            if self._authorization_guard is not None:
                self._authorization_guard(c,context)
            for binding in bindings:
                r = binding.reader
                _need(_stamp(binding.not_before) <= now < _stamp(binding.expires_at),
                      'ROOM_ACTOR_READ_PERMISSION_EXPIRED_OR_NOT_YET_VALID')
                current = self._state._load_session(c,tenant_ref=r.tenant_ref,workspace_ref=r.workspace_ref,
                    principal_ref=r.principal_ref,consumer_ref=r.consumer_ref,session_ref=r.session_ref,
                    for_update=False,required=False)
                project = self._state._load_project(c,tenant_ref=r.tenant_ref,workspace_ref=r.workspace_ref,
                    project_ref=r.project_ref,required=False)
                _need(current is not None and project is not None and project['project_status'] == 'ACTIVE'
                      and current['project_ref'] == r.project_ref
                      and current['project_revision'] == project['revision']
                      and current['session_binding_id'] == r.session_binding_id, 'ROOM_ACTOR_CURRENT_STALE')
                scope = _scope(binding)
                grant = {**scope,'reader_principal_ref':r.principal_ref,'read_not_before':binding.not_before,
                         'read_expires_at':binding.expires_at,
                         'receiver_assignment_ref':binding.receiver_assignment_ref}
                c.execute("SELECT set_config('cerebro.room_return_actor_read',%s,true)",
                          (_canonical(grant).decode('utf-8'),))
                where = ' AND '.join('o.'+key+'=%s' for key in scope)
                values = list(scope.values())
                if 'message_id' in args:
                    where += ' AND o.message_id=%s'
                    values.append(args['message_id'])
                c.execute('''SELECT o.*,d.status AS backend_status,d.owner_event_id AS accepted_event_id,
                    d.owner_seq AS accepted_owner_seq,d.pointer_sha256 AS accepted_pointer_sha256,
                    d.receiver_assignment_ref AS accepted_receiver_assignment_ref
                    FROM cerebro_room_return_d1_outbox o JOIN cerebro_bk11_backend_dispositions d
                    ON d.tenant_ref=o.tenant_ref AND d.workspace_ref=o.workspace_ref
                    AND d.route_ref=o.route_ref AND d.receiver_ref=o.receiver_ref
                    AND d.message_id=o.message_id AND d.owner_family='ROOM_RETURN'
                    WHERE '''+where+''' AND d.status IN ('ACCEPTED_PENDING_WORK','EXPIRED_NEEDS_OWNER_DISPOSITION')
                    AND d.receiver_assignment_ref=%s ORDER BY o.owner_seq LIMIT 2''',
                    (*values,binding.receiver_assignment_ref))
                row, extra = _row(c), _row(c)
                _need(extra is None, 'ROOM_ACTOR_ACCEPTED_BASIS_AMBIGUOUS')
                if row is not None:
                    results.append(self._basis(row,binding,now))
        return {'schema':'cerebro-room-return-accepted-actor-basis/v1','rows':results,
                'dispatch_performed':False,'business_completion_recorded':False,
                'business_truth':'ACTOR_OWNED_CURRENT_PENDING_DISPOSITION',
                'session_fence':'HOST_SELECTED_REQUEST_METADATA_NOT_CRYPTOGRAPHIC_CHAT_IDENTITY'}

    @staticmethod
    def _basis(row, binding, now):
        b = binding.producer_binding
        _need(all(row.get(k) == v for k,v in _scope(binding).items()), 'ROOM_ACTOR_ROW_SCOPE_MISMATCH')
        material, envelope = row['material'],row['envelope']
        _need(type(material) is str and 0 < len(material.encode('utf-8')) <= MAX_MATERIAL
              and len(material.encode('utf-8')) == row['material_bytes']
              and type(envelope) is str and 0 < len(envelope.encode('utf-8')) <= 4096
              and _sha(material.encode('utf-8')) == b.material_sha256
              and _sha(envelope.encode('utf-8')) == b.envelope_sha256, 'ROOM_ACTOR_MATERIAL_INTEGRITY')
        try:
            doc = json.loads(envelope)
        except ValueError:
            raise RoomReturnRefused('ROOM_ACTOR_ENVELOPE_INVALID') from None
        expected = {'task_ref':b.task_ref,'material_revision':b.material_revision,
                    'original_ref':b.original_ref,'attempt_ref':binding.attempt_ref,'artifact_ref':binding.artifact_ref}
        _need(type(doc) is dict and all(doc.get(k) == v for k,v in expected.items()),
              'ROOM_ACTOR_ORIGINAL_REVISION_ATTEMPT_ARTIFACT_MISMATCH')
        fields = {**{k:row[k] for k in ('assignment_ref','task_ref','material_revision','parent_sha256',
            'expected_action','tenant_ref','workspace_ref','project_ref','owner_ref','producer_principal_ref',
            'producer_consumer_ref','producer_session_ref','producer_session_binding_id','material_sha256',
            'envelope_sha256','material_bytes','material','envelope','recipient_ref','receiver_ref',
            'route_ref','route_owner_ref','binding_revision')},'original_ref':row['source_original_ref']}
        _need(_sha(_canonical(fields)) == row['event_fingerprint'], 'ROOM_ACTOR_EVENT_INTEGRITY')
        registration = _sha(_canonical({'owner':b.owner_ref,'task':b.task_ref,
            'revision':b.material_revision,'recipient':b.recipient_ref,'original_ref':b.original_ref,
            'parent_sha256':b.parent_sha256,'material_sha256':b.material_sha256,
            'envelope_sha256':b.envelope_sha256}))
        _need(registration == row['registration_key']
              and row['owner_event_key'] == 'rr:'+registration[:32], 'ROOM_ACTOR_REGISTRATION_INTEGRITY')
        pointer_raw = bytes(row['pointer'])
        _need(_sha(pointer_raw) == row['pointer_sha256'] == row['accepted_pointer_sha256']
              and row['accepted_event_id'] == row['owner_event_key']
              and row['accepted_owner_seq'] == row['owner_seq']
              and row['accepted_receiver_assignment_ref'] == binding.receiver_assignment_ref,
              'ROOM_ACTOR_ACCEPTED_RECEIPT_MISMATCH')
        try:
            pointer = json.loads(pointer_raw)
            body_sha = pointer.pop('body_sha256')
        except (ValueError,KeyError,TypeError):
            raise RoomReturnRefused('ROOM_ACTOR_POINTER_INVALID') from None
        _need(body_sha == _sha(_canonical(pointer)) and pointer.get('message_id') == row['message_id']
              and pointer.get('event_fingerprint') == row['event_fingerprint']
              and pointer.get('owner_event_key') == row['owner_event_key']
              and pointer.get('owner_revision') == row['owner_seq']
              and pointer.get('referent') == {'type':'ROOM_RETURN','id':row['room_return_ref']}
              and pointer.get('receiver_ref') == row['receiver_ref']
              and all(pointer.get(k) == row[k] for k in ('tenant_ref','workspace_ref','project_ref','owner_ref'))
              and pointer.get('schema') == 'cerebro.d1.pointer' and pointer.get('version') == 1,
              'ROOM_ACTOR_POINTER_INTEGRITY')
        expiry = row['expires_at'] if isinstance(row['expires_at'],datetime) else _stamp(row['expires_at'])
        _need(_stamp(pointer.get('expires_at')) == expiry, 'ROOM_ACTOR_POINTER_EXPIRY_MISMATCH')
        expired = expiry <= now or row['backend_status'] == 'EXPIRED_NEEDS_OWNER_DISPOSITION'
        return {'read_ref':binding.read_ref,'room_return_ref':row['room_return_ref'],
                'message_id':row['message_id'],'pointer_sha256':row['pointer_sha256'],
                'registration_key':row['registration_key'],'event_fingerprint':row['event_fingerprint'],
                **expected,'parent_sha256':b.parent_sha256,'recipient_ref':b.recipient_ref,
                'material':material,'envelope':envelope,'material_sha256':b.material_sha256,
                'envelope_sha256':b.envelope_sha256,'backend_status':row['backend_status'],
                'notification_expired':expired,'effect_eligible':False,'authority':'NONE_READ_ONLY_BASIS',
                'owner_disposition_required_for_stale_effects':expired,
                'business_dedupe_key':row['registration_key'],'dispatch_performed':False}
