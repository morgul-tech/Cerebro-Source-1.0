"""Single-row ROOM_RETURN owner record and D1 publication duty.

This adapter is inert unless an installation supplies an exact producer binding.
The binding is host-owned; tool arguments cannot select task, recipient, route,
principal, session, or the current material revision.  It creates no model work.
"""
from __future__ import annotations

import hashlib
import json
import re
import base64
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Any, Mapping

from pm_owner_atomic import _row

REF = re.compile(r"\A[A-Za-z0-9][A-Za-z0-9_.:@/#=-]{0,159}\Z")
HEX = re.compile(r"\A[a-f0-9]{64}\Z")
MAX_MATERIAL = 16_384
MAX_TTL = 120
SERVICE_PROFILE = "BK11_CONTEXT_EDGE_BACKEND_PRODUCTION/v1"


class RoomReturnRefused(RuntimeError):
    pass


def _need(ok: bool, code: str) -> None:
    if not ok:
        raise RoomReturnRefused(code)


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _principal_ref_valid(value: str) -> bool:
    if not isinstance(value, str) or len(value) > 160:
        return False
    if REF.fullmatch(value) is not None:
        return True
    if value.count("|") != 1:
        return False
    issuer, principal = value.split("|", 1)
    return REF.fullmatch(issuer) is not None and REF.fullmatch(principal) is not None


def _build_pointer(*, tenant_ref: str, workspace_ref: str, project_ref: str, owner_ref: str,
                   owner_event_key: str, owner_revision: int, event_fingerprint: str,
                   referent_id: str, receiver_ref: str, created_at: datetime, ttl_seconds: int) -> tuple[bytes,str]:
    message_id = "d1:" + _sha(_canonical({"t":tenant_ref,"w":workspace_ref,"p":project_ref,
        "r":receiver_ref,"k":owner_event_key,"v":owner_revision}))[:40]
    created = created_at.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    expires = (created_at.astimezone(timezone.utc)+timedelta(seconds=ttl_seconds)).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    body = {"schema":"cerebro.d1.pointer","version":1,"tenant_ref":tenant_ref,
        "workspace_ref":workspace_ref,"project_ref":project_ref,"owner_ref":owner_ref,
        "owner_event_key":owner_event_key,"owner_revision":owner_revision,
        "event_fingerprint":event_fingerprint,"referent":{"type":"ROOM_RETURN","id":referent_id},
        "receiver_ref":receiver_ref,"message_id":message_id,"dedupe_key":message_id,
        "class":"D1","kind":"DECISION","created_at":created,"expires_at":expires}
    body["body_sha256"]=_sha(_canonical(body))
    raw=_canonical(body)
    return raw,message_id


@dataclass(frozen=True)
class RoomReturnProducerBinding:
    """Exact installer-selected producer authority; never construct from request fields."""
    assignment_ref: str
    tenant_ref: str
    workspace_ref: str
    project_ref: str
    principal_ref: str
    consumer_ref: str
    session_ref: str
    session_binding_id: str
    owner_ref: str
    task_ref: str
    material_revision: str
    original_ref: str
    expected_action: str
    parent_sha256: str
    material_sha256: str
    envelope_sha256: str
    recipient_ref: str
    receiver_ref: str
    route_ref: str
    transport_owner_ref: str
    binding_revision: int
    pointer_ttl_seconds: int

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "RoomReturnProducerBinding":
        _need(isinstance(value, Mapping) and set(value) == set(cls.__dataclass_fields__),
              "ROOM_RETURN_BINDING_FIELDS")
        out = cls(**value)
        for name in cls.__dataclass_fields__:
            item = getattr(out, name)
            if name in {"binding_revision", "pointer_ttl_seconds"}:
                continue
            _need(type(item) is str and bool(item.strip()) and len(item.encode("utf-8")) <= 512
                  and (name in {"original_ref","expected_action"} or not any(ch.isspace() for ch in item)),
                  "ROOM_RETURN_BINDING_VALUE")
        for name in ("parent_sha256", "material_sha256", "envelope_sha256"):
            _need(HEX.fullmatch(getattr(out, name)) is not None, "ROOM_RETURN_BINDING_DIGEST")
        for name in ("assignment_ref","tenant_ref","workspace_ref","project_ref","principal_ref","consumer_ref",
                     "session_ref","session_binding_id","owner_ref","task_ref","material_revision",
                     "recipient_ref","receiver_ref","route_ref","transport_owner_ref"):
            item=getattr(out,name)
            valid=_principal_ref_valid(item) if name=="principal_ref" else REF.fullmatch(item) is not None
            _need(valid, "ROOM_RETURN_BINDING_REFERENCE")
        _need(type(out.binding_revision) is int and out.binding_revision > 0, "ROOM_RETURN_BINDING_REVISION")
        _need(type(out.pointer_ttl_seconds) is int and 1 <= out.pointer_ttl_seconds <= MAX_TTL,
              "ROOM_RETURN_TTL_BOUND")
        return out


class RoomReturnD1Outbox:
    """Authenticated registration, exact read, bounded discovery and publication CAS."""
    def __init__(self, *, state_port: Any, binding: RoomReturnProducerBinding | None,
                 registration_guard=None, prior_validator=None):
        _need(callable(getattr(state_port, "_transaction", None)), "ROOM_RETURN_STATE_PORT_REQUIRED")
        _need(binding is None or type(binding) is RoomReturnProducerBinding, "ROOM_RETURN_BINDING_INVALID")
        self._state, self._binding = state_port, binding
        _need(registration_guard is None or callable(registration_guard), 'ROOM_RETURN_REGISTRATION_GUARD')
        _need(prior_validator is None or callable(prior_validator), 'ROOM_RETURN_PRIOR_VALIDATOR')
        self._registration_guard,self._prior_validator=registration_guard,prior_validator

    def _producer(self, context: Any, *, write: bool):
        b = self._binding
        _need(b is not None, "ROOM_RETURN_PRODUCER_NOT_INSTALLED")
        ident = context.identity
        ident.validate()
        _need(("project_state:transition" if write else "project_state:read") in ident.state_scopes,
              "ROOM_RETURN_SCOPE_REQUIRED")
        session = context.transport_session()
        _need(type(session) is dict and session.get("session_ref") == b.session_ref,
              "ROOM_RETURN_CURRENT_SESSION_REQUIRED")
        _need((ident.tenant_ref, ident.workspace_ref, ident.principal_ref, ident.consumer_ref)
              == (b.tenant_ref, b.workspace_ref, b.principal_ref, b.consumer_ref),
              "ROOM_RETURN_PRODUCER_ASSIGNMENT_MISMATCH")
        return b, ident, session

    @contextmanager
    def _publisher(self, context: Any, *, write: bool):
        ident = context.identity
        ident.validate()
        _need(("project_state:transition" if write else "project_state:read") in ident.state_scopes,
              "ROOM_RETURN_PUBLISHER_SCOPE_REQUIRED")
        session = context.transport_session()
        _need(type(session) is dict and type(session.get("session_ref")) is str,
              "ROOM_RETURN_PUBLISHER_SESSION_REQUIRED")
        with self._state._transaction(tenant_ref=ident.tenant_ref, workspace_ref=ident.workspace_ref,
              principal_ref=ident.principal_ref, read_only=not write, repeatable_read=not write,
              passthrough_errors=(RoomReturnRefused,)) as c:
            if write:
                lock_key=json.dumps([ident.tenant_ref,ident.workspace_ref,ident.principal_ref,
                    ident.consumer_ref,session["session_ref"]],separators=(",",":"))
                c.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s,0))",(lock_key,))
            c.execute("""SELECT *,now() AS server_now FROM cerebro_bk11_service_assignments
              WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s AND consumer_ref=%s
                AND session_ref=%s AND service_role='publisher' AND owner_family='ROOM_RETURN'""",
              (ident.tenant_ref,ident.workspace_ref,ident.principal_ref,ident.consumer_ref,session["session_ref"]))
            assignment = _row(c)
            _need(assignment is not None and assignment["enabled"] is True
                  and assignment["profile"] == SERVICE_PROFILE
                  and assignment["expires_at"] > assignment["server_now"],
                  "ROOM_RETURN_PUBLISHER_ASSIGNMENT_UNAVAILABLE")
            current = self._state._load_session(c, tenant_ref=ident.tenant_ref, workspace_ref=ident.workspace_ref,
                principal_ref=ident.principal_ref, consumer_ref=ident.consumer_ref,
                session_ref=assignment["session_ref"], for_update=write, required=False)
            project = self._state._load_project(c, tenant_ref=ident.tenant_ref, workspace_ref=ident.workspace_ref,
                project_ref=assignment["project_ref"], for_update=write, required=False)
            _need(current is not None and project is not None and project["project_status"] == "ACTIVE"
                  and current["project_ref"] == assignment["project_ref"]
                  and current["project_revision"] == project["revision"]
                  and current["session_binding_id"] == assignment["session_binding_id"],
                  "ROOM_RETURN_PUBLISHER_ASSIGNMENT_STALE")
            _need(current["project_ref"]==assignment["project_ref"]
                  and current["project_revision"]==project["revision"],
                  "ROOM_RETURN_PUBLISHER_PROJECT_STALE")
            c.execute("""SELECT * FROM cerebro_pm_owner_d1_routes WHERE tenant_ref=%s AND workspace_ref=%s
              AND owner_ref=%s AND route_ref=%s""",
              (ident.tenant_ref,ident.workspace_ref,assignment["owner_ref"],assignment["route_ref"]))
            route = _row(c)
            _need(route is not None and (route["publisher_principal_ref"],route["publisher_consumer_ref"],
                  route["publisher_session_ref"],route["publisher_session_binding_id"],route["project_ref"],
                  route["receiver_ref"],route["binding_revision"],route["pointer_ttl_seconds"])
                  ==(ident.principal_ref,ident.consumer_ref,session["session_ref"],
                     assignment["session_binding_id"],assignment["project_ref"],assignment["receiver_ref"],
                     assignment["route_binding_revision"],assignment["pointer_ttl_seconds"]),
                  "ROOM_RETURN_PUBLISHER_ROUTE_STALE")
            _need(not write or route["drain_enabled"] is True,"ROOM_RETURN_DRAIN_DISABLED")
            assignment["drain_enabled"] = route["drain_enabled"]
            yield assignment, ident, c

    def register(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        _need(set(args) == {"idempotency_key", "material", "envelope"}, "ROOM_RETURN_REGISTER_FIELDS")
        b, ident, session = self._producer(context, write=True)
        _need(type(args["idempotency_key"]) is str and REF.fullmatch(args["idempotency_key"]) is not None,
              "ROOM_RETURN_IDEMPOTENCY_KEY")
        _need(type(args["material"]) is str and 0 < len(args["material"].encode("utf-8")) <= MAX_MATERIAL,
              "ROOM_RETURN_MATERIAL_SIZE")
        _need(type(args["envelope"]) is str and 0 < len(args["envelope"].encode("utf-8")) <= 4096,
              "ROOM_RETURN_ENVELOPE_SIZE")
        material = args["material"].encode("utf-8")
        envelope = args["envelope"].encode("utf-8")
        _need(_sha(material) == b.material_sha256 and _sha(envelope) == b.envelope_sha256,
              "ROOM_RETURN_MATERIAL_OR_ENVELOPE_MISMATCH")
        envelope_doc = json.loads(envelope.decode("utf-8"))
        _need(type(envelope_doc) is dict, "ROOM_RETURN_ENVELOPE_INVALID")
        registration_key = _sha(_canonical({"owner":b.owner_ref,"task":b.task_ref,
            "revision":b.material_revision,"recipient":b.recipient_ref,"original_ref":b.original_ref,
            "parent_sha256":b.parent_sha256,"material_sha256":b.material_sha256,
            "envelope_sha256":b.envelope_sha256}))
        fields = {"assignment_ref": b.assignment_ref, "task_ref": b.task_ref,
            "material_revision": b.material_revision, "parent_sha256": b.parent_sha256,
            "original_ref": b.original_ref, "expected_action": b.expected_action,
            "tenant_ref": b.tenant_ref, "workspace_ref": b.workspace_ref, "project_ref": b.project_ref,
            "owner_ref": b.owner_ref,
            "producer_principal_ref":b.principal_ref,"producer_consumer_ref":b.consumer_ref,
            "producer_session_ref":b.session_ref,"producer_session_binding_id":b.session_binding_id,
            "material_sha256": b.material_sha256, "envelope_sha256": b.envelope_sha256,
            "material_bytes": len(material), "material": args["material"], "envelope": args["envelope"],
            "recipient_ref": b.recipient_ref, "receiver_ref": b.receiver_ref,
            "route_ref": b.route_ref, "route_owner_ref": b.transport_owner_ref,
            "binding_revision": b.binding_revision}
        event_fingerprint = _sha(_canonical(fields))
        owner_event_key = "rr:" + registration_key[:32]
        with self._state._transaction(tenant_ref=ident.tenant_ref, workspace_ref=ident.workspace_ref,
              principal_ref=ident.principal_ref, read_only=False, repeatable_read=False,
              passthrough_errors=(RoomReturnRefused,)) as c:
            if self._registration_guard is not None:self._registration_guard(c,b,args,context)
            current = self._state._load_session(c, tenant_ref=b.tenant_ref, workspace_ref=b.workspace_ref,
                principal_ref=b.principal_ref, consumer_ref=b.consumer_ref, session_ref=b.session_ref,
                for_update=False, required=False)
            project = self._state._load_project(c, tenant_ref=b.tenant_ref, workspace_ref=b.workspace_ref,
                project_ref=b.project_ref, required=False)
            _need(current is not None and project is not None and project["project_status"] == "ACTIVE"
                  and current["project_ref"] == b.project_ref
                  and current["project_revision"] == project["revision"]
                  and current["session_binding_id"] == b.session_binding_id,
                  "ROOM_RETURN_CURRENT_ASSIGNMENT_STALE")
            # Serialize both uniqueness domains without locking owner rows: the
            # producer membrane grants INSERT/SELECT, while publisher alone settles.
            lock_keys=sorted((
                _canonical(["ROOM_RETURN_IDEMPOTENCY",b.tenant_ref,b.workspace_ref,b.owner_ref,
                            args["idempotency_key"]]).decode("utf-8"),
                _canonical(["ROOM_RETURN_REGISTRATION",b.tenant_ref,b.workspace_ref,b.owner_ref,
                            registration_key]).decode("utf-8")))
            for lock_key in lock_keys:
                c.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s,0))",(lock_key,))
            # The A1 producer does not read a separate transport owner's route.
            # The exact route/ref/revision/TTL are host-admitted here; the existing
            # D1 service assignment validates the live route in its own custody path.
            c.execute("""SELECT * FROM cerebro_room_return_d1_outbox
              WHERE tenant_ref=%s AND workspace_ref=%s AND owner_ref=%s
                AND (idempotency_key=%s OR registration_key=%s)""",
              (b.tenant_ref,b.workspace_ref,b.owner_ref,args["idempotency_key"],registration_key))
            prior = _row(c)
            if prior is not None:
                if self._prior_validator is not None:
                    self._prior_validator(prior,b,args,context)
                    return self._public(prior)
                _need(prior["registration_key"] == registration_key
                      and prior["event_fingerprint"] == event_fingerprint
                      and prior["material_sha256"] == b.material_sha256
                      and prior["envelope_sha256"] == b.envelope_sha256,
                      "ROOM_RETURN_IDEMPOTENCY_CONFLICT")
                return self._public(prior)
            c.execute("""SELECT nextval('public.cerebro_room_return_ref_seq') AS ref_seq,
              nextval('public.cerebro_room_return_d1_outbox_owner_seq_seq') AS owner_seq,now() AS server_now""")
            issued = _row(c)
            _need(issued is not None and type(issued["owner_seq"]) is int and issued["owner_seq"] > 0,
                  "ROOM_RETURN_SERVER_SEQUENCE_REQUIRED")
            room_return_ref = "rr:" + str(issued["ref_seq"])
            pointer,message_id = _build_pointer(tenant_ref=b.tenant_ref, workspace_ref=b.workspace_ref,
                project_ref=b.project_ref, owner_ref=b.owner_ref, owner_event_key=owner_event_key,
                owner_revision=issued["owner_seq"], event_fingerprint=event_fingerprint,
                referent_id=room_return_ref, receiver_ref=b.receiver_ref,
                created_at=issued["server_now"], ttl_seconds=b.pointer_ttl_seconds)
            expiry = issued["server_now"] + timedelta(seconds=b.pointer_ttl_seconds)
            c.execute("""INSERT INTO cerebro_room_return_d1_outbox
              (room_return_ref,owner_seq,tenant_ref,workspace_ref,project_ref,owner_ref,assignment_ref,route_ref,receiver_ref,
               producer_principal_ref,producer_consumer_ref,producer_session_ref,producer_session_binding_id,
               route_owner_ref,recipient_ref,task_ref,
               material_revision,source_original_ref,expected_action,parent_sha256,material_sha256,envelope_sha256,
               material_bytes,material,envelope,idempotency_key,registration_key,event_fingerprint,owner_event_key,
               binding_revision,message_id,pointer,pointer_sha256,state,created_at,expires_at)
              VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
               %s,%s,%s,%s,'INTENDED',%s,%s)
              ON CONFLICT DO NOTHING RETURNING *""",
              (room_return_ref,issued["owner_seq"],b.tenant_ref,b.workspace_ref,b.project_ref,b.owner_ref,b.assignment_ref,
               b.route_ref,b.receiver_ref,b.principal_ref,b.consumer_ref,b.session_ref,b.session_binding_id,b.transport_owner_ref,
               b.recipient_ref,b.task_ref,b.material_revision,b.original_ref,b.expected_action,b.parent_sha256,
               b.material_sha256,b.envelope_sha256,len(material),args["material"],args["envelope"],
               args["idempotency_key"],registration_key,event_fingerprint,owner_event_key,b.binding_revision,
               message_id,pointer,_sha(pointer),issued["server_now"],expiry))
            row = _row(c)
            if row is None:
                c.execute("""SELECT * FROM cerebro_room_return_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s
                  AND owner_ref=%s AND (idempotency_key=%s OR registration_key=%s)""",
                  (b.tenant_ref,b.workspace_ref,b.owner_ref,args["idempotency_key"],registration_key))
                row = _row(c)
                _need(row is not None and row["registration_key"]==registration_key
                      and row["event_fingerprint"]==event_fingerprint,"ROOM_RETURN_IDEMPOTENCY_CONFLICT")
        return self._public(row)

    @staticmethod
    def _public(row: Mapping[str, Any]) -> dict[str, Any]:
        return {"room_return_ref": row["room_return_ref"], "owner_seq": row["owner_seq"],
            "tenant_ref": row["tenant_ref"], "workspace_ref": row["workspace_ref"],
            "project_ref": row["project_ref"], "owner_ref": row["owner_ref"],
            "owner_event_key": row["owner_event_key"], "owner_revision": row["owner_seq"],
            "event_fingerprint": row["event_fingerprint"], "referent_type": "ROOM_RETURN",
            "referent_id": row["room_return_ref"], "receiver_ref": row["receiver_ref"],
            "created_at": row["created_at"].isoformat() if isinstance(row["created_at"], datetime) else row["created_at"],
            "expires_at": row["expires_at"].isoformat() if isinstance(row["expires_at"], datetime) else row["expires_at"],
            "enqueued_at": row["enqueued_at"].isoformat() if isinstance(row["enqueued_at"], datetime) else row["enqueued_at"],
            "pointer": base64.b64encode(bytes(row["pointer"])).decode("ascii") if row.get("pointer") else None,
            "message_id": row.get("message_id"), "pointer_sha256": row.get("pointer_sha256"),
            "state": row["state"], "claim_token": row.get("claim_token"),
            "attempts": row.get("attempts",0),
            "claimed_at": row["claimed_at"].isoformat() if isinstance(row.get("claimed_at"), datetime) else row.get("claimed_at"),
            "stream": row.get("stream"), "stream_seq": row.get("stream_seq"),
            "duplicate": row.get("duplicate"), "puback_latency_ms": row.get("puback_latency_ms"),
            "last_reason": row.get("last_reason"),
            "recipient_action": row.get("recipient_action", "PENDING"),
            "material_sha256": row["material_sha256"], "envelope_sha256": row["envelope_sha256"]}

    def read_exact(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        _need(set(args) == {"message_id"}, "ROOM_RETURN_READ_FIELDS")
        with self._publisher(context, write=False) as (a, ident, c):
            from actor_service_room_scope import owner_column,qualify
            owner_field,owner_value=owner_column(a)
            c.execute("""SELECT * FROM cerebro_room_return_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s
              AND """+owner_field+"""=%s AND route_owner_ref=%s AND route_ref=%s AND receiver_ref=%s AND message_id=%s""",
              (a["tenant_ref"],a["workspace_ref"],owner_value,a["owner_ref"],a["route_ref"],
               a["receiver_ref"],args["message_id"]))
            row = _row(c)
            if row is not None:qualify(c,a,row)
        return {"row": None if row is None else self._public(row)}

    def list_for_publisher(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        _need(set(args) <= {"op","after","limit"} and args.get("op") in ("list_pending","list_recovery_candidates"),
              "ROOM_RETURN_LIST_FIELDS")
        limit = args.get("limit",16)
        _need(type(limit) is int and 1 <= limit <= 64, "ROOM_RETURN_LIST_LIMIT")
        after = args.get("after")
        keyset = ""
        values: list[Any] = []
        if after is not None:
            _need(type(after) is dict and set(after) == {"enqueued_at","event_id"}
                  and type(after["enqueued_at"]) is str and type(after["event_id"]) is str,
                  "ROOM_RETURN_LIST_CURSOR")
            keyset = " AND (enqueued_at,owner_event_key)>(%s::timestamptz,%s)"
            values.extend((after["enqueued_at"],after["event_id"]))
        state_filter = " AND state<>'PUBLISHED'" if args["op"] == "list_pending" else ""
        with self._publisher(context, write=False) as (a, ident, c):
            from actor_service_room_scope import owner_column,qualify
            owner_field,owner_value=owner_column(a)
            values=[a["tenant_ref"],a["workspace_ref"],owner_value,a["owner_ref"],a["route_ref"],a["receiver_ref"]]
            if after is not None:
                values.extend((after["enqueued_at"],after["event_id"]))
            c.execute("""SELECT * FROM cerebro_room_return_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s
              AND """+owner_field+"""=%s AND route_owner_ref=%s AND route_ref=%s AND receiver_ref=%s"""+
              state_filter+keyset+" ORDER BY enqueued_at,owner_event_key LIMIT %s",(*values,limit+1))
            rows=[]
            for _ in range(limit+1):
                row=_row(c)
                if row is None:break
                rows.append(row)
            for row in rows:qualify(c,a,row)
            rows=[self._public(row) for row in rows]
        more=len(rows)>limit
        rows=rows[:limit]
        nxt={"enqueued_at":rows[-1]["enqueued_at"],"event_id":rows[-1]["owner_event_key"]} if more else None
        return {"rows":rows,"next":nxt,"drain_enabled":a["drain_enabled"]}

    def settle(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        _need(set(args) == {"message_id","from_state","from_token","fields"}, "ROOM_RETURN_SETTLE_FIELDS")
        fields = args["fields"]
        _need(type(fields) is dict and set(fields) <= {"state","claim_token","claimed_at","attempts",
            "stream","stream_seq","duplicate","puback_latency_ms","last_reason"}, "ROOM_RETURN_SETTLE_FIELDS")
        from pm_owner_d1_outbox import SETTLE_FIELDS, STATES
        _need(args["from_state"] in STATES and (args["from_token"] is None or type(args["from_token"]) is str),
              "ROOM_RETURN_SETTLE_CAS_INVALID")
        _need(type(fields) is dict and bool(fields) and set(fields) <= set(SETTLE_FIELDS)
              and "state" in fields and fields["state"] in STATES, "ROOM_RETURN_SETTLE_FIELDS_INVALID")
        for key, value in fields.items():
            expected = SETTLE_FIELDS[key]
            valid_type = type(value) is expected or (expected is float and type(value) is int)
            _need(value is None or valid_type,
                  "ROOM_RETURN_SETTLE_FIELD_TYPE")
            _need(not (type(value) is str and len(value) > 512), "ROOM_RETURN_SETTLE_VALUE_SIZE")
        assignments = ",".join(f"{key}=%s" for key in fields)
        with self._publisher(context, write=True) as (a, ident, c):
            from actor_service_room_scope import owner_column,qualify,generic
            owner_field,owner_value=owner_column(a)
            if generic(a):
                c.execute('''SELECT * FROM cerebro_room_return_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s
                    AND project_ref=%s AND route_owner_ref=%s AND route_ref=%s AND receiver_ref=%s AND message_id=%s FOR UPDATE''',
                    (a['tenant_ref'],a['workspace_ref'],a['project_ref'],a['owner_ref'],a['route_ref'],a['receiver_ref'],args['message_id']))
                original=_row(c)
                _need(original is not None,'EXACT_SELECTED_ROOM_OBLIGATION_REQUIRED');qualify(c,a,original)
            c.execute("UPDATE cerebro_room_return_d1_outbox SET "+assignments+
              " WHERE tenant_ref=%s AND workspace_ref=%s AND "+owner_field+"=%s AND route_owner_ref=%s"
              " AND route_ref=%s AND receiver_ref=%s AND message_id=%s AND state=%s"
              " AND claim_token IS NOT DISTINCT FROM %s RETURNING *",
              (*fields.values(),a["tenant_ref"],a["workspace_ref"],owner_value,a["owner_ref"],
               a["route_ref"],a["receiver_ref"],args["message_id"],args["from_state"],args["from_token"]))
            row = _row(c)
        return {"won": row is not None, "row": {} if row is None else self._public(row)}


class RoomReturnOutboxHost:
    def __init__(self, store: RoomReturnD1Outbox | tuple[RoomReturnD1Outbox, ...], *, actor_reader=None,admission_provider=None):
        stores = (store,) if type(store) is RoomReturnD1Outbox else store
        _need(type(stores) is tuple and 1 <= len(stores) <= 8
              and all(type(s) is RoomReturnD1Outbox for s in stores), "ROOM_RETURN_STORE_REQUIRED")
        _need(all(s._state is stores[0]._state for s in stores), "ROOM_RETURN_ONE_STATE_PORT_REQUIRED")
        bindings = [s._binding for s in stores if s._binding is not None]
        _need(len(set(bindings)) == len(bindings), "ROOM_RETURN_DUPLICATE_BINDING")
        selectors = [(b.tenant_ref,b.workspace_ref,b.principal_ref,b.consumer_ref,b.session_ref,
                      b.material_sha256,b.envelope_sha256) for b in bindings]
        _need(len(set(selectors)) == len(selectors), "ROOM_RETURN_AMBIGUOUS_PRODUCER_BINDING")
        if actor_reader is not None:
            from room_return_actor_reader import RoomReturnActorReader
            _need(type(actor_reader) is RoomReturnActorReader and actor_reader._state is stores[0]._state,
                  "ROOM_RETURN_ACTOR_READER_REQUIRED")
        self._stores, self._store, self._actor_reader = stores, stores[0], actor_reader
        self._admission_provider=admission_provider

    def _register(self, args, context):
        if self._admission_provider is not None:
            dynamic=self._admission_provider.register(args,context)
            if dynamic is not None:return dynamic
        # Retain singleton refusal/validation semantics. Multiple bindings never
        # accept request-selected actor/task/recipient/route selectors.
        if len(self._stores) == 1:
            return self._store.register(args, context)
        _need(type(args) is dict and set(args) == {"idempotency_key","material","envelope"},
              "ROOM_RETURN_REGISTER_FIELDS")
        _need(type(args['material']) is str and 0 < len(args['material'].encode('utf-8')) <= MAX_MATERIAL
              and type(args['envelope']) is str and 0 < len(args['envelope'].encode('utf-8')) <= 4096,
              "ROOM_RETURN_MATERIAL_SIZE")
        ident = context.identity
        ident.validate()
        session = context.transport_session()
        _need(type(session) is dict, "ROOM_RETURN_CURRENT_SESSION_REQUIRED")
        selector = (ident.tenant_ref,ident.workspace_ref,ident.principal_ref,ident.consumer_ref,
                    session.get('session_ref'),_sha(args['material'].encode('utf-8')),
                    _sha(args['envelope'].encode('utf-8')))
        matches = [s for s in self._stores if s._binding is not None and
                   (s._binding.tenant_ref,s._binding.workspace_ref,s._binding.principal_ref,
                    s._binding.consumer_ref,s._binding.session_ref,s._binding.material_sha256,
                    s._binding.envelope_sha256) == selector]
        _need(len(matches) == 1, "ROOM_RETURN_UNIQUE_PRODUCER_REQUIRED")
        return matches[0].register(args, context)

    def call(self, operation: str, args: dict[str, Any], context: Any) -> dict[str, Any]:
        if operation == 'read_accepted':
            if self._admission_provider is not None:
                dynamic=self._admission_provider.read_accepted(args,context)
                if dynamic is not None:return dynamic
            _need(self._actor_reader is not None, "ROOM_RETURN_ACTOR_READER_NOT_INSTALLED")
            return self._actor_reader.read(args, context)
        methods = {"register": self._register, "read_exact": self._store.read_exact,
                   "list_pending": self._store.list_for_publisher,
                   "list_recovery_candidates": self._store.list_for_publisher,
                   "settle": self._store.settle}
        _need(operation in methods, "ROOM_RETURN_OPERATION_INVALID")
        return methods[operation](args, context)
