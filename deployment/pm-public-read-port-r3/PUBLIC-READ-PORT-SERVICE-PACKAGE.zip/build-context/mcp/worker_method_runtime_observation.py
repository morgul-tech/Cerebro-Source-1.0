"""Bounded read-only installed-file/policy/schema/runtime membrane observation."""
import hashlib,json,os
from pathlib import Path
from worker_method_adoption import need,digest
from control_context_state_postgres import _fetchone,_fetchall
TABLES=('cerebro_worker_method_owner_authorization_revisions','cerebro_worker_method_read_acknowledgments')
def observe(root,connect,request):
    need(type(request)is dict and set(request)=={'paths','policy_fingerprint'},'runtime-observation-fields')
    paths=request['paths'];need(type(paths)is list and len(paths)<=128 and all(type(p)is str and not p.startswith('/')
         and '..' not in p.split('/') for p in paths),'runtime-observation-paths')
    files={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
    raw=os.environ.get('CEREBRO_WORKER_METHOD_OWNER_JSON','')
    need(bool(raw) and digest(json.loads(raw))==request['policy_fingerprint'],'actual-runtime-policy-mismatch')
    runtime=os.environ.get('CEREBRO_RUNTIME_DB_USER','');need(bool(runtime),'actual-runtime-role-unavailable')
    connection=connect()
    try:
        c=connection.cursor()
        try:
            c.execute('SET TRANSACTION READ ONLY')
            c.execute("SET LOCAL statement_timeout='5s'")
            c.execute('SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname=%s',(runtime,))
            flags=_fetchone(c);need(flags is not None and flags['rolsuper']is False and flags['rolbypassrls']is False,'runtime-role-membrane')
            c.execute('SELECT migration_id,schema_version,checksum_sha256 FROM cerebro_schema_migrations ORDER BY migration_id');ledger=_fetchall(c)
            expected=json.loads((root/'tooling/context/control_context_postgres_migrations.json').read_bytes())['migrations']
            need(ledger==[{k:m[k] for k in ('migration_id','schema_version','checksum_sha256')} for m in expected],'actual-schema-ledger-not-exact')
            for table in TABLES:
                c.execute("SELECT relrowsecurity,relforcerowsecurity,pg_has_role(%s,relowner,'MEMBER') AS owner_member FROM pg_class WHERE oid=%s::regclass",(runtime,'public.'+table))
                row=_fetchone(c);need(row and row['relrowsecurity']is True and row['relforcerowsecurity']is True and row['owner_member']is False,'actual-ledger-RLS-owner-membrane')
                forbidden='UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER'+(',INSERT' if table.endswith('revisions') else '')
                c.execute("SELECT has_table_privilege(%s,%s,'SELECT') AND NOT has_table_privilege(%s,%s,%s) AS permitted",(runtime,'public.'+table,runtime,'public.'+table,forbidden))
                need(_fetchone(c)['permitted']is True,'runtime-ledger-mutation-widened')
                if table.endswith('acknowledgments'):
                    c.execute("SELECT has_table_privilege(%s,%s,'INSERT') AS permitted",(runtime,'public.'+table))
                    need(_fetchone(c)['permitted']is True,'runtime-own-ack-insert-unavailable')
                c.execute("SELECT count(*) AS n FROM pg_trigger WHERE tgrelid=%s::regclass AND NOT tgisinternal AND tgenabled='O' AND tgname='cerebro_worker_method_append_only'",('public.'+table,))
                need(_fetchone(c)['n']==1,'actual-append-only-trigger-unavailable')
        finally:c.close();connection.rollback()
    finally:connection.close()
    pid1={}
    status=Path('/proc/1/status')
    if status.exists():pid1={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in status.read_text().splitlines() if line.startswith(('Uid:','Gid:','Groups:'))}
    return {'result':'READONLY_INSTALLED_RUNTIME_MEMBRANE_PASS','files':files,'policy_fingerprint':request['policy_fingerprint'],
            'schema_ledger_fingerprint':digest(ledger),'runtime_membrane':'ACTUAL_SELECT_ONLY_AUTH_OWN_ACK_INSERT_RLS_APPEND_ONLY',
            'pid1_observed_status_only':pid1,'limits':'Disk/policy/DB observation, not proof of cognition or direct in-process module attestation'}
