"""Protected same-Context owner publication and own-caller reading evidence.

No configuration means OFF. Configuration is host policy, never a tool input.
Acknowledgment proves an authenticated statement and byte mapping, not cognition.
"""
from __future__ import annotations
import base64, copy, hashlib, json, math, re, time
from contextlib import contextmanager
from types import SimpleNamespace
from worker_method_adoption import (IDENTITY, ADVANCE_POLICY, ROLE_CONTRACT_PATHS,
    digest, need, WorkerMethodAdoptionError, verify_delta)
from control_context_state_postgres import PostgresControlContextStatePort, _fetchone, _json_value

AUTH_TABLE = 'cerebro_worker_method_owner_authorization_revisions'
ACK_TABLE = 'cerebro_worker_method_read_acknowledgments'
KEY_FIELDS = (*IDENTITY, 'generation_ref')

def caller(context):
    context.identity.validate()
    need(type(context.identity.authenticated_client_ref)is str and bool(context.identity.authenticated_client_ref),
         'method-owner-issuer-verified-client-required')
    return {**{k:getattr(context.identity,k) for k in IDENTITY[:-1]},
            'session_ref':context.session_ref()}

def configuration(value, standing_grant):
    if value is None:return None
    need(type(value)is dict and set(value)=={'schema','enabled','generation_bindings'},
         'method-owner-configuration-fields')
    need(value['schema']=='cerebro-worker-method-owner-host/v1' and value['enabled']is True,
         'method-owner-configuration-disabled')
    need(type(standing_grant)is dict,'method-owner-existing-owner-identity-required')
    need(type(value['generation_bindings'])is list and bool(value['generation_bindings']),
         'method-owner-own-generation-bindings-required')
    seen=set()
    for b in value['generation_bindings']:
        need(type(b)is dict and set(b)=={'generation_ref','identity','birth_fingerprint','birth_receipt_fingerprint','provenance','client_ref'},
             'method-owner-generation-binding-fields')
        need(type(b['identity'])is dict and set(b['identity'])==set(IDENTITY)
             and all(type(v)is str and v for v in b['identity'].values()),'method-owner-generation-identity')
        need(b['identity']['tenant_ref']==standing_grant.get('tenant_ref') and b['identity']['workspace_ref']==standing_grant.get('workspace_ref')
             and b['identity']['principal_ref']==standing_grant.get('issuer_principal_ref'),
             'method-owner-generation-workspace')
        need(type(b['generation_ref'])is str and b['generation_ref'] not in seen,'method-owner-duplicate-binding')
        seen.add(b['generation_ref'])
        need(type(b['client_ref'])is str and bool(b['client_ref']),
             'method-owner-authenticated-worker-client-required')
        need(all(type(b[k])is str and re.fullmatch('[0-9a-f]{64}',b[k]) for k in ('birth_fingerprint','birth_receipt_fingerprint'))
             and type(b['provenance'])is str and bool(b['provenance'].strip()),'method-owner-birth-provenance-required')
    return copy.deepcopy(value)

def material_evidence(value):
    need(type(value)is dict and set(value)=={'reviewer','review_note','materials'},'method-owner-material-fields')
    need(all(type(value[k])is str and 0<len(value[k].strip())<=8192 for k in ('reviewer','review_note')),
         'method-owner-actual-review-required')
    need(type(value['materials'])is list and len(value['materials'])==2,'method-owner-two-originals-required')
    kinds=set()
    for m in value['materials']:
        need(type(m)is dict and set(m)=={'kind','provenance','bytes_b64','sha256','bytes'},'method-owner-original-fields')
        need(type(m['provenance'])is str and bool(m['provenance'].strip()),'method-owner-original-provenance')
        try:raw=base64.b64decode(m['bytes_b64'],validate=True)
        except Exception as e:raise WorkerMethodAdoptionError('method-owner-original-encoding') from e
        need(0<len(raw)<=262144 and type(m['bytes'])is int and len(raw)==m['bytes']
             and hashlib.sha256(raw).hexdigest()==m['sha256'],'method-owner-original-bytes-mismatch')
        kinds.add(m['kind'])
    need(kinds=={'PRESERVED_HUMAN_ORDER','P23_OWNER_DESIGN_DISPOSITION'},'method-owner-original-kind')
    return copy.deepcopy(value)

class PostgresWorkerMethodOwner:
    def __init__(self, connection_factory, policy, standing_grant, *, fetch=None, clock=time.time):
        self.policy=configuration(policy,standing_grant)
        need(self.policy is not None,'WORKER_METHOD_OWNER_NOT_CONFIGURED')
        self.port=PostgresControlContextStatePort(connection_factory)
        self.clock=clock
        if fetch is None:
            from boot_birth_source import _http_get
            fetch=_http_get
        self.fetch=fetch

    def _binding(self, who, generation_ref, birth=None, client_ref=None):
        b=next((b for b in self.policy['generation_bindings'] if b['generation_ref']==generation_ref),None)
        need(b is not None and b['identity']==who,'method-owner-own-generation-caller-unbound')
        if client_ref is not None:need(client_ref==b['client_ref'],'method-owner-own-client-mismatch')
        if birth is not None:
            need(birth['generation_ref']==generation_ref and birth['tenant_ref']==who['tenant_ref']
                 and birth['workspace_ref']==who['workspace_ref'],'method-owner-generation-state-mismatch')
            a=birth.get('worker_method_adoption')
            need(b['birth_fingerprint']==(a['birth_fingerprint'] if a else birth['fingerprint'])
                 and b['birth_receipt_fingerprint']==birth['ready_unbound_receipt']['receipt_fingerprint'],
                 'method-owner-original-birth-binding-mismatch')
        return b

    def qualify_caller(self,context,birth):
        self._binding(caller(context),birth['generation_ref'],birth,context.identity.authenticated_client_ref)

    def publish(self,*args,**kwargs):
        raise WorkerMethodAdoptionError('method-owner-privileged-operator-only')

    def revoke(self,*args,**kwargs):
        raise WorkerMethodAdoptionError('method-owner-privileged-operator-only')

    @contextmanager
    def _transaction(self,who):
        with self.port._transaction(tenant_ref=who['tenant_ref'],workspace_ref=who['workspace_ref'],
                principal_ref=who['principal_ref'],passthrough_errors=(WorkerMethodAdoptionError,),worker_method_commit=True) as c:
            c.execute('SET LOCAL search_path = public')
            c.execute("SELECT set_config('cerebro.consumer_ref', %s, true)",(who['consumer_ref'],))
            c.execute("SELECT set_config('cerebro.session_ref', %s, true)",(who['session_ref'],))
            yield c

    def _lock(self,c,who,gen):
        key=tuple(who[k] for k in IDENTITY)+(gen,)
        c.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))',
                  ('worker-method-owner:'+json.dumps(key,separators=(',',':')),))

    def _latest(self,c,who,gen):
        c.execute('SELECT record_payload FROM '+AUTH_TABLE+' WHERE '+
            ' AND '.join(k+'=%s' for k in KEY_FIELDS)+' ORDER BY revision DESC LIMIT 1',
            tuple(who[k] for k in IDENTITY)+(gen,))
        row=_fetchone(c)
        return _json_value(row['record_payload'],field='worker-method-owner') if row else None

    def _ack(self,c,who,gen,ref):
        c.execute('SELECT acknowledgment_payload FROM '+ACK_TABLE+' WHERE '+
            ' AND '.join(k+'=%s' for k in KEY_FIELDS)+' AND acknowledgment_ref=%s',
            tuple(who[k] for k in IDENTITY)+(gen,ref))
        row=_fetchone(c)
        need(row is not None,'method-owner-own-reading-evidence-missing')
        a=_json_value(row['acknowledgment_payload'],field='worker-method-ack')
        subject=copy.deepcopy(a);fp=subject.pop('fingerprint',None)
        need(fp==digest(subject) and a['identity']==who and a['generation_ref']==gen,
             'method-owner-reading-evidence-corrupt')
        return a

    def acknowledge(self,args,context,birth):
        fields={'generation_ref','expected_revision','source_revision','expected_files',
                'expected_role_contracts','method_version','delta_fingerprint','changed_next_action'}
        need(type(args)is dict and set(args)==fields,'method-reading-exact-fields-required')
        who=caller(context);self._binding(who,args['generation_ref'],birth,context.identity.authenticated_client_ref)
        need('project_state:transition' in context.identity.state_scopes,'method-reading-transition-scope-required')
        need(birth['lifecycle']=='READY_UNBOUND' and birth['revision']==args['expected_revision'],
             'method-reading-stale-generation')
        delta=verify_delta(birth,args['source_revision'],self.fetch,args['expected_files'],args['expected_role_contracts'])
        need(args['method_version']==delta['verified_source']['method_version']
             and args['delta_fingerprint']==delta['delta_fingerprint'],'method-reading-version-delta-mismatch')
        need(type(args['changed_next_action'])is str and 1<=len(args['changed_next_action'].strip())<=8192,
             'method-reading-changed-action-required')
        a={'schema':'cerebro-worker-own-method-acknowledgment/v1','identity':who,
           'generation_ref':birth['generation_ref'],'expected_revision':birth['revision'],
           'state_fingerprint':birth['fingerprint'],
           'birth_receipt_fingerprint':birth['ready_unbound_receipt']['receipt_fingerprint'],
           'old_source':delta['old_source'],'new_source':delta['new_source'],
           'delta_fingerprint':delta['delta_fingerprint'],'files':delta['files'],
           'role_contracts':delta['role_contracts'],'method_version':args['method_version'],
           'changed_next_action':args['changed_next_action'],'statement_only_not_cognition_proof':True,
           'authenticated_client_ref':context.identity.authenticated_client_ref,
           'session_assurance':'REQUEST_METADATA_UNATTESTED_OWNER_ATTRIBUTED',
           'actor_binding_provenance':self._binding(who,args['generation_ref'])['provenance']}
        ref='METHOD-READ-'+digest(a);a['acknowledgment_ref']=ref;a['fingerprint']=digest(a)
        with self._transaction(who) as c:
            self._lock(c,who,birth['generation_ref'])
            c.execute('INSERT INTO '+ACK_TABLE+' ('+','.join(KEY_FIELDS)+',acknowledgment_ref,acknowledgment_payload) VALUES ('+
                ','.join(['%s']*7)+',%s::jsonb) ON CONFLICT DO NOTHING',
                tuple(who[k] for k in IDENTITY)+(birth['generation_ref'],ref,json.dumps(a)))
            need(self._ack(c,who,birth['generation_ref'],ref)==a,'method-reading-write-readback-mismatch')
        # Distinct postcommit read: failure/connection ambiguity must never trigger blind repetition.
        try:
            with self._transaction(who) as c:need(self._ack(c,who,birth['generation_ref'],ref)==a,'method-reading-postcommit-mismatch')
        except Exception:
            return {'result':'COMMITTED_READBACK_UNKNOWN','acknowledgment_ref':ref}
        return a

    def publish_operator(self,args,permit,read_birth,*,preview=False):
        need(type(args)is dict and set(args)=={'generation_ref','read_evidence_ref','expected_owner_revision',
             'destination_ref','not_before','expires_at','decision_material'},'method-owner-publication-fields')
        from worker_method_operator_custody import require_operator_permit
        publisher=require_operator_permit(permit)
        gen=args['generation_ref']
        b=next((b for b in self.policy['generation_bindings'] if b['generation_ref']==gen),None)
        need(b is not None,'method-owner-generation-not-configured')
        who=copy.deepcopy(b['identity']);birth=read_birth(who,gen);self._binding(who,gen,birth)
        materials=material_evidence(args['decision_material'])
        need(args['destination_ref']=='P55_CONDUCTOR','method-owner-destination-not-selected')
        now=self.clock()
        need(all(type(args[k])in (int,float) and math.isfinite(args[k]) for k in ('not_before','expires_at'))
             and args['not_before']<=now<args['expires_at'],'method-owner-finite-current-interval-required')
        with self._transaction(who) as c:
            self._lock(c,who,gen);prior=self._latest(c,who,gen)
            need(type(args['expected_owner_revision'])is int and args['expected_owner_revision']==(prior['revision'] if prior else 0),
                 'method-owner-publication-CAS-conflict')
            ack=self._ack(c,who,gen,args['read_evidence_ref'])
            need(ack['authenticated_client_ref']==b['client_ref']
                 and ack['session_assurance']=='REQUEST_METADATA_UNATTESTED_OWNER_ATTRIBUTED'
                 and ack['expected_revision']==birth['revision'] and ack['state_fingerprint']==birth['fingerprint']
                 and ack['birth_receipt_fingerprint']==b['birth_receipt_fingerprint'],'method-owner-stale-own-reading')
            delta=verify_delta(birth,ack['new_source'],self.fetch,ack['files'],ack['role_contracts'])
            auth={'schema':'cerebro-worker-method-owner-authorization/v1',
                'authorization_ref':'METHOD-OWNER-'+digest({'ack':ack['fingerprint'],'material':materials,'publisher':publisher}),
                'revision':args['expected_owner_revision']+1,'scope':'WORKER_METHOD_ADOPTION_EXACT_DELTA',
                'identity':who,'generation_ref':gen,'expected_revision':birth['revision'],
                'destination_ref':args['destination_ref'],'birth_fingerprint':birth['fingerprint'],
                'birth_receipt_fingerprint':b['birth_receipt_fingerprint'],
                'old_source':delta['old_source'],'new_source':delta['new_source'],
                'delta_fingerprint':delta['delta_fingerprint'],'read_evidence_ref':args['read_evidence_ref'],
                'read_material_fingerprint':digest(delta['files']['new']),'same_birth_caller_verified':True,
                'current':True,'revoked':False,'not_before':args['not_before'],'expires_at':args['expires_at'],
                'source_advance_policy':ADVANCE_POLICY,'role_contract_fingerprint':digest(delta['role_contracts'])}
            record={'revision':auth['revision'],'authorization':auth,'expected_files':delta['files'],
                    'expected_role_contracts':delta['role_contracts'],'publisher':publisher,
                    'decision_material':materials,'acknowledgment_fingerprint':ack['fingerprint']}
            from worker_method_operator_custody import guard_operator
            guard_operator(c,permit)
            if preview:return {'result':'EXACT_RECORD_PREVIEW_NO_WRITE','record_fingerprint':digest(record),'revision':record['revision']}
            self._append(c,who,gen,record)
            guard_operator(c,permit)
        return self._postcommit(who,gen,record)

    def _append(self,c,who,gen,record):
        c.execute('INSERT INTO '+AUTH_TABLE+' ('+','.join(KEY_FIELDS)+',revision,record_payload) VALUES ('+
            ','.join(['%s']*7)+',%s::jsonb)',tuple(who[k] for k in IDENTITY)+(gen,record['revision'],json.dumps(record)))
        need(c.rowcount==1,'method-owner-append-unproven')

    def _postcommit(self,who,gen,record):
        try:
            with self._transaction(who) as c:actual=self._latest(c,who,gen)
        except Exception:
            return {'result':'COMMITTED_READBACK_UNKNOWN','revision':record['revision']}
        return {'result':'COMMITTED_READBACK_PASS' if actual==record else 'COMMITTED_READBACK_CHANGED',
                'revision':record['revision'],'authorization_ref':record['authorization']['authorization_ref']}

    def revoke_operator(self,args,permit,*,preview=False):
        need(type(args)is dict and set(args)=={'generation_ref','expected_owner_revision','reason'},'method-owner-revocation-fields')
        from worker_method_operator_custody import require_operator_permit
        publisher=require_operator_permit(permit)
        b=next((b for b in self.policy['generation_bindings'] if b['generation_ref']==args['generation_ref']),None)
        need(b is not None,'method-owner-generation-not-configured')
        who=b['identity'];gen=b['generation_ref']
        need(type(args['reason'])is str and 0<len(args['reason'].strip())<=8192,'method-owner-revocation-reason')
        with self._transaction(who) as c:
            self._lock(c,who,gen);prior=self._latest(c,who,gen)
            need(prior is not None and type(args['expected_owner_revision'])is int
                 and args['expected_owner_revision']==prior['revision'],'method-owner-revocation-CAS-conflict')
            record=copy.deepcopy(prior);record['revision']+=1
            record['authorization'].update(revision=record['revision'],current=False,revoked=True)
            record['revocation']={'publisher':publisher,'reason':args['reason']}
            from worker_method_operator_custody import guard_operator
            guard_operator(c,permit)
            if preview:return {'result':'EXACT_RECORD_PREVIEW_NO_WRITE','record_fingerprint':digest(record),'revision':record['revision']}
            self._append(c,who,gen,record)
            guard_operator(c,permit)
        return self._postcommit(who,gen,record)

    @contextmanager
    def hold(self,*,identity,generation_ref):
        self._binding(identity,generation_ref)
        # This connection holds only policy lock, never the generation CAS row.
        with self._transaction(identity) as c:
            self._lock(c,identity,generation_ref)
            record=self._latest(c,identity,generation_ref)
            need(record is not None,'WORKER_METHOD_ADOPTION_NOT_ISSUED')
            def check():
                now=self.clock();current=self._latest(c,identity,generation_ref)
                need(current==record,'method-owner-latest-revision-changed')
                a=current['authorization']
                need(a['current']is True and a['revoked']is False and a['not_before']<=now<a['expires_at'],
                     'method-owner-revoked-or-expired')
                ack=self._ack(c,identity,generation_ref,a['read_evidence_ref'])
                need(ack['fingerprint']==record['acknowledgment_fingerprint']
                     and ack['authenticated_client_ref']==self._binding(identity,generation_ref)['client_ref']
                     and ack['session_assurance']=='REQUEST_METADATA_UNATTESTED_OWNER_ATTRIBUTED'
                     and ack['delta_fingerprint']==a['delta_fingerprint']
                     and ack['files']==record['expected_files']
                     and ack['role_contracts']==record['expected_role_contracts']
                     and ack['birth_receipt_fingerprint']==a['birth_receipt_fingerprint'],
                     'method-owner-reading-not-matched')
                return copy.deepcopy(a)
            check()
            yield SimpleNamespace(expected_files=copy.deepcopy(record['expected_files']),
                expected_role_contracts=copy.deepcopy(record['expected_role_contracts']),check_current=check)
