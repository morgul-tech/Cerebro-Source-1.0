"""Request-scoped X9 consumer over the reviewed PR85 PostgreSQL custody port."""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from typing import Any, Mapping

from adapters.x9_channel_ingress import CHANNEL, PMOwnerCut, PointerRecord, X9ChannelIngress
from pm_owner_atomic import PmOwnerAssignment, PostgresPmOwner, _row
from providers.x9_postgres_custody import PostgresX9SessionAPI
from providers.x9_role_binding import (
    ProviderSessionTuple, RoleAssignment, TrustedCustodyConfiguration,
)
from providers.x9_session_channel import X9SessionChannelPort


class X9ReceiverError(ValueError):
    pass


def _need(condition: bool, code: str) -> None:
    if not condition:
        raise X9ReceiverError(code)


def configuration_from_mapping(value: Mapping[str, Any]) -> TrustedCustodyConfiguration:
    """Decode one explicit host-owned role assignment, never a request field."""
    _need(isinstance(value, Mapping) and set(value) == {"config_ref", "channel", "producer", "receiver"},
          "X9_HOST_CONFIG_EXACT_FIELDS_REQUIRED")
    roles = {}
    for role in ("producer", "receiver"):
        item = value[role]
        _need(isinstance(item, Mapping) and set(item) == {"role", "assignment_ref", "source_ref", "identity"},
              "X9_HOST_ROLE_EXACT_FIELDS_REQUIRED")
        identity = item["identity"]
        _need(isinstance(identity, Mapping)
              and set(identity) == set(ProviderSessionTuple.__dataclass_fields__),
              "X9_HOST_IDENTITY_EXACT_FIELDS_REQUIRED")
        roles[role] = RoleAssignment(role=item["role"], assignment_ref=item["assignment_ref"],
                                     source_ref=item["source_ref"],
                                     identity=ProviderSessionTuple(**identity))
    config = TrustedCustodyConfiguration(config_ref=value["config_ref"],
                                         channel=value["channel"],
                                         producer=roles["producer"], receiver=roles["receiver"])
    try:
        config.validate()
    except (TypeError, ValueError) as exc:
        raise X9ReceiverError("X9_HOST_CONFIG_INVALID") from exc
    return config


class _FixedConfigurationPort:
    def __init__(self, value: TrustedCustodyConfiguration):
        self._value = value

    def read_configuration(self, channel: str) -> TrustedCustodyConfiguration:
        _need(channel == CHANNEL, "X9_CHANNEL_MISMATCH")
        return self._value


_LEGACY_PM_ACTIVE_HOLD = {
    "sender_use": "AFTER_OWNER_RECEIPT_READBACK",
    "x9_consume": "NOT_YET_CLAIMED",
}


def _receiver_active_hold(value: Any) -> Any:
    # This immutable PM owner receipt predates the canonical active-hold schema.
    # Only its exact transition marker means that no active hold was asserted.
    return None if type(value) is dict and value == _LEGACY_PM_ACTIVE_HOLD else value


class _ScopedPmOwnerReader:
    """Read only the pointer's current PM referent as the authenticated X9 receiver."""

    def __init__(self, api: PostgresX9SessionAPI, config: TrustedCustodyConfiguration,
                 owner: PmOwnerAssignment):
        self._api, self._config, self._owner = api, config, owner

    def read_current_for_pointer(self, pointer: PointerRecord) -> PMOwnerCut:
        producer = self._config.producer.identity
        owner = self._owner
        _need((owner.tenant_ref, owner.workspace_ref, owner.project_ref, owner.principal_ref,
               owner.consumer_ref, owner.session_ref) ==
              (producer.tenant_ref, producer.workspace_ref, producer.project_ref,
               producer.principal_ref, producer.consumer_ref, producer.session_ref),
              "X9_PM_PRODUCER_POLICY_MISMATCH")
        _need(pointer.referent_id is not None and pointer.owner_seq is not None
              and pointer.owner_ref == owner.owner_ref
              and pointer.producer_id == producer.principal_ref,
              "X9_PM_POINTER_POLICY_MISMATCH")
        with self._api._transaction(write=False) as (cursor, identity, _session, _config, binding):
            _need(binding.role == "receiver" and identity.principal_ref == self._config.receiver.identity.principal_ref,
                  "X9_RECEIVER_READ_AUTHORIZATION_REQUIRED")
            cursor.execute("""SELECT receipt_ref FROM cerebro_pm_owner_current
                WHERE tenant_ref=%s AND workspace_ref=%s AND owner_ref=%s AND referent_id=%s
                FOR SHARE""", (owner.tenant_ref, owner.workspace_ref, owner.owner_ref, pointer.referent_id))
            current = _row(cursor)
            _need(current is not None, "X9_PM_CURRENT_REFERENT_MISSING")
            cursor.execute("""SELECT record_payload,snapshot_sha256,projection_payload
                FROM cerebro_pm_owner_receipts WHERE tenant_ref=%s AND workspace_ref=%s
                AND project_ref=%s AND owner_ref=%s AND referent_id=%s AND receipt_ref=%s""",
                (owner.tenant_ref, owner.workspace_ref, owner.project_ref, owner.owner_ref,
                 pointer.referent_id, current["receipt_ref"]))
            first = _row(cursor)
            _need(first is not None, "X9_PM_RECEIPT_MISSING")
            record = PostgresPmOwner._record(first)
            projection = first["projection_payload"]
            if isinstance(projection, str):
                projection = json.loads(projection)
            _need(isinstance(projection, dict), "X9_PM_PROJECTION_INVALID")
            # Independent immutable receipt readback in the same current-row lock.
            cursor.execute("""SELECT record_payload,snapshot_sha256,projection_payload
                FROM cerebro_pm_owner_receipts WHERE tenant_ref=%s AND workspace_ref=%s
                AND project_ref=%s AND owner_ref=%s AND referent_id=%s AND receipt_ref=%s""",
                (owner.tenant_ref, owner.workspace_ref, owner.project_ref, owner.owner_ref,
                 pointer.referent_id, current["receipt_ref"]))
            second = _row(cursor)
            _need(second is not None and PostgresPmOwner._record(second) == record
                  and second["projection_payload"] == first["projection_payload"],
                  "X9_PM_READBACK_MISMATCH")
        _need(record.get("owner_ref") == owner.owner_ref and record.get("referent_id") == pointer.referent_id
              and record.get("receipt_ref") == current["receipt_ref"]
              and isinstance(record.get("owner_seq"), int)
              and isinstance(projection.get("material_sha256"), str)
              and isinstance(projection.get("source_cut"), str),
              "X9_PM_OWNER_SNAPSHOT_INVALID")
        relation = ("SAME" if record["owner_seq"] == pointer.owner_seq
                    else "SUPERSEDED" if record["owner_seq"] > pointer.owner_seq else "UNKNOWN")
        return PMOwnerCut(owner_ref=record["owner_ref"], claim_ref=record["claim_ref"],
                          packet_ref=record["packet_ref"], packet_sha256=record["packet_sha256"],
                          queue_ref=record["queue_ref"], revision=record["revision_after"],
                          relation_to_hint=relation, material_sha256=projection["material_sha256"],
                          source_cut=projection["source_cut"], committed_readback=True,
                          authenticated=True, material_ready=record["ready_state"] == "MATERIAL_READY",
                          active_hold=_receiver_active_hold(projection.get("active_hold")))


class X9ReceiverHost:
    """An actual MCP consumer call with X9's own current authenticated session."""

    def __init__(self, *, config: TrustedCustodyConfiguration, authenticator: Any,
                 connection_factory: Any, pm_owner_assignment: PmOwnerAssignment | None = None):
        _need(isinstance(config, TrustedCustodyConfiguration), "X9_CONFIG_REQUIRED")
        config.validate()
        _need(callable(connection_factory), "X9_CONNECTION_FACTORY_REQUIRED")
        self._config = config
        self._authenticator = authenticator
        self._connection_factory = connection_factory
        self._config_port = _FixedConfigurationPort(config)
        self._pm_owner_assignment = pm_owner_assignment

    def _channel(self, context: Any, *, required_scope: str = "project_state:read") -> tuple[X9SessionChannelPort, PostgresX9SessionAPI]:
        identity = context.identity
        identity.validate()
        expected = self._config.receiver.identity
        transport = context.transport_session()
        _need(transport is not None and transport["session_ref"] == expected.session_ref,
              "X9_CURRENT_RECEIVER_SESSION_REQUIRED")
        _need((identity.tenant_ref, identity.workspace_ref, identity.principal_ref, identity.consumer_ref)
              == (expected.tenant_ref, expected.workspace_ref, expected.principal_ref, expected.consumer_ref),
              "X9_RECEIVER_IDENTITY_MISMATCH")
        _need(isinstance(context.private_headers, Mapping), "X9_PRIVATE_HEADERS_REQUIRED")
        api = PostgresX9SessionAPI(
            authenticator=self._authenticator,
            header_provider=lambda: context.private_headers,
            connection_factory=self._connection_factory,
            configuration_provider=self._config_port,
            enabled=True, role="receiver", required_scope=required_scope,
        )
        return X9SessionChannelPort(api=api, enabled=True), api

    def read_pointer(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        _need(set(args) == {"event_id"} and isinstance(args["event_id"], str),
              "X9_READ_EVENT_ID_REQUIRED")
        channel, _api = self._channel(context)
        readback = channel.read_pointer_by_event_id(args["event_id"])
        if readback is None:
            return {"state": "ABSENT_OR_UNVERIFIED", "event_id": args["event_id"]}
        return {"state": "POINTER_READBACK", "event_id": args["event_id"],
                "record": asdict(readback.record), "content_sha256": readback.content_sha256,
                "revision_token": readback.revision_token}

    def observe_signalvev_notice(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        """X9 read-only pointer plus fresh current PM cut; no disposition/consume."""
        _need(set(args) == {"event_id"} and isinstance(args["event_id"], str),
              "X9_SIGNALVEV_EVENT_ID_REQUIRED")
        _need(self._pm_owner_assignment is not None, "X9_PM_OWNER_POLICY_REQUIRED")
        channel, api = self._channel(context, required_scope="project_state:read")
        readback = channel.read_pointer_by_event_id(args["event_id"])
        if readback is None:
            return {"schema": "cerebro-signalvev-notice-observation/v1",
                    "state": "ABSENT_OR_UNVERIFIED", "event_id": args["event_id"]}
        cut = _ScopedPmOwnerReader(api, self._config, self._pm_owner_assignment).read_current_for_pointer(
            readback.record)
        return {"schema": "cerebro-signalvev-notice-observation/v1",
                "state": "CURRENT_READBACK", "event_id": args["event_id"],
                "pointer": asdict(readback.record), "pointer_sha256": readback.content_sha256,
                "pm_current_cut": asdict(cut)}

    def consume(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        _need(set(args) == {"event_id"} and isinstance(args["event_id"], str),
              "X9_CONSUME_EVENT_ID_REQUIRED")
        _need(self._pm_owner_assignment is not None, "X9_PM_OWNER_POLICY_REQUIRED")
        channel, api = self._channel(context, required_scope="project_state:transition")
        ingress = X9ChannelIngress(
            enabled=True, channel=channel,
            pm_hint_reader=_ScopedPmOwnerReader(api, self._config, self._pm_owner_assignment),
            producer_principal=self._config.producer.identity.principal_ref,
            x9_principal=self._config.receiver.identity.principal_ref,
            x9_session_ref=self._config.receiver.identity.session_ref)
        result = ingress.consume(args["event_id"], now=datetime.now(timezone.utc))
        value = {"state": result.state, "reason": result.reason, "event_id": args["event_id"]}
        if result.pointer_sha256 is not None:
            value["pointer_sha256"] = result.pointer_sha256
        if result.disposition is not None:
            value["disposition"] = asdict(result.disposition)
        return value
