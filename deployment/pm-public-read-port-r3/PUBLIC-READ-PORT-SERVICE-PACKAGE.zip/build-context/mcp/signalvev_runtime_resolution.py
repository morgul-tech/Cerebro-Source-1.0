"""Fail-closed, read-only Signalvev transport resolution for a bound local runtime.

The host must supply a separately authorized custody reader.  A request never
supplies an identity, pointer hash, role, session or provider configuration.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from typing import Any, Callable, Mapping

from adapters.x9_channel_ingress import CHANNEL, SCHEMA as POINTER_SCHEMA, PMOwnerCut, PointerRecord, Readback
from pm_owner_atomic import PmOwnerAssignment, PmOwnerError, PostgresPmOwner, _row
from providers.x9_role_binding import TrustedCustodyConfiguration

SCHEMA = "cerebro-signalvev-transport-resolution/v1"


class RuntimeResolutionError(ValueError):
    pass


@dataclass(frozen=True)
class RuntimeBinding:
    tenant_ref: str
    workspace_ref: str
    project_ref: str
    principal_ref: str
    session_ref: str = ""
    consumer_ref: str = "LOCAL_CEREBRO_RUNTIME"


class RuntimeResolutionHost:
    """Host-bound existing PostgreSQL reader; deliberately has no write method."""

    def __init__(self, *, binding: RuntimeBinding,
                 reader: PostgresRuntimeNoticeReader, enabled: bool = False):
        if not isinstance(binding, RuntimeBinding) or not all(
            isinstance(getattr(binding, key), str) and getattr(binding, key)
            for key in ("tenant_ref", "workspace_ref", "project_ref", "principal_ref", "session_ref")
        ) or binding.consumer_ref != "LOCAL_CEREBRO_RUNTIME" or \
                not isinstance(reader, PostgresRuntimeNoticeReader) or reader._binding != binding:
            raise RuntimeResolutionError("RUNTIME_HOST_BINDING_REQUIRED")
        self._binding, self._reader, self._enabled = binding, reader, enabled is True

    def resolve(self, args: Mapping[str, Any], identity: Any) -> dict[str, Any]:
        if not self._enabled:
            raise RuntimeResolutionError("RUNTIME_RESOLUTION_DISABLED")
        if not isinstance(args, Mapping) or set(args) != {"event_id"} or not isinstance(args["event_id"], str) or not args["event_id"].startswith("pm-event:"):
            raise RuntimeResolutionError("EVENT_ID_ONLY_REQUIRED")
        expected = self._binding
        if any(getattr(identity, key, None) != getattr(expected, key) for key in
               ("tenant_ref", "workspace_ref", "principal_ref", "consumer_ref")) or \
                "project_state:read" not in getattr(identity, "state_scopes", frozenset()):
            raise RuntimeResolutionError("SCOPED_RUNTIME_IDENTITY_REQUIRED")
        event_id = args["event_id"]
        try:
            result = self._reader.read_current(event_id)
        except RuntimeResolutionError as exc:
            if str(exc) in {"POINTER_CUSTODY_MISMATCH", "POINTER_ORIGINAL_RECEIPT_MISSING",
                            "POINTER_ORIGINAL_RECEIPT_MISMATCH", "POINTER_OWNER_MISMATCH",
                            "POINTER_RECORD_INVALID"}:
                return {"schema": SCHEMA, "state": "UNKNOWN", "event_id": event_id}
            raise
        if result is None:
            return {"schema": SCHEMA, "state": "UNKNOWN", "event_id": event_id}
        pointer_readback, cut = result
        pointer = getattr(pointer_readback, "record", None)
        pointer_sha = getattr(pointer_readback, "content_sha256", None)
        if not isinstance(pointer, PointerRecord) or not isinstance(cut, PMOwnerCut) or \
                pointer.event_id != event_id or pointer.content_sha256 != pointer_sha or \
                not isinstance(pointer_sha, str) or len(pointer_sha) != 64:
            return {"schema": SCHEMA, "state": "UNKNOWN", "event_id": event_id}
        relation = cut.relation_to_hint
        if relation not in {"SAME", "SUPERSEDED"} or not cut.authenticated or not cut.committed_readback:
            return {"schema": SCHEMA, "state": "UNKNOWN", "event_id": event_id}
        if relation == "SAME" and (not cut.material_ready or cut.revision != pointer.revision):
            return {"schema": SCHEMA, "state": "UNKNOWN", "event_id": event_id}
        return {"schema": SCHEMA, "state": relation, "event_id": event_id,
                "pointer": asdict(pointer), "pointer_sha256": pointer_sha,
                "pm_current_cut": asdict(cut)}


class PostgresRuntimeNoticeReader:
    """Service-owned read transaction over existing immutable X9 and PM ledgers.

    The separate X9 runtime SELECT policy is deliberately not installed here.
    Without that approved policy, the pointer query fails closed under RLS.
    """

    def __init__(self, *, binding: RuntimeBinding, pm_owner: PmOwnerAssignment,
                 x9_config: TrustedCustodyConfiguration, connection_factory: Callable[[], Any]):
        if (not isinstance(binding, RuntimeBinding) or not binding.session_ref
                or not isinstance(pm_owner, PmOwnerAssignment)
                or not isinstance(x9_config, TrustedCustodyConfiguration)
                or not callable(connection_factory)):
            raise RuntimeResolutionError("RUNTIME_CUSTODY_CONFIGURATION_REQUIRED")
        x9_config.validate()
        producer = x9_config.producer.identity
        if (binding.tenant_ref, binding.workspace_ref, binding.project_ref) != (
                pm_owner.tenant_ref, pm_owner.workspace_ref, pm_owner.project_ref) or (
                producer.tenant_ref, producer.workspace_ref, producer.project_ref,
                producer.principal_ref, producer.consumer_ref, producer.session_ref) != (
                pm_owner.tenant_ref, pm_owner.workspace_ref, pm_owner.project_ref,
                pm_owner.principal_ref, pm_owner.consumer_ref, pm_owner.session_ref):
            raise RuntimeResolutionError("RUNTIME_PM_X9_POLICY_MISMATCH")
        self._binding, self._pm_owner, self._config = binding, pm_owner, x9_config
        self._connect = connection_factory

    def read_current(self, event_id: str) -> tuple[Readback, PMOwnerCut] | None:
        b, p, cfg = self._binding, self._pm_owner, self._config
        conn = cursor = None
        try:
            conn = self._connect()
            if getattr(conn, "autocommit", False) is not False:
                raise RuntimeResolutionError("TRANSACTIONAL_RUNTIME_CONNECTION_REQUIRED")
            cursor = conn.cursor()
            cursor.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY")
            cursor.execute("SET LOCAL statement_timeout = '3000ms'")
            for key, value in (("tenant_ref", b.tenant_ref), ("workspace_ref", b.workspace_ref),
                               ("project_ref", b.project_ref), ("principal_ref", b.principal_ref),
                               ("consumer_ref", b.consumer_ref), ("session_ref", b.session_ref),
                               ("runtime_notice_read_enabled", "true")):
                cursor.execute("SELECT set_config(%s,%s,true)", ("cerebro." + key, value))
            cursor.execute("""SELECT s.session_binding_id,s.session_revision,s.session_fingerprint,
                       s.project_revision,p.aggregate_revision,p.project_status
                FROM cerebro_control_session_bindings s JOIN cerebro_project_instances p
                  ON (s.tenant_ref,s.workspace_ref,s.project_ref)=(p.tenant_ref,p.workspace_ref,p.project_ref)
                WHERE s.tenant_ref=%s AND s.workspace_ref=%s AND s.project_ref=%s
                  AND s.principal_ref=%s AND s.consumer_ref=%s AND s.session_ref=%s""",
                (b.tenant_ref,b.workspace_ref,b.project_ref,b.principal_ref,b.consumer_ref,b.session_ref))
            session = _row(cursor)
            if (session is None or session["project_status"] != "ACTIVE"
                    or session["project_revision"] != session["aggregate_revision"]
                    or not session["session_binding_id"] or session["session_revision"] < 1
                    or not session["session_fingerprint"]):
                raise RuntimeResolutionError("CURRENT_RUNTIME_SESSION_REQUIRED")
            cursor.execute("""SELECT record_payload,content_sha256,writer_principal,writer_consumer,
                       writer_session,writer_role,writer_assignment_ref,peer_role,peer_assignment_ref,
                       peer_session_ref,config_ref,provider_revision
                FROM cerebro_x9_channel_records WHERE tenant_ref=%s AND workspace_ref=%s
                  AND project_ref=%s AND channel=%s AND record_kind='POINTER' AND event_id=%s""",
                (b.tenant_ref,b.workspace_ref,b.project_ref,CHANNEL,event_id))
            row = _row(cursor)
            if row is None:
                return None
            raw = row["record_payload"]
            if isinstance(raw, str):
                raw = json.loads(raw)
            if not isinstance(raw, dict):
                raise RuntimeResolutionError("POINTER_RECORD_INVALID")
            raw = dict(raw)
            raw["way_home"] = tuple(raw.get("way_home", ()))
            pointer = PointerRecord(**raw)
            producer, receiver = cfg.producer, cfg.receiver
            if (pointer.schema != POINTER_SCHEMA or pointer.event_id != event_id
                    or pointer.content_sha256 != row["content_sha256"]
                    or pointer.producer_id != producer.identity.principal_ref
                    or pointer.receiver_ref != receiver.identity.session_ref
                    or (row["writer_principal"],row["writer_consumer"],row["writer_session"],
                        row["writer_role"],row["writer_assignment_ref"],row["peer_role"],
                        row["peer_assignment_ref"],row["peer_session_ref"],row["config_ref"]) !=
                       (producer.identity.principal_ref,producer.identity.consumer_ref,
                        producer.identity.session_ref,producer.role,producer.assignment_ref,
                        receiver.role,receiver.assignment_ref,receiver.identity.session_ref,cfg.config_ref)
                    or type(row["provider_revision"]) is not int or row["provider_revision"] < 1):
                raise RuntimeResolutionError("POINTER_CUSTODY_MISMATCH")
            cursor.execute("""SELECT record_payload,snapshot_sha256,projection_payload
                FROM cerebro_pm_owner_receipts WHERE tenant_ref=%s AND workspace_ref=%s
                  AND project_ref=%s AND owner_ref=%s AND referent_id=%s
                  AND record_payload->>'commit_ref'=%s""",
                (b.tenant_ref,b.workspace_ref,b.project_ref,p.owner_ref,
                 pointer.referent_id,pointer.attempt_id))
            original_row = _row(cursor)
            if original_row is None or cursor.fetchone() is not None:
                raise RuntimeResolutionError("POINTER_ORIGINAL_RECEIPT_MISSING")
            try:
                original = PostgresPmOwner._record(original_row)
            except PmOwnerError as exc:
                raise RuntimeResolutionError("POINTER_ORIGINAL_RECEIPT_MISMATCH") from None
            original_projection = original_row["projection_payload"]
            if isinstance(original_projection, str):
                original_projection = json.loads(original_projection)
            if (not isinstance(original_projection, dict)
                    or (pointer.event_id,pointer.owner_ref,pointer.referent_id,
                        pointer.revision,pointer.expected_sha256,pointer.claim_ref,
                        pointer.packet_ref,pointer.packet_sha256,pointer.queue_ref,
                        pointer.source_cut,pointer.owner_seq) !=
                       (original.get("event_id"),original.get("owner_ref"),original.get("referent_id"),
                        original.get("revision_after"),original.get("snapshot_sha256"),
                        original.get("claim_ref"),original.get("packet_ref"),
                        original.get("packet_sha256"),original.get("queue_ref"),
                        original_projection.get("source_cut"),original.get("owner_seq"))):
                raise RuntimeResolutionError("POINTER_ORIGINAL_RECEIPT_MISMATCH")
            cursor.execute("""SELECT receipt_ref FROM cerebro_pm_owner_current
                WHERE tenant_ref=%s AND workspace_ref=%s AND owner_ref=%s AND referent_id=%s""",
                (b.tenant_ref,b.workspace_ref,p.owner_ref,pointer.referent_id))
            current = _row(cursor)
            if current is None:
                return None
            cursor.execute("""SELECT record_payload,snapshot_sha256,projection_payload
                FROM cerebro_pm_owner_receipts WHERE tenant_ref=%s AND workspace_ref=%s
                  AND project_ref=%s AND owner_ref=%s AND referent_id=%s AND receipt_ref=%s""",
                (b.tenant_ref,b.workspace_ref,b.project_ref,p.owner_ref,
                 pointer.referent_id,current["receipt_ref"]))
            receipt = _row(cursor)
            if receipt is None:
                return None
            try:
                record = PostgresPmOwner._record(receipt)
            except PmOwnerError as exc:
                raise RuntimeResolutionError("POINTER_OWNER_MISMATCH") from None
            projection = receipt["projection_payload"]
            if isinstance(projection, str):
                projection = json.loads(projection)
            if (not isinstance(projection, dict) or pointer.owner_ref != p.owner_ref
                    or pointer.referent_id != record.get("referent_id")
                    or not isinstance(record.get("owner_seq"), int)):
                raise RuntimeResolutionError("POINTER_OWNER_MISMATCH")
            relation = ("SAME" if record["owner_seq"] == pointer.owner_seq
                        else "SUPERSEDED" if record["owner_seq"] > pointer.owner_seq else "UNKNOWN")
            cut = PMOwnerCut(owner_ref=p.owner_ref,claim_ref=record["claim_ref"],
                packet_ref=record["packet_ref"],packet_sha256=record["packet_sha256"],
                queue_ref=record["queue_ref"],revision=record["revision_after"],
                relation_to_hint=relation,material_sha256=projection["material_sha256"],
                source_cut=projection["source_cut"],committed_readback=True,
                authenticated=True,material_ready=record["ready_state"] == "MATERIAL_READY")
            return (Readback(pointer,pointer.content_sha256,producer.identity.principal_ref,
                             "x9pg:" + str(row["provider_revision"])),cut)
        except RuntimeResolutionError:
            raise
        except Exception as exc:
            raise RuntimeResolutionError("RUNTIME_CUSTODY_READ_UNAVAILABLE") from None
        finally:
            if conn is not None:
                try: conn.rollback()
                except Exception: pass
            for item in (cursor,conn):
                if item is not None:
                    try: item.close()
                    except Exception: pass
