"""Fixed private input installation/status for RouteB; never an arbitrary file API."""
import hashlib,json,os,stat
from pathlib import Path
from worker_method_adoption import need,digest
from worker_method_owner import configuration
from worker_method_operator_custody import INPUT,_privileged_os,private_input,validate_envelope

def actual_host_grant(policy):
    raw=os.environ.get('CEREBRO_STANDING_WORKER_GRANT_JSON','')
    need(bool(raw),'existing-standing-owner-grant-unavailable')
    grant=json.loads(raw)
    configuration(policy,grant)
    need(grant.get('schema')=='cerebro-standing-worker-grant/v1' and grant.get('scope')=='WORKER_ATTACH'
         and grant.get('current')is True and grant.get('revoked')is False,'existing-standing-owner-grant-not-current')
    return grant

def parent_custody():
    need(_privileged_os(),'privileged-operator-os-required')
    if not INPUT.parent.exists():INPUT.parent.mkdir(mode=0o755)
    for p in INPUT.parents:
        st=p.lstat()
        need(stat.S_ISDIR(st.st_mode) and st.st_uid==0 and not st.st_mode&0o022,'operator-parent-custody')

def input_status():
    parent_custody()
    if not INPUT.exists():return {'result':'INPUT_ABSENT','input_sha256':None}
    value=private_input(check_window=False)
    requested=dict(value);requested['standing_owner_identity']=None
    return {'result':'PRIVATE_INPUT_PRESENT','input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
            'operation':value['operation'],'input_fingerprint':digest(value),'requested_input_fingerprint':digest(requested)}

def install(raw,*,transport_sha,previous_sha,package_fp):
    parent_custody()
    need(len(raw)<=1048576 and hashlib.sha256(raw).hexdigest()==transport_sha,'private-input-transport-drift')
    value=json.loads(raw)
    grant=actual_host_grant(value['policy'])
    need(value.get('standing_owner_identity') is None or value['standing_owner_identity']==grant,
         'cannot-replace-existing-host-grant')
    value['standing_owner_identity']=grant
    validate_envelope(value)
    need(value['package_fingerprint']==package_fp,'private-input-package-drift')
    before=input_status();expected=before['input_sha256'] or 'ABSENT'
    need(previous_sha==expected,'private-input-archive-CAS-conflict')
    encoded=json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()+b'\n'
    if before['input_sha256']:
        folder=INPUT.parent/'worker-method-owner-inputs'
        folder.mkdir(mode=0o700,exist_ok=True)
        st=folder.lstat();need(stat.S_ISDIR(st.st_mode) and st.st_uid==0 and stat.S_IMODE(st.st_mode)==0o700,'private-input-archive-custody')
        archive=folder/(before['input_sha256']+'.json')
        old=INPUT.read_bytes()
        if archive.exists():need(archive.read_bytes()==old,'private-input-archive-diverged')
        else:
            fd=os.open(archive,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            with os.fdopen(fd,'wb') as f:f.write(old);f.flush();os.fsync(f.fileno())
    pending=INPUT.parent/('worker-method-owner-pending-'+transport_sha+'.json')
    fd=os.open(pending,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
    # Exact previous-hash CAS again immediately before replacing the fixed path.
    need((hashlib.sha256(INPUT.read_bytes()).hexdigest() if INPUT.exists() else 'ABSENT')==previous_sha,
         'private-input-changed-before-replace')
    os.replace(pending,INPUT)
    private_input()
    return {'result':'PRIVATE_INPUT_INSTALLED','input_sha256':hashlib.sha256(encoded).hexdigest(),
            'previous_input_sha256':before['input_sha256'],'host_grant_fingerprint':digest(grant)}
