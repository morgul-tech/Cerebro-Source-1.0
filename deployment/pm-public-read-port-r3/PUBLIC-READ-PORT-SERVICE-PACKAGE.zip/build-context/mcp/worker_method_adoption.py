"""Exact later WORKER method adoption; birth evidence is never rewritten.

No authority is supplied by this module or by WORKER_ATTACH alone. The host must
bind a current owner reader whose hold() fences revocation through DB commit.
Default host binding is absent/NOT_ISSUED. Test readers are not owner approvals.
"""
from __future__ import annotations
import copy,hashlib,json,time,math
from boot_birth_source import (_method_contract_at_head, _verify_current_method_details,
                               _source_head, COMPARE_URL)

OLD='42c2d064b00c58f3d06b1c4777534311bb03df6c'
NEW='95031069a73944ee82aeab6f77f3ae975d667ab5'
CHANGED=('standards/development/implementation-learning-loop.yaml',
         'tooling/return-bridge/TASK_LOCAL_PROFILE.md')
PROFILE=CHANGED[1]
SCHEMA='cerebro-worker-method-adoption/v1'
ROLE_CONTRACT_PATHS=('engines/context/control-context-state.schema.json','standards/control-context-state-service.yaml','standards/native-substrate.yaml')
ADVANCE_POLICY='UNCHANGED_SELECTED_METHOD_AND_WORKER_CONTRACTS_ONLY'
IDENTITY=('tenant_ref','workspace_ref','principal_ref','consumer_ref','session_ref')

class WorkerMethodAdoptionError(ValueError): pass
class WorkerMethodCommitUnknown(RuntimeError): pass
def need(ok,reason):
    if not ok:raise WorkerMethodAdoptionError(reason)
def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

def _pinned_sha(ref,path,fetch):
    raw=fetch(f'https://raw.githubusercontent.com/morgul-tech/Cerebro-Source-1.0/{ref}/{path}')
    need(type(raw)is bytes and 0<len(raw)<=2000000,'method-adoption-contract-blob-unavailable')
    return hashlib.sha256(raw).hexdigest()

def _ancestry(base,head,fetch):
    if base==head:return
    comparison=json.loads(fetch(f'{COMPARE_URL}/{base}...{head}'))
    need(type(comparison)is dict and comparison.get('status')=='ahead'
         and comparison.get('base_commit',{}).get('sha')==base
         and comparison.get('merge_base_commit',{}).get('sha')==base,
         'method-adoption-not-descendant')

def verify_selected_contract_continuity(fetch,expected_method,expected_role,selected_source=NEW):
    """One bounded current snapshot; no head chase, semantic judge or authority."""
    need(type(expected_role)is dict and set(ROLE_CONTRACT_PATHS).issubset(expected_role)
         and len(expected_role)<=32 and all(type(p)is str and not p.startswith('/') and '..' not in p.split('/')
             and type(h)is str and len(h)==64 and all(c in '0123456789abcdef' for c in h) for p,h in expected_role.items()),
         'method-adoption-selected-role-scope-required')
    head=_source_head(fetch)[0]
    _ancestry(selected_source,head,fetch)
    current,material=_verify_current_method_details(head,fetch)
    role={p:_pinned_sha(head,p,fetch) for p in expected_role}
    need(role==expected_role,'method-adoption-affected-worker-authority-contract-changed')
    method=dict(x.split('|',1) for x in material);method[PROFILE]=_pinned_sha(head,PROFILE,fetch)
    need(method==expected_method,'method-adoption-further-material-readoption-required')
    need(_source_head(fetch)[0]==head,'method-adoption-bounded-currentness-conflict')
    return {'selected_source':selected_source,'observed_current_source':head,
            'current_method_fingerprint':current['method_fingerprint'],
            'selected_contract_fingerprint':digest({'method':expected_method,'role':expected_role}),
            'continuity':'EXACT_SELECTED' if head==selected_source else 'CODE_ONLY_SELECTED_CONTRACTS_UNCHANGED',
            'authority':'NONE_ELIGIBILITY_ONLY'}

def verify_delta(birth,source_revision,fetch,expected_files,expected_role):
    """Exact material adoption edge plus explicitly selected contract continuity."""
    import re
    prior=birth.get('worker_method_adoption')
    if prior:validate_adoption(birth)
    old_source=prior['new_source'] if prior else birth['source_revision']
    need(type(source_revision)is str and re.fullmatch('[0-9a-f]{40}',source_revision)
         and source_revision!=old_source,'method-adoption-distinct-pinned-edge-required')
    need(type(expected_files)is dict and set(expected_files)=={'old','new'},'method-adoption-owner-material-required')
    old_profile,old_material,old_fp=_method_contract_at_head(old_source,fetch)
    need(old_fp==(prior['new_method_fingerprint'] if prior else birth['civilization_method_attestation']['method_fingerprint']),
         'method-adoption-birth-method-drift')
    selected_profile,new_material,new_fp=_method_contract_at_head(source_revision,fetch)
    old=dict(x.split('|',1) for x in old_material);new=dict(x.split('|',1) for x in new_material)
    old[PROFILE]=_pinned_sha(old_source,PROFILE,fetch);new[PROFILE]=_pinned_sha(source_revision,PROFILE,fetch)
    actual={'old':old,'new':new}
    need(actual==expected_files,'method-adoption-material-not-owner-selected')
    need(old!=new,'method-adoption-material-change-required')
    _ancestry(old_source,source_revision,fetch)
    selected_role={p:_pinned_sha(source_revision,p,fetch) for p in expected_role}
    need(selected_role==expected_role,'method-adoption-role-scope-not-owner-selected')
    proof=verify_selected_contract_continuity(fetch,new,selected_role,source_revision)
    # This is the selected admitted method basis, explicitly not a claim NEW is main.
    selected={'source_revision':source_revision,'method_ref':selected_profile['id'],
              'method_version':selected_profile['version'],'method_fingerprint':new_fp}
    return {'old_source':old_source,'new_source':source_revision,'old_method_fingerprint':old_fp,
            'new_method_fingerprint':new_fp,'files':actual,'role_contracts':selected_role,
            'role_contract_fingerprint':digest(selected_role),'current_validation':proof,
            'delta_fingerprint':digest(actual),'verified_source':selected}


def validate_authorization(value,*,identity,birth,read_ref,delta,clock=time.time):
    fields={'schema','authorization_ref','revision','scope','identity','generation_ref',
            'expected_revision','destination_ref','birth_fingerprint','birth_receipt_fingerprint',
            'old_source','new_source','delta_fingerprint','read_evidence_ref',
            'read_material_fingerprint','same_birth_caller_verified','current','revoked',
            'not_before','expires_at','source_advance_policy','role_contract_fingerprint'}
    need(type(value)is dict and set(value)==fields,'method-adoption-authorization-fields')
    need(value['schema']=='cerebro-worker-method-owner-authorization/v1'
         and value['scope']=='WORKER_METHOD_ADOPTION_EXACT_DELTA'
         and value['destination_ref']=='P55_CONDUCTOR','method-adoption-not-issued')
    need(type(value['authorization_ref'])is str and bool(value['authorization_ref'])
         and type(value['revision'])is int and value['revision']>0,'method-adoption-authorization-reference')
    need(value['identity']==identity and set(identity)==set(IDENTITY)
         and all(type(x)is str and x for x in identity.values()),'method-adoption-foreign-caller')
    need(value['same_birth_caller_verified']is True,'method-adoption-birth-caller-not-owner-verified')
    need(value['generation_ref']==birth['generation_ref']
         and value['expected_revision']==birth['revision']
         and value['birth_fingerprint']==birth['fingerprint']
         and value['birth_receipt_fingerprint']==birth['ready_unbound_receipt']['receipt_fingerprint'],
         'method-adoption-foreign-birth')
    need(value['old_source']==delta['old_source'] and value['new_source']==delta['new_source']
         and value['delta_fingerprint']==delta['delta_fingerprint']
         and value['source_advance_policy']==ADVANCE_POLICY
         and value['role_contract_fingerprint']==delta['role_contract_fingerprint'],
         'method-adoption-owner-delta-mismatch')
    need(value['read_evidence_ref']==read_ref and type(read_ref)is str and bool(read_ref)
         and value['read_material_fingerprint']==digest(delta['files']['new']),
         'method-adoption-later-read-not-owner-verified')
    now=clock()
    need(value['current']is True and value['revoked']is False
         and type(value['not_before'])in (int,float) and type(value['expires_at'])in (int,float)
         and math.isfinite(value['not_before']) and math.isfinite(value['expires_at'])
         and value['not_before']<=now<value['expires_at'],'method-adoption-owner-not-current')
    return copy.deepcopy(value)

def make_adopted(birth,*,identity,authorization,delta):
    from control_context_registry import validate_pre_role_generation,pre_role_generation_fingerprint
    validate_pre_role_generation(birth)
    need(birth['lifecycle']=='READY_UNBOUND','method-adoption-exact-ready-birth-required')
    record={'schema':SCHEMA,'generation_ref':birth['generation_ref'],'caller_fingerprint':digest(identity),
            'birth_revision':2,'destination_ref':authorization['destination_ref'],'birth_fingerprint':birth.get('worker_method_adoption',{}).get('birth_fingerprint',birth['fingerprint']),
            'birth_receipt_fingerprint':birth['ready_unbound_receipt']['receipt_fingerprint'],
            'old_source':delta['old_source'],'new_source':delta['new_source'],'old_method_fingerprint':delta['old_method_fingerprint'],
            'new_method_fingerprint':delta['new_method_fingerprint'],
            'delta_fingerprint':delta['delta_fingerprint'],
            'source_advance_policy':authorization['source_advance_policy'],
            'role_contract_fingerprint':delta['role_contract_fingerprint'],
            'validation_at_prepare':copy.deepcopy(delta['current_validation']),
            'authorization_ref':authorization['authorization_ref'],
            'authorization_revision':authorization['revision'],'authorization_digest':digest(authorization),
            'read_evidence_ref':authorization['read_evidence_ref'],
            'read_material_fingerprint':authorization['read_material_fingerprint'],
            'adoption_ref':'METHOD-ADOPTION-'+digest(authorization)[:24],
            'revision':birth['revision']+1,'authority':'NONE_METHOD_ONLY'}
    if 'worker_method_adoption' in birth:record['previous_adoption']=copy.deepcopy(birth['worker_method_adoption'])
    record['receipt_fingerprint']=digest(record)
    result=copy.deepcopy(birth);result['revision']=record['revision'];result['worker_method_adoption']=record
    result['fingerprint']=pre_role_generation_fingerprint(result)
    validate_pre_role_generation(result)
    return result

def validate_adoption(state):
    """Validate separate durable evidence without changing the birth fields."""
    a=state.get('worker_method_adoption')
    need(type(a)is dict,'method-adoption-receipt-required')
    fields={'schema','generation_ref','caller_fingerprint','birth_revision','destination_ref','birth_fingerprint',
            'birth_receipt_fingerprint','old_source','new_source','old_method_fingerprint',
            'new_method_fingerprint','delta_fingerprint','authorization_ref','authorization_revision',
            'authorization_digest','read_evidence_ref','read_material_fingerprint','adoption_ref',
            'revision','authority','receipt_fingerprint','source_advance_policy',
            'role_contract_fingerprint','validation_at_prepare'}
    need(fields.issubset(a) and set(a).issubset(fields|{'previous_adoption'}) and a['schema']==SCHEMA and a['authority']=='NONE_METHOD_ONLY'
         and a['birth_revision']==2 and type(a['revision'])is int and a['revision']>=3 and a['destination_ref']=='P55_CONDUCTOR','method-adoption-receipt-fields')
    need(a['source_advance_policy']==ADVANCE_POLICY and type(a['validation_at_prepare'])is dict
         and a['validation_at_prepare'].get('selected_source')==a['new_source']
         and a['validation_at_prepare'].get('authority')=='NONE_ELIGIBILITY_ONLY',
         'method-adoption-continuity-policy-invalid')
    subject=copy.deepcopy(a);subject.pop('receipt_fingerprint')
    need(digest(subject)==a['receipt_fingerprint'],'method-adoption-receipt-fingerprint')
    need(a['generation_ref']==state['generation_ref'] and a['old_source']==(a['previous_adoption']['new_source'] if 'previous_adoption' in a else state['source_revision'])
         and a['old_method_fingerprint']==(a['previous_adoption']['new_method_fingerprint'] if 'previous_adoption' in a else state['civilization_method_attestation']['method_fingerprint'])
         and a['birth_receipt_fingerprint']==state['ready_unbound_receipt']['receipt_fingerprint'],
         'method-adoption-birth-binding')
    need(type(a['caller_fingerprint']) is str and len(a['caller_fingerprint'])==64
         and all(c in '0123456789abcdef' for c in a['caller_fingerprint']),
         'method-adoption-receipt-identity')
    restored=copy.deepcopy(state);restored.pop('worker_method_adoption');restored['revision']=2
    restored['lifecycle']='READY_UNBOUND';restored['role_overlay']=None;restored.pop('fingerprint')
    need(digest(restored)==a['birth_fingerprint'],'method-adoption-birth-mutated')
    need((state['lifecycle']=='READY_UNBOUND' and state['revision']==a['revision'])
         or (state['lifecycle']=='ROLE_ATTACHED' and state['revision']==a['revision']+1),'method-adoption-lifecycle-revision')
    if 'previous_adoption' in a:
        previous=adoption_input_state(state)
        need(previous['revision']+1==a['revision'],'method-adoption-history-revision')
        validate_adoption(previous)
    else:need(a['revision']==3,'method-adoption-initial-revision')
    return copy.deepcopy(a)

def adoption_input_state(state):
    from control_context_registry import pre_role_generation_fingerprint
    result=copy.deepcopy(state);a=result.pop('worker_method_adoption')
    result['lifecycle']='READY_UNBOUND';result['role_overlay']=None
    if 'previous_adoption' in a:
        result['worker_method_adoption']=copy.deepcopy(a['previous_adoption'])
        result['revision']=a['previous_adoption']['revision']
    else:result['revision']=2
    result['fingerprint']=pre_role_generation_fingerprint(result)
    return result

def validate_commit(current,candidate,expected_revision):
    from control_context_registry import validate_pre_role_generation
    need(type(expected_revision)is int and expected_revision==current['revision'] and current['lifecycle']=='READY_UNBOUND','method-adoption-cas-conflict')
    validate_pre_role_generation(current);validate_pre_role_generation(candidate)
    need(candidate['revision']==current['revision']+1,'method-adoption-revision')
    restored=adoption_input_state(candidate)
    need(restored==current,'method-adoption-birth-mutated')
