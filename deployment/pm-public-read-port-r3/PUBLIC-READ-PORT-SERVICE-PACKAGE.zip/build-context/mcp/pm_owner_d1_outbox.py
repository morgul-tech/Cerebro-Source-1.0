"""BK11 durable PM-owner D1 outbox in the existing Context PostgreSQL transaction.

Closes exactly one seam: a qualifying MATERIAL_READY owner commit and its D1 publication obligation now commit (or
roll back) together. Nothing here publishes, connects to a broker, wakes a receiver or consumes X9.

* DEFAULT OFF twice: the host must construct ``PostgresPmOwner(d1_outbox=...)`` AND an installation-owned route row
  (``cerebro_pm_owner_d1_routes.enqueue_enabled``) must exist. Absent either, commit behaviour is unchanged.
* Every intent field is derived from the committed owner record and the route row: the ORIGINAL PM event_id,
  receipt_ref, commit_ref, revision_after (opaque PM string revision), owner_seq, referent, hashes. The D1 wire format
  needs a numeric owner revision and a transport message id; both are DERIVED deterministically
  (owner_revision := owner_seq, message_id := d1 identity of scope+receiver+event_id+owner_seq), recorded in a
  mapping that is checked by an exact roundtrip parse before insert. No replacement PM event/receipt is created.
* One intent per (exact canonical event, explicit route/receiver/delivery class); payload bytes, hash and identity are
  immutable (DB trigger). Same idempotency key => the commit replays => the same receipt and the same intent.
* The D1 publisher (a separately authenticated, host-assigned principal with its own persisted current session)
  gets only bounded scoped listing / exact read / compare-and-set settle of publication state, and only while the
  route's ``drain_enabled`` holds. The X9 receiver gets only an exact route-scoped pointer resolution.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Mapping

from pm_owner_atomic import PmOwnerAssignment, PmOwnerError, PostgresPmOwner, _row

OUTBOX_SCHEMA_VERSION = 1
D1_SCHEMA, D1_VERSION, D1_CLASS, D1_KIND = "cerebro.d1.pointer", 1, "D1", "HINT"
REFERENT_TYPE = "PM_READY_HINT"
MAPPING_SCHEMA = "cerebro-pm-owner-d1-mapping/v1"
D1_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:@/#=-]{0,159}$")
HEX64 = re.compile(r"^[0-9a-f]{64}$")
MESSAGE_ID = re.compile(r"^d1:[0-9a-f]{40}$")
STATES = ("INTENDED", "SEND_CLAIMED", "PUBLISHED", "UNKNOWN_PENDING", "REJECTED_CAPACITY", "CONFLICT_HOLD",
          "RECONCILE_HOLD")
SETTLE_FIELDS = {"state": str, "claim_token": str, "claimed_at": str, "attempts": int, "stream": str,
                 "stream_seq": int, "duplicate": bool, "puback_latency_ms": float, "last_reason": str}
POINTER_KEYS = frozenset({"schema", "version", "tenant_ref", "workspace_ref", "project_ref", "owner_ref",
                          "owner_event_key", "owner_revision", "event_fingerprint", "referent", "receiver_ref",
                          "message_id", "dedupe_key", "class", "kind", "created_at", "expires_at", "body_sha256"})
MAX_LIST = 64
ROW_COLUMNS = ("tenant_ref", "workspace_ref", "project_ref", "owner_ref", "route_ref", "receiver_ref",
               "delivery_class", "binding_revision", "event_id", "receipt_ref", "commit_ref", "referent_id",
               "revision_after", "owner_seq", "snapshot_sha256", "packet_sha256", "message_id", "pointer",
               "pointer_sha256", "mapping_payload", "mapping_sha256", "created_at", "expires_at", "state",
               "claim_token", "claimed_at", "attempts", "stream", "stream_seq", "duplicate", "puback_latency_ms",
               "last_reason", "enqueued_at")


class PmOwnerD1Error(PmOwnerError):
    pass


def _need(condition: bool, code: str) -> None:
    if not condition:
        raise PmOwnerD1Error(code)


# ---------------------------------------------------------------------- D1 wire format (cerebro.d1.pointer v1)
def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def d1_iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def d1_message_identity(tenant: str, workspace: str, project: str, receiver: str, owner_event_key: str,
                        owner_revision: int) -> str:
    """Same formula as d1js.pointer.message_identity (stable scope+identity => Nats-Msg-Id and dedupe key)."""
    return "d1:" + _sha(_canonical({"t": tenant, "w": workspace, "p": project, "r": receiver,
                                    "k": owner_event_key, "v": owner_revision}))[:40]


def build_d1_pointer(*, tenant_ref: str, workspace_ref: str, project_ref: str, owner_ref: str, owner_event_key: str,
                     owner_revision: int, event_fingerprint: str, referent_id: str, receiver_ref: str,
                     created_at: datetime, ttl_seconds: int) -> bytes:
    msg_id = d1_message_identity(tenant_ref, workspace_ref, project_ref, receiver_ref, owner_event_key,
                                 owner_revision)
    body = {"schema": D1_SCHEMA, "version": D1_VERSION, "tenant_ref": tenant_ref, "workspace_ref": workspace_ref,
            "project_ref": project_ref, "owner_ref": owner_ref, "owner_event_key": owner_event_key,
            "owner_revision": owner_revision, "event_fingerprint": event_fingerprint,
            "referent": {"type": REFERENT_TYPE, "id": referent_id}, "receiver_ref": receiver_ref,
            "message_id": msg_id, "dedupe_key": msg_id, "class": D1_CLASS, "kind": D1_KIND,
            "created_at": d1_iso(created_at), "expires_at": d1_iso(created_at + timedelta(seconds=ttl_seconds))}
    body["body_sha256"] = _sha(_canonical(body))
    return _canonical(body)


def parse_d1_pointer_exact(raw: bytes) -> dict[str, Any]:
    """Strict roundtrip check used before insert (the receiver runs its own strict d1js parser)."""
    _need(isinstance(raw, (bytes, bytearray)) and 0 < len(raw) <= 4096, "PM_OWNER_D1_POINTER_SIZE")
    doc = json.loads(bytes(raw).decode("utf-8"))
    _need(isinstance(doc, dict) and set(doc) == POINTER_KEYS and _canonical(doc) == bytes(raw),
          "PM_OWNER_D1_POINTER_NOT_CANONICAL")
    body = {k: v for k, v in doc.items() if k != "body_sha256"}
    _need(doc["body_sha256"] == _sha(_canonical(body)), "PM_OWNER_D1_POINTER_DIGEST")
    _need(doc["message_id"] == doc["dedupe_key"] == d1_message_identity(
        doc["tenant_ref"], doc["workspace_ref"], doc["project_ref"], doc["receiver_ref"], doc["owner_event_key"],
        doc["owner_revision"]), "PM_OWNER_D1_POINTER_IDENTITY")
    for key in ("tenant_ref", "workspace_ref", "project_ref", "owner_ref", "owner_event_key", "receiver_ref"):
        _need(isinstance(doc[key], str) and D1_ID.fullmatch(doc[key]) is not None, "PM_OWNER_D1_POINTER_ID_SHAPE")
    return doc


def _parse_observed(value: Any) -> datetime:
    _need(isinstance(value, str), "PM_OWNER_D1_OBSERVED_AT_INVALID")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    _need(parsed.tzinfo is not None, "PM_OWNER_D1_OBSERVED_AT_INVALID")
    return parsed


# ---------------------------------------------------------------------- host-owned publisher assignment
@dataclass(frozen=True)
class D1PublisherAssignment:
    owner_ref: str
    route_ref: str
    tenant_ref: str
    workspace_ref: str
    project_ref: str
    principal_ref: str
    consumer_ref: str
    session_ref: str
    session_binding_id: str

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "D1PublisherAssignment":
        _need(isinstance(value, Mapping) and set(value) == set(cls.__dataclass_fields__),
              "PM_OWNER_D1_PUBLISHER_EXACT_FIELDS_REQUIRED")
        out = cls(**value)
        for key in cls.__dataclass_fields__:
            v = getattr(out, key)
            _need(isinstance(v, str) and bool(v.strip()) and len(v.encode("utf-8")) <= 256
                  and not any(c.isspace() for c in v), "PM_OWNER_D1_PUBLISHER_INVALID")
        return out


def _serialize(row: Mapping[str, Any]) -> dict[str, Any]:
    out = {k: row.get(k) for k in ROW_COLUMNS}
    pointer = out["pointer"]
    if isinstance(pointer, memoryview):
        pointer = pointer.tobytes()
    out["pointer"] = base64.b64encode(bytes(pointer)).decode("ascii")
    if isinstance(out["enqueued_at"], datetime):
        out["enqueued_at"] = out["enqueued_at"].isoformat()
    if isinstance(out["mapping_payload"], str):
        out["mapping_payload"] = json.loads(out["mapping_payload"])
    return out


class PmOwnerD1Outbox:
    """Service-owned owner outbox. Constructed by the host only; tool arguments never select routes or roles."""

    def __init__(self, *, state_port: Any, pm_assignment: PmOwnerAssignment,
                 publisher_assignment: D1PublisherAssignment | None = None,
                 x9_configuration: Any | None = None) -> None:
        _need(callable(getattr(state_port, "_transaction", None))
              and callable(getattr(state_port, "_load_session", None)), "PM_OWNER_D1_STATE_PORT_REQUIRED")
        _need(type(pm_assignment) is PmOwnerAssignment, "PM_OWNER_D1_PM_ASSIGNMENT_REQUIRED")
        _need(publisher_assignment is None or type(publisher_assignment) is D1PublisherAssignment,
              "PM_OWNER_D1_PUBLISHER_ASSIGNMENT_INVALID")
        if publisher_assignment is not None:
            _need((publisher_assignment.owner_ref, publisher_assignment.tenant_ref, publisher_assignment.workspace_ref,
                   publisher_assignment.project_ref) == (pm_assignment.owner_ref, pm_assignment.tenant_ref,
                                                         pm_assignment.workspace_ref, pm_assignment.project_ref),
                  "PM_OWNER_D1_PUBLISHER_SCOPE_MISMATCH")
            _need(publisher_assignment.principal_ref != pm_assignment.principal_ref
                  and publisher_assignment.session_ref != pm_assignment.session_ref,
                  "PM_OWNER_D1_PUBLISHER_MUST_BE_DISTINCT_FROM_PM")
        self._state = state_port
        self._pm = pm_assignment
        self._publisher = publisher_assignment
        self._x9_configuration = x9_configuration
        # Deterministic synthetic fault seam for the disposable integration batch only (labelled; default empty).
        self.faults: dict[str, Any] = {}

    def _fault(self, point: str) -> None:
        action = self.faults.get(point)
        if action is not None:
            action()

    @staticmethod
    def require_schema(cursor: Any) -> None:
        cursor.execute("SELECT outbox_schema_version FROM cerebro_pm_owner_d1_outbox_meta WHERE singleton")
        meta = _row(cursor)
        _need(meta is not None, "PM_OWNER_D1_OUTBOX_SCHEMA_MISSING")
        _need(meta["outbox_schema_version"] == OUTBOX_SCHEMA_VERSION, "PM_OWNER_D1_OUTBOX_SCHEMA_VERSION_REFUSED")

    # ------------------------------------------------------------------ inside the PM owner commit transaction
    def enqueue_committed(self, cursor: Any, record: Mapping[str, Any]) -> list[dict[str, Any]]:
        """Called by PostgresPmOwner.commit inside its transaction, after the receipt/current/head writes.
        No route => no obligation, no change. Any failure raises => the WHOLE owner commit rolls back."""
        a = self._pm
        _need(record.get("ready_state") == "MATERIAL_READY", "PM_OWNER_D1_NOT_MATERIAL")
        cursor.execute("""SELECT to_regclass('cerebro_pm_owner_d1_routes') IS NOT NULL AS present""")
        present = _row(cursor)
        if not (present and present["present"]):
            return []                                       # migration not installed: unchanged behaviour
        self.require_schema(cursor)
        # No FOR SHARE: the runtime role has no UPDATE policy on routes (RLS would hide locked rows). The INSERT
        # policy re-checks the route (enabled, same binding revision) at write time inside this transaction.
        cursor.execute("""SELECT route_ref,receiver_ref,delivery_class,pointer_ttl_seconds,binding_revision
            FROM cerebro_pm_owner_d1_routes WHERE tenant_ref=%s AND workspace_ref=%s AND owner_ref=%s
            AND project_ref=%s AND enqueue_enabled ORDER BY route_ref""",
                       (a.tenant_ref, a.workspace_ref, a.owner_ref, a.project_ref))
        routes = []
        while True:
            row = _row(cursor)
            if row is None:
                break
            routes.append(row)
        if not routes:
            return []
        _need(record.get("owner_ref") == a.owner_ref and type(record.get("owner_seq")) is int
              and record["owner_seq"] >= 1, "PM_OWNER_D1_RECORD_INVALID")
        for key in ("event_id", "receipt_ref", "commit_ref", "referent_id", "revision_after"):
            _need(isinstance(record.get(key), str) and D1_ID.fullmatch(record[key]) is not None,
                  "PM_OWNER_D1_RECORD_ID_SHAPE")
        _need(HEX64.fullmatch(record.get("snapshot_sha256") or "") is not None
              and HEX64.fullmatch(record.get("packet_sha256") or "") is not None, "PM_OWNER_D1_RECORD_HASH_SHAPE")
        created = _parse_observed(record.get("observed_at"))
        cursor.execute("SELECT set_config('cerebro.d1_actor', 'pm_owner_commit', true)")
        intents = []
        for route in routes:
            intents.append(self._insert_intent(cursor, record, route, created))
        cursor.execute("SELECT set_config('cerebro.d1_actor', '', true)")
        self._fault("after_enqueue_before_commit")
        return intents

    def _insert_intent(self, cursor: Any, record: Mapping[str, Any], route: Mapping[str, Any],
                       created: datetime) -> dict[str, Any]:
        a = self._pm
        _need(D1_ID.fullmatch(route["receiver_ref"]) is not None and route["delivery_class"] == "D1_POINTER_HINT",
              "PM_OWNER_D1_ROUTE_INVALID")
        pointer = build_d1_pointer(
            tenant_ref=a.tenant_ref, workspace_ref=a.workspace_ref, project_ref=a.project_ref, owner_ref=a.owner_ref,
            owner_event_key=record["event_id"], owner_revision=record["owner_seq"],
            event_fingerprint=record["snapshot_sha256"], referent_id=record["referent_id"],
            receiver_ref=route["receiver_ref"], created_at=created, ttl_seconds=route["pointer_ttl_seconds"])
        doc = parse_d1_pointer_exact(pointer)
        mapping = {"schema": MAPPING_SCHEMA, "route_ref": route["route_ref"],
                   "binding_revision": route["binding_revision"], "delivery_class": route["delivery_class"],
                   "pm": {"event_id": record["event_id"], "receipt_ref": record["receipt_ref"],
                          "commit_ref": record["commit_ref"], "revision_after": record["revision_after"],
                          "owner_seq": record["owner_seq"], "referent_id": record["referent_id"],
                          "snapshot_sha256": record["snapshot_sha256"], "packet_sha256": record["packet_sha256"]},
                   "d1": {"owner_event_key": doc["owner_event_key"], "owner_revision": doc["owner_revision"],
                          "event_fingerprint": doc["event_fingerprint"], "message_id": doc["message_id"],
                          "receiver_ref": doc["receiver_ref"], "referent": doc["referent"]},
                   "revision_kinds": {"pm.revision_after": "PM_OPAQUE_STRING_REVISION",
                                      "d1.owner_revision": "PM_OWNER_SEQ_INTEGER"},
                   "derivation": "owner_event_key=pm.event_id; owner_revision=pm.owner_seq; "
                                 "event_fingerprint=pm.snapshot_sha256; message_id=d1_identity(scope,receiver,"
                                 "event_id,owner_seq)"}
        # roundtrip: the wire bytes carry exactly the original PM identity (nothing stripped or replaced)
        _need((doc["owner_event_key"], doc["owner_revision"], doc["event_fingerprint"], doc["referent"]["id"])
              == (record["event_id"], record["owner_seq"], record["snapshot_sha256"], record["referent_id"]),
              "PM_OWNER_D1_MAPPING_ROUNDTRIP")
        mapping_sha = _sha(_canonical(mapping))
        values = (a.tenant_ref, a.workspace_ref, a.project_ref, a.owner_ref, route["route_ref"],
                  route["receiver_ref"], route["delivery_class"], route["binding_revision"], record["event_id"],
                  record["receipt_ref"], record["commit_ref"], record["referent_id"], record["revision_after"],
                  record["owner_seq"], record["snapshot_sha256"], record["packet_sha256"], doc["message_id"], pointer,
                  _sha(pointer), _canonical(mapping).decode("utf-8"), mapping_sha, doc["created_at"],
                  doc["expires_at"])
        cursor.execute("""INSERT INTO cerebro_pm_owner_d1_outbox
            (tenant_ref,workspace_ref,project_ref,owner_ref,route_ref,receiver_ref,delivery_class,binding_revision,
             event_id,receipt_ref,commit_ref,referent_id,revision_after,owner_seq,snapshot_sha256,packet_sha256,
             message_id,pointer,pointer_sha256,mapping_payload,mapping_sha256,created_at,expires_at,state)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s,%s,%s,'INTENDED')
            ON CONFLICT (tenant_ref,workspace_ref,owner_ref,event_id,route_ref) DO NOTHING""", values)
        cursor.execute("""SELECT event_id,receipt_ref,message_id,pointer_sha256,mapping_sha256,state
            FROM cerebro_pm_owner_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s AND owner_ref=%s
            AND event_id=%s AND route_ref=%s""",
                       (a.tenant_ref, a.workspace_ref, a.owner_ref, record["event_id"], route["route_ref"]))
        stored = _row(cursor)
        _need(stored is not None and (stored["receipt_ref"], stored["message_id"], stored["pointer_sha256"],
                                      stored["mapping_sha256"]) == (record["receipt_ref"], doc["message_id"],
                                                                     _sha(pointer), mapping_sha),
              "PM_OWNER_D1_INTENT_CONFLICT")
        return {"route_ref": route["route_ref"], "message_id": doc["message_id"], "pointer_sha256": _sha(pointer),
                "mapping_sha256": mapping_sha}

    # ------------------------------------------------------------------ D1 publisher (separate principal)
    def _publisher_txn(self, identity: Any, transport_session: Mapping[str, Any] | None, *, write: bool):
        p = self._publisher
        _need(p is not None, "PM_OWNER_D1_PUBLISHER_NOT_ASSIGNED")
        _need(("project_state:transition" if write else "project_state:read") in identity.state_scopes,
              "PM_OWNER_D1_SCOPE_REQUIRED")
        _need(transport_session is not None and transport_session.get("session_ref") == p.session_ref,
              "PM_OWNER_D1_PUBLISHER_SESSION_REQUIRED")
        _need((identity.tenant_ref, identity.workspace_ref, identity.principal_ref, identity.consumer_ref)
              == (p.tenant_ref, p.workspace_ref, p.principal_ref, p.consumer_ref),
              "PM_OWNER_D1_PUBLISHER_IDENTITY_REQUIRED")
        return self._state._transaction(tenant_ref=p.tenant_ref, workspace_ref=p.workspace_ref,
                                        principal_ref=p.principal_ref, read_only=not write,
                                        repeatable_read=not write, passthrough_errors=(PmOwnerError,))

    def _publisher_current(self, cursor: Any, *, write: bool) -> dict[str, Any]:
        p = self._publisher
        session = self._state._load_session(cursor, tenant_ref=p.tenant_ref, workspace_ref=p.workspace_ref,
                                            principal_ref=p.principal_ref, consumer_ref=p.consumer_ref,
                                            session_ref=p.session_ref, for_update=False, required=False)
        _need(session is not None, "PM_OWNER_D1_PUBLISHER_CURRENT_SESSION_REQUIRED")
        project = self._state._load_project(cursor, tenant_ref=p.tenant_ref, workspace_ref=p.workspace_ref,
                                            project_ref=p.project_ref, required=False)
        _need(project is not None and project.get("project_status") == "ACTIVE"
              and session["project_ref"] == p.project_ref and session["session_binding_id"] == p.session_binding_id
              and session["project_revision"] == project["revision"], "PM_OWNER_D1_PUBLISHER_STALE_SESSION")
        self.require_schema(cursor)
        cursor.execute("""SELECT * FROM cerebro_pm_owner_d1_routes WHERE tenant_ref=%s AND workspace_ref=%s
            AND owner_ref=%s AND route_ref=%s""",
                       (p.tenant_ref, p.workspace_ref, p.owner_ref, p.route_ref))
        route = _row(cursor)
        _need(route is not None and (route["publisher_principal_ref"], route["publisher_consumer_ref"],
                                     route["publisher_session_ref"], route["publisher_session_binding_id"],
                                     route["project_ref"])
              == (p.principal_ref, p.consumer_ref, p.session_ref, p.session_binding_id, p.project_ref),
              "PM_OWNER_D1_ROUTE_PUBLISHER_MISMATCH")
        _need(not write or route["drain_enabled"] is True, "PM_OWNER_D1_DRAIN_DISABLED")
        return route

    def read_for_publisher(self, args: Mapping[str, Any], identity: Any,
                           transport_session: Mapping[str, Any] | None) -> dict[str, Any]:
        op = args.get("op")
        _need(op in ("list_pending", "list_recovery_candidates", "read_exact"), "PM_OWNER_D1_READ_OP_INVALID")
        p = self._publisher
        with self._publisher_txn(identity, transport_session, write=False) as cursor:
            route = self._publisher_current(cursor, write=False)
            if op == "read_exact":
                _need(set(args) == {"op", "message_id"} and isinstance(args["message_id"], str)
                      and MESSAGE_ID.fullmatch(args["message_id"]) is not None, "PM_OWNER_D1_MESSAGE_ID_REQUIRED")
                cursor.execute("""SELECT * FROM cerebro_pm_owner_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s
                    AND owner_ref=%s AND route_ref=%s AND message_id=%s""",
                               (p.tenant_ref, p.workspace_ref, p.owner_ref, p.route_ref, args["message_id"]))
                row = _row(cursor)
                return {"row": _serialize(row) if row else None, "drain_enabled": route["drain_enabled"]}
            _need(set(args) <= {"op", "after", "limit"}, "PM_OWNER_D1_LIST_EXACT_FIELDS")
            limit = args.get("limit", 16)
            _need(type(limit) is int and 1 <= limit <= MAX_LIST, "PM_OWNER_D1_LIST_LIMIT_INVALID")
            after = args.get("after")
            params: list[Any] = [p.tenant_ref, p.workspace_ref, p.owner_ref, p.route_ref]
            keyset = ""
            if after is not None:
                _need(isinstance(after, Mapping) and set(after) == {"enqueued_at", "event_id"}
                      and isinstance(after["enqueued_at"], str) and isinstance(after["event_id"], str),
                      "PM_OWNER_D1_LIST_CURSOR_INVALID")
                keyset = " AND (enqueued_at, event_id) > (%s::timestamptz, %s)"
                params += [after["enqueued_at"], after["event_id"]]
            # PubAck does not prove receiver disposition. Discovery includes published
            # owner obligations; the caller must perform genuine scoped disposition
            # readback before deciding recovery. This read neither settles nor republishes.
            state_filter = " AND state <> 'PUBLISHED'" if op == "list_pending" else ""
            cursor.execute("""SELECT * FROM cerebro_pm_owner_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s
                AND owner_ref=%s AND route_ref=%s""" + state_filter + keyset +
                           " ORDER BY enqueued_at, event_id LIMIT %s", (*params, limit + 1))
            rows = []
            while True:
                row = _row(cursor)
                if row is None:
                    break
                rows.append(_serialize(row))
            more = len(rows) > limit
            rows = rows[:limit]
            nxt = {"enqueued_at": rows[-1]["enqueued_at"], "event_id": rows[-1]["event_id"]} if more else None
            return {"rows": rows, "next": nxt, "drain_enabled": route["drain_enabled"]}

    def settle_for_publisher(self, args: Mapping[str, Any], identity: Any,
                             transport_session: Mapping[str, Any] | None) -> dict[str, Any]:
        """Compare-and-set on (state, claim_token); exactly one caller can move a given (state, token)."""
        _need(set(args) == {"message_id", "from_state", "from_token", "fields"}, "PM_OWNER_D1_SETTLE_EXACT_FIELDS")
        _need(isinstance(args["message_id"], str) and MESSAGE_ID.fullmatch(args["message_id"]) is not None,
              "PM_OWNER_D1_MESSAGE_ID_REQUIRED")
        _need(args["from_state"] in STATES and (args["from_token"] is None or isinstance(args["from_token"], str)),
              "PM_OWNER_D1_SETTLE_FROM_INVALID")
        fields = args["fields"]
        _need(isinstance(fields, Mapping) and fields and set(fields) <= set(SETTLE_FIELDS)
              and "state" in fields and fields["state"] in STATES, "PM_OWNER_D1_SETTLE_FIELDS_INVALID")
        for key, value in fields.items():
            kind = SETTLE_FIELDS[key]
            ok = value is None or (type(value) is kind) or (kind is float and type(value) is int)
            _need(ok and not (isinstance(value, str) and len(value) > 512), "PM_OWNER_D1_SETTLE_VALUE_INVALID")
        p = self._publisher
        with self._publisher_txn(identity, transport_session, write=True) as cursor:
            self._publisher_current(cursor, write=True)
            cursor.execute("SELECT set_config('cerebro.d1_actor', 'd1_publisher', true)")
            cols = ", ".join(f"{k}=%s" for k in fields)
            cursor.execute(f"""UPDATE cerebro_pm_owner_d1_outbox SET {cols} WHERE tenant_ref=%s AND workspace_ref=%s
                AND owner_ref=%s AND route_ref=%s AND message_id=%s AND state=%s
                AND claim_token IS NOT DISTINCT FROM %s""",
                           (*fields.values(), p.tenant_ref, p.workspace_ref, p.owner_ref, p.route_ref,
                            args["message_id"], args["from_state"], args["from_token"]))
            won = cursor.rowcount == 1
            cursor.execute("""SELECT * FROM cerebro_pm_owner_d1_outbox WHERE tenant_ref=%s AND workspace_ref=%s
                AND owner_ref=%s AND route_ref=%s AND message_id=%s""",
                           (p.tenant_ref, p.workspace_ref, p.owner_ref, p.route_ref, args["message_id"]))
            row = _row(cursor)
            _need(row is not None, "PM_OWNER_D1_INTENT_MISSING")
        return {"won": won, "row": _serialize(row)}            # returned only after COMMIT

    # ------------------------------------------------------------------ X9 receiver: exact pointer resolution
    def resolve_for_receiver(self, args: Mapping[str, Any], api: Any) -> dict[str, Any]:
        """Inside the EXISTING X9 receiver custody transaction (fresh OAuth + persisted current session + role
        tuple). Returns only route-scoped exact facts; never material bodies."""
        op = args.get("op")
        _need(op in ("resolve", "verify_route") and set(args) == {"op", "message_id", "pointer_sha256"}
              and isinstance(args["message_id"], str) and MESSAGE_ID.fullmatch(args["message_id"]) is not None
              and isinstance(args["pointer_sha256"], str) and HEX64.fullmatch(args["pointer_sha256"]) is not None,
              "PM_OWNER_D1_RESOLVE_EXACT_FIELDS")
        a = self._pm
        with api._transaction(write=False) as (cursor, identity, _session, config, binding):
            _need(binding.role == "receiver", "PM_OWNER_D1_RECEIVER_ROLE_REQUIRED")
            self.require_schema(cursor)
            cursor.execute("""SELECT o.*, r.x9_config_ref, r.receiver_assignment_ref, r.receiver_ref AS route_receiver
                FROM cerebro_pm_owner_d1_outbox o JOIN cerebro_pm_owner_d1_routes r
                ON (r.tenant_ref,r.workspace_ref,r.owner_ref,r.route_ref)=(o.tenant_ref,o.workspace_ref,o.owner_ref,o.route_ref)
                WHERE o.tenant_ref=%s AND o.workspace_ref=%s AND o.owner_ref=%s AND o.message_id=%s""",
                           (a.tenant_ref, a.workspace_ref, a.owner_ref, args["message_id"]))
            row = _row(cursor)
            exact = row is not None and row["pointer_sha256"] == args["pointer_sha256"]
            if op == "verify_route":
                return {"exact": exact, "receiver_ref": row["receiver_ref"] if exact else None}
            _need(exact, "PM_OWNER_D1_POINTER_NOT_OWNER_COMMITTED")
            _need(row["x9_config_ref"] == config.config_ref and row["receiver_assignment_ref"] == binding.assignment_ref
                  and row["receiver_ref"] == row["route_receiver"], "PM_OWNER_D1_RECEIVER_NOT_ROUTED")
            mapping = row["mapping_payload"]
            if isinstance(mapping, str):
                mapping = json.loads(mapping)
            _need(_sha(_canonical(mapping)) == row["mapping_sha256"], "PM_OWNER_D1_MAPPING_DRIFT")
            cursor.execute("""SELECT c.receipt_ref, rc.record_payload, rc.snapshot_sha256
                FROM cerebro_pm_owner_current c JOIN cerebro_pm_owner_receipts rc
                ON (rc.tenant_ref,rc.workspace_ref,rc.owner_ref,rc.receipt_ref)=(c.tenant_ref,c.workspace_ref,c.owner_ref,c.receipt_ref)
                WHERE c.tenant_ref=%s AND c.workspace_ref=%s AND c.owner_ref=%s AND c.referent_id=%s""",
                           (a.tenant_ref, a.workspace_ref, a.owner_ref, row["referent_id"]))
            current = _row(cursor)
            _need(current is not None, "PM_OWNER_D1_CURRENT_REFERENT_MISSING")
            record = PostgresPmOwner._record(current)
        return {"mapping": mapping, "mapping_sha256": row["mapping_sha256"], "message_id": row["message_id"],
                "pointer_sha256": row["pointer_sha256"], "receiver_ref": row["receiver_ref"],
                "current": {"receipt_ref": record["receipt_ref"], "event_id": record["event_id"],
                            "owner_seq": record["owner_seq"], "snapshot_sha256": record["snapshot_sha256"],
                            "revision_after": record["revision_after"], "ready_state": record["ready_state"]},
                "committed_readback": True}


class D1OutboxHost:
    """Request-scoped tool host: publisher operations and X9-receiver pointer resolution."""

    def __init__(self, *, outbox: PmOwnerD1Outbox, authenticator: Any, connection_factory: Any) -> None:
        _need(isinstance(outbox, PmOwnerD1Outbox), "PM_OWNER_D1_OUTBOX_REQUIRED")
        _need(callable(connection_factory), "PM_OWNER_D1_CONNECTION_FACTORY_REQUIRED")
        self._outbox, self._auth, self._factory = outbox, authenticator, connection_factory

    def read(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        return self._outbox.read_for_publisher(args, context.identity, context.transport_session())

    def settle(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        return self._outbox.settle_for_publisher(args, context.identity, context.transport_session())

    def resolve(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        config = self._outbox._x9_configuration
        _need(config is not None, "PM_OWNER_D1_X9_CONFIGURATION_REQUIRED")
        from x9_receiver_host import X9ReceiverError, X9ReceiverHost
        host = X9ReceiverHost(config=config, authenticator=self._auth, connection_factory=self._factory)
        try:
            _channel, api = host._channel(context, required_scope="project_state:read")
        except X9ReceiverError as exc:
            raise PmOwnerD1Error(str(exc)) from None
        return self._outbox.resolve_for_receiver(args, api)
