"""PM-session X9 pointer sender over the existing authenticated custody port."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from threading import Lock
from typing import Any, Mapping

from adapters.x9_channel_ingress import (
    CHANNEL, HEX64, ID, PointerContext, PointerRecord, SCHEMA, X9ChannelIngress,
)
from pm_owner_atomic import PmOwnerAssignment, PostgresPmOwner, _hash, _row
from providers.x9_postgres_custody import PostgresPMProducerChannel, PostgresX9SessionAPI
from providers.x9_role_binding import TrustedCustodyConfiguration
from signalvev_sensing.activation import decide_activation
from signalvev_sensing.return_sink import make_closure
from x9_receiver_host import _FixedConfigurationPort


class X9ProducerError(ValueError):
    pass


def _need(condition: bool, code: str) -> None:
    if not condition:
        raise X9ProducerError(code)


class X9ProducerHost:
    """One normal producer call. The only caller field is an actual PM receipt ref."""

    def __init__(self, *, config: TrustedCustodyConfiguration, pm_owner_assignment: PmOwnerAssignment,
                 authenticator: Any, connection_factory: Any):
        _need(isinstance(config, TrustedCustodyConfiguration), "X9_PRODUCER_CONFIG_REQUIRED")
        config.validate()
        _need(isinstance(pm_owner_assignment, PmOwnerAssignment), "X9_PM_OWNER_POLICY_REQUIRED")
        expected = config.producer.identity
        _need((pm_owner_assignment.tenant_ref, pm_owner_assignment.workspace_ref,
               pm_owner_assignment.project_ref, pm_owner_assignment.principal_ref,
               pm_owner_assignment.consumer_ref, pm_owner_assignment.session_ref,
               pm_owner_assignment.session_binding_id) ==
              (expected.tenant_ref, expected.workspace_ref, expected.project_ref,
               expected.principal_ref, expected.consumer_ref, expected.session_ref,
               expected.session_binding_id), "X9_PM_PRODUCER_POLICY_MISMATCH")
        _need(callable(connection_factory), "X9_PRODUCER_CONNECTION_FACTORY_REQUIRED")
        self._config = config
        self._pm_owner_assignment = pm_owner_assignment
        self._authenticator = authenticator
        self._connection_factory = connection_factory
        self._config_port = _FixedConfigurationPort(config)
        self._uncertain_events: set[str] = set()
        self._uncertain_lock = Lock()

    def _channel(self, context: Any) -> tuple[PostgresPMProducerChannel, PostgresX9SessionAPI]:
        identity = context.identity
        identity.validate()
        expected = self._config.producer.identity
        transport = context.transport_session()
        _need(transport is not None and transport["session_ref"] == expected.session_ref,
              "X9_CURRENT_PRODUCER_SESSION_REQUIRED")
        _need((identity.tenant_ref, identity.workspace_ref, identity.principal_ref,
               identity.consumer_ref) ==
              (expected.tenant_ref, expected.workspace_ref, expected.principal_ref,
               expected.consumer_ref), "X9_PRODUCER_IDENTITY_MISMATCH")
        _need(isinstance(context.private_headers, Mapping), "X9_PRIVATE_HEADERS_REQUIRED")
        api = PostgresX9SessionAPI(
            authenticator=self._authenticator,
            header_provider=lambda: context.private_headers,
            connection_factory=self._connection_factory,
            configuration_provider=self._config_port,
            enabled=True, role="producer", required_scope="project_state:transition",
        )
        return PostgresPMProducerChannel(api), api

    def _receipt(self, api: PostgresX9SessionAPI, receipt_ref: str) -> tuple[dict[str, Any], dict[str, Any]]:
        owner = self._pm_owner_assignment
        with api._transaction(write=False) as (cursor, identity, _session, _config, binding):
            _need(binding.role == "producer" and identity.principal_ref == owner.principal_ref,
                  "X9_PRODUCER_READ_AUTHORIZATION_REQUIRED")
            cursor.execute("""SELECT record_payload,snapshot_sha256,projection_payload,packet_payload
                FROM cerebro_pm_owner_receipts WHERE tenant_ref=%s AND workspace_ref=%s
                AND project_ref=%s AND owner_ref=%s AND receipt_ref=%s""",
                (owner.tenant_ref, owner.workspace_ref, owner.project_ref, owner.owner_ref, receipt_ref))
            first = _row(cursor)
            _need(first is not None, "X9_PM_RECEIPT_MISSING")
            record = PostgresPmOwner._record(first)
            _need(record.get("receipt_ref") == receipt_ref
                  and record.get("owner_ref") == owner.owner_ref
                  and isinstance(record.get("referent_id"), str)
                  and record["referent_id"].startswith("pm-ready:"),
                  "X9_PM_RECEIPT_IDENTITY_MISMATCH")
            cursor.execute("""SELECT receipt_ref FROM cerebro_pm_owner_current
                WHERE tenant_ref=%s AND workspace_ref=%s AND owner_ref=%s AND referent_id=%s
                FOR SHARE""",
                (owner.tenant_ref, owner.workspace_ref, owner.owner_ref, record["referent_id"]))
            current = _row(cursor)
            _need(current is not None and current["receipt_ref"] == receipt_ref,
                  "X9_PM_RECEIPT_NOT_CURRENT")
            cursor.execute("""SELECT record_payload,snapshot_sha256,projection_payload,packet_payload
                FROM cerebro_pm_owner_receipts WHERE tenant_ref=%s AND workspace_ref=%s
                AND project_ref=%s AND owner_ref=%s AND receipt_ref=%s""",
                (owner.tenant_ref, owner.workspace_ref, owner.project_ref, owner.owner_ref, receipt_ref))
            second = _row(cursor)
            _need(second is not None and PostgresPmOwner._record(second) == record
                  and second["projection_payload"] == first["projection_payload"]
                  and second["packet_payload"] == first["packet_payload"],
                  "X9_PM_RECEIPT_READBACK_MISMATCH")
            projection = first["projection_payload"]
            if isinstance(projection, str):
                try:
                    projection = json.loads(projection)
                except ValueError as exc:
                    raise X9ProducerError("X9_PM_PROJECTION_INVALID") from exc
            packet = first["packet_payload"]
            if isinstance(packet, str):
                try:
                    packet = json.loads(packet)
                except ValueError as exc:
                    raise X9ProducerError("X9_PM_PACKET_INVALID") from exc
        _need(isinstance(projection, dict)
              and isinstance(projection.get("material_sha256"), str)
              and HEX64.fullmatch(projection["material_sha256"]) is not None
              and isinstance(projection.get("source_cut"), str)
              and ID.fullmatch(projection["source_cut"]) is not None,
              "X9_PM_MATERIAL_PROJECTION_INVALID")
        _need(isinstance(packet, dict) and "material" in packet
              and _hash(packet) == record.get("packet_sha256")
              and _hash(packet["material"]) == projection["material_sha256"],
              "X9_PM_MATERIAL_HASH_MISMATCH")
        return record, projection

    def append_pointer(self, args: dict[str, Any], context: Any) -> dict[str, Any]:
        _need(set(args) == {"receipt_ref"} and isinstance(args["receipt_ref"], str)
              and ID.fullmatch(args["receipt_ref"]) is not None,
              "X9_PRODUCER_RECEIPT_REF_ONLY")
        channel, api = self._channel(context)
        record, projection = self._receipt(api, args["receipt_ref"])
        _need(record.get("ready_state") == "MATERIAL_READY", "X9_PM_MATERIAL_NOT_READY")
        _need(type(record.get("owner_seq")) is int and record["owner_seq"] >= 1,
              "X9_PM_OWNER_SEQUENCE_INVALID")
        try:
            observed = datetime.fromisoformat(record["observed_at"].replace("Z", "+00:00"))
        except (KeyError, TypeError, ValueError) as exc:
            raise X9ProducerError("X9_PM_OBSERVED_AT_INVALID") from exc
        _need(observed.tzinfo is not None, "X9_PM_OBSERVED_AT_INVALID")
        expires = (observed.astimezone(timezone.utc) + timedelta(hours=24)).isoformat()
        now = datetime.now(timezone.utc)
        _need(now <= datetime.fromisoformat(expires), "X9_PM_RECEIPT_EXPIRED")
        try:
            pointer = PointerContext(
                event_id=record["event_id"], attempt_id=record["commit_ref"],
                owner_ref=record["owner_ref"], referent_type="PM_READY_HINT",
                revision=record["revision_after"], expected_sha256=record["snapshot_sha256"],
                claim_ref=record["claim_ref"], packet_ref=record["packet_ref"],
                packet_sha256=record["packet_sha256"], queue_ref=record["queue_ref"],
                producer_id=self._config.producer.identity.principal_ref,
                receiver_ref=self._config.receiver.identity.session_ref,
                source_cut=projection["source_cut"], expires_at=expires,
                way_home=tuple(record["way_home"]), referent_id=record["referent_id"],
                owner_seq=record["owner_seq"],
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise X9ProducerError("X9_PM_RECEIPT_FIELDS_INVALID") from exc
        _need(pointer.valid(), "X9_PM_POINTER_CONTEXT_INVALID")
        closure = make_closure(
            event_id=pointer.event_id, owner_ref=pointer.owner_ref,
            referent_type=pointer.referent_type, referent_id=pointer.referent_id,
            revision_after=pointer.revision, disposition="ACK_READ",
            reason="OWNER_READ_MATCHES_EVENT", observed_sha256=pointer.expected_sha256,
            activation=decide_activation("ACK_READ", "SEMANTIC"), way_home=pointer.way_home)
        ingress = X9ChannelIngress(
            enabled=True, channel=channel,
            producer_principal=self._config.producer.identity.principal_ref,
            x9_principal=self._config.receiver.identity.principal_ref,
            x9_session_ref=self._config.receiver.identity.session_ref)
        # An uncertain prior send is reconciled by exact original event read only.
        with self._uncertain_lock:
            uncertain = pointer.event_id in self._uncertain_events
        if uncertain:
            original = PointerRecord(
                SCHEMA, closure.closure_id, pointer.event_id, pointer.attempt_id,
                pointer.owner_ref, pointer.referent_type, pointer.revision,
                pointer.expected_sha256, pointer.claim_ref, pointer.packet_ref,
                pointer.packet_sha256, pointer.queue_ref, pointer.producer_id,
                pointer.receiver_ref, pointer.source_cut, pointer.expires_at,
                pointer.way_home, pointer.referent_id, pointer.owner_seq)
            try:
                readback = channel.read_pointer_by_event_id(pointer.event_id)
            except Exception:
                readback = None
            if X9ChannelIngress._pointer_readback(readback, original, pointer.producer_id):
                return {"state": "DEPOSITED_READBACK", "reason": "EXACT_EVENT_READBACK",
                        "event_id": pointer.event_id, "pointer_sha256": original.content_sha256}
            return {"state": "HOLD_UNREADABLE", "reason": "UNKNOWN_SEND_NO_REPLAY",
                    "event_id": pointer.event_id}
        result = ingress.deposit(closure, pointer, now=now)
        if result.reason == "UNKNOWN_SEND_NO_REPLAY":
            with self._uncertain_lock:
                self._uncertain_events.add(pointer.event_id)
        value = {"state": result.state, "reason": result.reason, "event_id": pointer.event_id}
        if result.pointer_sha256 is not None:
            value["pointer_sha256"] = result.pointer_sha256
        return value
