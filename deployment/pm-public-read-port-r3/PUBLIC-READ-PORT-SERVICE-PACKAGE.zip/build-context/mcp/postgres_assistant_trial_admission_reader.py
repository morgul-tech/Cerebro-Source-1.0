"""LOCAL PREPARATION ONLY: one immutable supplement plus existing 0008 row fences.

No defaults, profile creation, signing, schema writes or general grant surface.
Deployment must separately qualify every writer's lock order and file custody.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import stat
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from assistant_trial_owner import AssistantTrialOwnerRefused, AssistantTrialOwnerResolver


class TrialAdmissionReaderRefused(AssistantTrialOwnerRefused):
    pass


def require(ok, code):
    if not ok:
        raise TrialAdmissionReaderRefused(code)


def exact_text(value):
    return (type(value) is str and bool(value) and value == value.strip()
            and len(value.encode('utf-8')) <= 512
            and not any(ord(c) < 32 or ord(c) == 127 for c in value))


PROFILE_FIELDS = {'schema', 'profile_ref', 'owner_ref', 'owner_revision', 'enabled',
    'trial_scope', 'caller', 'generation_ref', 'source_revision', 'method_fingerprint',
    'expected_revision', 'decision_ref', 'overlay_ref', 'actor_ref',
    'actor_generation_ref', 'recipient_ref', 'trial_target_ref', 'not_before', 'not_after'}
SUPPLEMENT_FIELDS = {'schema', 'profile', 'policy_ref', 'policy_revision',
    'decision_owner_revision', 'owner_authorization_ref', 'writer_contract_ref'}
CALLER_FIELDS = ('tenant_ref', 'workspace_ref', 'principal_ref', 'consumer_ref', 'session_ref')


class PostgresAssistantTrialAdmissionReader:
    def __init__(self, *, connection_factory, profile_ref, supplement_path,
                 supplement_sha256, lock_path, reader_uid, reader_gid,
                 writer_contract_ref):
        require(callable(connection_factory), 'connection-factory-required')
        require(exact_text(profile_ref) and exact_text(writer_contract_ref), 'explicit-owner-refs-required')
        require(type(reader_uid) is int and reader_uid > 0 and type(reader_gid) is int
                and reader_gid >= 0, 'qualified-service-principal-required')
        require(type(supplement_sha256) is str and len(supplement_sha256) == 64
                and all(c in '0123456789abcdef' for c in supplement_sha256), 'immutable-supplement-pin-required')
        self._connect = connection_factory
        self._ref = profile_ref
        self._path = Path(supplement_path)
        self._pin = supplement_sha256
        self._lock = Path(lock_path)
        require(self._path.is_absolute() and self._lock.is_absolute()
                and self._path != self._lock and self._path.parent == self._lock.parent,
                'exact-distinct-private-supplement-and-lock-required')
        self._uid, self._gid = reader_uid, reader_gid
        self._contract = writer_contract_ref
        self._active = ContextVar('postgres_assistant_trial_reader_window', default=None)

    def _open_protected(self, path):
        require(os.name == 'posix' and os.geteuid() == self._uid
                and os.getegid() == self._gid, 'actual-qualified-reader-principal-required')
        for parent in path.parents:
            info = parent.lstat()
            require(stat.S_ISDIR(info.st_mode) and info.st_uid == 0
                    and not info.st_mode & 0o022, 'protected-root-ancestry-required')
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            info = os.fstat(fd)
            current = path.lstat()
            require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                    and info.st_uid == 0 and info.st_gid == self._gid
                    and stat.S_IMODE(info.st_mode) == 0o440
                    and (info.st_dev, info.st_ino) == (current.st_dev, current.st_ino),
                    'immutable-owner-file-custody-required')
            return fd, info
        except BaseException:
            os.close(fd)
            raise

    def _supplement(self, fd):
        os.lseek(fd, 0, os.SEEK_SET)
        raw = os.read(fd, 65537)
        require(len(raw) <= 65536 and hashlib.sha256(raw).hexdigest() == self._pin,
                'supplement-bytes-changed-or-unqualified')
        value = json.loads(raw)
        require(type(value) is dict and set(value) == SUPPLEMENT_FIELDS
                and value['schema'] == 'd1-existing0008-assistant-trial-supplement/v1'
                and value['writer_contract_ref'] == self._contract,
                'exact-qualified-supplement-contract-required')
        profile = value['profile']
        require(type(profile) is dict and set(profile) == PROFILE_FIELDS
                and profile['schema'] == 'cerebro-isolated-assistant-trial-profile/v1'
                and profile['profile_ref'] == self._ref
                and profile['trial_scope'] == 'BUILD7_SINGLE_ISOLATED_ASSISTANT'
                and profile['recipient_ref'] == 'A1' and profile['enabled'] is True,
                'one-trial-profile-not-admitted')
        caller = profile['caller']
        require(type(caller) is dict and set(caller) == set(CALLER_FIELDS)
                and all(exact_text(caller[k]) for k in CALLER_FIELDS),
                'exact-raw-caller-required')
        require(exact_text(profile['owner_revision'])
                and all(exact_text(value[k]) for k in ('policy_ref', 'owner_authorization_ref'))
                and type(value['policy_revision']) is int and value['policy_revision'] > 0
                and type(value['decision_owner_revision']) is int and value['decision_owner_revision'] > 0,
                'actual-owner-revisions-required')
        # Remaining profile validation and time eligibility are enforced by the
        # exact published AssistantTrialOwnerResolver, with an injected real clock.
        return value

    @staticmethod
    def _row(cursor):
        row = cursor.fetchone()
        require(row is not None, 'existing-owner-head-absent')
        if isinstance(row, dict):
            return dict(row)
        require(cursor.description is not None, 'owner-row-description-unavailable')
        return dict(zip([x.name if hasattr(x, 'name') else x[0] for x in cursor.description], row))

    def _policy(self, cursor, supplement, lock):
        profile = supplement['profile']
        caller = profile['caller']
        binding = tuple(caller[k] for k in CALLER_FIELDS)
        suffix = ' FOR SHARE' if lock else ''
        cursor.execute('''SELECT tenant_ref,workspace_ref,principal_ref,consumer_ref,session_ref,
            policy_ref,policy_revision,current,revoked,owner_authorization_ref,allowed_role,source_revision
            FROM cerebro_assistant_overlay_policy_heads
            WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s
            AND consumer_ref=%s AND session_ref=%s AND policy_ref=%s''' + suffix,
            binding + (supplement['policy_ref'],))
        policy = self._row(cursor)
        require(policy.get('current') is True and policy.get('revoked') is False
                and all(policy.get(k) == caller[k] for k in CALLER_FIELDS),
                'raw-current-owner-policy-required')
        require(policy.get('source_revision') == profile['source_revision']
                and policy.get('policy_ref') == supplement['policy_ref']
                and type(policy.get('policy_revision')) is int
                and policy['policy_revision'] == supplement['policy_revision']
                and policy.get('allowed_role') == 'ASSISTANT'
                and policy.get('owner_authorization_ref') == supplement['owner_authorization_ref'],
                'qualified-assistant-owner-policy-required')
        return policy

    def _heads(self, cursor, supplement, lock):
        policy = self._policy(cursor, supplement, lock)
        profile = supplement['profile']
        caller = profile['caller']
        binding = tuple(caller[k] for k in CALLER_FIELDS)
        suffix = ' FOR SHARE' if lock else ''
        cursor.execute('''SELECT tenant_ref,workspace_ref,principal_ref,consumer_ref,session_ref,
            generation_ref,decision_ref,policy_ref,policy_revision,owner_revision,current,revoked,
            expected_revision,source_revision,overlay_ref,actor_ref,actor_generation_ref,
            pre_role_fingerprint,ready_unbound_receipt_fingerprint
            FROM cerebro_assistant_overlay_decision_heads
            WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s
            AND consumer_ref=%s AND session_ref=%s AND generation_ref=%s''' + suffix,
            binding + (profile['generation_ref'],))
        decision = self._row(cursor)
        for row in (policy, decision):
            require(row.get('current') is True and row.get('revoked') is False,
                    'owner-head-not-current-or-revoked')
            require(all(row.get(k) == caller[k] for k in CALLER_FIELDS), 'raw-owner-tuple-mismatch')
            require(row.get('source_revision') == profile['source_revision']
                    and row.get('policy_ref') == supplement['policy_ref']
                    and type(row.get('policy_revision')) is int
                    and row['policy_revision'] == supplement['policy_revision'], 'owner-policy-revision-or-source-mismatch')
        require(policy.get('allowed_role') == 'ASSISTANT'
                and policy.get('owner_authorization_ref') == supplement['owner_authorization_ref'],
                'qualified-assistant-owner-policy-required')
        require(type(decision.get('owner_revision')) is int
                and decision['owner_revision'] == supplement['decision_owner_revision'],
                'decision-owner-revision-changed')
        require(all(decision.get(k) == profile[k] for k in ('generation_ref', 'decision_ref',
                'expected_revision', 'overlay_ref', 'actor_ref', 'actor_generation_ref')),
                'fixed-one-trial-decision-mismatch')
        require(all(type(decision.get(k)) is str and len(decision[k]) == 64
                    and all(c in '0123456789abcdef' for c in decision[k])
                    for k in ('pre_role_fingerprint', 'ready_unbound_receipt_fingerprint')),
                'actual-existing-ready-fingerprints-required')
        return policy, decision

    @staticmethod
    def _close(connection, cursor, original):
        first = None
        for obj, method in ((connection, 'rollback'), (cursor, 'close'), (connection, 'close')):
            if obj is not None:
                try:
                    getattr(obj, method)()
                except BaseException as exc:
                    first = first or exc
        if original is None and first is not None:
            raise TrialAdmissionReaderRefused('owner-window-release-unavailable') from first

    @contextmanager
    def hold_current(self, profile_ref):
        require(profile_ref == self._ref and self._active.get() is None, 'exact-nonnested-profile-required')
        import fcntl
        lock_fd = profile_fd = connection = cursor = token = None
        original = None
        try:
            lock_fd, lock_info = self._open_protected(self._lock)
            fcntl.flock(lock_fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
            profile_fd, profile_info = self._open_protected(self._path)
            supplement = self._supplement(profile_fd)
            connection = self._connect()
            cursor = connection.cursor()
            cursor.execute("SET LOCAL statement_timeout = '5s'")
            baseline = self._heads(cursor, supplement, True)
            window_ref = 'assistant-owner-window:' + uuid.uuid4().hex
            active = {'window_ref': window_ref, 'supplement': supplement, 'profile_fd': profile_fd,
                'profile_info': profile_info, 'lock_info': lock_info, 'cursor': cursor, 'baseline': baseline}
            token = self._active.set(active)
            self.assert_current(profile_ref, window_ref, supplement['profile']['owner_revision'])
            yield {'window_ref': window_ref, 'profile': copy.deepcopy(supplement['profile'])}
        except BaseException as exc:
            original = exc
            raise
        finally:
            if token is not None:
                self._active.reset(token)
            release_error = None
            try:
                self._close(connection, cursor, original)
            except BaseException as exc:
                release_error = exc
            if profile_fd is not None:
                try:
                    os.close(profile_fd)
                except BaseException as exc:
                    release_error = release_error or exc
            if lock_fd is not None:
                try:
                    fcntl.flock(lock_fd, fcntl.LOCK_UN)
                except BaseException as exc:
                    release_error = release_error or exc
                finally:
                    try:
                        os.close(lock_fd)
                    except BaseException as exc:
                        release_error = release_error or exc
            if original is None and release_error is not None:
                raise TrialAdmissionReaderRefused('owner-window-release-unavailable') from release_error

    def assert_current(self, profile_ref, window_ref, owner_revision):
        active = self._active.get()
        require(active is not None and profile_ref == self._ref
                and window_ref == active['window_ref']
                and owner_revision == active['supplement']['profile']['owner_revision'],
                'actual-held-window-and-revision-required')
        for path, info in ((self._path, active['profile_info']), (self._lock, active['lock_info'])):
            current = path.lstat()
            require(stat.S_ISREG(current.st_mode) and current.st_nlink == 1
                    and current.st_uid == 0 and current.st_gid == self._gid
                    and stat.S_IMODE(current.st_mode) == 0o440
                    and (current.st_dev, current.st_ino) == (info.st_dev, info.st_ino),
                    'owner-file-or-lock-inode-changed')
        require(self._supplement(active['profile_fd']) == active['supplement'], 'immutable-profile-changed')
        require(self._heads(active['cursor'], active['supplement'], False) == active['baseline'],
                'held-owner-head-changed')

    def assert_ready_binding(self, pre_role_generation):
        active = self._active.get()
        require(active is not None, 'actual-owner-window-required-for-ready-binding')
        profile = active['supplement']['profile']
        self.assert_current(self._ref, active['window_ref'], profile['owner_revision'])
        decision = active['baseline'][1]
        receipt = pre_role_generation.get('ready_unbound_receipt')
        require(type(receipt) is dict
                and decision['pre_role_fingerprint'] == pre_role_generation.get('fingerprint')
                and decision['ready_unbound_receipt_fingerprint'] == receipt.get('receipt_fingerprint'),
                'existing-owner-decision-ready-binding-mismatch')


class Existing0008AssistantTrialResolver(AssistantTrialOwnerResolver):
    """Keep the existing 0008 actual-ready fingerprints as well as Source checks."""
    def __init__(self, *, profile_ref, admission_reader, clock):
        require(type(admission_reader) is PostgresAssistantTrialAdmissionReader,
                'exact-qualified-existing0008-reader-required')
        super().__init__(profile_ref=profile_ref, admission_reader=admission_reader, clock=clock)
        self._existing_reader = admission_reader

    def resolve(self, *, pre_role_generation, verified_source, identity, session_ref):
        self._existing_reader.assert_ready_binding(pre_role_generation)
        return super().resolve(pre_role_generation=pre_role_generation,
            verified_source=verified_source, identity=identity, session_ref=session_ref)


class Existing0008ProposalAdmissionReader(PostgresAssistantTrialAdmissionReader):
    """Only the existing local proposal ABI, never a host attach decision reader.

The proposal may precede birth, so it fences actual policy plus profile without
claiming any READY decision. Host attach still uses the exact full reader above.
"""
    def _heads(self, cursor, supplement, lock):
        return self._policy(cursor, supplement, lock), None

    def assert_ready_binding(self, pre_role_generation):
        raise TrialAdmissionReaderRefused('proposal-reader-cannot-admit-host-attach')


class Existing0008ProposalGate:
    """Expose only Source's optional check_client_admission(request) interface."""
    def __init__(self, *, profile_ref, admission_reader, clock):
        require(type(admission_reader) is Existing0008ProposalAdmissionReader,
                'exact-proposal-reader-required')
        self._checker = AssistantTrialOwnerResolver(
            profile_ref=profile_ref, admission_reader=admission_reader, clock=clock)

    def check_client_admission(self, request):
        return self._checker.check_client_admission(request)
