"""Existing service pair's installer-selected project actor-material scope.

This is not a chat grant. The real service assignment/lease/current/route guard
must already have succeeded. Legacy EXACT_OWNER behavior is unchanged.
"""
import json
from actor_admission_model import SCHEMA,AGGREGATE,canonical,digest,need
from pm_owner_atomic import _row

def generic(assignment):return assignment.get('room_return_scope','EXACT_OWNER')=='PROJECT_ADMITTED_ACTORS'
def owner_column(assignment):return ('project_ref',assignment['project_ref']) if generic(assignment) else ('owner_ref',assignment['room_owner_ref'])

def qualify(c,assignment,row):
    if not generic(assignment):return
    need(assignment['owner_family']=='ROOM_RETURN','PROJECT_SCOPE_REQUIRES_ROOM_FAMILY')
    if row['owner_ref']==assignment['room_owner_ref']:
        # Preserve the existing exact owner's already admitted path; its producer
        # still has the original exact static binding, not a generic wildcard.
        return
    access={'project_ref':assignment['project_ref'],'principal_ref':assignment['principal_ref'],'mode':'SERVICE_READ'}
    c.execute("SELECT set_config('cerebro.actor_admission_access',%s,true)",(canonical(access).decode(),))
    c.execute('''SELECT state_schema,state_payload,state_fingerprint FROM cerebro_owner_state_heads
        WHERE tenant_ref=%s AND workspace_ref=%s AND project_ref=%s AND owner='project' AND aggregate_ref=%s''',
        (assignment['tenant_ref'],assignment['workspace_ref'],assignment['project_ref'],AGGREGATE))
    root=_row(c);need(root is not None and root['state_schema']==SCHEMA,'PROJECT_MATERIAL_OWNER_RECORD_REQUIRED')
    doc=json.loads(root['state_payload']) if type(root['state_payload'])is str else root['state_payload']
    need(digest(doc)==root['state_fingerprint'],'PROJECT_MATERIAL_OWNER_INTEGRITY')
    material=doc['materials'].get(row['assignment_ref']);need(material is not None,'EXACT_DURABLE_MATERIAL_ADMISSION_REQUIRED')
    from actor_material_provider import business_scope
    scope=business_scope(material,assignment['project_ref'],assignment)
    need(all(row.get(k)==v for k,v in scope.items()) and row['expected_action']==material['expected_action']
         and row['binding_revision']==material['route']['binding_revision'],'SERVICE_MATERIAL_SCOPE_MISMATCH')
    if assignment['service_role']=='receiver':
        need(assignment['assignment_ref']==material['route']['receiver_assignment_ref'],'MATERIAL_RECEIVER_ASSIGNMENT_MISMATCH')
    import hashlib
    need(hashlib.sha256(row['material'].encode()).hexdigest()==material['material_sha256']
         and hashlib.sha256(row['envelope'].encode()).hexdigest()==material['envelope_sha256'],
         'SERVICE_MATERIAL_CONTENT_INTEGRITY')
