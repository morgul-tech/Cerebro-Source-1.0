"""Resolve real task material from the selected durable project-owner aggregate.

No wildcard digest, per-material environment, request-selected identity or lease.
Current carrier gates serialize registration against the owner's move commit.
"""
import hashlib,json
from datetime import datetime,timezone
from pm_owner_atomic import _row
from actor_admission_model import (AdmissionRefused,caller,own_actor,active,digest,canonical,need,participants,producer_snapshot,task_entry)
from room_return_d1_outbox import RoomReturnD1Outbox,RoomReturnProducerBinding,RoomReturnRefused,_canonical,_sha
from room_return_actor_reader import RoomReturnActorReader,RoomReturnActorReadBinding,RoomReturnActorIdentity,ROW_BINDING_FIELDS

def business_scope(material,project,who):
    route=material['route']
    return {'tenant_ref':who['tenant_ref'],'workspace_ref':who['workspace_ref'],'project_ref':project,
            'owner_ref':material['owner_actor_ref'],'task_ref':material['task_ref'],
            'material_revision':material['material_revision'],'source_original_ref':material['original_ref'],
            'parent_sha256':material['parent_sha256'],'material_sha256':material['material_sha256'],
            'envelope_sha256':material['envelope_sha256'],'recipient_ref':material['recipient_actor_ref'],
            'route_owner_ref':route['transport_owner_ref'],'route_ref':route['route_ref'],'receiver_ref':route['receiver_ref']}

def binding_for(material,doc,who,project):
    a=active(doc,material['sender_actor_ref'],who)
    return _producer_binding(material,who,project,producer_snapshot(a))

def accepted_binding_for(material,doc,who,project):
    origin=material.get('producer')
    if origin is None:
        sender=participants(doc)[material['sender_actor_ref']]
        need(not sender.get('retired_carriers'),'LEGACY_ORIGINAL_PRODUCER_MISSING_NO_RECONSTRUCTION')
        origin=producer_snapshot(sender)
    return _producer_binding(material,who,project,origin)

def _producer_binding(material,who,project,origin):
    r=material['route']
    return RoomReturnProducerBinding.from_mapping(dict(assignment_ref=material['material_ref'],
        tenant_ref=who['tenant_ref'],workspace_ref=who['workspace_ref'],project_ref=project,
        principal_ref=origin['principal_ref'],consumer_ref=origin['consumer_ref'],session_ref=origin['session_ref'],
        session_binding_id=origin['session_binding_id'],owner_ref=material['owner_actor_ref'],task_ref=material['task_ref'],
        material_revision=material['material_revision'],original_ref=material['original_ref'],expected_action=material['expected_action'],
        parent_sha256=material['parent_sha256'],material_sha256=material['material_sha256'],envelope_sha256=material['envelope_sha256'],
        recipient_ref=material['recipient_actor_ref'],receiver_ref=r['receiver_ref'],route_ref=r['route_ref'],
        transport_owner_ref=r['transport_owner_ref'],binding_revision=r['binding_revision'],pointer_ttl_seconds=r['pointer_ttl_seconds']))

def binding_from_original(row,ttl):
    values={attr:row[field] for field,attr in ROW_BINDING_FIELDS.items()}
    values['pointer_ttl_seconds']=ttl
    return RoomReturnProducerBinding.from_mapping(values)

class ActorMaterialProvider:
    def __init__(self,host):self.host=host;self.state=host.state;self.store=host.store
    def _project(self,context):
        from control_context_state_port import StateBindingError
        who=caller(context)
        try:current=self.state.read_session(**who,scopes=context.identity.state_scopes)
        except StateBindingError as error:
            if str(error) in ('control-session-not-bound','session-read-result-missing'):return None
            raise
        return current
    def _load(self,context):
        current=self._project(context)
        if current is None:return None
        project=current['project_ref']
        who=caller(context)
        with self.store.transaction(who,project,write=False,mode='ACTOR_READ') as c:
            before=self.store.load(c,who,project)
        doc=before['payload'];key=None
        for actor_ref,a in participants(doc).items():
            from actor_admission_model import carrier_matches
            if carrier_matches(a,who):key=actor_ref;break
            for old in a.get('retired_carriers',[]):
                need(not all(old['carrier'][k]==who[k] for k in ('principal_ref','consumer_ref','session_ref')),
                     'OLD_CARRIER_EXECUTION_FENCED')
        if key is None:return None
        active(doc,key,who)
        actor=participants(doc)[key]
        need(actor['session_binding_id']==current['session_binding_id'],
             'OWN_CURRENT_SESSION_BINDING_CHANGED_REQUALIFY_DESTINATION')
        if actor.get('kind')!='AUTHENTICATED_BUSINESS_PARTY':
            need(self.host._native(actor,context,doc)==actor['native_snapshot'],'ACTUAL_NATIVE_ROLE_CHANGED_REQUALIFY_OWNER')
        return project,who,doc,key
    @staticmethod
    def _window(doc,material):
        _,task=task_entry(doc,material['task_ref'],material['attempt_ref'])
        need(task is not None,'SELECTED_TASK_PHASE_REQUIRED');now=datetime.now(timezone.utc)
        return datetime.fromisoformat(task['not_before'].replace('Z','+00:00'))<=now<datetime.fromisoformat(task['expires_at'].replace('Z','+00:00'))
    def register(self,args,context):
        found=self._load(context)
        if found is None:return None # Legacy singleton remains a legitimate separate path.
        project,who,doc,key=found
        need(type(args)is dict and set(args)=={'idempotency_key','material','envelope'}
             and type(args['material'])is str and 0<len(args['material'].encode())<=16384
             and type(args['envelope'])is str and 0<len(args['envelope'].encode())<=4096,'EXACT_MATERIAL_FIELDS')
        mh=hashlib.sha256(args['material'].encode()).hexdigest();eh=hashlib.sha256(args['envelope'].encode()).hexdigest()
        matches=[m for m in doc['materials'].values() if m['sender_actor_ref']==key
                 and m['material_sha256']==mh and m['envelope_sha256']==eh]
        need(len(matches)==1,'DURABLE_EXACT_SELECTED_MATERIAL_REQUIRED')
        material=matches[0];need(self._window(doc,material),'TASK_PERMISSION_EXPIRED')
        if material.get('producer') is not None:
            need(material['producer']==producer_snapshot(participants(doc)[key]),
                 'ORIGINAL_PRODUCER_SESSION_CHANGED_RECONCILE_NO_REAUTHOR')
        binding=binding_for(material,doc,who,project)
        def guarded_registration(c,b,args,ctx):
            c.execute("SELECT set_config('cerebro.actor_admission_access',%s,true)",
                      (canonical({'project_ref':project,'principal_ref':who['principal_ref'],'mode':'ACTOR_READ'}).decode(),))
            # Registration is a write transaction, so a real row SHARE lock is
            # legal. Move's UPDATE waits until the admitted outbox commit ends.
            from actor_admission_model import AGGREGATE
            c.execute('''SELECT state_payload,state_schema,state_fingerprint FROM cerebro_owner_state_heads WHERE tenant_ref=%s AND workspace_ref=%s
                AND project_ref=%s AND owner='project' AND aggregate_ref=%s FOR SHARE''',
                (who['tenant_ref'],who['workspace_ref'],project,AGGREGATE))
            row=_row(c);need(row is not None,'CURRENT_ADMISSION_MISSING')
            current=json.loads(row['state_payload']) if type(row['state_payload'])is str else row['state_payload']
            from actor_admission_model import SCHEMA
            need(row['state_schema']==SCHEMA and current.get('schema')==SCHEMA
                 and digest(current)==row['state_fingerprint'],'CURRENT_ADMISSION_INTEGRITY')
            actor=active(current,key,who)
            need(material['recipient_actor_ref'] in actor['allowed_peers'] and material['route']['route_ref'] in actor['allowed_routes'],
                 'CURRENT_TASK_PEER_ROUTE_SCOPE_REVOKED')
            need(actor.get('route_bindings',{}).get(material['route']['route_ref'])==material['route'],
                 'CURRENT_TASK_ROUTE_BINDING_REVOKED')
            need(participants(current)[key]['epoch']==participants(doc)[key]['epoch']
                 and current['materials'].get(material['material_ref'])==material and self._window(current,material),
                 'CARRIER_OR_MATERIAL_CHANGED_BEFORE_REGISTER')
        def guarded_prior(row,b,args,ctx):
            scope=business_scope(material,project,who)
            need(all(row[k]==v for k,v in scope.items()) and row['expected_action']==material['expected_action']
                 and row['assignment_ref']==material['material_ref'],'ORIGINAL_MATERIAL_CONFLICT_NO_REPLAY')
            original=binding_from_original(row,material['route']['pointer_ttl_seconds'])
            # Existing bytes belong to their original producer. A moved sender
            # reads that exact prior receipt; it never writes as the old caller.
            fields={**{field:row[field] for field in ('assignment_ref','task_ref','material_revision','parent_sha256',
                'expected_action','tenant_ref','workspace_ref','project_ref','owner_ref','producer_principal_ref',
                'producer_consumer_ref','producer_session_ref','producer_session_binding_id','material_sha256','envelope_sha256',
                'material_bytes','material','envelope','recipient_ref','receiver_ref','route_ref','route_owner_ref','binding_revision')},
                'original_ref':row['source_original_ref']}
            need(_sha(_canonical(fields))==row['event_fingerprint'] and row['material']==args['material']
                 and row['envelope']==args['envelope'] and _sha(bytes(row['pointer']))==row['pointer_sha256'],
                 'ORIGINAL_OWNER_RECEIPT_INTEGRITY')
        def guard(*values):
            try:return guarded_registration(*values)
            except AdmissionRefused as error:raise RoomReturnRefused(str(error)) from None
        def prior(*values):
            try:return guarded_prior(*values)
            except AdmissionRefused as error:raise RoomReturnRefused(str(error)) from None
        try:return RoomReturnD1Outbox(state_port=self.state,binding=binding,registration_guard=guard,prior_validator=prior).register(args,context)
        except AdmissionRefused as error:raise RoomReturnRefused(str(error)) from None

    def read_accepted(self,args,context):
        need(type(args)is dict and args.get('op') in ('read_exact','list_accepted')
             and set(args)<= {'op','message_id','after','material_ref'},'OWN_ACCEPTED_READ_FIELDS')
        need((args['op']=='read_exact' and set(args)=={'op','message_id','material_ref'}) or
             (args['op']=='list_accepted' and 'message_id' not in args),'OWN_ACCEPTED_READ_SHAPE')
        from actor_admission_model import reference
        for field in ('message_id','material_ref','after'):
            if field in args:reference(args[field])
        found=self._load(context)
        if found is None:return None
        project,who,doc,key=found
        materials=sorted((m for m in doc['materials'].values() if m['recipient_actor_ref']==key),key=lambda m:m['material_ref'])
        outside_window=sum(not self._window(doc,m) for m in materials)
        if args['op']=='list_accepted':
            # An expired historical task must not poison the whole page and
            # prevent a later authorized task from reaching the same actor.
            # Exact stale reads retain the reader's explicit expiry refusal.
            materials=[m for m in materials if self._window(doc,m)]
        if args['op']=='read_exact':materials=[m for m in materials if m['material_ref']==args['material_ref']]
        if args.get('after') is not None:materials=[m for m in materials if m['material_ref']>args['after']]
        selected=materials[:8];bindings=[]
        reader=RoomReturnActorIdentity(**who,project_ref=project,session_binding_id=participants(doc)[key]['session_binding_id'])
        for material in selected:
            # These are EXPECTED ROW FIELDS from committed owner data, never an
            # authenticated context or foreign state-port invocation. No MOVE is
            # supported; original producer metadata remains immutable.
            producer=accepted_binding_for(material,doc,who,project)
            _,task=task_entry(doc,material['task_ref'],material['attempt_ref'])
            need(task is not None,'SELECTED_TASK_PHASE_REQUIRED')
            bindings.append(RoomReturnActorReadBinding(material['material_ref'],producer,reader,
                material['route']['receiver_assignment_ref'],material['attempt_ref'],material['artifact_ref'],
                task['not_before'],task['expires_at']))
        if bindings:
            query={'op':args['op']}
            if 'message_id' in args:query['message_id']=args['message_id']
            def authorize(c,ctx):
                # Revalidate in the accepted-reader's own read snapshot. No
                # read-only row lock or foreign session identity is substituted.
                c.execute("SELECT set_config('cerebro.actor_admission_access',%s,true)",
                    (canonical({'project_ref':project,'principal_ref':who['principal_ref'],'mode':'ACTOR_READ'}).decode(),))
                from actor_admission_model import AGGREGATE,SCHEMA
                c.execute('''SELECT state_payload,state_schema,state_fingerprint FROM cerebro_owner_state_heads
                    WHERE tenant_ref=%s AND workspace_ref=%s AND project_ref=%s
                    AND owner='project' AND aggregate_ref=%s''',
                    (who['tenant_ref'],who['workspace_ref'],project,AGGREGATE))
                row=_row(c);need(row is not None,'CURRENT_ADMISSION_MISSING')
                current=json.loads(row['state_payload']) if type(row['state_payload'])is str else row['state_payload']
                need(row['state_schema']==SCHEMA and current.get('schema')==SCHEMA and
                     digest(current)==row['state_fingerprint'],'CURRENT_ADMISSION_INTEGRITY')
                actor=active(current,key,who)
                need(actor['epoch']==participants(doc)[key]['epoch'] and
                     actor['session_binding_id']==reader.session_binding_id,'READER_ADMISSION_CHANGED')
                need(all(current['materials'].get(m['material_ref'])==m for m in selected),
                     'ACCEPTED_MATERIAL_BASIS_CHANGED')
            def guard(c,ctx):
                try:authorize(c,ctx)
                except AdmissionRefused as error:raise RoomReturnRefused(str(error)) from None
            result=RoomReturnActorReader(self.state,tuple(bindings),authorization_guard=guard).read(query,context)
        else:result={'rows':[],'dispatch_performed':False,'business_completion_recorded':False}
        result['next']=selected[-1]['material_ref'] if len(materials)>8 else None
        # Lexicographic cursor spans this scan only: acceptance may occur behind it.
        # Consumers must follow next across empty pages and restart the next check.
        result['scan_cursor_scope']='ONE_BOUNDED_SCAN'
        result['restart_next_check']='FROM_BEGINNING'
        result['page_size']=8
        result['dedupe_by']='business_dedupe_key_AFTER_ACTUAL_WORK'
        result['out_of_window_materials']=outside_window
        result['out_of_window_owner_disposition_required']=outside_window>0
        return result
