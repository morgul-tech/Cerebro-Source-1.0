"""LOCAL PREPARATION: constructor only; never imported or wired in serving app.

Every input must come from a separately qualified actual owner cut. This function
creates no profile/row/key/clock and changes no existing runtime object.
"""
from postgres_assistant_trial_admission_reader import (
    PostgresAssistantTrialAdmissionReader, Existing0008AssistantTrialResolver,
    TrialAdmissionReaderRefused,
    Existing0008ProposalAdmissionReader, Existing0008ProposalGate,
)


def prepare_constructor_objects(*, connection_factory, profile_ref,
        supplement_path, supplement_sha256, lock_path, reader_uid, reader_gid,
        writer_contract_ref, real_clock, existing_issuer, existing_verifier,
        current_source_continuity_verifier):
    if (not callable(real_clock) or existing_issuer is not existing_verifier
            or not callable(getattr(existing_issuer, 'seal', None))
            or not callable(getattr(existing_verifier, 'verify', None))
            or not callable(current_source_continuity_verifier)):
        raise TrialAdmissionReaderRefused('qualified-existing-constructor-inputs-required')
    reader = PostgresAssistantTrialAdmissionReader(
        connection_factory=connection_factory, profile_ref=profile_ref,
        supplement_path=supplement_path, supplement_sha256=supplement_sha256,
        lock_path=lock_path, reader_uid=reader_uid, reader_gid=reader_gid,
        writer_contract_ref=writer_contract_ref)
    resolver = Existing0008AssistantTrialResolver(
        profile_ref=profile_ref, admission_reader=reader, clock=real_clock)
    host_arguments = {
        'assistant_overlay_control_resolver': resolver,
        'assistant_overlay_attestation_issuer': existing_issuer,
        'resolution_attestation_verifier': existing_verifier,
        'assistant_overlay_source_continuity_verifier': current_source_continuity_verifier,
    }
    proposal_reader = Existing0008ProposalAdmissionReader(
        connection_factory=connection_factory, profile_ref=profile_ref,
        supplement_path=supplement_path, supplement_sha256=supplement_sha256,
        lock_path=lock_path, reader_uid=reader_uid, reader_gid=reader_gid,
        writer_contract_ref=writer_contract_ref)
    proposal_gate = Existing0008ProposalGate(
        profile_ref=profile_ref, admission_reader=proposal_reader, clock=real_clock)
    return {'host_constructor_arguments': host_arguments,
            'client_proposal_owner_gate': proposal_gate}
