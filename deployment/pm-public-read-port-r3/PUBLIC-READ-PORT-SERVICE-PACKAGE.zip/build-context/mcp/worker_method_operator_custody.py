"""Route B permit: actual OS/service DB custody, never an OAuth/tool JSON identity."""
from __future__ import annotations
import json,math,os,stat,time
from pathlib import Path
from worker_method_adoption import digest,need,WorkerMethodAdoptionError
from control_context_state_postgres import _fetchone
_KEY=object()
INPUT=Path('/run/cerebro/worker-method-owner-operation.json')
def _operator_uid():return os.geteuid() if hasattr(os,'geteuid') else None
def _privileged_os():return os.name=='posix' and _operator_uid()==0

class _Permit:
    def __init__(self,key,value,expires):self._key=key;self.value=value;self.expires=expires

def private_input(path=INPUT,*,check_window=True):
    need(_privileged_os(),'method-operator-privileged-os-custody-required')
    # Exact fixed root-owned private regular file, never symlink/caller-selected path.
    for parent in path.parents:
        parent_info=parent.lstat()
        need(stat.S_ISDIR(parent_info.st_mode) and parent_info.st_uid==0
             and not (stat.S_IMODE(parent_info.st_mode)&0o022),'method-operator-parent-custody')
    info=path.lstat()
    need(stat.S_ISREG(info.st_mode) and info.st_uid==0 and info.st_nlink==1
         and stat.S_IMODE(info.st_mode)==0o600 and info.st_size<=1048576,
         'method-operator-private-input-custody')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        opened=os.fstat(fd)
        need((opened.st_dev,opened.st_ino,opened.st_uid,opened.st_mode,opened.st_size)==
             (info.st_dev,info.st_ino,info.st_uid,info.st_mode,info.st_size),'method-operator-input-race')
        raw=os.read(fd,1048577)
    finally:os.close(fd)
    def pairs(items):
        result={}
        for k,v in items:
            need(k not in result,'method-operator-duplicate-input-key');result[k]=v
        return result
    value=json.loads(raw,object_pairs_hook=pairs)
    need(type(value)is dict and set(value)=={'schema','authorization_ref','operator_ref','not_before',
         'expires_at','allowed_operations','qualification_fingerprint','policy','standing_owner_identity',
         'operation','arguments','decision_material','package_fingerprint'},'method-operator-input-fields')
    return validate_envelope(value,check_window=check_window)

def validate_envelope(value,*,check_window=True):
    need(type(value)is dict and set(value)=={'schema','authorization_ref','operator_ref','not_before','expires_at',
        'allowed_operations','qualification_fingerprint','policy','standing_owner_identity','operation','arguments',
        'decision_material','package_fingerprint'},'method-operator-envelope-fields')
    need(value['schema']=='cerebro-worker-method-operator-input/v1','method-operator-input-schema')
    need(type(value['allowed_operations'])is list and bool(value['allowed_operations'])
         and len(value['allowed_operations'])==len(set(value['allowed_operations']))
         and set(value['allowed_operations']).issubset({'PUBLISH','REVOKE','RECONCILE','MIGRATE'}),
         'method-operator-exact-allowed-operations')
    need(all(type(value[k])is str and 0<len(value[k].strip())<=256 for k in ('authorization_ref','operator_ref'))
         and type(value['arguments'])is dict and type(value['policy'])is dict
         and type(value['standing_owner_identity'])is dict,'method-operator-provenance-types')
    need(value['operation'] in {'PUBLISH','REVOKE','RECONCILE','MIGRATE'}
         and value['operation'] in value['allowed_operations'],'method-operator-operation-not-released')
    if check_window:require_window(value)
    return value

def require_window(value):
    need(all(type(value[k])in (int,float) and math.isfinite(value[k]) for k in ('not_before','expires_at'))
         and value['not_before']<=time.time()<value['expires_at'],'method-operator-release-not-current')

def database_identity(cursor):
    cursor.execute('SELECT current_database() AS database_ref,session_user AS operator_database_role, '
                   'current_setting(\'server_version_num\') AS server_version_num,current_schemas(false) AS effective_schemas, '
                   'has_schema_privilege(current_user,\'public\',\'USAGE\') AND has_schema_privilege(current_user,\'public\',\'CREATE\') AS schema_privilege')
    row=_fetchone(cursor);need(row is not None,'method-operator-db-identity-unavailable')
    return row

def qualify_permit(connection_factory,envelope):
    need(_privileged_os(),'method-operator-privileged-os-custody-required')
    require_window(envelope)
    connection=connection_factory()
    try:
        cursor=connection.cursor()
        try:
            cursor.execute('SET TRANSACTION READ ONLY')
            identity=database_identity(cursor)
            need(identity['effective_schemas']==['public'],'method-operator-public-schema-binding-required')
            need(digest(identity)==envelope['qualification_fingerprint'],'method-operator-db-qualification-drift')
            cursor.execute("SELECT has_table_privilege(current_user,'public.cerebro_worker_method_owner_authorization_revisions','SELECT') AND has_table_privilege(current_user,'public.cerebro_worker_method_owner_authorization_revisions','INSERT') AS permitted")
            need(_fetchone(cursor)['permitted']is True,'method-operator-owner-ledger-rights-required')
        finally:cursor.close();connection.rollback()
    finally:connection.close()
    value={'route':'EXISTING_PRIVILEGED_CONTEXT_SERVICE_DB_OPERATOR','operator_ref':envelope['operator_ref'],
           'authorization_ref':envelope['authorization_ref'],'os_uid':_operator_uid(),
           'database_identity':identity,'package_fingerprint':envelope['package_fingerprint'],
           'private_input_fingerprint':digest(envelope)}
    return _Permit(_KEY,value,envelope['expires_at'])

def require_operator_permit(permit):
    need(type(permit)is _Permit and permit._key is _KEY and _privileged_os() and time.time()<permit.expires,'method-operator-current-private-custody-required')
    return dict(permit.value)

def guard_operator(cursor,permit):
    value=require_operator_permit(permit)
    need(database_identity(cursor)==value['database_identity'],'method-operator-db-identity-changed')
    cursor.execute("SELECT has_table_privilege(current_user,'public.cerebro_worker_method_owner_authorization_revisions','SELECT') AND has_table_privilege(current_user,'public.cerebro_worker_method_owner_authorization_revisions','INSERT') AS permitted")
    need(_fetchone(cursor)['permitted']is True,'method-operator-owner-ledger-rights-lost')
