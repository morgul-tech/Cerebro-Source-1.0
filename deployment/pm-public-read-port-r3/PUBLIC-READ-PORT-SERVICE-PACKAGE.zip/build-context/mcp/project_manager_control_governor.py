#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import json
import sys
from typing import Any

SCHEMA = "cerebro-project-manager-control-governor/v1"
DECISION_SCHEMA = "cerebro-project-manager-control-governor-decision/v1"
PROFILE_VERIFICATION_SCHEMA = "cerebro-project-manager-profile-verification/v1"
LIFECYCLE_EFFECT_VERIFICATION_SCHEMA = "cerebro-context-lifecycle-effect-verification/v1"

FRONTIER_ACTORS = {"PROJECT_MANAGER", "HUMAN"}
FRONTIER_STATES = {"PENDING", "COMPLETE", "BLOCKED", "SKIPPED"}
INTERRUPTS = {"NONE", "PAUSE", "STOP", "TERMINATE"}
TERMINAL_STATES = {"ACTIVE", "COMPLETE", "STOP", "TERMINATE"}
CONTINUATION_DISPOSITIONS = {
    "PENDING", "HANDOFF", "NONE_REQUIRED", "RECOVERY_REVIEW", "NON_PROPAGATING"
}
LEARNING_DISPOSITIONS = {
    "PENDING", "GENERALIZABLE_LEARNING_CANDIDATE", "NO_GENERALIZABLE_LEARNING",
    "RECOVERY_REVIEW_ONLY", "NON_PROPAGATING"
}

EXECUTION_STATES = {"ACTIVE", "TERMINAL_REPORTED", "CLOSED"}
VERIFICATION_STATES = {"NOT_REQUIRED", "PENDING", "PASS", "FAIL", "UNAVAILABLE", "UNKNOWN"}
ADMISSION_STATES = {"NOT_REQUIRED", "PENDING", "ADMITTED", "REJECTED"}
EVIDENCE_CARRIER_STATES = {"NOT_APPLICABLE", "AVAILABLE", "UNAVAILABLE", "ERROR", "UNKNOWN"}


class ProjectManagerGovernorError(ValueError):
    pass


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ProjectManagerGovernorError(message)


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _fingerprint(value: dict[str, Any]) -> str:
    subject = copy.deepcopy(value)
    subject.pop("decision_fingerprint", None)
    subject.pop("decision_ref", None)
    return hashlib.sha256(_canonical(subject)).hexdigest()


def _verify_profile(
    *,
    profile_binding: Any,
    session: dict[str, Any],
    profile_verifier: Any | None,
) -> dict[str, Any]:
    _require(isinstance(profile_binding, dict), "trusted-pm-profile-binding-required")
    _require(profile_verifier is not None, "constructor-bound-pm-profile-verifier-required")
    verify = getattr(profile_verifier, "verify", None)
    _require(callable(verify), "pm-profile-verifier-invalid")
    try:
        result = verify(binding=copy.deepcopy(profile_binding), session=copy.deepcopy(session))
    except Exception as exc:
        raise ProjectManagerGovernorError(f"pm-profile-verification-failed:{exc}") from exc
    _require(isinstance(result, dict), "pm-profile-verification-object-required")
    _require(result.get("schema") == PROFILE_VERIFICATION_SCHEMA, "pm-profile-verification-schema-mismatch")
    _require(result.get("result") == "PASS", "pm-profile-verification-nonpass")
    _require(result.get("profile") == "PROJECT_MANAGER", "pm-profile-must-be-PROJECT_MANAGER")
    _require(result.get("session_ref") == session.get("session_ref"), "pm-profile-session-ref-mismatch")
    _require(
        isinstance(result.get("binding_fingerprint"), str) and len(result["binding_fingerprint"]) == 64,
        "pm-profile-binding-fingerprint-required",
    )
    _require(
        isinstance(result.get("verifier_ref"), str) and bool(result["verifier_ref"].strip()),
        "pm-profile-verifier-ref-required",
    )
    return result


def _validate_frontier(candidate: dict[str, Any], canonical_next_action: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    raw = candidate.get("frontier_actions")
    _require(isinstance(raw, list) and bool(raw), "pm-frontier-actions-required")
    seen: set[str] = set()
    rows: list[dict[str, Any]] = []
    first_incomplete: dict[str, Any] | None = None

    for index, item in enumerate(raw):
        _require(isinstance(item, dict), f"pm-frontier-action-object-required:{index}")
        action_ref = str(item.get("action_ref") or "").strip()
        actor = str(item.get("actor") or "").upper()
        state = str(item.get("state") or "").upper()
        _require(action_ref, f"pm-frontier-action-ref-required:{index}")
        _require(action_ref not in seen, f"pm-frontier-action-ref-duplicate:{action_ref}")
        seen.add(action_ref)
        _require(actor in FRONTIER_ACTORS, f"pm-frontier-actor-invalid:{actor}")
        _require(state in FRONTIER_STATES, f"pm-frontier-state-invalid:{state}")
        internally_executable = item.get("internally_executable") is True
        human_action_required = item.get("human_action_required") is True

        if actor == "PROJECT_MANAGER":
            _require(not human_action_required, f"pm-owned-action-cannot-require-human:{action_ref}")
        if actor == "HUMAN":
            _require(not internally_executable, f"human-action-cannot-be-internally-executable:{action_ref}")
            _require(human_action_required, f"human-action-must-declare-human-required:{action_ref}")

        normalized = {
            "sequence": index + 1,
            "action_ref": action_ref,
            "actor": actor,
            "state": state,
            "internally_executable": internally_executable,
            "human_action_required": human_action_required,
            "delegation_target_ref": item.get("delegation_target_ref"),
        }
        rows.append(normalized)
        if first_incomplete is None and state not in {"COMPLETE", "SKIPPED"}:
            first_incomplete = normalized

    canonical_ref = str(canonical_next_action.get("action_ref") or "NONE")
    canonical_owner = str(canonical_next_action.get("owner") or "NONE").upper()
    if canonical_ref != "NONE":
        _require(first_incomplete is not None, "canonical-next-action-present-but-frontier-complete")
        _require(first_incomplete["action_ref"] == canonical_ref, "pm-frontier-does-not-match-canonical-next-action")
        if canonical_owner == "HUMAN":
            _require(first_incomplete["actor"] == "HUMAN", "canonical-human-next-action-actor-mismatch")
        elif canonical_owner == "MACHINE":
            _require(first_incomplete["actor"] == "PROJECT_MANAGER", "canonical-machine-next-action-must-be-pm-owned-in-pm-governor")
        elif canonical_owner not in {"NONE", ""}:
            raise ProjectManagerGovernorError(f"canonical-next-action-owner-unsupported:{canonical_owner}")

    if first_incomplete is not None and first_incomplete["actor"] == "HUMAN":
        _require(
            canonical_ref != "NONE" and canonical_owner == "HUMAN",
            "human-frontier-cannot-create-unbound-human-boundary",
        )

    if first_incomplete is None:
        next_action = {
            "action_ref": "NONE",
            "action_class": "CONTROL",
            "owner": "NONE",
            "pm_actor": "NONE",
            "internally_executable": False,
            "required_before_event_closure": False,
            "human_continuation_allowed": False,
        }
    elif first_incomplete["actor"] == "PROJECT_MANAGER":
        next_action = {
            "action_ref": first_incomplete["action_ref"],
            "action_class": "CONTROL",
            "owner": "MACHINE",
            "pm_actor": "PROJECT_MANAGER",
            "internally_executable": first_incomplete["internally_executable"],
            "required_before_event_closure": True,
            "human_continuation_allowed": False,
        }
    else:
        next_action = {
            "action_ref": first_incomplete["action_ref"],
            "action_class": "HUMAN_ACTION",
            "owner": "HUMAN",
            "pm_actor": "HUMAN",
            "internally_executable": False,
            "required_before_event_closure": False,
            "human_continuation_allowed": True,
        }

    return {"frontier": rows, "first_incomplete": first_incomplete}, next_action


def _shared_write_gate(candidate: dict[str, Any]) -> dict[str, Any]:
    raw = candidate.get("shared_write_transaction")
    if raw is None:
        return {"applicable": False, "result": "PASS", "next_transaction_allowed": True}
    _require(isinstance(raw, dict), "shared-write-transaction-object-required")
    semantic_intent_id = str(raw.get("semantic_intent_id") or "").strip()
    idempotency_key = str(raw.get("idempotency_key") or "").strip()
    _require(semantic_intent_id, "shared-semantic-intent-id-required")
    _require(idempotency_key, "shared-idempotency-key-required")
    writer_count = int(raw.get("active_semantic_writer_count") or 0)
    overlapping = int(raw.get("overlapping_attempt_count") or 0)
    _require(writer_count == 1, "shared-single-semantic-writer-required")
    _require(overlapping == 0, "shared-overlapping-same-intent-attempt-prohibited")
    _require(raw.get("retry_without_fresh_read") is not True, "shared-retry-without-fresh-read-prohibited")

    attempted = raw.get("provider_write_attempted") is True
    accepted = raw.get("provider_write_accepted") is True
    readback = raw.get("provider_readback_verified") is True
    if accepted:
        _require(attempted, "shared-provider-accept-without-write-attempt-invalid")
    next_allowed = not attempted or (accepted and readback)
    if raw.get("next_transaction_requested") is True:
        _require(next_allowed, "shared-next-transaction-before-provider-readback-prohibited")

    return {
        "applicable": True,
        "result": "PASS",
        "semantic_intent_id": semantic_intent_id,
        "idempotency_key": idempotency_key,
        "provider_write_attempted": attempted,
        "provider_write_accepted": accepted,
        "provider_readback_verified": readback,
        "next_transaction_allowed": next_allowed,
    }


def _worker_terminal_gate(candidate: dict[str, Any]) -> dict[str, Any]:
    raw = candidate.get("worker_terminal_admission")
    if raw is None:
        return {"applicable": False, "result": "PASS", "integrator_open": False}
    _require(isinstance(raw, dict), "worker-terminal-admission-object-required")
    expected = [str(x) for x in raw.get("expected_worker_refs", [])]
    admitted = [str(x) for x in raw.get("admitted_terminal_refs", [])]
    _require(len(expected) == len(set(expected)), "worker-expected-ref-duplicate")
    _require(len(admitted) == len(set(admitted)), "worker-admitted-ref-duplicate")
    _require(set(admitted).issubset(set(expected)), "worker-admitted-terminal-not-expected")
    _require(raw.get("worker_self_admission_present") is not True, "worker-self-admission-prohibited")
    _require(raw.get("pm_independent_admission_verified") is True or not admitted, "worker-terminal-requires-independent-pm-admission")
    integrator_open = set(admitted) == set(expected) and bool(expected)
    if integrator_open:
        _require(raw.get("frozen_integration_input_manifest") is True, "integrator-requires-frozen-input-manifest")
    if raw.get("integrator_open_requested") is True:
        _require(integrator_open, "integrator-open-before-all-terminal-admissions-prohibited")
    return {
        "applicable": True,
        "result": "PASS",
        "expected_worker_refs": expected,
        "admitted_terminal_refs": admitted,
        "integrator_open": integrator_open,
    }


def _lifecycle_candidate_fingerprint(candidate: dict[str, Any]) -> str:
    subject = copy.deepcopy(candidate)
    subject.pop("candidate_fingerprint", None)
    return hashlib.sha256(_canonical(subject)).hexdigest()


def _require_hex(value: Any, length: int, message: str) -> str:
    _require(isinstance(value, str) and len(value) == length, message)
    _require(all(ch in "0123456789abcdef" for ch in value), message)
    return value


def _lifecycle_mutation_gate(
    candidate: dict[str, Any],
    *,
    lifecycle_effect_verifier: Any | None = None,
    session: dict[str, Any] | None = None,
) -> dict[str, Any]:
    raw = candidate.get("lifecycle_mutation")
    if raw is None:
        return {"applicable": False, "result": "PASS"}
    required = {
        "mutation_id", "idempotency_key", "operation", "actor_generation_id",
        "slot_pointer_ref", "expected_slot_pointer",
        "expected_lifecycle_revision", "expected_lifecycle_state",
        "expected_claim_revision", "authority_source",
        "observed_event_frontier", "candidate_fingerprint",
    }
    _require(isinstance(raw, dict), "lifecycle-mutation-object-required")
    _require(required.issubset(raw), "lifecycle-mutation-required-fields-missing")
    operation = str(raw.get("operation") or "").upper()
    _require(operation in {"RETIRE", "BIND", "START"}, "lifecycle-mutation-operation-invalid")
    for field in (
        "mutation_id", "idempotency_key", "actor_generation_id", "slot_pointer_ref",
        "expected_slot_pointer", "expected_lifecycle_state", "authority_source",
    ):
        _require(isinstance(raw.get(field), str) and bool(raw[field].strip()), f"lifecycle-{field}-required")
    _require(
        isinstance(raw.get("expected_lifecycle_revision"), int)
        and raw["expected_lifecycle_revision"] >= 0,
        "lifecycle-expected-lifecycle-revision-invalid",
    )
    expected_claim_revision = raw.get("expected_claim_revision")
    _require(
        expected_claim_revision == "NOT_APPLICABLE"
        or (isinstance(expected_claim_revision, int) and expected_claim_revision >= 0),
        "lifecycle-expected-claim-revision-invalid",
    )
    _require(
        type(raw.get("observed_event_frontier")) is int
        and raw["observed_event_frontier"] >= 0,
        "lifecycle-observed-event-frontier-invalid",
    )
    supplied_fingerprint = _require_hex(
        raw.get("candidate_fingerprint"), 64, "lifecycle-candidate-fingerprint-invalid"
    )
    _require(
        supplied_fingerprint == _lifecycle_candidate_fingerprint(raw),
        "lifecycle-candidate-fingerprint-mismatch",
    )

    base = {
        "applicable": True,
        "result": "PASS",
        "candidate": copy.deepcopy(raw),
        "state_owner": "CONTEXT",
        "control_owner": "MCP",
        "governor_direct_authority": False,
        "state_mutation_by_governor": False,
    }

    if operation in {"RETIRE", "START"}:
        binding_present = raw.get("principal_succession_permit_binding") is not None
        verify_succession = getattr(
            lifecycle_effect_verifier, "verify_principal_succession", None
        )
        if callable(verify_succession):
            try:
                succession = verify_succession(
                    candidate=copy.deepcopy(raw),
                    session=copy.deepcopy(session or {}),
                )
            except Exception as exc:
                raise ProjectManagerGovernorError(
                    f"principal-succession-verification-failed:{exc}"
                ) from exc
            _require(
                isinstance(succession, dict)
                and succession.get("schema")
                == "cerebro-principal-succession-verification/v1",
                "principal-succession-verification-schema-mismatch",
            )
            _require(
                succession.get("result") in {"PASS", "PASS_NON_PRINCIPAL_UNCHANGED"},
                "principal-succession-verification-nonpass",
            )
            role = succession.get("trusted_actor_role")
            _require(
                succession.get("generation_ref") == raw["actor_generation_id"],
                "principal-succession-trusted-generation-mismatch",
            )
            if role == "PRINCIPAL":
                _require(
                    binding_present and succession.get("applicable") is True
                    and succession.get("result") == "PASS"
                    and succession.get("operation") == operation,
                    "principal-succession-trusted-principal-permit-required",
                )
            else:
                _require(
                    role in {"ASSISTANT", "IMPLEMENTER", "PROJECT_MANAGER", "RESEARCHER", "WORKER"}
                    and not binding_present and succession.get("applicable") is False
                    and succession.get("result") == "PASS_NON_PRINCIPAL_UNCHANGED",
                    "principal-succession-trusted-nonprincipal-role-required",
                )
            base["principal_succession"] = copy.deepcopy(succession)
        else:
            raise ProjectManagerGovernorError(
                "constructor-bound-principal-succession-verifier-required"
            )

    transition = raw.get("source_transition")
    if transition is None:
        base["effect_pending_context_commit_receipt"] = operation in {"BIND", "START"}
        return base

    _require(operation == "BIND", "requalification-must-use-existing-BIND-operation")
    _require(
        raw.get("expected_lifecycle_state") == "REQUALIFICATION_REQUIRED",
        "requalification-expected-state-must-be-REQUALIFICATION_REQUIRED",
    )
    _require(raw.get("claim_ref") is None, "requalification-active-claim-prohibited")
    _require(
        raw.get("expected_claim_revision") == "NOT_APPLICABLE",
        "requalification-claim-revision-must-be-NOT_APPLICABLE",
    )
    observed_pointer = str(raw.get("observed_slot_pointer") or "")
    _require(observed_pointer, "requalification-observed-slot-pointer-required")
    _require(
        observed_pointer == raw.get("expected_slot_pointer"),
        "requalification-generation-pointer-mismatch",
    )
    _require(isinstance(transition, dict), "requalification-source-transition-object-required")
    _require(
        transition.get("intent") == "SAME_GENERATION_SOURCE_REQUALIFICATION",
        "requalification-intent-invalid",
    )
    previous_head = _require_hex(
        transition.get("previous_source_head"), 40, "requalification-previous-source-head-invalid"
    )
    target_head = _require_hex(
        transition.get("target_source_head"), 40, "requalification-target-source-head-invalid"
    )
    _require(previous_head != target_head, "requalification-source-head-must-advance")
    for field in (
        "current_source_verified", "actor_nonretired_verified",
        "no_active_claim_verified", "generation_pointer_verified",
    ):
        _require(transition.get(field) is True, f"requalification-{field}-required")
    changed_contracts = transition.get("changed_contracts")
    _require(isinstance(changed_contracts, list), "requalification-changed-contracts-array-required")
    _require(
        all(isinstance(x, str) and bool(x.strip()) for x in changed_contracts)
        and len(changed_contracts) == len(set(changed_contracts)),
        "requalification-changed-contracts-invalid",
    )
    gates_rerun = transition.get("gates_rerun")
    _require(
        isinstance(gates_rerun, list) and bool(gates_rerun)
        and all(isinstance(x, str) and bool(x.strip()) for x in gates_rerun)
        and len(gates_rerun) == len(set(gates_rerun)),
        "requalification-gates-rerun-invalid",
    )
    _require_hex(
        transition.get("prerequisite_fingerprint"), 64,
        "requalification-prerequisite-fingerprint-invalid",
    )
    _require_hex(
        transition.get("boot_fingerprint"), 64,
        "requalification-boot-fingerprint-invalid",
    )

    base.update({
        "effect_kind": "SAME_GENERATION_SOURCE_REQUALIFICATION",
        "existing_operation": "BIND",
        "previous_source_head": previous_head,
        "target_source_head": target_head,
        "same_generation_identity": raw["actor_generation_id"],
        "ready_effect_allowed": False,
        "bind_effect_allowed": False,
        "effect_pending_context_commit_receipt": True,
        "effect_pending_exact_post_state_readback": True,
    })

    evidence = raw.get("effect_evidence")
    if evidence is None:
        base["result"] = "PASS_CANDIDATE_READY_FOR_CONTEXT"
        return base

    _require(isinstance(evidence, dict), "requalification-effect-evidence-object-required")
    _require(
        isinstance(evidence.get("receipt_id"), str) and bool(evidence["receipt_id"].strip()),
        "requalification-context-receipt-id-required",
    )
    _require(evidence.get("context_commit_result") == "COMMITTED", "requalification-context-commit-required")
    _require(evidence.get("durable") is True, "requalification-context-receipt-must-be-durable")
    _require(
        evidence.get("post_state_readback_verified") is True,
        "requalification-exact-post-state-readback-required",
    )
    _require(
        evidence.get("post_actor_generation_id") == raw["actor_generation_id"],
        "requalification-post-generation-mismatch",
    )
    _require(
        evidence.get("post_lifecycle_state") == "READY_CURRENT",
        "requalification-post-state-must-be-READY_CURRENT",
    )
    _require(
        evidence.get("post_source_head") == target_head,
        "requalification-post-source-head-mismatch",
    )
    _require(
        isinstance(evidence.get("provider_revision"), int) and evidence["provider_revision"] >= 0,
        "requalification-provider-revision-invalid",
    )
    _require_hex(
        evidence.get("receipt_fingerprint"), 64,
        "requalification-receipt-fingerprint-invalid",
    )
    verify_effect = getattr(lifecycle_effect_verifier, "verify_lifecycle_effect", None)
    _require(callable(verify_effect), "constructor-bound-context-effect-verifier-required")
    try:
        verified_effect = verify_effect(
            evidence=copy.deepcopy(evidence),
            candidate=copy.deepcopy(raw),
            session=copy.deepcopy(session or {}),
        )
    except Exception as exc:
        raise ProjectManagerGovernorError(f"context-effect-verification-failed:{exc}") from exc
    _require(isinstance(verified_effect, dict), "context-effect-verification-object-required")
    _require(
        verified_effect.get("schema") == LIFECYCLE_EFFECT_VERIFICATION_SCHEMA,
        "context-effect-verification-schema-mismatch",
    )
    _require(verified_effect.get("result") == "PASS", "context-effect-verification-nonpass")
    for field in (
        "receipt_id", "post_actor_generation_id", "post_lifecycle_state",
        "post_source_head", "provider_revision", "receipt_fingerprint",
    ):
        _require(
            verified_effect.get(field) == evidence.get(field),
            f"context-effect-verification-{field}-mismatch",
        )
    _require(
        isinstance(verified_effect.get("verifier_ref"), str)
        and bool(verified_effect["verifier_ref"].strip()),
        "context-effect-verifier-ref-required",
    )
    base.update({
        "result": "PASS_EFFECT_VERIFIED",
        "ready_effect_allowed": True,
        "bind_effect_allowed": True,
        "effect_pending_context_commit_receipt": False,
        "effect_pending_exact_post_state_readback": False,
        "context_commit_receipt_id": evidence["receipt_id"],
        "provider_revision": evidence["provider_revision"],
        "context_effect_verifier_ref": verified_effect["verifier_ref"],
    })
    return base



def _executor_terminal_reconciliation_gate(candidate: dict[str, Any]) -> dict[str, Any]:
    raw = candidate.get("executor_terminal_reconciliation")
    if raw is None:
        return {"applicable": False, "result": "PASS", "executor_reactivation_allowed": False, "next_edge_class": "NONE"}
    _require(isinstance(raw, dict), "executor-terminal-reconciliation-object-required")
    executor_ref = str(raw.get("executor_ref") or "").strip()
    execution_state = str(raw.get("execution_state") or "").upper()
    verification_state = str(raw.get("verification_state") or "").upper()
    admission_state = str(raw.get("admission_state") or "").upper()
    _require(executor_ref, "executor-terminal-executor-ref-required")
    _require(execution_state in EXECUTION_STATES, f"executor-terminal-execution-state-invalid:{execution_state}")
    _require(verification_state in VERIFICATION_STATES, f"executor-terminal-verification-state-invalid:{verification_state}")
    _require(admission_state in ADMISSION_STATES, f"executor-terminal-admission-state-invalid:{admission_state}")

    defect_verified = raw.get("new_execution_defect_verified") is True
    carrier = raw.get("evidence_carrier")
    if carrier is None:
        carrier = {"status": "NOT_APPLICABLE"}
    _require(isinstance(carrier, dict), "executor-terminal-evidence-carrier-object-required")
    carrier_status = str(carrier.get("status") or "NOT_APPLICABLE").upper()
    _require(carrier_status in EVIDENCE_CARRIER_STATES, f"executor-terminal-carrier-state-invalid:{carrier_status}")
    exact_question = str(carrier.get("exact_evidence_question") or "").strip()
    capable_carrier_ref = str(carrier.get("capable_carrier_ref") or "").strip()
    uncertain_carrier = carrier_status in {"UNAVAILABLE", "ERROR", "UNKNOWN"}
    if uncertain_carrier:
        _require(verification_state != "FAIL", "carrier-unavailable-cannot-classify-subject-fail")
        _require(not defect_verified, "carrier-unavailable-cannot-verify-execution-defect")
        _require(exact_question, "carrier-unavailable-requires-exact-evidence-question")
    if carrier_status == "UNAVAILABLE":
        _require(capable_carrier_ref, "carrier-unavailable-requires-capable-carrier-route")

    if defect_verified:
        _require(execution_state == "TERMINAL_REPORTED", "verified-execution-defect-requires-terminal-reported-execution")
        _require(verification_state == "FAIL", "verified-execution-defect-requires-verification-fail")
    if raw.get("executor_reactivated") is True:
        _require(defect_verified, "executor-terminal-reopen-requires-verified-execution-defect")

    next_edge = "NONE"
    reactivation_allowed = False
    if execution_state == "TERMINAL_REPORTED":
        if defect_verified:
            next_edge = "REMEDIATE_EXECUTION"
            reactivation_allowed = True
        elif verification_state in {"PENDING", "UNAVAILABLE", "UNKNOWN"}:
            next_edge = "VERIFY"
        elif verification_state in {"PASS", "NOT_REQUIRED"} and admission_state == "PENDING":
            next_edge = "ADMIT"
        elif verification_state in {"PASS", "NOT_REQUIRED"} and admission_state in {"ADMITTED", "NOT_REQUIRED"}:
            next_edge = "CLOSE"
        elif admission_state == "REJECTED":
            next_edge = "REVIEW_ADMISSION"
        elif verification_state == "FAIL":
            raise ProjectManagerGovernorError("verification-fail-without-verified-execution-defect-cannot-reopen-executor")
        else:
            next_edge = "VERIFY_OR_ADMIT"

    return {
        "applicable": True, "result": "PASS", "executor_ref": executor_ref,
        "execution_state": execution_state, "verification_state": verification_state,
        "admission_state": admission_state, "evidence_carrier_status": carrier_status,
        "evidence_result": "UNKNOWN" if uncertain_carrier else verification_state,
        "capable_carrier_ref": capable_carrier_ref or None,
        "new_execution_defect_verified": defect_verified,
        "executor_reactivation_allowed": reactivation_allowed, "next_edge_class": next_edge,
        "state_owner": "EXISTING_WORK_CLAIM_OR_LIFECYCLE_ENVELOPE",
        "persistent_state_axis_created": False,
    }


def _continuation_progress_gate(candidate: dict[str, Any], next_action: dict[str, Any]) -> dict[str, Any]:
    applicable = (
        next_action.get("owner") == "MACHINE"
        and next_action.get("pm_actor") == "PROJECT_MANAGER"
        and next_action.get("internally_executable") is True
    )
    if not applicable:
        return {"applicable": False, "result": "PASS", "same_cycle_progress_required": False, "response_handoff_allowed": True}
    observation = candidate.get("pm_same_cycle_progress")
    if observation is None:
        return {
            "applicable": True, "result": "PASS_OBLIGATION_ACTIVE",
            "same_cycle_progress_required": True, "response_handoff_allowed": False,
            "acceptable_terminal_evidence": ["VERIFIED_STATE_DELTA", "EXACT_EXTERNAL_BLOCKER"],
            "human_pulse_dependency_allowed": False,
        }
    _require(isinstance(observation, dict), "pm-same-cycle-progress-object-required")
    state_delta = observation.get("state_delta_observed") is True
    status_only = observation.get("status_only_terminal_surface") is True
    blocker = str(observation.get("exact_external_blocker") or "").strip()
    machine_route_available = observation.get("machine_route_available")
    if state_delta:
        return {"applicable": True, "result": "PASS_STATE_DELTA_OBSERVED", "same_cycle_progress_required": False, "response_handoff_allowed": True, "state_delta_observed": True, "human_pulse_dependency_allowed": False}
    if blocker:
        _require(machine_route_available is False, "external-blocker-requires-machine-route-unavailable")
        return {"applicable": True, "result": "PASS_EXACT_EXTERNAL_BLOCKER", "same_cycle_progress_required": False, "response_handoff_allowed": True, "state_delta_observed": False, "exact_external_blocker": blocker, "human_pulse_dependency_allowed": False}
    _require(not status_only, "self-next-owner-status-only-prohibited")
    raise ProjectManagerGovernorError("self-next-owner-executable-edge-requires-state-delta-or-exact-external-blocker")

def _interrupt_gate(candidate: dict[str, Any]) -> dict[str, Any]:
    raw = candidate.get("interrupt")
    if raw is None:
        return {"intent": "NONE", "result": "PASS"}
    _require(isinstance(raw, dict), "pm-interrupt-object-required")
    intent = str(raw.get("intent") or "NONE").upper()
    _require(intent in INTERRUPTS, f"pm-interrupt-invalid:{intent}")
    if intent == "PAUSE":
        _require(raw.get("claim_reserved") is True, "pause-must-reserve-claim")
        _require(raw.get("fresh_revalidation_on_resume") is True, "pause-resume-must-revalidate")
        _require(raw.get("continuation_propagates") is True, "pause-must-preserve-continuation")
    elif intent == "STOP":
        _require(raw.get("claim_released") is True, "stop-must-release-claim")
        _require(raw.get("partial_work_quarantined") is True, "stop-must-quarantine-partial-work")
        _require(raw.get("recovery_review_required") is True, "stop-must-require-recovery-review")
        _require(raw.get("direct_continuation_allowed") is False, "stop-direct-continuation-prohibited")
    elif intent == "TERMINATE":
        _require(raw.get("claim_released") is True, "terminate-must-release-claim")
        _require(raw.get("minimal_tombstone_retained") is True, "terminate-must-retain-minimal-tombstone")
        _require(raw.get("continuation_propagates") is False, "terminate-continuation-propagation-prohibited")
        _require(raw.get("substantive_inheritance_allowed") is False, "terminate-substantive-inheritance-prohibited")
    return {"intent": intent, "result": "PASS"}


def _operational_debt_gate(candidate: dict[str, Any]) -> dict[str, Any]:
    terminal_raw = candidate.get("terminal")
    terminal_state = str((terminal_raw or {}).get("state") or "ACTIVE").upper()
    retire_requested = candidate.get("retire_requested") is True
    if terminal_state != "COMPLETE" and not retire_requested:
        return {"applicable": False, "result": "PASS", "terminal_blocked": False}
    pulse = candidate.get("operational_pulse")
    _require(isinstance(pulse, dict), "pre-close-operational-pulse-required")
    _require(pulse.get("stage") == "PRE_CLOSE", "pre-close-operational-pulse-stage-required")
    _require(pulse.get("currentness") == "CURRENT", "pre-close-operational-pulse-current-required")
    _require(pulse.get("persistence_readback_verified") is True, "pre-close-pulse-persistence-readback-required")
    _require(
        pulse.get("result") in {"PASS", "NONE", "DRAIN_REQUIRED"},
        "pre-close-operational-pulse-result-invalid",
    )
    unresolved = pulse.get("relevant_debt", [])
    _require(isinstance(unresolved, list), "pre-close-relevant-debt-array-required")
    _require(not unresolved and pulse.get("result") != "DRAIN_REQUIRED", "unresolved-relevant-debt-blocks-terminal")
    return {
        "applicable": True,
        "result": "PASS",
        "terminal_blocked": False,
        "watermarks": copy.deepcopy(pulse.get("watermarks")),
        "debt_result": pulse.get("result"),
    }


def _terminal_gate(candidate: dict[str, Any]) -> dict[str, Any]:
    raw = candidate.get("terminal")
    if raw is None:
        return {"state": "ACTIVE", "result": "PASS", "terminal_ready": False}
    _require(isinstance(raw, dict), "pm-terminal-object-required")
    state = str(raw.get("state") or "ACTIVE").upper()
    continuation = str(raw.get("continuation_disposition") or "PENDING").upper()
    learning = str(raw.get("learning_disposition") or "PENDING").upper()
    _require(state in TERMINAL_STATES, f"pm-terminal-state-invalid:{state}")
    _require(continuation in CONTINUATION_DISPOSITIONS, f"pm-continuation-disposition-invalid:{continuation}")
    _require(learning in LEARNING_DISPOSITIONS, f"pm-learning-disposition-invalid:{learning}")

    ready = False
    if state == "COMPLETE":
        _require(continuation in {"HANDOFF", "NONE_REQUIRED"}, "complete-requires-continuation-disposition")
        _require(
            learning in {"GENERALIZABLE_LEARNING_CANDIDATE", "NO_GENERALIZABLE_LEARNING"},
            "complete-requires-learning-disposition",
        )
        ready = True
    elif state == "STOP":
        _require(continuation == "RECOVERY_REVIEW", "stop-terminal-requires-recovery-review-continuation")
        _require(learning == "RECOVERY_REVIEW_ONLY", "stop-learning-routes-through-recovery-review")
        ready = True
    elif state == "TERMINATE":
        _require(continuation == "NON_PROPAGATING", "terminate-terminal-must-be-non-propagating")
        _require(learning == "NON_PROPAGATING", "terminate-learning-must-be-non-propagating")
        ready = True
    return {
        "state": state,
        "continuation_disposition": continuation,
        "learning_disposition": learning,
        "terminal_ready": ready,
        "result": "PASS",
    }


def _progress_gate(candidate: dict[str, Any]) -> dict[str, Any]:
    if candidate.get("long_running_execution") is not True:
        return {"applicable": False, "result": "PASS"}
    raw = candidate.get("progress_observability")
    _require(isinstance(raw, dict), "long-running-pm-work-requires-progress-observability")
    _require(raw.get("heartbeat_enabled") is True, "long-running-pm-work-requires-heartbeat")
    _require(raw.get("phase_updates_enabled") is True, "long-running-pm-work-requires-phase-updates")
    _require(raw.get("silent_stall_surface_prohibited") is True, "long-running-pm-work-silent-stall-prohibited")
    return {
        "applicable": True,
        "result": "PASS",
        "heartbeat_enabled": True,
        "phase_updates_enabled": True,
        "silent_stall_surface_prohibited": True,
    }


def govern_project_manager_event(
    *,
    candidate: dict[str, Any],
    canonical_next_action: dict[str, Any],
    session: dict[str, Any],
    profile_binding: dict[str, Any],
    profile_verifier: Any | None,
) -> dict[str, Any]:
    _require(isinstance(candidate, dict), "pm-governance-candidate-object-required")
    _require(candidate.get("schema") == SCHEMA, "pm-governance-candidate-schema-mismatch")
    _require(isinstance(canonical_next_action, dict), "canonical-next-action-object-required")
    _require(isinstance(session, dict), "control-session-object-required")
    event_ref = str(candidate.get("event_ref") or "").strip()
    _require(event_ref, "pm-governance-event-ref-required")

    profile = _verify_profile(
        profile_binding=profile_binding,
        session=session,
        profile_verifier=profile_verifier,
    )
    frontier, next_action = _validate_frontier(candidate, canonical_next_action)
    shared = _shared_write_gate(candidate)
    lifecycle = _lifecycle_mutation_gate(
        candidate,
        lifecycle_effect_verifier=profile_verifier,
        session=session,
    )
    worker = _worker_terminal_gate(candidate)
    executor_reconciliation = _executor_terminal_reconciliation_gate(candidate)
    interrupt = _interrupt_gate(candidate)
    operational_debt = _operational_debt_gate(candidate)
    terminal = _terminal_gate(candidate)
    progress = _progress_gate(candidate)
    continuation_progress = _continuation_progress_gate(candidate, next_action)

    if next_action["owner"] == "HUMAN":
        _require(terminal.get("state") not in {"TERMINATE"}, "terminated-pm-event-cannot-produce-human-continuation")
    if terminal.get("terminal_ready") is True:
        _require(next_action["action_ref"] == "NONE", "terminal-ready-event-cannot-have-incomplete-frontier")

    decision: dict[str, Any] = {
        "schema": DECISION_SCHEMA,
        "authority": "MCP",
        "direct_live_authority": False,
        "state_mutation_by_governor": False,
        "profile_verification": profile,
        "event_ref": event_ref,
        "session_ref": session.get("session_ref"),
        "frontier": frontier,
        "next_action": next_action,
        "shared_write_gate": shared,
        "worker_terminal_gate": worker,
        "executor_terminal_reconciliation_gate": executor_reconciliation,
        "lifecycle_mutation_gate": lifecycle,
        "interrupt_gate": interrupt,
        "operational_debt_gate": operational_debt,
        "terminal_gate": terminal,
        "progress_observability_gate": progress,
        "continuation_progress_gate": continuation_progress,
        "human_continuation_allowed": next_action["human_continuation_allowed"],
        "pm_internal_action_must_run_before_human_boundary": (
            next_action["owner"] == "MACHINE" and next_action["required_before_event_closure"] is True
        ),
        "decision_fingerprint": "",
        "decision_ref": "",
        "result": "PASS",
    }
    decision["decision_fingerprint"] = _fingerprint(decision)
    decision["decision_ref"] = "PMCG-" + decision["decision_fingerprint"][:24].upper()
    return decision


def selftest() -> dict[str, Any]:
    tests: list[dict[str, Any]] = []

    def check(name: str, fn) -> None:
        try:
            ok = bool(fn())
            tests.append({"name": name, "result": "PASS" if ok else "FAIL"})
        except Exception as exc:
            tests.append({"name": name, "result": "FAIL", "detail": str(exc)})

    class Verifier:
        def verify(self, *, binding: dict[str, Any], session: dict[str, Any]) -> dict[str, Any]:
            if binding.get("binding_id") != "PM-BINDING-1":
                return {"schema": PROFILE_VERIFICATION_SCHEMA, "result": "BLOCKED"}
            return {
                "schema": PROFILE_VERIFICATION_SCHEMA,
                "result": "PASS",
                "profile": "PROJECT_MANAGER",
                "session_ref": session["session_ref"],
                "binding_fingerprint": "a"*64,
                "verifier_ref": "SELFTEST-CONSTRUCTOR-BOUND",
            }

    verifier = Verifier()
    session = {"session_ref": "SESSION-PM-1"}
    binding = {"binding_id": "PM-BINDING-1"}

    def pre_close_pulse() -> dict[str, Any]:
        return {
            "stage": "PRE_CLOSE",
            "currentness": "CURRENT",
            "result": "NONE",
            "relevant_debt": [],
            "watermarks": {
                "control": {"carrier_ref": "PM", "provider_revision": 1, "event_frontier": "E1"},
                "protobox": {"channel_ref": "PROTOBOX", "observed_revision": 1},
            },
            "persistence_readback_verified": True,
        }

    def valid_candidate() -> dict[str, Any]:
        return {
            "schema": SCHEMA,
            "event_ref": "EVENT-PM-1",
            "frontier_actions": [
                {
                    "action_ref": "PM-REFRESH-SHARED",
                    "actor": "PROJECT_MANAGER",
                    "state": "PENDING",
                    "internally_executable": True,
                    "human_action_required": False,
                }
            ],
            "long_running_execution": True,
            "progress_observability": {
                "heartbeat_enabled": True,
                "phase_updates_enabled": True,
                "silent_stall_surface_prohibited": True,
            },
        }

    canonical_machine = {
        "action_ref": "PM-REFRESH-SHARED",
        "owner": "MACHINE",
        "internally_executable": True,
        "required_before_event_closure": True,
    }

    check("verified-profile-and-pm-internal-frontier-pass", lambda: govern_project_manager_event(
        candidate=valid_candidate(), canonical_next_action=canonical_machine, session=session,
        profile_binding=binding, profile_verifier=verifier
    )["pm_internal_action_must_run_before_human_boundary"] is True)

    def expect_block(mutator, *, canonical=canonical_machine, verifier_arg=verifier, binding_arg=binding) -> bool:
        c = valid_candidate()
        mutator(c)
        try:
            govern_project_manager_event(
                candidate=c, canonical_next_action=canonical, session=session,
                profile_binding=binding_arg, profile_verifier=verifier_arg
            )
        except ProjectManagerGovernorError:
            return True
        return False

    check("self-asserted-profile-without-verifier-blocks", lambda: expect_block(lambda c: None, verifier_arg=None))
    check("pm-owned-action-cannot-be-human-handoff", lambda: expect_block(
        lambda c: c["frontier_actions"][0].update({"human_action_required": True})
    ))
    check("canonical-frontier-mismatch-blocks", lambda: expect_block(
        lambda c: c["frontier_actions"][0].update({"action_ref": "OTHER"})
    ))
    check("human-frontier-cannot-self-create-human-boundary", lambda: expect_block(
        lambda c: c["frontier_actions"][0].update({
            "actor": "HUMAN",
            "internally_executable": False,
            "human_action_required": True,
        }),
        canonical={"action_ref":"NONE","owner":"NONE"},
    ))

    def completed_human_then_pm() -> bool:
        c = valid_candidate()
        c["frontier_actions"] = [
            {
                "action_ref": "HUMAN-RUN-HOST",
                "actor": "HUMAN",
                "state": "COMPLETE",
                "internally_executable": False,
                "human_action_required": True,
            },
            {
                "action_ref": "PM-READ-RESULT",
                "actor": "PROJECT_MANAGER",
                "state": "PENDING",
                "internally_executable": True,
                "human_action_required": False,
            },
        ]
        out = govern_project_manager_event(
            candidate=c,
            canonical_next_action={"action_ref":"NONE","owner":"NONE"},
            session=session, profile_binding=binding, profile_verifier=verifier,
        )
        return out["next_action"]["action_ref"] == "PM-READ-RESULT" and out["human_continuation_allowed"] is False
    check("completed-human-work-is-removed-from-frontier", completed_human_then_pm)

    check("duplicate-shared-writer-blocks", lambda: expect_block(
        lambda c: c.update({"shared_write_transaction":{
            "semantic_intent_id":"SAME","idempotency_key":"ID-1","active_semantic_writer_count":2,
            "overlapping_attempt_count":0,"retry_without_fresh_read":False
        }})
    ))
    check("shared-overlapping-attempt-blocks", lambda: expect_block(
        lambda c: c.update({"shared_write_transaction":{
            "semantic_intent_id":"SAME","idempotency_key":"ID-1","active_semantic_writer_count":1,
            "overlapping_attempt_count":1,"retry_without_fresh_read":False
        }})
    ))
    check("shared-retry-without-fresh-read-blocks", lambda: expect_block(
        lambda c: c.update({"shared_write_transaction":{
            "semantic_intent_id":"SAME","idempotency_key":"ID-1","active_semantic_writer_count":1,
            "overlapping_attempt_count":0,"retry_without_fresh_read":True
        }})
    ))
    check("worker-self-admission-blocks", lambda: expect_block(
        lambda c: c.update({"worker_terminal_admission":{
            "expected_worker_refs":["W1"],"admitted_terminal_refs":["W1"],
            "worker_self_admission_present":True,"pm_independent_admission_verified":True,
            "frozen_integration_input_manifest":True
        }})
    ))
    check("integrator-before-all-terminal-admissions-blocks", lambda: expect_block(
        lambda c: c.update({"worker_terminal_admission":{
            "expected_worker_refs":["W1","W2"],"admitted_terminal_refs":["W1"],
            "worker_self_admission_present":False,"pm_independent_admission_verified":True,
            "frozen_integration_input_manifest":False,"integrator_open_requested":True
        }})
    ))
    check("pause-preserve-and-revalidate-pass", lambda: govern_project_manager_event(
        candidate={**valid_candidate(),"interrupt":{
            "intent":"PAUSE","claim_reserved":True,"fresh_revalidation_on_resume":True,"continuation_propagates":True
        }},
        canonical_next_action=canonical_machine,session=session,profile_binding=binding,profile_verifier=verifier
    )["interrupt_gate"]["intent"]=="PAUSE")
    check("stop-direct-continuation-blocks", lambda: expect_block(
        lambda c: c.update({"interrupt":{
            "intent":"STOP","claim_released":True,"partial_work_quarantined":True,
            "recovery_review_required":True,"direct_continuation_allowed":True
        }})
    ))
    check("terminate-substantive-inheritance-blocks", lambda: expect_block(
        lambda c: c.update({"interrupt":{
            "intent":"TERMINATE","claim_released":True,"minimal_tombstone_retained":True,
            "continuation_propagates":False,"substantive_inheritance_allowed":True
        }})
    ))

    def terminal_missing_learning() -> bool:
        c = valid_candidate()
        c["frontier_actions"][0]["state"] = "COMPLETE"
        c["terminal"] = {"state":"COMPLETE","continuation_disposition":"NONE_REQUIRED","learning_disposition":"PENDING"}
        c["operational_pulse"] = pre_close_pulse()
        try:
            govern_project_manager_event(candidate=c,canonical_next_action={"action_ref":"NONE","owner":"NONE"},
                session=session,profile_binding=binding,profile_verifier=verifier)
        except ProjectManagerGovernorError:
            return True
        return False
    check("complete-without-learning-disposition-blocks", terminal_missing_learning)

    def valid_terminal() -> bool:
        c = valid_candidate()
        c["frontier_actions"][0]["state"] = "COMPLETE"
        c["terminal"] = {
            "state":"COMPLETE","continuation_disposition":"NONE_REQUIRED",
            "learning_disposition":"GENERALIZABLE_LEARNING_CANDIDATE"
        }
        c["operational_pulse"] = pre_close_pulse()
        out=govern_project_manager_event(candidate=c,canonical_next_action={"action_ref":"NONE","owner":"NONE"},
            session=session,profile_binding=binding,profile_verifier=verifier)
        return out["terminal_gate"]["terminal_ready"] is True
    check("complete-with-continuation-and-learning-disposition-passes", valid_terminal)

    def unresolved_debt_blocks_terminal() -> bool:
        c = valid_candidate()
        c["frontier_actions"][0]["state"] = "COMPLETE"
        c["terminal"] = {
            "state":"COMPLETE","continuation_disposition":"NONE_REQUIRED",
            "learning_disposition":"NO_GENERALIZABLE_LEARNING"
        }
        pulse = pre_close_pulse()
        pulse["result"] = "DRAIN_REQUIRED"
        pulse["relevant_debt"] = [{"debt_id": "D1"}]
        c["operational_pulse"] = pulse
        try:
            govern_project_manager_event(candidate=c, canonical_next_action={"action_ref":"NONE","owner":"NONE"},
                session=session, profile_binding=binding, profile_verifier=verifier)
        except ProjectManagerGovernorError:
            return True
        return False

    check("unresolved-relevant-debt-blocks-complete", unresolved_debt_blocks_terminal)
    check("pre-close-without-persisted-pulse-blocks", lambda: expect_block(
        lambda c: c.update({
            "frontier_actions": [{**c["frontier_actions"][0], "state": "COMPLETE"}],
            "terminal": {"state":"COMPLETE","continuation_disposition":"NONE_REQUIRED",
                         "learning_disposition":"NO_GENERALIZABLE_LEARNING"},
        }),
        canonical={"action_ref":"NONE","owner":"NONE"},
    ))
    check("unresolved-relevant-debt-blocks-retire", lambda: expect_block(
        lambda c: c.update({
            "retire_requested": True,
            "operational_pulse": {
                **pre_close_pulse(),
                "result": "DRAIN_REQUIRED",
                "relevant_debt": [{"debt_id": "D-RETIRE"}],
            },
        })
    ))

    check("long-running-without-heartbeat-blocks", lambda: expect_block(
        lambda c: c.update({"progress_observability":{
            "heartbeat_enabled":False,"phase_updates_enabled":True,"silent_stall_surface_prohibited":True
        }})
    ))


    def reconciliation_candidate() -> dict[str, Any]:
        return {"executor_terminal_reconciliation": {"executor_ref": "L-CANARY", "execution_state": "TERMINAL_REPORTED", "verification_state": "PENDING", "admission_state": "PENDING", "new_execution_defect_verified": False, "executor_reactivated": False, "evidence_carrier": {"status": "AVAILABLE"}}}

    check("terminal-executor-pending-verification-does-not-reopen", lambda: (
        _executor_terminal_reconciliation_gate(reconciliation_candidate())["executor_reactivation_allowed"] is False
        and _executor_terminal_reconciliation_gate(reconciliation_candidate())["next_edge_class"] == "VERIFY"
    ))
    check("terminal-executor-admission-pending-does-not-reopen", lambda: (
        _executor_terminal_reconciliation_gate({"executor_terminal_reconciliation": {**reconciliation_candidate()["executor_terminal_reconciliation"], "verification_state": "PASS"}})["next_edge_class"] == "ADMIT"
    ))

    def carrier_fail_is_blocked() -> bool:
        c = reconciliation_candidate()
        c["executor_terminal_reconciliation"]["verification_state"] = "FAIL"
        c["executor_terminal_reconciliation"]["evidence_carrier"] = {"status": "UNAVAILABLE", "exact_evidence_question": "exact terminal effect?", "capable_carrier_ref": "CAPABLE-CARRIER"}
        try:
            _executor_terminal_reconciliation_gate(c)
        except ProjectManagerGovernorError:
            return True
        return False
    check("carrier-unavailable-cannot-be-subject-fail", carrier_fail_is_blocked)

    check("verified-execution-defect-allows-remediation", lambda: (
        _executor_terminal_reconciliation_gate({"executor_terminal_reconciliation": {**reconciliation_candidate()["executor_terminal_reconciliation"], "verification_state": "FAIL", "new_execution_defect_verified": True}})["executor_reactivation_allowed"] is True
    ))
    check("self-next-owner-executable-edge-requires-same-cycle-progress", lambda: (
        govern_project_manager_event(candidate=valid_candidate(), canonical_next_action=canonical_machine, session=session, profile_binding=binding, profile_verifier=verifier)["continuation_progress_gate"]["same_cycle_progress_required"] is True
    ))
    check("self-next-owner-status-only-terminal-blocks", lambda: expect_block(
        lambda c: c.update({"pm_same_cycle_progress": {"state_delta_observed": False, "status_only_terminal_surface": True, "machine_route_available": True}})
    ))
    passed=sum(1 for x in tests if x["result"]=="PASS")
    return {
        "schema":"cerebro-project-manager-control-governor-selftest/v1",
        "result":"PASS" if passed==len(tests) else "FAIL",
        "tests":tests,
        "passed":passed,
        "total":len(tests),
    }


def main() -> int:
    result=selftest()
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return 0 if result["result"]=="PASS" else 1


if __name__=="__main__":
    raise SystemExit(main())
