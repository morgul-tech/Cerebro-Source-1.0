"""Read own bounded admission projection; privileged operator material remains private."""
from worker_method_owner import caller
from worker_method_adoption import need

def read_evidence(owner,args,context):
    need(type(args)is dict and set(args).issubset({'generation_ref','read_evidence_ref'})
         and 'generation_ref' in args,'method-evidence-read-fields')
    who=caller(context);gen=args['generation_ref']
    need('project_state:read' in context.identity.state_scopes,'method-evidence-read-scope-required')
    owner._binding(who,gen,client_ref=context.identity.authenticated_client_ref)
    with owner._transaction(who) as c:
        owner._lock(c,who,gen)
        record=owner._latest(c,who,gen)
        # Operator originals, reviewer identity and publication provenance stay private.
        if record is None:projection=None
        else:
            from worker_method_adoption import digest
            a=record['authorization']
            projection={k:a[k] for k in ('authorization_ref','revision','generation_ref','expected_revision',
                'destination_ref','old_source','new_source','delta_fingerprint','read_evidence_ref',
                'current','revoked','not_before','expires_at')}
            projection['record_fingerprint']=digest(record)
        result={'latest_owner_record':projection}
        if 'read_evidence_ref' in args:
            result['acknowledgment']=owner._ack(c,who,gen,args['read_evidence_ref'])
        else:
            # Bounded latest acknowledgments for an unknown response, never another caller.
            from worker_method_owner import ACK_TABLE,KEY_FIELDS,IDENTITY,_json_value
            from control_context_state_postgres import _fetchall
            c.execute('SELECT acknowledgment_payload FROM '+ACK_TABLE+' WHERE '+
                ' AND '.join(k+'=%s' for k in KEY_FIELDS)+' ORDER BY created_at DESC, acknowledgment_ref DESC LIMIT 8',
                tuple(who[k] for k in IDENTITY)+(gen,))
            result['recent_acknowledgments']=[_json_value(r['acknowledgment_payload'],field='worker-method-evidence') for r in _fetchall(c)]
    return result
