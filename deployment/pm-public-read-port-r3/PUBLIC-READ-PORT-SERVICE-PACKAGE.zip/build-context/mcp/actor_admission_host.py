"""Reusable authorized task entry and private actor/session administration."""
import copy
from datetime import datetime,timezone
from pm_owner_atomic import _row
from actor_admission_model import (need,exact,reference,digest,caller,carrier_matches,
    participants,prepare_destination,select_round,select_task,admit_actor,activate,
    admit_material,own_actor,active,stamp,AdmissionRefused,set_access_window,access_binding_digest)
from actor_admission_store import ProjectAdmissionStore
_OWNER_PORT_KEY=object()
class _OwnerInvocation:
    def __init__(self,key,request_fingerprint,qualifier):
        need(key is _OWNER_PORT_KEY and callable(qualifier),'PRIVATE_OPERATOR_CONSTRUCTOR_REQUIRED')
        self._key=key;self.request_fingerprint=request_fingerprint;self.qualifier=qualifier
def issuer_binding(value):
    if value is None:return None
    from actor_admission_model import HEX
    exact(value,('appointment_ref','appointment_sha256','tenant_ref','workspace_ref','principal_ref',
        'consumer_ref','signed_client_ref','projects','roles','not_before','expires_at'))
    need(type(value['appointment_ref'])is str and bool(value['appointment_ref'])
         and HEX.fullmatch(value['appointment_sha256']) is not None,'APPOINTMENT_REQUIRED')
    for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref','signed_client_ref'):
        need(type(value[k])is str and bool(value[k]),'OWN_ISSUER_NAMESPACE_REQUIRED')
    need(type(value['projects'])is list and len(value['projects'])==1 and value['roles']==['WORKER'],'EXACT_EXISTING_PROJECT_AND_W_ONLY')
    reference(value['projects'][0]);start=datetime.fromisoformat(value['not_before'].replace('Z','+00:00'));end=datetime.fromisoformat(value['expires_at'].replace('Z','+00:00'))
    need(start.tzinfo is not None and end.tzinfo is not None and end>start,'FINITE_ISSUER_WINDOW_REQUIRED')
    return copy.deepcopy(value)
class ActorAdmissionHost:
    def __init__(self,state_port,*,issuer=None):
        self.state=state_port;self.store=ProjectAdmissionStore(state_port);self.issuer=issuer_binding(issuer)
    def _issuer(self,context,project,args):
        v=getattr(context,'owner_invocation',None)
        need(type(v)is _OwnerInvocation and v._key is _OWNER_PORT_KEY and v.request_fingerprint==digest(args),
             'PRIVATE_QUALIFIED_OPERATOR_REQUIRED_NOT_SHARED_MCP_IDENTITY')
        v.qualifier();b=self.issuer;need(b is not None,'TECHNICAL_ISSUER_TRUST_BINDING_NOT_INSTALLED');who=caller(context)
        need(all(who[k]==b[k] for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref'))
             and project in b['projects'],'APPOINTED_OWN_ISSUER_SCOPE_MISMATCH')
        need(datetime.fromisoformat(b['not_before'].replace('Z','+00:00'))<=datetime.now(timezone.utc)<
             datetime.fromisoformat(b['expires_at'].replace('Z','+00:00')),'ISSUER_APPOINTMENT_EXPIRED')
    def _project(self,c,who,project):
        p=self.state._load_project(c,tenant_ref=who['tenant_ref'],workspace_ref=who['workspace_ref'],project_ref=project,required=False)
        need(p is not None and p['project_status']=='ACTIVE','ACTUAL_EXISTING_ACTIVE_PROJECT_REQUIRED')
    def _own_native(self,s,context):
        exact(s,('actor_ref','generation_ref','birth_generation_ref','native_role'));need(s['native_role']=='WORKER','ONLY_EXISTING_W_SUPPORTED')
        i=context.identity
        shadow=self.state.read_actor_generation_shadow(tenant_ref=i.tenant_ref,workspace_ref=i.workspace_ref,
            principal_ref=i.principal_ref,role='WORKER',generation_ref=s['generation_ref'],scopes=i.state_scopes)
        need(shadow['actor_ref']==s['actor_ref'] and shadow['role']=='WORKER' and shadow['lifecycle'] in ('READY','ACTIVE'),'OWN_EXISTING_W_NATIVE_REQUIRED')
        reference(s['birth_generation_ref'])
        birth=self.state.read_pre_role_generation(tenant_ref=i.tenant_ref,workspace_ref=i.workspace_ref,
            principal_ref=i.principal_ref,generation_ref=s['birth_generation_ref'],scopes=i.state_scopes)
        overlay=birth.get('role_overlay') or {}
        need(birth['lifecycle']=='ROLE_ATTACHED' and overlay.get('actor_generation_ref')==s['generation_ref']
             and overlay.get('actor_ref')==s['actor_ref'] and overlay.get('role')=='WORKER','OWN_IMMUTABLE_BIRTH_LINK_REQUIRED')
        return {k:shadow[k] for k in ('revision','fingerprint','source_revision','actor_ref','generation_ref','role','tenant_ref','workspace_ref')}
    def _native(self,a,context,doc):
        need(a.get('kind')=='NATIVE_EXECUTOR','BUSINESS_PARTY_CANNOT_USE_NATIVE_OPERATION')
        return self._own_native(a['native_selection'],context)
    @staticmethod
    def _expected(args,before):
        need(type(args['expected_revision'])is int and args['expected_revision']==before['revision']
             and args['expected_fingerprint']==before['fingerprint'],'OWNER_EXPECTED_OLD_CONFLICT')
    def _current_actor(self,doc,context,who,project):
        key,a=own_actor(doc,who)
        current=self.state.read_session(**who,scopes=context.identity.state_scopes)
        need(current['project_ref']==project and current['session_binding_id']==a['session_binding_id'],
             'OWN_CURRENT_SESSION_BINDING_CHANGED_REQUALIFY_DESTINATION')
        if a['kind']=='NATIVE_EXECUTOR':
            need(self._native(a,context,doc)==a['native_snapshot'],'OWN_NATIVE_CHANGED_REQUALIFY_OWNER')
        return key,a
    def _route(self,c,who,project,route):
        c.execute('''SELECT * FROM cerebro_pm_owner_d1_routes WHERE tenant_ref=%s AND workspace_ref=%s
         AND project_ref=%s AND owner_ref=%s AND route_ref=%s''',
         (who['tenant_ref'],who['workspace_ref'],project,route['transport_owner_ref'],route['route_ref']))
        r=_row(c);need(r is not None and r['receiver_ref']==route['receiver_ref'] and r['binding_revision']==route['binding_revision']
            and r['pointer_ttl_seconds']==route['pointer_ttl_seconds'],'ACTUAL_ROUTE_MISMATCH')
        c.execute('SELECT *,now() AS server_now FROM cerebro_bk11_service_assignments WHERE assignment_ref=%s',(route['receiver_assignment_ref'],))
        a=_row(c);need(a is not None and a['tenant_ref']==who['tenant_ref'] and a['workspace_ref']==who['workspace_ref']
            and a['project_ref']==project and a['owner_family']=='ROOM_RETURN' and a['service_role']=='receiver'
            and a.get('room_return_scope')=='PROJECT_ADMITTED_ACTORS' and a['enabled'] is True and a['expires_at']>a['server_now']
            and a['route_ref']==route['route_ref'] and a['receiver_ref']==route['receiver_ref']
            and a['owner_ref']==route['transport_owner_ref'],'EXACT_CURRENT_RELEASED_SERVICE_SCOPE_REQUIRED')
    def _access_window_current(self,c,doc,window,context,who,project):
        # Administrative ledger reads only, under the real private issuer.
        # Never construct a W caller or execute a tool as the stored carrier.
        if window['mode']=='REVOKE':return
        need(stamp(window['not_before'])<=datetime.now(timezone.utc)<stamp(window['expires_at']),
             'ACCESS_WINDOW_EXPIRED_BEFORE_COMMIT')
        p=self.state._load_project(c,tenant_ref=who['tenant_ref'],workspace_ref=who['workspace_ref'],
            project_ref=project,required=False)
        need(p is not None and p['project_status']=='ACTIVE','ACTUAL_EXISTING_ACTIVE_PROJECT_REQUIRED')
        for subject in window['subjects']:
            a=participants(doc).get(subject['actor_ref'])
            need(a is not None and a['execution']=='ACTIVE' and a['epoch']==subject['expected_epoch']
                 and access_binding_digest(a)==subject['expected_binding_sha256'],'ACCESS_CURRENT_BINDING_CHANGED')
            # This existing owner entry reads its own namespace/native ledger.
            need(a['carrier']['principal_ref']==who['principal_ref']
                 and a['carrier']['consumer_ref']==who['consumer_ref'],'ACCESS_FOREIGN_ISSUER_NAMESPACE_DENIED')
            current=self.state._load_session(c,tenant_ref=who['tenant_ref'],workspace_ref=who['workspace_ref'],
                principal_ref=a['carrier']['principal_ref'],consumer_ref=a['carrier']['consumer_ref'],
                session_ref=a['carrier']['session_ref'],project=p,required=False)
            need(current is not None and current['project_ref']==project
                 and current['project_revision']==p['revision']
                 and current['session_binding_id']==a['session_binding_id'],'ACCESS_CURRENT_SESSION_BINDING_STALE')
            if a['kind']=='NATIVE_EXECUTOR':
                need(self._native(a,context,doc)==a['native_snapshot'],'ACCESS_CURRENT_NATIVE_CHANGED')
            for route in a['route_bindings'].values():self._route(c,who,project,route)
    def call(self,args,context):
        need(type(args)is dict and type(args.get('op'))is str,'ADMISSION_OPERATION_REQUIRED')
        op=args['op'];project=reference(args.get('project_ref'));who=caller(context)
        private=op in ('preview_round','select_round','admit_actor','owner_read','set_access_window')
        readonly=op in ('preview_round','owner_read','read_operation','own_read','describe_own_destination')
        need(('project_state:read' if readonly else 'project_state:transition') in context.identity.state_scopes,'ADMISSION_SCOPE_REQUIRED')
        if private:self._issuer(context,project,args)
        if readonly:
            if op=='preview_round':exact(args,('op','project_ref','selection','expected_revision','expected_fingerprint'))
            elif op=='describe_own_destination':exact(args,('op','project_ref'))
            elif op=='own_read':exact(args,('op','project_ref','actor_ref'))
            else:exact(args,('op','project_ref','operation_ref','request_fingerprint'))
            with self.store.transaction(who,project,write=False,mode='ISSUER_READ' if private else 'ACTOR_READ') as c:
                self._project(c,who,project);before=self.store.load(c,who,project);doc=before['payload']
                if op=='preview_round':
                    self._expected(args,before);select_round(doc,args['selection'])
                    for p in args['selection']['task']['phases'].values():self._route(c,who,project,p['route'])
                    basis={'project_ref':project,'revision':before['revision'],'fingerprint':before['fingerprint'],
                        'selection':args['selection'],'appointment_sha256':self.issuer['appointment_sha256']}
                    return {'basis':basis,'preview_digest':digest(basis),'authority':'NONE_PREVIEW_ONLY'}
                if op in ('owner_read','read_operation'):
                    prior=self.store.prior(c,who,reference(args['operation_ref']),args['request_fingerprint'])
                    return {'original_operation':prior,'current_revision':before['revision'],'current_fingerprint':before['fingerprint'],
                        'selected_round':doc if op=='owner_read' else None,'replayed':False,'retry_allowed':False}
                if op=='own_read':
                    a=participants(doc).get(args['actor_ref']);need(a is not None and carrier_matches(a,who),'OWN_SELECTED_CARRIER_REQUIRED')
                    eligible=a['execution']=='ACTIVE' and (a.get('access_expires_at') is None or
                        datetime.now(timezone.utc)<stamp(a['access_expires_at']));native=a['kind']=='NATIVE_EXECUTOR'
                    if eligible:
                        current=self.state.read_session(**who,scopes=context.identity.state_scopes)
                        eligible=current['project_ref']==project and current['session_binding_id']==a['session_binding_id']
                        if eligible and native:eligible=self._native(a,context,doc)==a['native_snapshot']
                    return {'actor':a,'execution_eligible':eligible,'native_execution_eligible':eligible and native,
                        'committed_revision':before['revision'],'committed_fingerprint':before['fingerprint'],'authority':'SELECTED_ROUND_ONLY'}
                return {'revision':before['revision'],'fingerprint':before['fingerprint'],'authority':'NONE'}
        fields=('op','project_ref','expected_revision','expected_fingerprint','operation_ref')
        if op=='prepare_own_destination':exact(args,fields+('destination','native_selection'));mode='OWN_DESTINATION'
        elif op=='select_round':exact(args,fields+('preview',));mode='ISSUER_COMMIT'
        elif op=='admit_actor':exact(args,fields+('admission',));mode='ISSUER_COMMIT'
        elif op=='set_access_window':exact(args,fields+('access_window',));mode='ISSUER_COMMIT'
        elif op=='register_task':exact(args,fields+('task',));mode='ACTOR_MATERIAL'
        elif op=='admit_material':exact(args,fields+('material',));mode='ACTOR_MATERIAL'
        elif op=='confirm_own_readback':exact(args,fields+('actor_ref','epoch'));mode='ACTOR_ACTIVATE'
        else:raise AdmissionRefused('OPERATION_PARKED_OR_UNSUPPORTED')
        operation=reference(args['operation_ref']);fp=digest(args)
        with self.store.transaction(who,project,write=False,mode='ISSUER_READ' if private else 'ACTOR_READ') as c:
            prior=self.store.prior(c,who,operation,fp);before=self.store.load(c,who,project)
        if prior:return {'result':'EXACT_ORIGINAL_COMMIT_OBSERVED_NO_REPLAY','receipt':prior,'request_fingerprint':fp}
        self._expected(args,before)
        if op=='confirm_own_readback':
            a=participants(before['payload']).get(args['actor_ref'])
            need(a is not None and carrier_matches(a,who) and a['epoch']==args['epoch'] and a['execution']=='DESTINATION_DISABLED','OWN_COMMITTED_READBACK_REQUIRED')
            if a['kind']=='NATIVE_EXECUTOR':need(self._native(a,context,before['payload'])==a['native_snapshot'],'OWN_W_NATIVE_CHANGED')
            from control_context_tools import _session_binding_id
            current=self.state.bind_session(**who,project_ref=project,session_binding_id=_session_binding_id(context,project),scopes=context.identity.state_scopes)
            session_binding=current['session_binding_id']
        def final_guard(c):
            if private:self._issuer(context,project,args)
            if op=='set_access_window':self._access_window_current(c,after,args['access_window'],context,who,project)
            if op=='admit_material':
                from actor_material_provider import ActorMaterialProvider
                need(ActorMaterialProvider._window(after,material),'TASK_EXPIRED_BEFORE_COMMIT')
            if op in ('register_task','admit_material'):
                self._current_actor(after,context,who,project)
            if op=='register_task':
                need(datetime.now(timezone.utc)<stamp(args['task']['expires_at']),'TASK_EXPIRED_BEFORE_COMMIT')
            if op=='admit_actor':
                admitted=participants(after)[args['admission']['party']['actor_ref']]
                need(datetime.now(timezone.utc)<stamp(admitted['activation_expires_at']),
                     'ACTOR_ACTIVATION_EXPIRED_BEFORE_COMMIT')
            if op=='confirm_own_readback':
                need(datetime.now(timezone.utc)<datetime.fromisoformat(participants(after)[args['actor_ref']]['activation_expires_at'].replace('Z','+00:00')),'ACTIVATION_EXPIRED_BEFORE_COMMIT')
        with self.store.transaction(who,project,write=True,mode=mode,final_guard=final_guard) as c:
            self._project(c,who,project);need(self.store.prior(c,who,operation,fp) is None,'ORIGINAL_COMMIT_APPEARED_RECONCILE_NO_REPLAY')
            before=self.store.load(c,who,project,lock=True);self._expected(args,before);doc=before['payload'];destination_ref=None
            if op=='prepare_own_destination':
                after,destination_ref=prepare_destination(doc,who,args['destination'])
                if args['native_selection'] is not None:
                    evidence={'selection':copy.deepcopy(args['native_selection']),'snapshot':self._own_native(args['native_selection'],context)}
                    old=doc['destinations'].get(destination_ref,{}).get('own_native_evidence')
                    need(old is None or old==evidence,'OWN_NATIVE_CHANGED_USE_NEW_DESTINATION')
                    after['destinations'][destination_ref]['own_native_evidence']=evidence
            elif op=='select_round':
                exact(args['preview'],('basis','preview_digest'));b=args['preview']['basis']
                need(digest(b)==args['preview']['preview_digest'] and b['project_ref']==project and b['revision']==before['revision']
                    and b['fingerprint']==before['fingerprint'] and b['appointment_sha256']==self.issuer['appointment_sha256'],'EXACT_PREVIEW_AND_OLD_BASIS_REQUIRED')
                after=select_round(doc,b['selection'])
                for p in b['selection']['task']['phases'].values():self._route(c,who,project,p['route'])
            elif op=='admit_actor':
                after=admit_actor(doc,args['admission'])
                for route in args['admission']['route_bindings'].values():self._route(c,who,project,route)
            elif op=='set_access_window':
                after=set_access_window(doc,args['access_window'])
                self._access_window_current(c,doc,args['access_window'],context,who,project)
            elif op=='register_task':
                key,a=self._current_actor(doc,context,who,project)
                need(a['kind']=='AUTHENTICATED_BUSINESS_PARTY' and 'REGISTER_TASK' in a['allowed_operations']
                     and type(args['task'])is dict and args['task'].get('owner_actor_ref')==key,'OWN_AUTHORIZED_TASK_OWNER_REQUIRED')
                after=select_task(doc,args['task'])
                need(datetime.now(timezone.utc)<stamp(args['task']['expires_at']),'TASK_PERMISSION_EXPIRED')
                # Routes are exact issuer-admitted data, not a private transport
                # owner lookup with the ordinary task owner's identity. Live
                # service custody still gates the later normal delivery.
            elif op=='confirm_own_readback':after=activate(doc,args['actor_ref'],who,args['epoch'],session_binding)
            else:
                self._current_actor(doc,context,who,project)
                after,material=admit_material(doc,args['material'],who)
            if after==doc:
                return {'result':'EXACT_ALREADY_PRESENT_NO_WRITE','revision':before['revision'],
                        'fingerprint':before['fingerprint'],'retry_allowed':False}
            receipt=self.store.save(c,who,project,before,after,operation,fp)
        with self.store.transaction(who,project,write=False,mode='ISSUER_READ' if private else 'ACTOR_READ') as c:
            observed=self.store.load(c,who,project)
        need(observed['revision']==receipt['revision'] and observed['fingerprint']==receipt['fingerprint'],'COMMIT_READBACK_CHANGED_RECONCILE_ORIGINAL')
        return {'result':'COMMITTED_INDEPENDENT_READBACK_PASS','receipt':receipt,'request_fingerprint':fp,
                'destination_ref':destination_ref,'destination_active':op=='confirm_own_readback'}
