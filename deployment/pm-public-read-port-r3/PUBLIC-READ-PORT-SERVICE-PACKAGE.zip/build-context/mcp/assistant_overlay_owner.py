"""Current owner-backed Assistant overlay decision reader for the Context host.

This module owns no policy and exposes no write surface. It reads one exact,
already-persisted current Assistant policy plus one exact decision from the
existing Context PostgreSQL home and holds both owner revisions stable while
the existing atomic role attach runs.
"""

from __future__ import annotations

import copy
import re
from contextlib import contextmanager, ExitStack
from contextvars import ContextVar
from typing import Any, Callable


SHA256 = re.compile(r"^[0-9a-f]{64}$")
HEX40 = re.compile(r"^[0-9a-f]{40}$")
REF = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.@:-]{0,255}$")

POLICY_FIELDS = (
    "tenant_ref", "workspace_ref", "principal_ref", "consumer_ref", "session_ref",
    "policy_ref", "policy_revision", "current", "revoked", "owner_authorization_ref",
    "allowed_role", "source_revision",
)
DECISION_FIELDS = (
    "tenant_ref", "workspace_ref", "principal_ref", "consumer_ref", "session_ref",
    "generation_ref", "decision_ref", "policy_ref", "policy_revision", "owner_revision",
    "current", "revoked", "pre_role_fingerprint", "ready_unbound_receipt_fingerprint",
    "expected_revision", "source_revision", "overlay_ref", "actor_ref", "actor_generation_ref",
)


class AssistantOverlayOwnerError(RuntimeError):
    pass


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise AssistantOverlayOwnerError(message)


def _text(value: Any) -> str:
    _require(isinstance(value, str) and bool(value.strip()), "assistant-owner-text-required")
    return value.strip()


def _row_dict(cursor: Any, row: Any) -> dict[str, Any]:
    if isinstance(row, dict):
        return dict(row)
    description = getattr(cursor, "description", None)
    _require(description is not None, "assistant-owner-cursor-description-required")
    names = [item.name if hasattr(item, "name") else item[0] for item in description]
    return dict(zip(names, row))


def _cleanup(connection: Any, cursor: Any, original: BaseException | None) -> None:
    """Close every acquired DB resource without masking an earlier denial."""
    failures: list[BaseException] = []
    if connection is not None:
        try:
            connection.rollback()
        except BaseException as exc:  # cleanup must continue through later resources
            failures.append(exc)
    if cursor is not None:
        try:
            cursor.close()
        except BaseException as exc:
            failures.append(exc)
    if connection is not None:
        try:
            connection.close()
        except BaseException as exc:
            failures.append(exc)
    if original is None and failures:
        raise failures[0]


class _DecisionFence:
    def __init__(self, resolver: "PostgresAssistantOverlayDecisionResolver", binding: dict[str, Any]):
        self._resolver = resolver
        self._binding = copy.deepcopy(binding)
        self._connection = None
        self._cursor = None

    def __enter__(self):
        try:
            self._connection = self._resolver._connection_factory()
            self._cursor = self._connection.cursor()
            self._resolver._set_local_timeout(self._cursor)
            policy = self._resolver._select_policy(self._cursor, self._binding, for_share=True)
            self._resolver._validate_bound_policy(policy, self._binding)
            decision = self._resolver._select_decision(self._cursor, self._binding, for_share=True)
            self._resolver._validate_bound_decision(decision, self._binding)
            return self
        except BaseException as exc:
            _cleanup(self._connection, self._cursor, exc)
            self._connection = None
            self._cursor = None
            raise

    def assert_current(self) -> None:
        _require(self._cursor is not None, "assistant-owner-fence-not-entered")
        policy = self._resolver._select_policy(self._cursor, self._binding, for_share=False)
        self._resolver._validate_bound_policy(policy, self._binding)
        decision = self._resolver._select_decision(self._cursor, self._binding, for_share=False)
        self._resolver._validate_bound_decision(decision, self._binding)

    def __exit__(self, exc_type, exc, tb):
        original = exc if isinstance(exc, BaseException) else None
        try:
            _cleanup(self._connection, self._cursor, original)
        finally:
            self._connection = None
            self._cursor = None
        return False


class PostgresAssistantOverlayDecisionResolver:
    """Read and fence one exact current Assistant policy and decision.

    The client cannot select actor, role, overlay, policy, decision or signature.
    Those values must already exist in server-owned policy/decision heads and be
    bound to the authenticated tenant/workspace/principal/consumer/session tuple.
    """

    POLICY_SCHEMA = "cerebro-assistant-overlay-policy/v1"
    DECISION_SCHEMA = "cerebro-assistant-overlay-decision/v1"
    POLICY_TABLE = "cerebro_assistant_overlay_policy_heads"
    DECISION_TABLE = "cerebro_assistant_overlay_decision_heads"

    def __init__(self, connection_factory: Callable[[], Any]):
        _require(callable(connection_factory), "assistant-owner-connection-factory-required")
        self._connection_factory = connection_factory
        self._pending: dict[int, dict[str, Any]] = {}
        self._admission = ContextVar("assistant_normal_admission_window", default=None)

    @contextmanager
    def hold_admission_window(self):
        """One host call; resolve acquires owner row locks before returning ALLOW.

        No input, trial profile, policy write or authority is introduced here.
        Locks survive seal, atomic attach and readback until the host exits.
        """
        _require(self._admission.get() is None, "assistant-owner-nested-window-refused")
        with ExitStack() as stack:
            state = {"stack": stack, "fence": None, "attempted": False}
            token = self._admission.set(state)
            try:
                yield
            finally:
                self._admission.reset(token)

    def check_admission_current(self):
        state = self._admission.get()
        _require(state is not None and state["fence"] is not None,
                 "assistant-owner-resolved-admission-window-required")
        state["fence"].assert_current()

    @staticmethod
    def _set_local_timeout(cursor: Any) -> None:
        cursor.execute("SET LOCAL statement_timeout = '5s'")

    @staticmethod
    def _identity_tuple(identity: Any, session_ref: str) -> dict[str, str]:
        return {
            "tenant_ref": _text(getattr(identity, "tenant_ref", None)),
            "workspace_ref": _text(getattr(identity, "workspace_ref", None)),
            "principal_ref": _text(getattr(identity, "principal_ref", None)),
            "consumer_ref": _text(getattr(identity, "consumer_ref", None)),
            "session_ref": _text(session_ref),
        }

    def _select_policy(self, cursor: Any, binding: dict[str, Any], *, for_share: bool) -> dict[str, Any]:
        cursor.execute(
            """
            SELECT tenant_ref, workspace_ref, principal_ref, consumer_ref, session_ref,
                   policy_ref, policy_revision, current, revoked, owner_authorization_ref,
                   allowed_role, source_revision
              FROM cerebro_assistant_overlay_policy_heads
             WHERE tenant_ref = %s AND workspace_ref = %s AND principal_ref = %s
               AND consumer_ref = %s AND session_ref = %s AND policy_ref = %s
            """ + (" FOR SHARE" if for_share else ""),
            (
                binding["tenant_ref"], binding["workspace_ref"], binding["principal_ref"],
                binding["consumer_ref"], binding["session_ref"], binding["policy_ref"],
            ),
        )
        row = cursor.fetchone()
        _require(row is not None, "assistant-owner-policy-absent")
        return _row_dict(cursor, row)

    def _select_decision(self, cursor: Any, binding: dict[str, Any], *, for_share: bool) -> dict[str, Any]:
        cursor.execute(
            """
            SELECT tenant_ref, workspace_ref, principal_ref, consumer_ref, session_ref,
                   generation_ref, decision_ref, policy_ref, policy_revision, owner_revision,
                   current, revoked, pre_role_fingerprint, ready_unbound_receipt_fingerprint,
                   expected_revision, source_revision, overlay_ref, actor_ref, actor_generation_ref
              FROM cerebro_assistant_overlay_decision_heads
             WHERE tenant_ref = %s AND workspace_ref = %s AND principal_ref = %s
               AND consumer_ref = %s AND session_ref = %s AND generation_ref = %s
            """ + (" FOR SHARE" if for_share else ""),
            (
                binding["tenant_ref"], binding["workspace_ref"], binding["principal_ref"],
                binding["consumer_ref"], binding["session_ref"], binding["generation_ref"],
            ),
        )
        row = cursor.fetchone()
        _require(row is not None, "assistant-owner-decision-absent")
        return _row_dict(cursor, row)

    @classmethod
    def _validate_policy(cls, row: dict[str, Any]) -> None:
        _require(row.get("current") is True and row.get("revoked") is False,
                 "assistant-owner-policy-not-current")
        _require(type(row.get("policy_revision")) is int and row["policy_revision"] > 0,
                 "assistant-owner-policy-revision-required")
        for field in ("policy_ref", "owner_authorization_ref"):
            value = row.get(field)
            _require(isinstance(value, str) and REF.fullmatch(value) is not None,
                     "assistant-owner-policy-ref-invalid:" + field)
        _require(row.get("allowed_role") == "ASSISTANT",
                 "assistant-owner-policy-role-mismatch")
        _require(isinstance(row.get("source_revision"), str) and HEX40.fullmatch(row["source_revision"]) is not None,
                 "assistant-owner-policy-source-invalid")

    @classmethod
    def _validate_decision(cls, row: dict[str, Any]) -> None:
        _require(row.get("current") is True and row.get("revoked") is False,
                 "assistant-owner-decision-not-current")
        _require(type(row.get("owner_revision")) is int and row["owner_revision"] > 0,
                 "assistant-owner-revision-required")
        _require(type(row.get("policy_revision")) is int and row["policy_revision"] > 0,
                 "assistant-owner-decision-policy-revision-required")
        _require(type(row.get("expected_revision")) is int and row["expected_revision"] > 0,
                 "assistant-owner-expected-revision-required")
        for field in ("decision_ref", "policy_ref", "generation_ref", "overlay_ref", "actor_ref", "actor_generation_ref"):
            value = row.get(field)
            _require(isinstance(value, str) and REF.fullmatch(value) is not None,
                     "assistant-owner-ref-invalid:" + field)
        for field in ("pre_role_fingerprint", "ready_unbound_receipt_fingerprint"):
            _require(isinstance(row.get(field), str) and SHA256.fullmatch(row[field]) is not None,
                     "assistant-owner-fingerprint-invalid:" + field)
        _require(isinstance(row.get("source_revision"), str) and HEX40.fullmatch(row["source_revision"]) is not None,
                 "assistant-owner-source-invalid")

    @classmethod
    def _validate_bound_policy(cls, row: dict[str, Any], binding: dict[str, Any]) -> None:
        cls._validate_policy(row)
        for field in (
            "tenant_ref", "workspace_ref", "principal_ref", "consumer_ref", "session_ref",
            "policy_ref", "policy_revision", "owner_authorization_ref", "source_revision",
        ):
            _require(row.get(field) == binding.get(field), "assistant-owner-policy-fence-mismatch:" + field)

    @classmethod
    def _validate_bound_decision(cls, row: dict[str, Any], binding: dict[str, Any]) -> None:
        cls._validate_decision(row)
        for field in (
            "tenant_ref", "workspace_ref", "principal_ref", "consumer_ref", "session_ref",
            "generation_ref", "decision_ref", "policy_ref", "policy_revision", "owner_revision",
            "pre_role_fingerprint", "ready_unbound_receipt_fingerprint", "expected_revision",
            "source_revision", "overlay_ref", "actor_ref", "actor_generation_ref",
        ):
            _require(row.get(field) == binding.get(field), "assistant-owner-fence-mismatch:" + field)

    def resolve(self, *, pre_role_generation: dict[str, Any], verified_source: dict[str, Any],
                identity: Any, session_ref: str) -> dict[str, Any]:
        window = self._admission.get()
        if window is not None:
            _require(not window["attempted"], "assistant-owner-window-already-attempted")
            window["attempted"] = True
        _require(isinstance(pre_role_generation, dict), "assistant-owner-pre-role-required")
        _require(isinstance(verified_source, dict), "assistant-owner-verified-source-required")
        receipt = pre_role_generation.get("ready_unbound_receipt")
        _require(isinstance(receipt, dict), "assistant-owner-ready-receipt-required")
        binding = {
            **self._identity_tuple(identity, session_ref),
            "generation_ref": _text(pre_role_generation.get("generation_ref")),
        }

        connection = None
        cursor = None
        try:
            connection = self._connection_factory()
            cursor = connection.cursor()
            self._set_local_timeout(cursor)
            decision = self._select_decision(cursor, binding, for_share=False)
            self._validate_decision(decision)
            policy_binding = {**binding, "policy_ref": decision["policy_ref"]}
            policy = self._select_policy(cursor, policy_binding, for_share=False)
            self._validate_policy(policy)
        except BaseException as exc:
            _cleanup(connection, cursor, exc)
            raise
        else:
            _cleanup(connection, cursor, None)

        _require(policy["policy_ref"] == decision["policy_ref"]
                 and policy["policy_revision"] == decision["policy_revision"],
                 "assistant-owner-policy-revision-mismatch")
        _require(policy["source_revision"] == decision["source_revision"],
                 "assistant-owner-policy-source-mismatch")
        _require(decision["pre_role_fingerprint"] == pre_role_generation.get("fingerprint"),
                 "assistant-owner-pre-role-fingerprint-mismatch")
        _require(decision["ready_unbound_receipt_fingerprint"] == receipt.get("receipt_fingerprint"),
                 "assistant-owner-ready-receipt-fingerprint-mismatch")
        _require(decision["expected_revision"] == pre_role_generation.get("revision"),
                 "assistant-owner-generation-revision-mismatch")
        _require(decision["source_revision"] == pre_role_generation.get("source_revision")
                 == verified_source.get("source_revision"),
                 "assistant-owner-source-mismatch")

        result = {
            "result": "ALLOW",
            "decision_ref": decision["decision_ref"],
            "pre_role_fingerprint": decision["pre_role_fingerprint"],
            "ready_unbound_receipt_fingerprint": decision["ready_unbound_receipt_fingerprint"],
            "overlay_payload": {
                "generation_ref": decision["generation_ref"],
                "expected_revision": decision["expected_revision"],
                "overlay_ref": decision["overlay_ref"],
                "actor_ref": decision["actor_ref"],
                "role": "ASSISTANT",
                "actor_generation_ref": decision["actor_generation_ref"],
                "source_revision": decision["source_revision"],
            },
        }
        fence_binding = {
            **binding,
            "decision_ref": decision["decision_ref"],
            "policy_ref": decision["policy_ref"],
            "policy_revision": decision["policy_revision"],
            "owner_authorization_ref": policy["owner_authorization_ref"],
            "owner_revision": decision["owner_revision"],
            "pre_role_fingerprint": decision["pre_role_fingerprint"],
            "ready_unbound_receipt_fingerprint": decision["ready_unbound_receipt_fingerprint"],
            "expected_revision": decision["expected_revision"],
            "source_revision": decision["source_revision"],
            "overlay_ref": decision["overlay_ref"],
            "actor_ref": decision["actor_ref"],
            "actor_generation_ref": decision["actor_generation_ref"],
        }
        if window is None:
            # Existing explicit resolve/hold_current callers retain their API.
            self._pending[id(result)] = fence_binding
        else:
            # Re-read under actual FOR SHARE locks: an intervening owner change
            # refuses before the result can be sealed by the host.
            window["fence"] = window["stack"].enter_context(_DecisionFence(self, fence_binding))
            self.check_admission_current()
        return result

    def hold_current(self, decision: dict[str, Any]) -> _DecisionFence:
        binding = self._pending.pop(id(decision), None)
        _require(binding is not None, "assistant-owner-decision-not-bound")
        return _DecisionFence(self, binding)
