"""Bounded BK11 task data and owner-authorized carrier updates; no role creation."""
import copy,hashlib,json,re
from datetime import datetime,timezone
SCHEMA='cerebro-project-actor-admissions/v1'
AGGREGATE='actor-execution-admissions'
REF=re.compile(r'\A[A-Za-z0-9][A-Za-z0-9_.:@/#=-]{0,159}\Z')
HEX=re.compile(r'\A[a-f0-9]{64}\Z')
class AdmissionRefused(RuntimeError):pass
def need(ok,reason):
    if not ok:raise AdmissionRefused(reason)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(value):return hashlib.sha256(canonical(value)).hexdigest()
def reference(value):need(type(value)is str and REF.fullmatch(value)is not None,'REFERENCE_INVALID');return value
def exact(value,keys):need(type(value)is dict and set(value)==set(keys),'EXACT_FIELDS_REQUIRED')
def blank():return {'schema':SCHEMA,'actors':{},'business_owners':{},'destinations':{},'tasks':{},'materials':{}}
def participants(doc):return {**doc['business_owners'],**doc['actors']}
def caller(context):
    i=context.identity;i.validate();s=context.transport_session()
    need(type(s)is dict and type(s.get('session_ref'))is str,'OWN_TRANSPORT_METADATA_REQUIRED')
    return {'tenant_ref':i.tenant_ref,'workspace_ref':i.workspace_ref,'principal_ref':i.principal_ref,
            'consumer_ref':i.consumer_ref,'session_ref':s['session_ref']}
def carrier_matches(actor,who):
    return all(actor['carrier'].get(k)==who[k] for k in ('principal_ref','consumer_ref','session_ref'))
def active(doc,actor_ref,who):
    a=participants(doc).get(actor_ref)
    need(a is not None and a['execution']=='ACTIVE' and carrier_matches(a,who),'OWN_CURRENT_EXECUTION_FENCED')
    if a.get('access_expires_at') is not None:
        need(datetime.now(timezone.utc)<stamp(a['access_expires_at']),'ACTOR_ACCESS_EXPIRED')
    return a
def stamp(value):
    need(type(value)is str and len(value)<=64,'FINITE_TIME_REQUIRED')
    try:result=datetime.fromisoformat(value.replace('Z','+00:00'))
    except ValueError:raise AdmissionRefused('FINITE_TIME_REQUIRED') from None
    need(result.tzinfo is not None,'FINITE_TIME_REQUIRED');return result
def producer_snapshot(actor):
    need(type(actor.get('session_binding_id'))is str and bool(actor['session_binding_id']),
         'ORIGINAL_PRODUCER_BINDING_REQUIRED')
    return {**{k:actor['carrier'][k] for k in ('principal_ref','consumer_ref','session_ref')},
            'session_binding_id':actor['session_binding_id'],'epoch':actor['epoch']}
def own_actor(doc,who,*,require_active=True):
    found=[(key,a) for key,a in participants(doc).items() if carrier_matches(a,who)]
    need(len(found)==1,'OWN_ACTOR_AMBIGUOUS_OR_MISSING')
    key,a=found[0]
    if require_active:active(doc,key,who)
    return key,a

def access_binding_digest(actor):
    """Exact existing identity/permission fence; excludes only access decisions."""
    return digest({k:v for k,v in actor.items()
                   if k not in ('access_expires_at','ordinary_access_decision')})

def set_access_window(doc,window):
    """Private owner-only finite access data change, never actor activation.

    The host supplies issuer, live binding and aggregate CAS guards. Task dates,
    effect permissions, producer snapshots and all existing identities survive.
    """
    exact(window,('schema','mode','subjects','not_before','expires_at',
                  'owner_decision_ref','owner_decision_sha256'))
    need(window['schema']=='cerebro-ordinary-actor-access-window/v1'
         and window['mode'] in ('GRANT','REVOKE'),'ACCESS_WINDOW_MODE_REQUIRED')
    need(type(window['owner_decision_ref'])is str and 0<len(window['owner_decision_ref'])<=512
         and type(window['owner_decision_sha256'])is str
         and HEX.fullmatch(window['owner_decision_sha256']) is not None,'ACCESS_OWNER_DECISION_REQUIRED')
    now=datetime.now(timezone.utc);start=stamp(window['not_before']);end=stamp(window['expires_at'])
    need(start<=now and (start<=now<end if window['mode']=='GRANT' else start<=end<=now),
         'CURRENT_FINITE_ACCESS_WINDOW_REQUIRED')
    subjects=window['subjects']
    need(type(subjects)is list and 1<=len(subjects)<=2,'BOUNDED_EXISTING_ACCESS_SUBJECTS_REQUIRED')
    seen=set();out=copy.deepcopy(doc)
    for subject in subjects:
        exact(subject,('actor_ref','expected_epoch','expected_access_expires_at','expected_binding_sha256'))
        key=reference(subject['actor_ref']);need(key not in seen,'DUPLICATE_ACCESS_SUBJECT');seen.add(key)
        a=participants(doc).get(key)
        need(a is not None and type(subject['expected_epoch'])is int
             and a['epoch']==subject['expected_epoch'],'EXISTING_ACCESS_ACTOR_EPOCH_REQUIRED')
        need(a.get('access_expires_at')==subject['expected_access_expires_at']
             and access_binding_digest(a)==subject['expected_binding_sha256'],'ACCESS_EXPECTED_BEFOREIMAGE_CHANGED')
        if window['mode']=='GRANT':
            need(a['execution']=='ACTIVE' and type(a.get('session_binding_id'))is str
                 and bool(a['session_binding_id']),'ACCESS_UPDATE_CANNOT_ACTIVATE_OR_BIND')
        target=out['actors'] if key in out['actors'] else out['business_owners']
        target[key]['access_expires_at']=window['expires_at']
        target[key]['ordinary_access_decision']={
            'schema':window['schema'],'mode':window['mode'],
            'not_before':window['not_before'],'expires_at':window['expires_at'],
            'owner_decision_ref':window['owner_decision_ref'],
            'owner_decision_sha256':window['owner_decision_sha256'],
            'epoch':a['epoch'],'binding_sha256':subject['expected_binding_sha256']}
    return out
def prepare_destination(doc,who,metadata):
    exact(metadata,('carrier_ref','host','home'))
    need(all(type(v)is str and 0<len(v.encode())<=512 and '\x00' not in v for v in metadata.values()),'DESTINATION_METADATA_REQUIRED')
    record={'carrier':{**{k:who[k] for k in ('principal_ref','consumer_ref','session_ref')},**metadata},
            'assurance':'AUTHENTICATED_CALLER_WITH_REQUEST_SESSION_METADATA;HOST_HOME_SELF_REPORTED;NO_GRANT'}
    key='destination:'+digest(record)[:40];out=copy.deepcopy(doc)
    need(key in out['destinations'] or len(out['destinations'])<64,'DESTINATION_BOUND')
    previous=out['destinations'].get(key)
    if previous and 'own_native_evidence' in previous:record['own_native_evidence']=previous['own_native_evidence']
    out['destinations'][key]=record
    return out,key
def admit_actor(doc,admission):
    """Only called by the host's qualified issuer. Never invent native identity."""
    exact(admission,('party','allowed_peers','allowed_routes','route_bindings','activation_expires_at',
                     'access_expires_at','expected_epoch','enabled'))
    p=admission['party']
    exact(p,('actor_ref','kind','destination_ref','native_selection','owner_basis_ref','owner_basis_sha256','continuity'))
    key=reference(p['actor_ref']);need(p['kind'] in ('NATIVE_EXECUTOR','AUTHENTICATED_BUSINESS_PARTY'),'SUPPORTED_PARTY_KIND_REQUIRED')
    need(type(admission['expected_epoch'])is int and type(admission['enabled'])is bool,'EXACT_EPOCH_AND_STATUS_REQUIRED')
    now=datetime.now(timezone.utc)
    need(now<stamp(admission['activation_expires_at'])<=stamp(admission['access_expires_at']),
         'FINITE_ACTIVATION_AND_ACCESS_WINDOW_REQUIRED')
    need(type(p['owner_basis_ref'])is str and bool(p['owner_basis_ref']) and
         type(p['owner_basis_sha256'])is str and HEX.fullmatch(p['owner_basis_sha256'])is not None,'EXACT_OWNER_BASIS_REQUIRED')
    exact(p['continuity'],('current_ref','pending_refs','unknown_effect_refs'))
    need(type(p['continuity']['current_ref'])is str and 0<len(p['continuity']['current_ref'])<=512,'CURRENT_REF_REQUIRED')
    for f in ('pending_refs','unknown_effect_refs'):
        need(type(p['continuity'][f])is list and len(p['continuity'][f])<=64 and
             all(type(v)is str and 0<len(v)<=512 for v in p['continuity'][f]),'BOUNDED_CONTINUITY_REQUIRED')
    for f in ('allowed_peers','allowed_routes'):
        values=admission[f];need(type(values)is list and 0<len(values)<=64 and
             all(type(v)is str for v in values) and len(set(values))==len(values),'BOUNDED_PERMISSION_REQUIRED')
        for v in values:reference(v)
    need(key not in admission['allowed_peers'],'DISTINCT_PEERS_REQUIRED')
    need(type(admission['route_bindings'])is dict and set(admission['route_bindings'])==set(admission['allowed_routes']),
         'EXACT_AUTHORIZED_ROUTE_BINDINGS_REQUIRED')
    for route_ref,route in admission['route_bindings'].items():
        validate_route(route);need(route_ref==route['route_ref'],'EXACT_AUTHORIZED_ROUTE_BINDINGS_REQUIRED')
    d=doc['destinations'].get(p['destination_ref']);need(d is not None,'OWN_DESTINATION_REQUIRED')
    old=participants(doc).get(key);carrier=d['carrier']
    need(admission['expected_epoch']==(old['epoch'] if old else 0),'ACTOR_EPOCH_CONFLICT')
    for other_key,a in participants(doc).items():
        if other_key!=key:
            need(not all(a['carrier'][k]==carrier[k] for k in ('principal_ref','consumer_ref','session_ref')),
                 'CARRIER_ALREADY_ASSIGNED')
            need(not any(all(r['carrier'][k]==carrier[k] for k in ('principal_ref','consumer_ref','session_ref'))
                         for r in a.get('retired_carriers',[])),'RETIRED_CARRIER_CANNOT_BE_REASSIGNED')
    record={**copy.deepcopy(p),'carrier':copy.deepcopy(carrier),'epoch':1 if old is None else old['epoch']+1,
            'execution':'DESTINATION_DISABLED' if admission['enabled'] else 'REVOKED',
            'session_binding_id':None,'retired_carriers':copy.deepcopy(old.get('retired_carriers',[])) if old else [],
            'activation_expires_at':admission['activation_expires_at'],'access_expires_at':admission['access_expires_at'],
            'allowed_peers':copy.deepcopy(admission['allowed_peers']),'allowed_routes':copy.deepcopy(admission['allowed_routes']),
            'route_bindings':copy.deepcopy(admission['route_bindings']),
            'allowed_operations':['OWN_READBACK','ADMIT_SELECTED_MATERIAL','REGISTER_SELECTED_MATERIAL','READ_OWN_ACCEPTED_BASIS']}
    if p['kind']=='AUTHENTICATED_BUSINESS_PARTY':
        need(p['native_selection'] is None,'BUSINESS_NATIVE_FIELDS_MUST_BE_NULL')
        record.update(native_role=None,generation_ref=None,native_status='NOT_APPLICABLE')
        record['allowed_operations'].append('REGISTER_TASK')
    else:
        native=p['native_selection'];exact(native,('actor_ref','generation_ref','birth_generation_ref','native_role'))
        evidence=d.get('own_native_evidence')
        need(native['actor_ref']==key and native['native_role']=='WORKER' and type(evidence)is dict
             and evidence['selection']==native,'OWN_EXISTING_W_NATIVE_EVIDENCE_REQUIRED')
        record.update(native,native_snapshot=copy.deepcopy(evidence['snapshot']))
    out=copy.deepcopy(doc)
    if old:
        need(old['kind']==p['kind'] and old['native_selection']==p['native_selection'],
             'SESSION_CHANGE_CANNOT_REPLACE_ACTOR_KIND_OR_GENERATION')
        for field in ('pending_refs','unknown_effect_refs'):
            kept=list(dict.fromkeys(old['continuity'][field]+record['continuity'][field]))
            need(len(kept)<=64,'BOUNDED_CONTINUITY_REQUIRED')
            record['continuity'][field]=kept
        # Fill provenance before changing the carrier; never reconstruct it from
        # the new session when reading already accepted material.
        for material in out['materials'].values():
            if material['sender_actor_ref']==key and 'producer' not in material:
                material['producer']=producer_snapshot(old)
        changed=any(old['carrier'][k]!=carrier[k] for k in ('principal_ref','consumer_ref','session_ref'))
        if changed:
            need(not any(all(r['carrier'][k]==carrier[k] for k in ('principal_ref','consumer_ref','session_ref'))
                         for r in record['retired_carriers']),'RETIRED_CARRIER_CANNOT_BE_REACTIVATED')
            need(len(record['retired_carriers'])<32,'RETIRED_CARRIER_BOUND')
            record['retired_carriers'].append({'carrier':copy.deepcopy(old['carrier']),
                'epoch':old['epoch'],'session_binding_id':old['session_binding_id']})
    else:need(len(participants(out))<8,'ADMITTED_ACTOR_BOUND')
    target='actors' if p['kind']=='NATIVE_EXECUTOR' else 'business_owners'
    out[target][key]=record
    return out
def select_round(doc,selection):
    exact(selection,('parties','task','activation_expires_at'))
    need(not doc['actors'] and not doc['business_owners'] and not doc['tasks'] and not doc['materials'],
         'INITIAL_SETUP_ALREADY_EXISTS_USE_ACTOR_OR_TASK_OPERATION')
    expiry=datetime.fromisoformat(selection['activation_expires_at'].replace('Z','+00:00'))
    need(expiry.tzinfo is not None and datetime.now(timezone.utc)<expiry,'FINITE_OWN_ACTIVATION_WINDOW_REQUIRED')
    specs=selection['parties'];need(type(specs)is list and len(specs)==2,'EXACT_TWO_PARTIES_REQUIRED')
    need({p.get('kind') for p in specs}=={'NATIVE_EXECUTOR','AUTHENTICATED_BUSINESS_PARTY'},'EXACT_BUSINESS_AND_NATIVE_PAIR')
    out=copy.deepcopy(doc);carriers=[]
    for p in specs:
        exact(p,('actor_ref','kind','destination_ref','native_selection','owner_basis_ref','owner_basis_sha256','continuity'))
        key=reference(p['actor_ref']);need(key not in participants(out),'DISTINCT_PARTIES_REQUIRED')
        d=doc['destinations'].get(p['destination_ref']);need(d is not None,'OWN_DESTINATION_REQUIRED')
        carrier=d['carrier'];namespace=tuple(carrier[k] for k in ('principal_ref','consumer_ref','session_ref'))
        need(namespace not in carriers,'DISTINCT_OWN_CARRIERS_REQUIRED');carriers.append(namespace)
        need(type(p['owner_basis_ref'])is str and bool(p['owner_basis_ref']) and HEX.fullmatch(p['owner_basis_sha256']) is not None,'EXACT_OWNER_BASIS_REQUIRED')
        exact(p['continuity'],('current_ref','pending_refs','unknown_effect_refs'))
        need(type(p['continuity']['current_ref'])is str and bool(p['continuity']['current_ref']),'CURRENT_REF_REQUIRED')
        for field in ('pending_refs','unknown_effect_refs'):
            need(type(p['continuity'][field])is list and len(p['continuity'][field])<=64
                 and all(type(v)is str and 0<len(v)<=512 for v in p['continuity'][field]),'BOUNDED_CONTINUITY_REQUIRED')
        record={**copy.deepcopy(p),'carrier':carrier,'epoch':1,'execution':'DESTINATION_DISABLED',
                'session_binding_id':None,'retired_carriers':[],'activation_expires_at':selection['activation_expires_at'],
                'access_expires_at':selection['task']['expires_at'],
                'allowed_operations':['OWN_READBACK','ADMIT_SELECTED_MATERIAL','REGISTER_SELECTED_MATERIAL','READ_OWN_ACCEPTED_BASIS']}
        if p['kind']=='AUTHENTICATED_BUSINESS_PARTY':
            need(p['native_selection'] is None,'BUSINESS_NATIVE_FIELDS_MUST_BE_NULL')
            record.update(native_role=None,generation_ref=None,native_status='NOT_APPLICABLE')
            record['allowed_operations'].append('REGISTER_TASK')
            out['business_owners'][key]=record
        else:
            native=p['native_selection'];exact(native,('actor_ref','generation_ref','birth_generation_ref','native_role'))
            evidence=d.get('own_native_evidence')
            need(native['actor_ref']==key and native['native_role']=='WORKER' and type(evidence)is dict
                 and evidence['selection']==native,'OWN_EXISTING_W_NATIVE_EVIDENCE_REQUIRED')
            record.update(native,native_snapshot=evidence['snapshot'])
            out['actors'][key]=record
    task=selection['task'];phase=task['phases']
    need(task['owner_actor_ref'] in out['business_owners'],'BUSINESS_TASK_OWNER_REQUIRED')
    forward=phase.get('FORWARD',{});ret=phase.get('RETURN',{})
    need(forward.get('sender_actor_ref')==task['owner_actor_ref'] and forward.get('recipient_actor_ref') in out['actors']
         and ret.get('sender_actor_ref')==forward['recipient_actor_ref'] and ret.get('recipient_actor_ref')==task['owner_actor_ref'],
         'EXACT_FORWARD_RETURN_DIRECTIONS_REQUIRED')
    for key,a in participants(out).items():
        sent=[p for p in phase.values() if p.get('sender_actor_ref')==key]
        a['allowed_peers']=list(dict.fromkeys(p['recipient_actor_ref'] for p in sent))
        a['allowed_routes']=list(dict.fromkeys(p['route']['route_ref'] for p in sent))
        a['route_bindings']={p['route']['route_ref']:copy.deepcopy(p['route']) for p in sent}
    return select_task(out,task)
def activate(doc,actor_ref,who,epoch,session_binding_id):
    out=copy.deepcopy(doc);a=participants(out).get(actor_ref)
    need(a is not None and a['epoch']==epoch and carrier_matches(a,who),'OWN_COMMITTED_CARRIER_READBACK_MISMATCH')
    need(a['execution']=='DESTINATION_DISABLED','DESTINATION_ALREADY_ACTIVE_OR_FENCED')
    need(datetime.now(timezone.utc)<datetime.fromisoformat(a['activation_expires_at'].replace('Z','+00:00')),'ACTIVATION_EXPIRED')
    reference(session_binding_id);a['session_binding_id']=session_binding_id;a['execution']='ACTIVE'
    return out

def validate_route(route):
    exact(route,('route_ref','transport_owner_ref','receiver_ref','receiver_assignment_ref','binding_revision','pointer_ttl_seconds'))
    for k in ('route_ref','transport_owner_ref','receiver_ref','receiver_assignment_ref'):reference(route[k])
    need(type(route['binding_revision'])is int and route['binding_revision']>0
         and type(route['pointer_ttl_seconds'])is int and 1<=route['pointer_ttl_seconds']<=120,'EXACT_ROUTE_REVISION_TTL_REQUIRED')

def task_entry(doc,task_ref,attempt_ref):
    """Resolve the exact pair without rewriting any legacy key or effect ID."""
    key=canonical([reference(task_ref),reference(attempt_ref)]).decode()
    legacy=task_ref+':'+attempt_ref
    found=[]
    for stored_key in (legacy,key):
        if stored_key not in doc['tasks']:continue
        task=doc['tasks'][stored_key]
        need(type(task)is dict,'TASK_RECORD_INVALID_PRESERVE_ORIGINAL')
        matches=task.get('task_ref')==task_ref and task.get('attempt_ref')==attempt_ref
        if stored_key==key:need(matches,'TASK_KEY_IDENTITY_MISMATCH')
        if matches:found.append((stored_key,task))
    need(len(found)<=1,'TASK_IDENTITY_AMBIGUOUS_PRESERVE_ORIGINAL')
    return found[0] if found else (key,None)


def select_task(doc,task):
    exact(task,('task_ref','attempt_ref','owner_actor_ref','not_before','expires_at','phases'))
    reference(task['task_ref']);reference(task['attempt_ref'])
    need(task['owner_actor_ref'] in participants(doc),'TASK_OWNER_NOT_SELECTED')
    start=stamp(task['not_before']);end=stamp(task['expires_at'])
    need(start.tzinfo is not None and end.tzinfo is not None and end>start,'ACTUAL_TASK_PERMISSION_WINDOW_REQUIRED')
    need(type(task['phases'])is dict and set(task['phases'])=={'FORWARD','RETURN'},'EXACT_TASK_PHASES_REQUIRED')
    need(all(type(p)is dict for p in task['phases'].values()),'EXACT_TASK_PHASES_REQUIRED')
    owner=task['owner_actor_ref'];forward=task['phases']['FORWARD'];reply=task['phases']['RETURN']
    need(owner in doc['business_owners'] and forward.get('sender_actor_ref')==owner
         and forward.get('recipient_actor_ref') in doc['actors']
         and reply.get('sender_actor_ref')==forward['recipient_actor_ref']
         and reply.get('recipient_actor_ref')==owner,'EXACT_FORWARD_RETURN_DIRECTIONS_REQUIRED')
    for phase,p in task['phases'].items():
        exact(p,('sender_actor_ref','recipient_actor_ref','material_revision','original_ref','expected_action',
                 'original_sha256','artifact_repository','artifact_path_prefix','route','content'))
        content=p['content'];exact(content,('mode','material_sha256','envelope_sha256'))
        need(content['mode'] in ('EXACT','SENDER_AUTHORED'),'AUTHORIZED_CONTENT_MODE_REQUIRED')
        if content['mode']=='EXACT':
            need(all(type(content[k])is str and HEX.fullmatch(content[k])is not None
                     for k in ('material_sha256','envelope_sha256')),'EXACT_CONTENT_DIGESTS_REQUIRED')
        else:need(content['material_sha256'] is None and content['envelope_sha256'] is None,'SENDER_CONTENT_DIGESTS_MUST_BE_NULL')
        need(type(p['original_sha256'])is str and HEX.fullmatch(p['original_sha256'])is not None,'EXACT_ORIGINAL_DIGEST_REQUIRED')
        sender,receiver=p['sender_actor_ref'],p['recipient_actor_ref']
        need(sender in participants(doc) and receiver in participants(doc),'TASK_PEERS_NOT_SELECTED')
        need(receiver in participants(doc)[sender]['allowed_peers'],'PEER_NOT_ADMITTED')
        for k in ('material_revision','original_ref','expected_action','artifact_repository','artifact_path_prefix'):
            need(type(p[k])is str and 0<len(p[k].encode())<=512,'TASK_OWNER_RULE_REQUIRED')
        route=p['route'];validate_route(route)
        need(route['route_ref'] in participants(doc)[sender]['allowed_routes'],'ROUTE_NOT_ADMITTED')
        need(participants(doc)[sender].get('route_bindings',{}).get(route['route_ref'])==route,
             'EXACT_AUTHORIZED_ROUTE_BINDING_REQUIRED')
    key,previous=task_entry(doc,task['task_ref'],task['attempt_ref']);out=copy.deepcopy(doc)
    if previous is not None:need(previous==task,'TASK_RULE_CONFLICT_PRESERVE_ORIGINAL')
    else:need(len(out['tasks'])<64,'TASK_BOUND');out['tasks'][key]=copy.deepcopy(task)
    return out

def admit_material(doc,args,who):
    exact(args,('task_ref','attempt_ref','phase','material','envelope','artifact'))
    key,task=task_entry(doc,args['task_ref'],args['attempt_ref'])
    need(task is not None and args['phase'] in ('FORWARD','RETURN'),'SELECTED_TASK_PHASE_REQUIRED')
    p=task['phases'][args['phase']];sender=active(doc,p['sender_actor_ref'],who)
    need(p['recipient_actor_ref'] in sender['allowed_peers'] and p['route']['route_ref'] in sender['allowed_routes'],
         'CURRENT_TASK_PEER_ROUTE_SCOPE_REVOKED')
    need(sender.get('route_bindings',{}).get(p['route']['route_ref'])==p['route'],
         'CURRENT_TASK_ROUTE_BINDING_REVOKED')
    now=datetime.now(timezone.utc)
    need(datetime.fromisoformat(task['not_before'].replace('Z','+00:00'))<=now<
         datetime.fromisoformat(task['expires_at'].replace('Z','+00:00')),'TASK_PERMISSION_EXPIRED_OR_NOT_YET_VALID')
    for k,bound in (('material',16384),('envelope',4096)):
        need(type(args[k])is str and 0<len(args[k].encode('utf-8'))<=bound,'BOUNDED_REAL_MATERIAL_REQUIRED')
    policy=p.get('content')
    need(type(policy)is dict,'LEGACY_TASK_CONTENT_POLICY_REQUIRES_NEW_AUTHORIZED_TASK')
    if policy['mode']=='EXACT':
        need(hashlib.sha256(args['material'].encode()).hexdigest()==policy['material_sha256'] and
             hashlib.sha256(args['envelope'].encode()).hexdigest()==policy['envelope_sha256'],
             'AUTHORIZED_TASK_CONTENT_DIGEST_MISMATCH')
    art=args['artifact'];exact(art,('repository','commit','path','bytes','sha256'))
    need(art['repository']==p['artifact_repository'] and type(art['commit'])is str
         and re.fullmatch(r'[a-f0-9]{40,64}',art['commit'])is not None
         and type(art['path'])is str and not art['path'].startswith(('/','\\'))
         and '\\' not in art['path'] and '..' not in art['path'].split('/')
         and type(art['bytes'])is int and art['bytes']>0
         and (art['path']==p['artifact_path_prefix'] or
              art['path'].startswith(p['artifact_path_prefix'].rstrip('/')+'/'))
         and HEX.fullmatch(art['sha256'])is not None,
         'EXACT_PORTABLE_ARTIFACT_RULE_REQUIRED')
    try:envelope=json.loads(args['envelope'])
    except ValueError:raise AdmissionRefused('ENVELOPE_INVALID') from None
    repository=art['repository'].removeprefix('https://github.com/').removesuffix('.git')
    artifact_ref=repository+'@'+art['commit']+':'+art['path']
    need(len(artifact_ref.encode())<=512,'ARTIFACT_REFERENCE_BOUND')
    expected={'task_ref':task['task_ref'],'attempt_ref':task['attempt_ref'],'material_revision':p['material_revision'],
              'original_ref':p['original_ref'],'expected_action':p['expected_action'],'artifact_ref':artifact_ref}
    need(type(envelope)is dict and all(envelope.get(k)==v for k,v in expected.items()),'OWNER_SELECTED_ENVELOPE_MISMATCH')
    need(envelope.get('schema')=='cerebro-business-material-envelope/v1' and envelope.get('phase')==args['phase']
         and envelope.get('artifact')==art,'EXACT_PORTABLE_ENVELOPE_ARTIFACT_REQUIRED')
    material_ref='material:'+digest([key,args['phase']])[:40]
    need(art['bytes']==len(args['material'].encode('utf-8'))
         and art['sha256']==hashlib.sha256(args['material'].encode('utf-8')).hexdigest(),
         'PORTABLE_ARTIFACT_BYTES_DIGEST_MISMATCH')
    record={'material_ref':material_ref,**expected,'phase':args['phase'],
        'parent_sha256':p['original_sha256'],
        'sender_actor_ref':p['sender_actor_ref'],'recipient_actor_ref':p['recipient_actor_ref'],
        'owner_actor_ref':p['sender_actor_ref'],'task_owner_actor_ref':task['owner_actor_ref'],
        'material_sha256':hashlib.sha256(args['material'].encode()).hexdigest(),
        'envelope_sha256':hashlib.sha256(args['envelope'].encode()).hexdigest(),'route':copy.deepcopy(p['route']),
        'producer':producer_snapshot(sender)}
    out=copy.deepcopy(doc)
    if material_ref in out['materials']:
        prior=out['materials'][material_ref]
        # Legacy v1 material is compared without rewriting its original fields.
        comparable={k:v for k,v in record.items() if k!='producer'} if 'producer' not in prior else record
        need(prior==comparable,'MATERIAL_CONFLICT_SAME_ATTEMPT_NO_REPLAY')
    else:need(len(out['materials'])<128,'MATERIAL_BOUND');out['materials'][material_ref]=record
    return out,record
