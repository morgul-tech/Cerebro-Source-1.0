# PM-owner D1 outbox (BK11 candidate, default OFF)

This candidate makes the real PM-owner commit transaction the source of D1 publication obligations. It does not
activate anything. With no route row, `commit_pm_owner_ready` behaves exactly as before. The D1 tools then return
`PM_OWNER_D1_OUTBOX_NOT_BOUND` unless the host constructs the outbox.

## What it changes

- **Migration `0009-pm-owner-d1-outbox`** is additive. It adds three relations:
  - `cerebro_pm_owner_d1_outbox_meta`: a singleton holding the schema version.
  - `cerebro_pm_owner_d1_routes`: installation-owned. The runtime role can only SELECT it.
  - `cerebro_pm_owner_d1_outbox`: the obligations table. It uses FORCE RLS and an immutable-identity trigger. Transitions only move forward, and rows cannot be deleted.
- **Commit path.** Inside the existing `MATERIAL_READY` commit, after the receipt, current pointer and head update, `PostgresPmOwner` inserts one outbox row per enabled route. The insert runs on the same cursor and in the same transaction.
  - Each row holds the original PM identity: `event_id`, `receipt_ref`, `commit_ref`, `revision_after`, `owner_seq`, `snapshot_sha256` and `packet_sha256`.
  - Each row also holds the derived D1 `message_id` and the exact canonical D1 pointer bytes.
  - No material body, mailbox, result copy, token or secret is stored.
  - The commit makes no broker or network call. A rollback or failure before COMMIT leaves neither the receipt nor the intent.
- **Identity mapping.** No new required field is added to `commit_pm_owner_ready`.
  - D1 `owner_event_key` = PM `event_id`.
  - `owner_revision` = PM `owner_seq` (numeric).
  - `event_fingerprint` = `snapshot_sha256`.
  - Referent = (`PM_READY_HINT`, `referent_id`).
  - The opaque `revision_after` is kept, not replaced.
- **New tools.** Three versioned tools are added. Each reauthenticates through the unchanged `OAuthBearerAuthenticator` and the persisted current session.
  - `read_pm_owner_d1_outbox_v1` (read):
    - Callable only by the host-assigned D1 publisher session.
    - `list_pending` uses a keyset cursor with limit ≤ 64; `read_exact` returns one row.
    - There is no whole-world scan.
  - `settle_pm_owner_d1_outbox_v1` (transition):
    - Callable only by the publisher.
    - Performs a compare-and-set on (state, claim_token) with a field whitelist, under the `d1_publisher` RLS actor.
  - `resolve_d1_pointer_v1` (read):
    - Callable only by the assigned X9 receiver session.
    - `resolve` / `verify_route` returns the stored pointer mapping and the current PM owner cut, inside the X9 receiver transaction.

## Enabling (later; each input owned by the named authority)

1. **Apply migration 0009.** Use the migration role through the existing runner (`apply_postgres_migrations`); the runtime never applies migrations.
   - The runtime readiness probe now requires the three new relations, so this code must not be deployed before 0009 is applied.
   - The migration is inert: it creates no route row.
2. **Re-run `deployment/provision_database.py`** for the runtime role.
3. **Run the role-binding proposal.** Then run `deployment/proposals/bk11_pm_owner_d1_outbox_role_binding.sql`:
   - It narrows the runtime role's UPDATE on the outbox to publication-state columns only.
   - It makes the routes and meta tables read-only.
   - It must run after every re-provision, because provisioning re-grants table-wide UPDATE.
4. **Set `CEREBRO_PM_OWNER_D1_PUBLISHER_JSON`.** This is nonsecret host policy, not a token.
   - It has exactly these fields: `owner_ref`, `route_ref`, `tenant_ref`, `workspace_ref`, `project_ref`, `principal_ref`, `consumer_ref`, `session_ref` and `session_binding_id`.
   - It requires `CEREBRO_PM_OWNER_ASSIGNMENT_JSON` and `CEREBRO_X9_CUSTODY_JSON`.
   - The publisher identity must be a distinct, separately issued service identity. It must not be the PM identity, the X9 receiver identity or the runtime read-only M2M credential.
5. **Insert one reviewed route row** as the installation owner. The row names:
   - the receiver and the receiver assignment;
   - the subject and stream;
   - the X9 config;
   - the publisher principal, consumer, session and binding id;
   - the TTL (≤ 120 s) and the binding revision;
   - `enqueue_enabled` / `drain_enabled`.

   The runtime role cannot write this table.
6. **Bind the Source side explicitly.** In `d1js.internal_binding`, set `InternalBinding(enabled=True, owner_mode="CONTEXT_SERVICE_OWNER", authorization_ref=…, role=…)`; it is OFF by default.
   - The publisher runs one bounded `publish_pending_once(limit)` per explicit call. There is no scheduler or daemon.
   - The receiver composition is receive-only.

## Safe rollback

Run `deployment/proposals/bk11_pm_owner_d1_outbox_disable.sql` as the migration/owner role. It sets `enqueue_enabled=false` and `drain_enabled=false`. Nothing is deleted or rewritten:

- Existing obligations keep their exact pointer bytes and state.
- New commits stop creating obligations; the commit itself is unchanged.
- The publisher reports `DRAIN_DISABLED_RETAINED` with zero broker calls.
- Settlement is refused by RLS.

To re-enable, set the flags back on the reviewed route row; the retained rows then drain through the unchanged claim-before-send publisher. There is no down-migration, so pending lineage is never dropped.

## Semantics and limits

Delivery is at-least-once, with idempotent dedupe on the D1 `message_id`, owner-side currentness, and an X9 disposition appended at most once.

- The receiver ACKs only after the X9 disposition is durable and an independent `ALREADY_DISPOSED` readback has succeeded. If either step fails, the message is NOACKed and stays pending.
- Dispositions keep `work_consumed=false` and `effect=NONE_CLAIMED`.
- There is no global exactly-once guarantee, no hard realtime, and no worker or chat task execution.

## Test recipe (local, synthetic, no production)

From the Source candidate `candidates/d1-jetstream-adapter-v0.1`, run `fixture/run_owner_outbox_batch.py`. It uses a disposable PostgreSQL 16 cluster and a loopback nats-server; see that candidate's README.
