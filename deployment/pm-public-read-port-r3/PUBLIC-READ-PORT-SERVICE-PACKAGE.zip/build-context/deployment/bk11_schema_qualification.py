"""Exact four-table BK11 schema qualification; no repair, DDL or general reflector.

Expected catalog was captured from the frozen reviewed SQL in real local PG16.
Its digest and source SQL digests are pinned; actual current production ledger/
owner/installation admission remain separate A1 prerequisites.
"""
from __future__ import annotations
import hashlib,json
from pathlib import Path

TABLES=('cerebro_bk11_service_assignments','cerebro_bk11_service_leases',
        'cerebro_bk11_operation_attempts','cerebro_bk11_backend_dispositions')
EXPECTED_SHA256='a399eaaf82a01b042132d68b538ae5f670684417f989caac61d20bdf6952986e'

def catalog(cursor):
    """Read only these fixed public relations. OIDs/role names/credentials never leave."""
    result={}
    for table in TABLES:
        cursor.execute('''SELECT c.relkind,c.relrowsecurity,c.relforcerowsecurity,c.relispartition,
          c.relowner=(SELECT oid FROM pg_roles WHERE rolname=current_user),
          EXISTS(SELECT 1 FROM pg_inherits WHERE inhrelid=c.oid OR inhparent=c.oid)
          FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
          WHERE n.nspname='public' AND c.relname=%s''',(table,))
        row=cursor.fetchone()
        if row is None:raise RuntimeError('BK11-partial-schema-reprovision-refused')
        if tuple(row)!=('r',True,True,False,True,False):
            raise RuntimeError('BK11-unqualified-table-owner-RLS-reprovision-refused')
        cursor.execute('''SELECT a.attname,format_type(a.atttypid,a.atttypmod),a.attnotnull,
          a.attidentity,a.attgenerated,pg_get_expr(d.adbin,d.adrelid,false),
          CASE WHEN a.attcollation=0 THEN NULL ELSE a.attcollation::regcollation::text END
          FROM pg_attribute a LEFT JOIN pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum
          WHERE a.attrelid=('public.'||%s)::regclass AND a.attnum>0 AND NOT a.attisdropped ORDER BY a.attnum''',(table,))
        columns=[list(row) for row in cursor.fetchall()]
        cursor.execute('''SELECT conname,contype,convalidated,condeferrable,condeferred,
          pg_get_constraintdef(oid,false),
          CASE WHEN conindid=0 THEN NULL ELSE
            (SELECT indisvalid AND indisready FROM pg_index WHERE indexrelid=conindid) END
          FROM pg_constraint WHERE conrelid=('public.'||%s)::regclass
          AND contype<>'n' ORDER BY conname''',(table,))
        # PG18 may catalog NOT NULL separately: attnotnull above remains exact.
        constraints=[list(row) for row in cursor.fetchall()]
        cursor.execute('''SELECT p.polname,p.polcmd,p.polpermissive,
          ARRAY(SELECT CASE WHEN role_oid=0 THEN 'PUBLIC' ELSE
            (SELECT rolname FROM pg_roles WHERE oid=role_oid) END
            FROM unnest(p.polroles) role_oid ORDER BY role_oid),
          pg_get_expr(p.polqual,p.polrelid,false),pg_get_expr(p.polwithcheck,p.polrelid,false)
          FROM pg_policy p WHERE p.polrelid=('public.'||%s)::regclass ORDER BY p.polname''',(table,))
        policies=[list(row) for row in cursor.fetchall()]
        cursor.execute('''SELECT tgname,tgenabled,pg_get_triggerdef(oid,false)
          FROM pg_trigger WHERE tgrelid=('public.'||%s)::regclass AND NOT tgisinternal ORDER BY tgname''',(table,))
        triggers=[list(row) for row in cursor.fetchall()]
        cursor.execute('''SELECT con.conrelid::regclass::text,con.conname,t.tgtype,t.tgenabled,
          t.tgfoid::regproc::text FROM pg_trigger t JOIN pg_constraint con ON con.oid=t.tgconstraint
          WHERE t.tgrelid=('public.'||%s)::regclass AND t.tgisinternal
          ORDER BY con.conrelid::regclass::text,con.conname,t.tgtype,t.tgfoid::regproc::text''',(table,))
        enforcement=[list(row) for row in cursor.fetchall()]
        result[table]={'columns':columns,'constraints':constraints,'policies':policies,
                      'triggers':triggers,'constraint_enforcement':enforcement}
    return result

def qualify(cursor,root:Path,role:str):
    path=root/'deployment/proposals/bk11_backend_expected_schema.json'
    raw=path.read_bytes().replace(b"\r\n",b"\n").replace(b"\r\n",b"\n")
    if len(raw)>65536 or hashlib.sha256(raw).hexdigest()!=EXPECTED_SHA256:
        raise RuntimeError('BK11-expected-schema-source-pin-refused')
    expected=json.loads(raw)
    if expected['schema']!='bk11-four-table-exact-catalog/v1' or set(expected['tables'])!=set(TABLES):
        raise RuntimeError('BK11-expected-schema-source-pin-refused')
    for item in expected['sql_inputs']:
        if item['path'] not in ('deployment/proposals/bk11_backend_service_custody.sql',
                                'deployment/proposals/bk11_backend_service_role_binding.sql'):
            raise RuntimeError('BK11-expected-schema-source-pin-refused')
        if hashlib.sha256((root/item['path']).read_bytes().replace(b"\r\n",b"\n")).hexdigest()!=item['sha256']:
            raise RuntimeError('BK11-expected-schema-source-pin-refused')
    if len(expected['sql_inputs'])!=2:
        raise RuntimeError('BK11-expected-schema-source-pin-refused')
    cursor.execute('SET LOCAL search_path = pg_catalog, public, pg_temp')
    cursor.execute("SET LOCAL lock_timeout = '5000ms'")
    # Frozen static table names, no caller-provided identifier or live policy repair.
    cursor.execute('LOCK TABLE '+','.join('public.'+name for name in TABLES)+' IN SHARE ROW EXCLUSIVE MODE')
    cursor.execute('''SELECT has_schema_privilege(%s,'public','CREATE'),
      EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
        WHERE n.nspname='public' AND c.relname=ANY(%s)
        AND pg_has_role(%s,c.relowner,'MEMBER'))''',(role,list(TABLES),role))
    if cursor.fetchone()!=(False,False):
        raise RuntimeError('BK11-runtime-schema-owner-rights-reprovision-refused')
    actual=catalog(cursor)
    if actual!=expected['tables']:
        raise RuntimeError('BK11-unqualified-exact-schema-reprovision-refused')
