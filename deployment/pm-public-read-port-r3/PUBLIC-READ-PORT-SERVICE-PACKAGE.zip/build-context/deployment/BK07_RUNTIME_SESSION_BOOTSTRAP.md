# BK07 provider-owned runtime session bootstrap

The dedicated BK07 M2M client keeps only `project_state:read` and has no
session-binding endpoint. The Context deployment operator binds its session
through `python -m deployment.runtime_session_bootstrap` **inside the deployed
Context service**, using the existing state port. Railway service access is
the provider-owned operator boundary; no runtime token or client secret is
accepted by this command.

Before running it, the Context host must set the exact nonsecret
`CEREBRO_LOCAL_RUNTIME_BINDING_JSON` with the approved issuer, client ID,
dedicated `/bk07-runtime` audience, fixed tenant/workspace/project/principal,
and the **actual** `local:` session reference delivered by the Liv runtime
host. Set `enabled=false` for bootstrap. Do not invent a reference or copy a
PM/X9 session. The command accepts no arguments, binds only the configured
principal/session to the configured project, then reads the persisted session
back and prints a nonsecret binding receipt. Repeating it with identical
config is idempotent. A collision, stale session or mismatched readback fails
closed.

This operation does not enable the notice resolver, change project state,
issue a token, send a notice, consume X9 or activate a profile. After an
independent readback of the exact session, the deployment owner may
separately set `enabled=true` and qualify the read-only resolver with actual
`SAME` and negative cases. The reader database credential remains separate
and sealed. Keep the runtime default OFF until all qualification gates pass.
