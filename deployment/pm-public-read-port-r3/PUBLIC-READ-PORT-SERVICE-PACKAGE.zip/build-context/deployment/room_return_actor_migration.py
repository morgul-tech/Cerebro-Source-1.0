"""Exact additive 13->14 policy migration, callable only by released owner port.

No CLI, credentials, sessions, default currentness decision or runtime migration.
The caller must bind actual target, authorization/window and cleanup separately.
"""
import json
from pathlib import Path


def apply_actor_read_policy(connection_factory, *, runtime_role, before_commit):
    from control_context_state_postgres import apply_postgres_migrations, _fetchone
    if not callable(before_commit) or type(runtime_role) is not str or not runtime_role:
        raise ValueError('EXACT_CURRENT_OWNER_GUARD_AND_RUNTIME_ROLE_REQUIRED')
    root = Path(__file__).resolve().parents[1]
    current = root/'tooling/context/control_context_postgres_migrations.json'
    base = json.loads((root/'deployment/proposals/room_return_actor_base_migrations.json').read_bytes())
    selected = json.loads(current.read_bytes())
    if len(base['migrations']) != 13 or len(selected['migrations']) != 14 or selected['migrations'][:13] != base['migrations']:
        raise ValueError('EXACT_INSTALLED_13_TO_14_PREFIX_REQUIRED')
    suffix = selected['migrations'][-2]
    if (suffix['migration_id'],suffix['path'],suffix['schema_version']) != (
            '0013-room-return-actor-read','control_context_state_postgres_0013_room_return_actor_read.sql',
            '1.12.0-room-return-actor-read-candidate'):
        raise ValueError('ONLY_ACTOR_READ_POLICIES_0013_ALLOWED')
    if (selected['migrations'][-1]['migration_id'],selected['migrations'][-1]['path']) != (
            '0014-actor-admission-owner','control_context_state_postgres_0014_actor_admission_owner.sql'):
        raise ValueError('ONLY_EXISTING_OWNER_ADMISSION_0014_ALLOWED')

    def final_guard(cursor):
        cursor.execute('SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname=%s',(runtime_role,))
        row = _fetchone(cursor)
        if row is None or row['rolsuper'] or row['rolbypassrls']:
            raise ValueError('ACTOR_READ_RUNTIME_ROLE_MEMBRANE_REQUIRED')
        for table in ('cerebro_room_return_d1_outbox','cerebro_bk11_backend_dispositions',
                      'cerebro_owner_state_heads','cerebro_owner_state_revisions',
                      'cerebro_owner_state_commit_receipts','cerebro_bk11_service_assignments'):
            cursor.execute('''SELECT relrowsecurity,relforcerowsecurity,
                pg_has_role(%s,relowner,'MEMBER') AS owner_member,
                has_table_privilege(%s,%s,'SELECT') AS can_read
                FROM pg_class WHERE oid=%s::regclass''',(runtime_role,runtime_role,'public.'+table,'public.'+table))
            row = _fetchone(cursor)
            if row is None or not row['relrowsecurity'] or not row['relforcerowsecurity'] or row['owner_member'] or not row['can_read']:
                raise ValueError('ACTOR_READ_EXISTING_SELECT_RLS_RIGHT_REQUIRED')
        for table,rights in (('cerebro_owner_state_heads',('INSERT','UPDATE')),
                            ('cerebro_owner_state_revisions',('INSERT',)),
                            ('cerebro_owner_state_commit_receipts',('INSERT',))):
            for right in rights:
                cursor.execute('SELECT has_table_privilege(%s,%s,%s) AS permitted',
                               (runtime_role,'public.'+table,right))
                if not _fetchone(cursor)['permitted']:raise ValueError('EXISTING_OWNER_WRITE_RIGHT_REQUIRED')
        cursor.execute("SELECT has_table_privilege(%s,'public.cerebro_bk11_service_assignments','INSERT,UPDATE,DELETE,TRUNCATE') AS forbidden",
                       (runtime_role,))
        if _fetchone(cursor)['forbidden']:raise ValueError('RUNTIME_CANNOT_ISSUE_SERVICE_ASSIGNMENTS')
        # Column grants count too; runtime must not promote its own scope.
        cursor.execute("SELECT has_any_column_privilege(%s,'public.cerebro_bk11_service_assignments','UPDATE') AS forbidden",
                       (runtime_role,))
        if _fetchone(cursor)['forbidden']:raise ValueError('RUNTIME_CANNOT_CHANGE_SERVICE_SCOPE_COLUMNS')
        for table,policy in (('cerebro_owner_state_heads','actor_admission_reserved'),
                             ('cerebro_owner_state_revisions','actor_admission_reserved'),
                             ('cerebro_owner_state_commit_receipts','actor_admission_reserved_receipts')):
            cursor.execute('''SELECT polpermissive FROM pg_policy WHERE polrelid=%s::regclass AND polname=%s''',
                           ('public.'+table,policy))
            policy_row=_fetchone(cursor)
            if policy_row is None or policy_row['polpermissive']:
                raise ValueError('RESERVED_OWNER_RESTRICTIVE_POLICY_REQUIRED')
        # Last check after all DB/role reads. No synthetic release is supplied here.
        before_commit(cursor)

    return apply_postgres_migrations(connection_factory,current,
        expected_installed_prefix=base['migrations'],before_commit=final_guard)
