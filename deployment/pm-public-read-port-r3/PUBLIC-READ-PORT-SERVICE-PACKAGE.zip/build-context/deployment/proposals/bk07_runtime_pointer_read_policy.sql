-- REVIEW PROPOSAL ONLY. Not a migration and not installed by the runtime.
-- Apply only after the exact Auth0 runtime client and database grant are approved.
-- The service sets these transaction-local values only after verifying the exact
-- OAuth runtime binding and its current persisted control session.
-- Administrator must replace the placeholder with a securely generated password
-- through the database secret manager; no credential is stored in this file.
-- Execute as one change transaction; any failed statement aborts all grants,
-- policy changes and role creation. This file is not in automatic migrations.

BEGIN;

CREATE ROLE cerebro_signalvev_reader NOLOGIN NOINHERIT NOSUPERUSER
    NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
GRANT USAGE ON SCHEMA public TO cerebro_signalvev_reader;
GRANT SELECT (tenant_ref,workspace_ref,project_ref,aggregate_revision,project_status)
    ON cerebro_project_instances TO cerebro_signalvev_reader;
GRANT SELECT (tenant_ref,workspace_ref,project_ref,principal_ref,consumer_ref,
    session_ref,session_binding_id,session_revision,session_fingerprint,project_revision)
    ON cerebro_control_session_bindings TO cerebro_signalvev_reader;
GRANT SELECT (tenant_ref,workspace_ref,project_ref,channel,record_kind,event_id,
    record_payload,content_sha256,writer_principal,writer_consumer,writer_session,
    writer_role,writer_assignment_ref,peer_role,peer_assignment_ref,peer_session_ref,
    config_ref,provider_revision)
    ON cerebro_x9_channel_records TO cerebro_signalvev_reader;
GRANT SELECT (tenant_ref,workspace_ref,owner_ref,referent_id,receipt_ref)
    ON cerebro_pm_owner_current TO cerebro_signalvev_reader;
GRANT SELECT (tenant_ref,workspace_ref,project_ref,owner_ref,referent_id,
    receipt_ref,record_payload,snapshot_sha256,projection_payload)
    ON cerebro_pm_owner_receipts TO cerebro_signalvev_reader;
-- After Human approval and secret custody: ALTER ROLE cerebro_signalvev_reader LOGIN PASSWORD <secure value>;
-- No INSERT, UPDATE, DELETE, sequence, role-assignment or disposition grant.

-- Restrictive policies intersect the existing permissive workspace/session
-- policies for this exact reader role. They prevent a stolen DB credential
-- from widening reads merely by setting custom transaction variables.
CREATE POLICY bk07_reader_project_limit ON cerebro_project_instances
    AS RESTRICTIVE FOR SELECT TO cerebro_signalvev_reader USING (
    tenant_ref = 'CEREBRO-TENANT-1'
    AND workspace_ref = 'BOOT-FULL-IMPLEMENTER-20260902T033946Z-GENERIC-7BAC373D'
    AND project_ref = 'TOTAL_MCP_REVISION');
CREATE POLICY bk07_reader_session_limit ON cerebro_control_session_bindings
    AS RESTRICTIVE FOR SELECT TO cerebro_signalvev_reader USING (
    tenant_ref = 'CEREBRO-TENANT-1'
    AND workspace_ref = 'BOOT-FULL-IMPLEMENTER-20260902T033946Z-GENERIC-7BAC373D'
    AND project_ref = 'TOTAL_MCP_REVISION'
    AND consumer_ref = 'LOCAL_CEREBRO_RUNTIME');
CREATE POLICY bk07_reader_owner_current_limit ON cerebro_pm_owner_current
    AS RESTRICTIVE FOR SELECT TO cerebro_signalvev_reader USING (
    tenant_ref = 'CEREBRO-TENANT-1'
    AND workspace_ref = 'BOOT-FULL-IMPLEMENTER-20260902T033946Z-GENERIC-7BAC373D'
    AND owner_ref = 'CURRENT_PM_PROJECT_MANAGER_C1A05B39');
CREATE POLICY bk07_reader_owner_receipt_limit ON cerebro_pm_owner_receipts
    AS RESTRICTIVE FOR SELECT TO cerebro_signalvev_reader USING (
    tenant_ref = 'CEREBRO-TENANT-1'
    AND workspace_ref = 'BOOT-FULL-IMPLEMENTER-20260902T033946Z-GENERIC-7BAC373D'
    AND project_ref = 'TOTAL_MCP_REVISION'
    AND owner_ref = 'CURRENT_PM_PROJECT_MANAGER_C1A05B39');

-- The existing x9_channel_read policy queries the separate X9 role-assignment
-- table. Keep it on the deployed actor DB role only, so the new reader does
-- not need SELECT on that sixth table or an actor assignment. The existing
-- actor service uses cerebro_runtime (verified from deployed nonsecret config).
ALTER POLICY x9_channel_read ON cerebro_x9_channel_records TO cerebro_runtime;

CREATE POLICY x9_runtime_notice_pointer_read
ON cerebro_x9_channel_records FOR SELECT TO cerebro_signalvev_reader USING (
    record_kind = 'POINTER'
    AND tenant_ref = 'CEREBRO-TENANT-1'
    AND workspace_ref = 'BOOT-FULL-IMPLEMENTER-20260902T033946Z-GENERIC-7BAC373D'
    AND project_ref = 'TOTAL_MCP_REVISION'
    AND tenant_ref = current_setting('cerebro.tenant_ref', true)
    AND workspace_ref = current_setting('cerebro.workspace_ref', true)
    AND project_ref = current_setting('cerebro.project_ref', true)
    AND current_setting('cerebro.consumer_ref', true) = 'LOCAL_CEREBRO_RUNTIME'
    AND current_setting('cerebro.runtime_notice_read_enabled', true) = 'true'
    AND EXISTS (
        SELECT 1 FROM cerebro_control_session_bindings s
        JOIN cerebro_project_instances p
          ON (s.tenant_ref,s.workspace_ref,s.project_ref) =
             (p.tenant_ref,p.workspace_ref,p.project_ref)
        WHERE s.tenant_ref = current_setting('cerebro.tenant_ref', true)
          AND s.workspace_ref = current_setting('cerebro.workspace_ref', true)
          AND s.project_ref = current_setting('cerebro.project_ref', true)
          AND s.principal_ref = current_setting('cerebro.principal_ref', true)
          AND s.consumer_ref = 'LOCAL_CEREBRO_RUNTIME'
          AND s.session_ref = current_setting('cerebro.session_ref', true)
          AND s.project_revision = p.aggregate_revision
          AND p.project_status = 'ACTIVE'
    )
);
CREATE POLICY bk07_reader_pointer_limit ON cerebro_x9_channel_records
    AS RESTRICTIVE FOR SELECT TO cerebro_signalvev_reader USING (
    tenant_ref = 'CEREBRO-TENANT-1'
    AND workspace_ref = 'BOOT-FULL-IMPLEMENTER-20260902T033946Z-GENERIC-7BAC373D'
    AND project_ref = 'TOTAL_MCP_REVISION'
    AND channel = 'PROSJEKTMANN_CHANNEL'
    AND record_kind = 'POINTER');

COMMIT;

-- Rollback, if this exact approved policy is installed:
-- DROP POLICY x9_runtime_notice_pointer_read ON cerebro_x9_channel_records;
-- ALTER POLICY x9_channel_read ON cerebro_x9_channel_records TO PUBLIC;
-- DROP POLICY bk07_reader_pointer_limit ON cerebro_x9_channel_records;
-- DROP POLICY bk07_reader_owner_receipt_limit ON cerebro_pm_owner_receipts;
-- DROP POLICY bk07_reader_owner_current_limit ON cerebro_pm_owner_current;
-- DROP POLICY bk07_reader_session_limit ON cerebro_control_session_bindings;
-- DROP POLICY bk07_reader_project_limit ON cerebro_project_instances;
-- REVOKE ALL ON cerebro_project_instances, cerebro_control_session_bindings,
--   cerebro_x9_channel_records, cerebro_pm_owner_current,
--   cerebro_pm_owner_receipts FROM cerebro_signalvev_reader;
-- DROP ROLE cerebro_signalvev_reader;
