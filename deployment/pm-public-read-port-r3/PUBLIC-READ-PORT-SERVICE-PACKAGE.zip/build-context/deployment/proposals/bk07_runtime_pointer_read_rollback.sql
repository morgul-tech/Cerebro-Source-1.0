-- REVIEW PROPOSAL ONLY. Execute only if the matching BK07 reader proposal
-- was approved and installed. One transaction prevents partial rollback.
BEGIN;

DROP POLICY x9_runtime_notice_pointer_read ON cerebro_x9_channel_records;
DROP POLICY bk07_reader_pointer_limit ON cerebro_x9_channel_records;
DROP POLICY bk07_reader_owner_receipt_limit ON cerebro_pm_owner_receipts;
DROP POLICY bk07_reader_owner_current_limit ON cerebro_pm_owner_current;
DROP POLICY bk07_reader_session_limit ON cerebro_control_session_bindings;
DROP POLICY bk07_reader_project_limit ON cerebro_project_instances;
ALTER POLICY x9_channel_read ON cerebro_x9_channel_records TO PUBLIC;

REVOKE ALL ON cerebro_project_instances, cerebro_control_session_bindings,
    cerebro_x9_channel_records, cerebro_pm_owner_current,
    cerebro_pm_owner_receipts FROM cerebro_signalvev_reader;
REVOKE USAGE ON SCHEMA public FROM cerebro_signalvev_reader;
DROP ROLE cerebro_signalvev_reader;

COMMIT;
