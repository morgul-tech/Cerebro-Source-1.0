-- REVIEW PROPOSAL ONLY (BK11 durable PM-owner outbox). Not a migration and not installed by the runtime.
-- Run AFTER deployment/provision_database.py (which re-grants table-wide UPDATE on every run), as the database
-- owner/administrator, in ONE transaction:  psql --single-transaction -v ON_ERROR_STOP=1 -f <this file>
-- Before running, set the runtime role name (no credential in this file):
--   SELECT set_config('cerebro.install_runtime_role', '<runtime role>', false);
-- Effect: the runtime role keeps SELECT/INSERT on the outbox (RLS still decides which rows) but may UPDATE only the
-- publication-state columns; identity/pointer columns are privilege-denied in addition to the immutability trigger.
-- Installation tables (routes, meta) become read-only for the runtime role. Nothing is deleted; no new role is made.
DO $bk11_binding$
DECLARE
    runtime_role text := current_setting('cerebro.install_runtime_role', true);
BEGIN
    IF runtime_role IS NULL OR runtime_role = '' THEN
        RAISE EXCEPTION 'set cerebro.install_runtime_role first';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = runtime_role AND NOT rolsuper AND NOT rolbypassrls) THEN
        RAISE EXCEPTION 'runtime role % missing, superuser or BYPASSRLS', runtime_role;
    END IF;
    EXECUTE format('REVOKE UPDATE, DELETE, TRUNCATE ON cerebro_pm_owner_d1_outbox FROM %I', runtime_role);
    EXECUTE format('GRANT SELECT, INSERT ON cerebro_pm_owner_d1_outbox TO %I', runtime_role);
    EXECUTE format('GRANT UPDATE (state, claim_token, claimed_at, attempts, stream, stream_seq, duplicate, '
                   'puback_latency_ms, last_reason) ON cerebro_pm_owner_d1_outbox TO %I', runtime_role);
    EXECUTE format('REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON cerebro_pm_owner_d1_routes FROM %I', runtime_role);
    EXECUTE format('REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON cerebro_pm_owner_d1_outbox_meta FROM %I',
                   runtime_role);
    EXECUTE format('GRANT SELECT ON cerebro_pm_owner_d1_routes, cerebro_pm_owner_d1_outbox_meta TO %I',
                   runtime_role);
END
$bk11_binding$;
