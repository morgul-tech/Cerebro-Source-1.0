-- INERT installation proposal, never called by the runtime. After actual ledger/
-- BOOT0008 composition and reviewed migration, run in the existing owner's one
-- transaction AFTER provision_database.py and the owner-outbox column whitelist.
-- Set cerebro.install_runtime_role through private operator custody, never a DSN export.
DO $binding$
DECLARE runtime_role text := current_setting('cerebro.install_runtime_role',true);
BEGIN
 IF runtime_role IS NULL OR runtime_role='' OR NOT EXISTS
  (SELECT 1 FROM pg_roles WHERE rolname=runtime_role AND NOT rolsuper AND NOT rolbypassrls
   AND NOT rolcreaterole AND NOT rolcreatedb) THEN
  RAISE EXCEPTION 'qualified existing runtime role required';
 END IF;
 IF EXISTS (SELECT 1 FROM pg_class WHERE oid IN
  ('cerebro_bk11_service_assignments'::regclass,'cerebro_bk11_service_leases'::regclass,
   'cerebro_bk11_operation_attempts'::regclass,'cerebro_bk11_backend_dispositions'::regclass)
  AND relowner=(SELECT oid FROM pg_roles WHERE rolname=runtime_role)) THEN
  RAISE EXCEPTION 'runtime must not own custody tables';
 END IF;
 EXECUTE format('REVOKE ALL ON cerebro_bk11_service_assignments,cerebro_bk11_service_leases,
  cerebro_bk11_operation_attempts,cerebro_bk11_backend_dispositions FROM %I',runtime_role);
 EXECUTE format('GRANT SELECT ON cerebro_bk11_service_assignments,cerebro_bk11_service_leases,
  cerebro_bk11_operation_attempts,cerebro_bk11_backend_dispositions TO %I',runtime_role);
 EXECUTE format('GRANT INSERT,UPDATE ON cerebro_bk11_service_leases TO %I',runtime_role);
 EXECUTE format('GRANT INSERT ON cerebro_bk11_operation_attempts,cerebro_bk11_backend_dispositions TO %I',runtime_role);
 EXECUTE format('GRANT UPDATE(phase,obligations,outcome,observed_at) ON cerebro_bk11_operation_attempts TO %I',runtime_role);
END
$binding$;

-- Assignment policy permits SELECT only. Runtime never creates/enables/rebinds it.
CREATE POLICY bk11_assignment_read ON cerebro_bk11_service_assignments FOR SELECT
 USING (tenant_ref=current_setting('cerebro.tenant_ref',true)
  AND workspace_ref=current_setting('cerebro.workspace_ref',true)
  AND principal_ref=current_setting('cerebro.principal_ref',true));
CREATE POLICY bk11_lease_scope ON cerebro_bk11_service_leases
 USING (EXISTS(SELECT 1 FROM cerebro_bk11_service_assignments a
  WHERE a.assignment_ref=cerebro_bk11_service_leases.assignment_ref AND a.enabled AND a.expires_at>now()))
 WITH CHECK (EXISTS(SELECT 1 FROM cerebro_bk11_service_assignments a
  WHERE a.assignment_ref=cerebro_bk11_service_leases.assignment_ref AND a.enabled AND a.expires_at>now()
   AND a.assignment_revision=cerebro_bk11_service_leases.assignment_revision));
CREATE POLICY bk11_attempt_scope ON cerebro_bk11_operation_attempts
 USING (EXISTS(SELECT 1 FROM cerebro_bk11_service_assignments a
  WHERE a.assignment_ref=cerebro_bk11_operation_attempts.assignment_ref AND a.enabled AND a.expires_at>now()))
 WITH CHECK (EXISTS(SELECT 1 FROM cerebro_bk11_service_assignments a
  WHERE a.assignment_ref=cerebro_bk11_operation_attempts.assignment_ref AND a.enabled AND a.expires_at>now()));
CREATE POLICY bk11_disposition_read ON cerebro_bk11_backend_dispositions FOR SELECT
 USING (EXISTS(SELECT 1 FROM cerebro_bk11_service_assignments a
  WHERE a.tenant_ref=cerebro_bk11_backend_dispositions.tenant_ref
   AND a.workspace_ref=cerebro_bk11_backend_dispositions.workspace_ref
   AND a.route_ref=cerebro_bk11_backend_dispositions.route_ref
   AND a.receiver_ref=cerebro_bk11_backend_dispositions.receiver_ref AND a.enabled AND a.expires_at>now()));
CREATE POLICY bk11_disposition_insert ON cerebro_bk11_backend_dispositions FOR INSERT
 WITH CHECK (EXISTS(SELECT 1 FROM cerebro_bk11_service_assignments a
  WHERE a.assignment_ref=cerebro_bk11_backend_dispositions.receiver_assignment_ref
   AND a.tenant_ref=cerebro_bk11_backend_dispositions.tenant_ref
   AND a.workspace_ref=cerebro_bk11_backend_dispositions.workspace_ref
   AND a.route_ref=cerebro_bk11_backend_dispositions.route_ref
   AND a.receiver_ref=cerebro_bk11_backend_dispositions.receiver_ref
   AND a.service_role='receiver' AND a.enabled AND a.expires_at>now()));
-- No UPDATE/DELETE disposition policy; original identity and durable custody are immutable.
-- Reprovision must reapply exact grants (policies created ONCE by admitted migration),
-- not replay this CREATE POLICY file against existing names. Disable retains all rows.
