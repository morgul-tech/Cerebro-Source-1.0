-- INERT PROPOSAL, NO MIGRATION SLOT OR MANIFEST ENTRY.
-- Compose ONLY after actual Context authority/BOOT0008/installed-ledger qualification.
-- Installation owner provisions assignment rows and exact runtime grants. Runtime
-- must not INSERT/UPDATE/DELETE assignments or self-provision identities/leases policy.
CREATE TABLE cerebro_bk11_service_assignments (
 assignment_ref text PRIMARY KEY,
 tenant_ref text NOT NULL, workspace_ref text NOT NULL, project_ref text NOT NULL,
 principal_ref text NOT NULL, consumer_ref text NOT NULL, session_ref text NOT NULL,
 session_binding_id text NOT NULL, route_ref text NOT NULL, owner_ref text NOT NULL,
 service_role text NOT NULL CHECK(service_role IN ('publisher','receiver')),
 receiver_ref text NOT NULL, profile text NOT NULL,
 enabled boolean NOT NULL DEFAULT false, assignment_revision bigint NOT NULL CHECK(assignment_revision>0),
 lease_ttl_s integer NOT NULL CHECK(lease_ttl_s BETWEEN 10 AND 600),
 expires_at timestamptz NOT NULL,
 UNIQUE(tenant_ref,workspace_ref,principal_ref,consumer_ref,session_ref)
);
CREATE TABLE cerebro_bk11_service_leases (
 assignment_ref text PRIMARY KEY REFERENCES cerebro_bk11_service_assignments(assignment_ref),
 lease_ref text NOT NULL UNIQUE, instance_ref text NOT NULL,
 fencing_epoch bigint NOT NULL CHECK(fencing_epoch>0), assignment_revision bigint NOT NULL,
 expires_at timestamptz NOT NULL
);
CREATE TABLE cerebro_bk11_operation_attempts (
 assignment_ref text NOT NULL REFERENCES cerebro_bk11_service_assignments(assignment_ref),
 operation_ref text NOT NULL, attempt_ref text NOT NULL,
 phase text NOT NULL, obligations jsonb NOT NULL DEFAULT '[]' CHECK(jsonb_typeof(obligations)='array' AND jsonb_array_length(obligations)<=8),
 outcome text NOT NULL DEFAULT 'OPEN', observed_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(assignment_ref,attempt_ref)
);
CREATE TABLE cerebro_bk11_backend_dispositions (
 tenant_ref text NOT NULL, workspace_ref text NOT NULL, route_ref text NOT NULL, receiver_ref text NOT NULL,
 message_id text NOT NULL CHECK(message_id ~ '^d1:[0-9a-f]{40}$'),
 pointer_sha256 text NOT NULL CHECK(pointer_sha256 ~ '^[0-9a-f]{64}$'),
 owner_event_id text NOT NULL, owner_seq bigint NOT NULL,
 status text NOT NULL CHECK(status IN ('ACCEPTED_PENDING_WORK','EXPIRED_NEEDS_OWNER_DISPOSITION')),
 receiver_assignment_ref text NOT NULL REFERENCES cerebro_bk11_service_assignments(assignment_ref),
 accepted_at timestamptz NOT NULL DEFAULT now(),
 downstream_work text NOT NULL DEFAULT 'PENDING_NOT_MODEL_EXECUTED' CHECK(downstream_work='PENDING_NOT_MODEL_EXECUTED'),
 PRIMARY KEY(tenant_ref,workspace_ref,route_ref,receiver_ref,message_id)
);
-- No body, token, password, arbitrary cursor or substitute business event is stored.
-- All four tables require FORCE RLS + exact service runtime grants before admission.
ALTER TABLE cerebro_bk11_service_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE cerebro_bk11_service_assignments FORCE ROW LEVEL SECURITY;
ALTER TABLE cerebro_bk11_service_leases ENABLE ROW LEVEL SECURITY;
ALTER TABLE cerebro_bk11_service_leases FORCE ROW LEVEL SECURITY;
ALTER TABLE cerebro_bk11_operation_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE cerebro_bk11_operation_attempts FORCE ROW LEVEL SECURITY;
ALTER TABLE cerebro_bk11_backend_dispositions ENABLE ROW LEVEL SECURITY;
ALTER TABLE cerebro_bk11_backend_dispositions FORCE ROW LEVEL SECURITY;
REVOKE ALL ON cerebro_bk11_service_assignments,cerebro_bk11_service_leases,
 cerebro_bk11_operation_attempts,cerebro_bk11_backend_dispositions FROM PUBLIC;
-- DENY BY DEFAULT: no policy/grant here until actual installation-role/runtime-role
-- binding is qualified. Never let generic reprovision GRANT ALL override this membrane.
