/** INERT reviewed-provisioning candidate. Issuer-owned map only, never request claims.
 * This is the credentials-exchange trigger, not the existing post-login Action.
 * Secrets are set privately at the real issuer; none are delivered with this source.
 */
exports.onExecuteCredentialsExchange = async (event, api) => {
  const resource = 'https://cerebro-context-deploy-production.up.railway.app';
  if (event.resource_server.identifier !== resource) return;
  const entries = JSON.parse(event.secrets.CEREBRO_BK11_M2M_BINDINGS_JSON);
  if (!Array.isArray(entries) || entries.length !== 2) throw new Error('BK11_ISSUER_BINDING_INVALID');
  const roles = new Set(), clients = new Set();
  for (const entry of entries) {
    if (Object.keys(entry).sort().join(',') !== 'client_id,role,tenant_ref,workspace_ref' ||
        !['publisher','receiver'].includes(entry.role) || roles.has(entry.role) || clients.has(entry.client_id) ||
        ![entry.client_id,entry.tenant_ref,entry.workspace_ref].every(v => typeof v === 'string' && /^[A-Za-z0-9_.:@/#=-]{1,160}$/.test(v)))
      throw new Error('BK11_ISSUER_BINDING_INVALID');
    roles.add(entry.role); clients.add(entry.client_id);
  }
  const entry = entries.find(e => e.client_id === event.client.client_id);
  if (!entry) return;
  const namespace = event.secrets.CEREBRO_BK11_CLAIM_NAMESPACE;
  if (namespace !== resource + '/claims') throw new Error('BK11_CURRENT_NAMESPACE_QUALIFICATION_REQUIRED');
  api.accessToken.setCustomClaim(namespace + '/tenant', entry.tenant_ref);
  api.accessToken.setCustomClaim(namespace + '/workspace', entry.workspace_ref);
  // Auth0 supplies signed iss/aud/sub=client_id@clients/exp/scope itself.
  // No model/native-role claim, arbitrary request field or grant is copied.
};
