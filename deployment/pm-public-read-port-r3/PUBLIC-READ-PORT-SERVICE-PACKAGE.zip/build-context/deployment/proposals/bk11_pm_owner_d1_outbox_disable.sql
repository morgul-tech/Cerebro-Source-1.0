-- REVIEW PROPOSAL ONLY (BK11 durable PM-owner outbox): SAFE ROLLBACK / DISABLE. Not a migration.
-- Run as the database owner/migration role (the runtime role cannot write routes), in one transaction:
--   psql --single-transaction -v ON_ERROR_STOP=1 -f <this file>
-- Effect: new MATERIAL_READY commits stop creating publication obligations (commit itself unchanged) and the
-- publisher stops draining (it reports DRAIN_DISABLED_RETAINED, zero broker calls). EVERY existing outbox row is
-- RETAINED with its exact pointer bytes and state; nothing is deleted or rewritten (the table has no DELETE policy
-- and a delete-refusing trigger). Re-enabling = setting the flags back to true on the reviewed route row(s); the
-- retained obligations then drain through the unchanged claim-before-send publisher.
-- Narrow the WHERE clause to one route_ref to disable a single route.
UPDATE cerebro_pm_owner_d1_routes
   SET enqueue_enabled = false,
       drain_enabled = false
 WHERE enqueue_enabled OR drain_enabled;
