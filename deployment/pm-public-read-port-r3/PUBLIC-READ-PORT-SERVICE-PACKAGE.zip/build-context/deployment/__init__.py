"""Deployment-only adapters for the governed Cerebro Context service."""
