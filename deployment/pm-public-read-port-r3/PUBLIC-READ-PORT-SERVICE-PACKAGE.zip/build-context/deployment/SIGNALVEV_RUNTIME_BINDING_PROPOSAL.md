# BK07 local runtime resolve grant proposal — default OFF

This is a reviewable permission proposal, not a grant or activation record.
The new `transport_resolve_signalvev_notice_v1` tool accepts exactly
`{"event_id":"pm-event:..."}`. It derives the pointer hash from the durable
X9 pointer and rereads the current PM owner cut within the service. Its result
is `SAME`, `SUPERSEDED`, or `UNKNOWN`; it never appends a disposition, consumes
X9, mutates PM ownership, sends NATS, or treats a caller-supplied hash as truth.

## Exact proposed binding

- Consumer: `LOCAL_CEREBRO_RUNTIME`, separate from `CHATGPT_REMOTE_MCP`.
- OAuth issuer: `https://dev-lmzknalapbdhfdua.us.auth0.com` (verified from
  the active Context service's public protected-resource metadata on 2026-10-07).
- OAuth client ID: existing dedicated Auth0 M2M client
  `s6Lu5katfEwbnFEoRyxq7RFvx1fG5i1v`. Its initial secret rotation is
  Human-attested; protected Liv custody is not yet verified. Do not rotate
  again merely to address token lifetime, and never record the secret here.
- Dedicated runtime API identifier/audience (proposed, not yet created):
  `https://cerebro-context-deploy-production.up.railway.app/bk07-runtime`.
  Its Auth0 `token_lifetime` is exactly 300 seconds, signing algorithm RS256,
  and sole scope is `project_state:read`. The existing shared Context API
  audience remains `https://cerebro-context-deploy-production.up.railway.app`
  with its existing 86400-second lifetime and client behavior unchanged.
- Tenant/workspace/project: `CEREBRO-TENANT-1` /
  `BOOT-FULL-IMPLEMENTER-20260902T033946Z-GENERIC-7BAC373D` /
  `TOTAL_MCP_REVISION` (read from the deployed nonsecret PM/X9 host policy).
- Runtime principal: exact `s6Lu5katfEwbnFEoRyxq7RFvx1fG5i1v@clients`,
  checked against `sub`; `azp` must equal the same client ID and `gty` must be
  `client-credentials`.
- Claims: exact `cerebro_tenant`, `cerebro_workspace`, `cerebro_project`,
  `sub`, and `azp` matching the host-owned binding. The deployed claim
  namespace is `https://cerebro-context-deploy-production.up.railway.app/claims`;
  the Auth0 credentials-exchange Action must emit its `/tenant`, `/workspace`,
  and `/project` claims for only this client and API audience. No request value
  may set or change these claims.
- Scope: exactly `project_state:read`; the runtime credential is refused by
  every other Context tool, even if presented there. A token containing
  `project_state:transition` is refused on the resolve route.
- Operation: resolve this one tool only. No PM producer or X9 receiver role,
  actor token, append, consume, or owner mutation.
- Configuration: `LocalRuntimeOAuthBinding.enabled=False` by default. The
  nonsecret binding must name the exact dedicated `runtime_audience`; the
  resolver refuses the shared audience even with an otherwise valid token.
  Enabling it requires an explicit provider-owned grant and deployed host
  configuration. The separately bound `RuntimeResolutionHost` is also OFF
  by default.

## Provider work that remains before enabling

The Auth0 tenant administrator must perform these exact provider actions only
after bounded Human approval and independent review: create one dedicated
resource server/API with the identifier, 300-second lifetime, RS256, and sole
read scope above; create one client grant for the existing dedicated M2M client
to that API with only `project_state:read`; revoke the prior shared-audience
grant `cgr_WLM1jCcMB43jbfXz` so this client cannot acquire 86400-second
shared-API tokens; and update the existing credentials-exchange Action
`5388ae14-f662-49f9-92b5-7351fe3715a7` to guard exact client ID and new
audience while preserving the three exact namespaced claims. Do not grant
transition or Management API access. Provider creation, grant revocation,
Action deployment, and token issuance have not occurred in this candidate.
The Context owner must persist one current `LOCAL_CEREBRO_RUNTIME`
control-session binding for that principal and the exact project, then set the
nonsecret `CEREBRO_LOCAL_RUNTIME_BINDING_JSON` with those values, the exact
`runtime_audience`, and
`enabled=true` only after the approved database pointer-read policy in
`deployment/proposals/bk07_runtime_pointer_read_policy.sql` has been reviewed
and applied. It is deliberately outside automatic migrations. The proposal
creates a separate `cerebro_signalvev_reader` database login with column-level
SELECT on only five existing tables and restrictive RLS limited to the exact current
tenant/workspace/project, PM owner, and pointer record kind. The Context host
must use its separate `CEREBRO_LOCAL_RUNTIME_READ_DATABASE_URL` credential for
this reader, never the existing read/write service connection. The database
administrator creates its password securely and stores the connection string
as a sealed Railway variable; no password belongs in SQL or review output.
The proposal also limits the existing X9 actor SELECT policy to the already
deployed `cerebro_runtime` DB role; otherwise its role-assignment subquery
would require granting the new reader a sixth table. This change and its
rollback are explicit in the uninstalled SQL for A4/DB-admin review.
The apply and rollback SQL files each use one PostgreSQL transaction, so a
policy or grant failure cannot leave a partial role/policy change. The pointer
policy compares the persisted session to explicit transaction-local
tenant/workspace/project settings, avoiding ambiguous inner-column binding.

The local Liv service account should hold the rotated M2M credential in its protected
OS credential store, never in Source/profile/logs. It obtains short-lived
access tokens from the same Auth0 `/oauth/token` client-credentials endpoint
for the exact dedicated runtime audience and refreshes by requesting a new token before
expiry; no refresh token is retained. Revocation is `DELETE
/api/v2/client-grants/{new-runtime-grant-id}`, disabling the service binding,
and dropping the exact
database policy. No secret value appears in this proposal.

Rollback keeps runtime disabled, revokes the new runtime grant, and reverts the
Action and Context code/config under the approved rollback. Do not silently
restore the old shared-audience grant. The new API remains inert without a
grant and may be removed only with explicit authorization. Existing shared
API metadata, issuer/JWKS, and non-runtime clients stay unchanged.

The service-owned `PostgresRuntimeNoticeReader` is now implemented default
OFF: it verifies the persisted runtime session, original X9 pointer hash and
writer custody, the immutable original PM receipt, and the current PM referent
in one read-only repeatable-read transaction. Without the proposed RLS policy
the pointer query fails closed. Local tests replace PostgreSQL effects; live
database authorization and readback remain unproven.

The API accepts runtime tokens with at most a five-minute lifespan. The local
caller must request a new client-credentials token before expiry; revoking the
client grant stops new tokens, and removing the persisted runtime session
stops the read immediately even for an unexpired token.

Human decision requested after changed-boundary review: approve or reject
those exact Auth0 API/grant/Action operations, the current runtime session
binding, and the narrow X9 pointer SELECT policy. Code review and tests alone
do not authorize any of them.

BK07 normal-use profile stays disabled, SEND0, X9 consume0, no replay.
