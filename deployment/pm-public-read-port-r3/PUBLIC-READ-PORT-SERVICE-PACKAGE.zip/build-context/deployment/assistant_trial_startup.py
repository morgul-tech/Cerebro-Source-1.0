"""One-shot, fixed-path Stage2 file provisioner; no arbitrary input paths."""
from __future__ import annotations

import base64
import binascii
import fcntl
import hashlib
import json
import math
import os
import pwd
import stat
import sys
import time
from pathlib import Path

OWNER_ENV = "CEREBRO_ASSISTANT_TRIAL_OWNER_JSON"
INPUT_ENV = "CEREBRO_ASSISTANT_TRIAL_PROVISIONING_INPUT_B64"
SUPPLEMENT_PATH = "/run/cerebro/assistant-trial/build7-one-trial-supplement.json"
LOCK_PATH = "/run/cerebro/assistant-trial/build7-one-trial-owner.lock"
INPUT_SCHEMA = "cerebro-assistant-trial-startup-provision/v1"
INPUT_FIELDS = {
    "schema", "authorization_ref", "not_before_epoch", "expires_at_epoch",
    "profile_ref", "reader_uid", "reader_gid", "writer_contract_ref",
    "supplement_sha256", "supplement_b64",
}
OWNER_FIELDS = {
    "profile_ref", "supplement_path", "supplement_sha256", "lock_path",
    "reader_uid", "reader_gid", "writer_contract_ref",
}
SUPPLEMENT_FIELDS = {
    "schema", "profile", "policy_ref", "policy_revision",
    "decision_owner_revision", "owner_authorization_ref", "writer_contract_ref",
}
PROFILE_FIELDS = {
    "schema", "profile_ref", "owner_ref", "owner_revision", "enabled",
    "trial_scope", "caller", "generation_ref", "source_revision",
    "method_fingerprint", "expected_revision", "decision_ref", "overlay_ref",
    "actor_ref", "actor_generation_ref", "recipient_ref", "trial_target_ref",
    "not_before", "not_after",
}
CALLER_FIELDS = {"tenant_ref", "workspace_ref", "principal_ref", "consumer_ref", "session_ref"}
MAX_SUPPLEMENT = 65536
MAX_ENVELOPE_B64 = 100000


class ProvisionFailure(Exception):
    def __init__(self, code: str):
        self.code = code


def need(ok: bool, code: str) -> None:
    if not ok:
        raise ProvisionFailure(code)


def strict_json(raw: bytes):
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, "DUPLICATE_JSON_KEY")
            out[key] = value
        return out
    return json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs)


def exact_text(value) -> bool:
    return (type(value) is str and bool(value) and value == value.strip()
            and len(value.encode("utf-8")) <= 512
            and not any(ord(c) < 32 or ord(c) == 127 for c in value))


def sha_text(value) -> bool:
    return (type(value) is str and len(value) == 64
            and all(c in "0123456789abcdef" for c in value))


def owner_config(raw: str):
    need(len(raw.encode("utf-8")) <= 8192, "OWNER_CONFIG_TOO_LARGE")
    value = strict_json(raw.encode("utf-8"))
    need(type(value) is dict and set(value) == OWNER_FIELDS, "OWNER_CONFIG_FIELDS")
    for key in ("profile_ref", "supplement_path", "supplement_sha256", "lock_path", "writer_contract_ref"):
        need(exact_text(value[key]), "OWNER_CONFIG_VALUE")
    need(value["supplement_path"] == SUPPLEMENT_PATH and value["lock_path"] == LOCK_PATH,
         "OWNER_CONFIG_PATH")
    need(sha_text(value["supplement_sha256"]), "OWNER_CONFIG_HASH")
    need(type(value["reader_uid"]) is int and value["reader_uid"] > 0
         and type(value["reader_gid"]) is int and value["reader_gid"] >= 0,
         "OWNER_CONFIG_PRINCIPAL")
    need(pwd.getpwnam("cerebro").pw_uid == value["reader_uid"], "SERVICE_UID_MISMATCH")
    return value


def decode_input(raw: str, owner):
    need(len(raw) <= MAX_ENVELOPE_B64, "PROVISION_INPUT_TOO_LARGE")
    try:
        envelope_raw = base64.b64decode(raw, validate=True)
    except (binascii.Error, ValueError):
        raise ProvisionFailure("PROVISION_INPUT_ENCODING") from None
    envelope = strict_json(envelope_raw)
    need(type(envelope) is dict and set(envelope) == INPUT_FIELDS, "PROVISION_INPUT_FIELDS")
    need(envelope["schema"] == INPUT_SCHEMA and exact_text(envelope["authorization_ref"]),
         "PROVISION_INPUT_AUTHORIZATION")
    for key in ("profile_ref", "writer_contract_ref"):
        need(exact_text(envelope[key]), "PROVISION_INPUT_OWNER_REF")
    for key in ("reader_uid", "reader_gid"):
        need(type(envelope[key]) is int, "PROVISION_INPUT_PRINCIPAL")
    for key in ("not_before_epoch", "expires_at_epoch"):
        need(type(envelope[key]) in (int, float) and math.isfinite(envelope[key]),
             "PROVISION_INPUT_WINDOW")
    need(envelope["not_before_epoch"] < envelope["expires_at_epoch"], "PROVISION_INPUT_WINDOW_ORDER")
    for key in ("profile_ref", "reader_uid", "reader_gid", "writer_contract_ref", "supplement_sha256"):
        owner_key = key
        need(envelope[key] == owner[owner_key], "PROVISION_INPUT_OWNER_MISMATCH")
    need(sha_text(envelope["supplement_sha256"]), "PROVISION_INPUT_HASH")
    need(type(envelope["supplement_b64"]) is str and len(envelope["supplement_b64"]) <= 90000,
         "PROVISION_INPUT_SUPPLEMENT_SIZE")
    try:
        supplement_raw = base64.b64decode(envelope["supplement_b64"], validate=True)
    except (binascii.Error, ValueError):
        raise ProvisionFailure("PROVISION_SUPPLEMENT_ENCODING") from None
    need(0 < len(supplement_raw) <= MAX_SUPPLEMENT, "PROVISION_SUPPLEMENT_SIZE")
    need(hashlib.sha256(supplement_raw).hexdigest() == owner["supplement_sha256"],
         "PROVISION_SUPPLEMENT_HASH")
    supplement = strict_json(supplement_raw)
    need(type(supplement) is dict and set(supplement) == SUPPLEMENT_FIELDS
         and supplement.get("schema") == "d1-existing0008-assistant-trial-supplement/v1",
         "PROVISION_SUPPLEMENT_FIELDS")
    profile = supplement.get("profile")
    need(type(profile) is dict and set(profile) == PROFILE_FIELDS
         and profile.get("schema") == "cerebro-isolated-assistant-trial-profile/v1",
         "PROVISION_PROFILE_FIELDS")
    caller = profile.get("caller")
    need(type(caller) is dict and set(caller) == CALLER_FIELDS, "PROVISION_CALLER_FIELDS")
    need(profile.get("profile_ref") == owner["profile_ref"]
         and supplement.get("writer_contract_ref") == owner["writer_contract_ref"]
         and supplement.get("owner_authorization_ref") == envelope["authorization_ref"],
         "PROVISION_SUPPLEMENT_OWNER_MISMATCH")
    return envelope, supplement_raw


def startup_mode(owner_raw, input_raw) -> str:
    if owner_raw is None and input_raw is None:
        return "OFF"
    need(owner_raw is not None and input_raw is not None, "PARTIAL_STARTUP_INPUT")
    return "PROVISION"


def require_active_window(envelope, now: float) -> None:
    need(envelope["not_before_epoch"] <= now < envelope["expires_at_epoch"],
         "PROVISION_AUTHORIZATION_WINDOW")


def protected_parent(reader_gid: int) -> str:
    paths = ("/run", "/run/cerebro", "/run/cerebro/assistant-trial")
    for index, path in enumerate(paths):
        try:
            os.lstat(path)
        except FileNotFoundError:
            if index < 2:
                os.mkdir(path, 0o755)
                os.chown(path, 0, 0)
                os.chmod(path, 0o755)
            else:
                os.mkdir(path, 0o750)
                os.chown(path, 0, reader_gid)
                os.chmod(path, 0o750)
        info = os.lstat(path)
        mode = stat.S_IMODE(info.st_mode)
        need(stat.S_ISDIR(info.st_mode) and info.st_uid == 0
             and not mode & 0o022, "PROTECTED_ANCESTRY")
        traverse = (info.st_gid == reader_gid and bool(mode & 0o010)) or bool(mode & 0o001)
        need(traverse, "PROTECTED_ANCESTRY_NOT_TRAVERSABLE")
        if index == 2:
            need(info.st_gid == reader_gid and bool(mode & 0o010),
                 "PROTECTED_PARENT_READER_GROUP")
    return paths[-1]


def open_existing(path: str, reader_gid: int, expected_sha: str | None, require_empty: bool) -> None:
    before = os.lstat(path)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and before.st_uid == 0 and before.st_gid == reader_gid
         and stat.S_IMODE(before.st_mode) == 0o440, "PROTECTED_FILE_METADATA")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        after = os.fstat(fd)
        need(stat.S_ISREG(after.st_mode) and after.st_nlink == 1
             and (after.st_dev, after.st_ino) == (before.st_dev, before.st_ino),
             "PROTECTED_FILE_IDENTITY")
        if require_empty:
            need(after.st_size == 0, "OWNER_LOCK_CONTENT")
        if expected_sha is not None:
            chunks = []
            total = 0
            while True:
                chunk = os.read(fd, 8192)
                if not chunk:
                    break
                total += len(chunk)
                need(total <= MAX_SUPPLEMENT, "PROTECTED_FILE_SIZE")
                chunks.append(chunk)
            need(hashlib.sha256(b"".join(chunks)).hexdigest() == expected_sha,
                 "PROTECTED_FILE_HASH")
    finally:
        os.close(fd)


def create_once(path: str, data: bytes, reader_gid: int):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    identity = None
    try:
        info = os.fstat(fd)
        identity = (info.st_dev, info.st_ino)
        need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "NEW_FILE_IDENTITY")
        os.fchown(fd, 0, reader_gid)
        offset = 0
        while offset < len(data):
            written = os.write(fd, data[offset:])
            need(written > 0, "NEW_FILE_WRITE")
            offset += written
        os.fchmod(fd, 0o440)
        os.fsync(fd)
        final = os.fstat(fd)
        need(final.st_uid == 0 and final.st_gid == reader_gid and final.st_nlink == 1
             and stat.S_IMODE(final.st_mode) == 0o440, "NEW_FILE_METADATA")
        os.close(fd)
        fd = -1
        return identity
    except BaseException:
        if fd >= 0:
            try:
                os.close(fd)
            except OSError:
                pass
        if identity is not None and not rollback_created(path, identity):
            raise ProvisionFailure("PROVISION_ROLLBACK_INCOMPLETE") from None
        raise


def rollback_created(path: str, identity) -> bool:
    if identity is None:
        return True
    try:
        current = os.lstat(path)
        if stat.S_ISREG(current.st_mode) and current.st_nlink == 1 \
                and (current.st_dev, current.st_ino) == identity:
            os.unlink(path)
            return True
        return False
    except FileNotFoundError:
        return True
    except OSError:
        return False


def provision(owner, envelope, supplement_raw) -> None:
    require_active_window(envelope, time.time())
    parent = protected_parent(owner["reader_gid"])
    parent_fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    supplement_id = lock_id = None
    try:
        fcntl.flock(parent_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        supplement_exists = os.path.lexists(SUPPLEMENT_PATH)
        lock_exists = os.path.lexists(LOCK_PATH)
        if supplement_exists and lock_exists:
            open_existing(SUPPLEMENT_PATH, owner["reader_gid"], owner["supplement_sha256"], False)
            open_existing(LOCK_PATH, owner["reader_gid"], None, True)
            return
        need(not supplement_exists and not lock_exists, "PARTIAL_PROVISIONING_STATE")
        supplement_id = create_once(SUPPLEMENT_PATH, supplement_raw, owner["reader_gid"])
        lock_id = create_once(LOCK_PATH, b"", owner["reader_gid"])
        open_existing(SUPPLEMENT_PATH, owner["reader_gid"], owner["supplement_sha256"], False)
        open_existing(LOCK_PATH, owner["reader_gid"], None, True)
    except BaseException:
        lock_clean = rollback_created(LOCK_PATH, lock_id)
        supplement_clean = rollback_created(SUPPLEMENT_PATH, supplement_id)
        if not lock_clean or not supplement_clean:
            raise ProvisionFailure("PROVISION_ROLLBACK_INCOMPLETE") from None
        raise
    finally:
        try:
            fcntl.flock(parent_fd, fcntl.LOCK_UN)
        finally:
            os.close(parent_fd)


def drop_and_exec(reader_uid: int | None, reader_gid: int | None) -> None:
    account = pwd.getpwnam("cerebro")
    uid = account.pw_uid if reader_uid is None else reader_uid
    gid = account.pw_gid if reader_gid is None else reader_gid
    need(uid == account.pw_uid and uid > 0 and gid >= 0, "SERVICE_PRINCIPAL")
    if os.geteuid() == 0:
        os.setgroups([])
        os.setgid(gid)
        os.setuid(uid)
    need(os.geteuid() == uid and os.getegid() == gid, "PRIVILEGE_DROP")
    port = os.environ.get("PORT") or "8000"
    need(port.isascii() and port.isdecimal() and 1 <= int(port) <= 65535, "PORT_VALUE")
    argv = ["uvicorn", "deployment.app:app", "--host", "0.0.0.0", "--port", port]
    os.execvpe(argv[0], argv, os.environ)


def main() -> None:
    owner_raw = os.environ.get(OWNER_ENV)
    input_raw = os.environ.get(INPUT_ENV)
    mode = startup_mode(owner_raw, input_raw)
    if mode == "OFF":
        drop_and_exec(None, None)
    need(os.geteuid() == 0, "ROOT_PROVISIONER_REQUIRED")
    owner = owner_config(owner_raw)
    envelope, supplement_raw = decode_input(input_raw, owner)
    provision(owner, envelope, supplement_raw)
    os.environ.pop(INPUT_ENV, None)
    owner_raw = input_raw = envelope = supplement_raw = None
    drop_and_exec(owner["reader_uid"], owner["reader_gid"])


if __name__ == "__main__":
    try:
        main()
    except ProvisionFailure as exc:
        sys.stderr.write("ASSISTANT_TRIAL_STARTUP_FAILED:" + exc.code + "\n")
        raise SystemExit(78) from None
    except Exception:
        sys.stderr.write("ASSISTANT_TRIAL_STARTUP_FAILED:UNQUALIFIED_INPUT_OR_HOST_STATE\n")
        raise SystemExit(78) from None
