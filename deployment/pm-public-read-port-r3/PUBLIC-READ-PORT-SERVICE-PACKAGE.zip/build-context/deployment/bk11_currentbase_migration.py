"""BK11-only current8 admission through the existing governed migration runner.

No new migration engine. Actual observed prefix+same transaction lock and exact
source checks reject collision/drift before DDL; F1 membrane qualifies before commit.
"""
import hashlib,json
from pathlib import Path
from psycopg.rows import tuple_row

ROOT=Path(__file__).resolve().parents[1]
BASE_SHA256='1bee766c388a93d31967c0e1c34876a2790c1d91873a4e88fef89acb5d4113a2'
NEXT_ID='0009-bk11-owner-backend-custody'
NEXT_VERSION='1.8.0-bk11-service-owned-delivery-v1'
NEXT_FILE='control_context_state_postgres_0009_bk11_owner_backend_custody.sql'

def apply_current8_migrations(connection_factory,runtime_role):
    from control_context_state_postgres import apply_postgres_migrations
    from deployment.provision_database import ROLE,_restore_bk11_membranes
    if type(runtime_role)is not str or not ROLE.fullmatch(runtime_role):
        raise RuntimeError('BK11-existing-runtime-role-reference-required')
    raw=(ROOT/'deployment/proposals/bk11_current8_base_manifest.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=BASE_SHA256:
        raise RuntimeError('BK11-current8-base-source-pin-refused')
    base=json.loads(raw);manifest_path=ROOT/'tooling/context/control_context_postgres_migrations.json'
    current=json.loads(manifest_path.read_bytes())
    if len(base['migrations'])!=8 or len(current['migrations'])!=9 or current['migrations'][:8]!=base['migrations']:
        raise RuntimeError('BK11-current8-prefix-preservation-required')
    suffix=current['migrations'][8]
    if (suffix['migration_id'],suffix['schema_version'],suffix['path'])!=(NEXT_ID,NEXT_VERSION,NEXT_FILE):
        raise RuntimeError('BK11-prospective-reviewed-revision-required')
    def qualify_before_commit(cursor):
        # Same real connection/transaction. Existing runner uses dict rows;
        # unchanged reviewed F1 qualification consumes tuple catalog rows.
        with cursor.connection.cursor(row_factory=tuple_row) as catalog_cursor:
            _restore_bk11_membranes(catalog_cursor,runtime_role)
    return apply_postgres_migrations(connection_factory,manifest_path,
        expected_installed_prefix=base['migrations'],before_commit=qualify_before_commit)
