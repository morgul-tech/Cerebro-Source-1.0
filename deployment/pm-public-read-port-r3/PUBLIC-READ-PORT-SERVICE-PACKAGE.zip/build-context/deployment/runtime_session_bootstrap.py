"""Provider-owned, one-session BK07 bootstrap for the Context service operator.

Run inside the deployed Context service. There is no public MCP operation and
the read-only runtime client cannot invoke this module remotely.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
MCP_DIR = ROOT / "mcp"
if str(MCP_DIR) not in sys.path:
    sys.path.insert(0, str(MCP_DIR))

from control_context_remote_service import LocalRuntimeOAuthBinding  # noqa: E402


class RuntimeSessionBootstrapError(RuntimeError):
    pass


def bind_configured_session(runtime: Any) -> dict[str, Any]:
    """Bind only the disabled, server-configured Liv session and reread it."""
    binding = runtime.config.service.local_runtime_binding
    if (not isinstance(binding, LocalRuntimeOAuthBinding)
            or binding.enabled is not False
            or not all(isinstance(getattr(binding, field), str) and getattr(binding, field)
                       for field in ("issuer", "client_id", "runtime_audience", "tenant_ref",
                                     "workspace_ref", "project_ref", "principal_ref", "session_ref"))
            or binding.principal_ref != binding.client_id + "@clients"
            or not binding.session_ref.startswith("local:")
            or not binding.session_ref[6:]
            or len(binding.session_ref.encode("utf-8")) > 512
            or any(ord(character) < 32 for character in binding.session_ref)):
        raise RuntimeSessionBootstrapError("DISABLED_EXACT_RUNTIME_BINDING_REQUIRED")
    subject = {
        "tenant_ref": binding.tenant_ref,
        "workspace_ref": binding.workspace_ref,
        "project_ref": binding.project_ref,
        "principal_ref": binding.principal_ref,
        "consumer_ref": "LOCAL_CEREBRO_RUNTIME",
        "session_ref": binding.session_ref,
    }
    session_binding_id = "CSB-" + hashlib.sha256(
        json.dumps(subject, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()[:24].upper()
    port = runtime.state_port
    port.bind_session(
        tenant_ref=binding.tenant_ref,
        workspace_ref=binding.workspace_ref,
        principal_ref=binding.principal_ref,
        consumer_ref="LOCAL_CEREBRO_RUNTIME",
        session_ref=binding.session_ref,
        session_binding_id=session_binding_id,
        scopes={"project_state:transition"},
        project_ref=binding.project_ref,
    )
    session = port.read_session(
        tenant_ref=binding.tenant_ref,
        workspace_ref=binding.workspace_ref,
        principal_ref=binding.principal_ref,
        consumer_ref="LOCAL_CEREBRO_RUNTIME",
        session_ref=binding.session_ref,
        scopes={"project_state:read"},
    )
    if (session["session_binding_id"] != session_binding_id
            or session["project_ref"] != binding.project_ref):
        raise RuntimeSessionBootstrapError("RUNTIME_SESSION_READBACK_MISMATCH")
    return {
        "session_ref": binding.session_ref,
        "session_binding_id": session_binding_id,
        "session_revision": session["session_revision"],
        "session_fingerprint": session["fingerprint"],
        "project_revision": session["project_revision"],
    }


def main() -> None:
    if len(sys.argv) != 1:
        raise RuntimeSessionBootstrapError("BOOTSTRAP_TAKES_NO_ARGUMENTS")
    from deployment.app import app  # Import only in the deployed provider environment.
    receipt = bind_configured_session(app._context_runtime)
    print(json.dumps(receipt, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
