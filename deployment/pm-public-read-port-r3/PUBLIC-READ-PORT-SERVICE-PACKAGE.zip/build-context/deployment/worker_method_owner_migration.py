"""Exact additive suffix through existing migration runner; never runtime startup.

Callable only after existing migration access and runtime role are qualified by
the owner. This file creates no credentials or roles and is not invoked by app.
"""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def apply_worker_method_owner_migration(connection_factory,runtime_role,*,final_guard=None):
    if final_guard is not None and not callable(final_guard):raise ValueError('migration-final-guard-invalid')
    from control_context_state_postgres import apply_postgres_migrations
    from psycopg import sql
    if type(runtime_role)is not str or not runtime_role.strip():
        raise ValueError('existing-context-runtime-role-required')
    base_path=ROOT/'deployment/proposals/worker_method_owner_base_manifest.json'
    base=json.loads(base_path.read_bytes())
    current_path=ROOT/'tooling/context/control_context_postgres_migrations.json'
    current=json.loads(current_path.read_bytes())
    if len(base['migrations'])!=11 or len(current['migrations'])!=12 or current['migrations'][:11]!=base['migrations']:
        raise ValueError('worker-method-migration-preserved-prefix-required')
    suffix=current['migrations'][-1]
    if (suffix['migration_id'],suffix['schema_version'],suffix['path'])!=(
        '0012-worker-method-owner','1.11.0-worker-method-owner-candidate','control_context_state_postgres_0012_worker_method_owner.sql'):
        raise ValueError('worker-method-migration-exact-suffix-required')
    return apply_postgres_migrations(connection_factory,current_path,
        expected_installed_prefix=base['migrations'],before_commit=lambda cursor:(qualify_worker_method_runtime(cursor,runtime_role),
            final_guard(cursor) if final_guard is not None else None))

def qualify_worker_method_runtime(cursor,runtime_role):
    from control_context_state_postgres import _fetchone
    from psycopg import sql
    cursor.execute('SELECT rolsuper,rolbypassrls FROM pg_roles WHERE rolname=%s',(runtime_role,))
    row=_fetchone(cursor)
    if row is None or row['rolsuper'] or row['rolbypassrls']:
        raise ValueError('worker-method-runtime-role-RLS-required')
    for table in ('cerebro_worker_method_owner_authorization_revisions','cerebro_worker_method_read_acknowledgments'):
        cursor.execute('SELECT pg_has_role(%s,relowner,\'MEMBER\') AS owner_member FROM pg_class WHERE oid=%s::regclass',
                       (runtime_role,'public.'+table))
        if _fetchone(cursor)['owner_member']:raise ValueError('worker-method-runtime-cannot-own-ledger')
        cursor.execute(sql.SQL('REVOKE ALL ON TABLE public.{} FROM {}').format(sql.Identifier(table),sql.Identifier(runtime_role)))
        permissions='SELECT,INSERT' if table.endswith('acknowledgments') else 'SELECT'
        cursor.execute(sql.SQL('GRANT '+permissions+' ON TABLE public.{} TO {}').format(sql.Identifier(table),sql.Identifier(runtime_role)))
        forbidden='UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER'
        if not table.endswith('acknowledgments'):forbidden+=',INSERT'
        ack_check=' AND has_table_privilege(%s,%s,\'INSERT\')' if table.endswith('acknowledgments') else ''
        parameters=(runtime_role,'public.'+table,runtime_role,'public.'+table,forbidden)
        if ack_check:parameters+=(runtime_role,'public.'+table)
        cursor.execute('SELECT has_table_privilege(%s,%s,\'SELECT\') '
            'AND NOT has_table_privilege(%s,%s,%s)'+ack_check+' AS permitted',parameters)
        if not _fetchone(cursor)['permitted']:raise ValueError('worker-method-inherited-runtime-privileges-refused')
