# ROOM_RETURN D1 candidate contract

This candidate carries the exact A1 owner material through the existing BK11
pointer transport. It does not grant an A1/native identity, wake a model, or mark
recipient work complete. The D1 service family is selected from the persisted
BK11 assignment and is checked consistently for exact obligation lookup,
receiver recovery discovery, and operation-attempt fencing. `route_owner_ref`
preserves the existing transport route owner while `owner_ref` records A1 as the
material owner.

`CEREBRO_ROOM_RETURN_PRODUCER_JSON` is host-owned nonsecret assignment input.
Missing input leaves registration disabled. It binds one authenticated current
principal/consumer/session, project, task/revision, original and envelope digests,
recipient, and exact existing transport route. Registration verifies exact bytes
and current session/project. A1 does not read the separate transport owner's
route; the existing D1 service assignment validates the exact live route,
revision, receiver and TTL under its own custody before transport work. A
single database row stores immutable owner material, idempotency/fingerprint,
positive server sequence, pointer and publication CAS fields. A repeated identical
registration returns the same event; changed content under the same key refuses.

The pointer uses the existing `cerebro.d1.pointer` v1 shape, `ROOM_RETURN`
referent and `DECISION` kind. Material stays in Context owner truth; transport
contains only its pointer. Existing claim/CAS, broker dedupe, backend commit and
independent readback-before-ACK remain in the Source runtime. The row's
`recipient_action` remains `PENDING` after ACK until an authorized ordinary
recipient disposition is correlated. No automatic app send or model execution
is added here.

Migration 0010 is a local candidate only. It preserves 0001–0009, defaults all
existing service assignments to `PM_OWNER`, adds an explicit `ROOM_RETURN`
family/room-owner binding, and grants no runtime privileges. Actual grants,
producer assignment, transport semantic use, migration, deployment, and recipient
handoff remain subject to exact P23 candidate/binding/effect admission.
