/**
 * Add the exact tenant/workspace claims expected by the deployed MCP service.
 * Configure CEREBRO_CLAIM_NAMESPACE, CEREBRO_TENANT_REF and
 * CEREBRO_WORKSPACE_REF as Auth0 Action secrets.
 */
exports.onExecutePostLogin = async (event, api) => {
  const namespace = event.secrets.CEREBRO_CLAIM_NAMESPACE.replace(/\/$/, "");
  api.accessToken.setCustomClaim(
    namespace + "/tenant",
    event.secrets.CEREBRO_TENANT_REF
  );
  api.accessToken.setCustomClaim(
    namespace + "/workspace",
    event.secrets.CEREBRO_WORKSPACE_REF
  );
};
