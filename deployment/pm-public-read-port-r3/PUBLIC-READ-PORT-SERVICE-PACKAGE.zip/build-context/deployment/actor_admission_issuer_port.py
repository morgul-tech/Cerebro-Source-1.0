"""Typed existing-owner administrative bootstrap, never arbitrary SQL or RPC.

Run only by the Human-appointed E2 technical holder under E1 qualification and
an actual finite release. Caller supplies its OWN qualified owner connection;
no credential lookup, identity loan, login, service start or session is created.
After this ONE shared project service scope, actor/task/material changes are data.
"""
import hashlib,json,time
from datetime import datetime
from pathlib import Path

APPOINTMENT_SHA256='117db49fb1aafe0625bfc84a68d90688901c1bc9c0c00ba91d1a137e7beed218'
def need(ok,reason):
    if not ok:raise RuntimeError(reason)
def normalized(value):
    if isinstance(value,datetime):return value.isoformat()
    if type(value)is dict:return {k:normalized(v) for k,v in value.items()}
    if type(value)is list:return [normalized(v) for v in value]
    return value
def digest(value):return hashlib.sha256(json.dumps(normalized(value),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def qualify_project_service_scope(connection_factory,*,inputs,release,before_commit):
    need(callable(connection_factory) and callable(before_commit),'QUALIFIED_OWNER_CONNECTION_AND_FINAL_GUARD_REQUIRED')
    need(type(inputs)is dict and set(inputs)=={'project_ref','before_rows','route_before','enabled'},'EXACT_BOOTSTRAP_INPUTS')
    need(type(inputs['before_rows'])is dict and set(inputs['before_rows'])=={'publisher','receiver'}
         and type(inputs['enabled'])is bool,'EXACT_EXISTING_SERVICE_PAIR_REQUIRED')
    need(release.get('operation')=='INSTALL_PROJECT_ACTOR_SERVICE_SCOPE'
         and release.get('appointment_sha256')==APPOINTMENT_SHA256
         and release.get('input_sha256')==digest(inputs)
         and release.get('entry_sha256')==hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'CURRENT_EXACT_APPOINTED_TECHNICAL_ENTRY_RELEASE_REQUIRED')
    need(release['not_before']<=time.time()<release['expires_at'],'ORIGINAL_FINITE_WINDOW_REQUIRED')
    connection=connection_factory();committing=False;expected={}
    try:
        c=connection.cursor();c.execute("SET LOCAL statement_timeout='5s'");c.execute("SET LOCAL lock_timeout='3s'")
        for role in ('publisher','receiver'):
            before=inputs['before_rows'][role]
            need(before['service_role']==role and before['owner_family']=='ROOM_RETURN'
                 and before['project_ref']==inputs['project_ref'],'EXACT_CURRENT_ROOM_PROJECT_SERVICE_REQUIRED')
            need(inputs['enabled']==before['enabled'], 'SCOPE_CHANGE_MUST_PRESERVE_CURRENT_ENABLED_STATE')
            key=json.dumps([before[k] for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref','session_ref')],separators=(',',':'))
            c.execute('SELECT pg_advisory_xact_lock(hashtextextended(%s,0))',(key,))
            c.execute('SELECT * FROM cerebro_bk11_service_assignments WHERE assignment_ref=%s FOR UPDATE',(before['assignment_ref'],))
            actual=c.fetchone();need(actual is not None and digest(dict(actual))==digest(before),'ACTUAL_SERVICE_BEFOREIMAGE_CHANGED')
            need(actual['room_return_scope']=='EXACT_OWNER','SHARED_SCOPE_ALREADY_CHANGED_RECONCILE_NO_REPLAY')
            c.execute('SELECT expires_at>now() AS active FROM cerebro_bk11_service_leases WHERE assignment_ref=%s FOR SHARE',(before['assignment_ref'],))
            lease=c.fetchone();need(lease is None or lease['active'] is False,'ORIGINAL_SERVICE_LEASE_MUST_FINISH_NO_FORCE_STOP')
            c.execute('SELECT * FROM cerebro_pm_owner_d1_routes WHERE tenant_ref=%s AND workspace_ref=%s AND owner_ref=%s AND route_ref=%s FOR SHARE',
                (before['tenant_ref'],before['workspace_ref'],before['owner_ref'],before['route_ref']))
            route=c.fetchone();need(route is not None and digest(dict(route))==digest(inputs['route_before'])
                and route['project_ref']==inputs['project_ref'] and route['receiver_ref']==before['receiver_ref'],
                'ACTUAL_ROUTE_BEFOREIMAGE_CHANGED')
            c.execute('''UPDATE cerebro_bk11_service_assignments SET room_return_scope='PROJECT_ADMITTED_ACTORS',
                enabled=%s,assignment_revision=assignment_revision+1 WHERE assignment_ref=%s
                AND assignment_revision=%s AND room_return_scope='EXACT_OWNER' RETURNING *''',
                (inputs['enabled'],before['assignment_ref'],before['assignment_revision']))
            changed=c.fetchone();need(changed is not None,'SERVICE_SCOPE_EXPECTED_OLD_CAS_FAILED');expected[role]=dict(changed)
        # Preserve all actual principal/session/role/route/legacy-owner fields;
        # a new actor never needs another project service scope/config change.
        need(release['not_before']<=time.time()<release['expires_at'],'DEADLINE_BEFORE_OWNER_COMMIT')
        before_commit(c);need(time.time()<release['expires_at'],'DEADLINE_AFTER_FINAL_GUARD')
        committing=True;connection.commit();committing=False
    except Exception:
        try:connection.rollback()
        finally:connection.close()
        if committing:raise RuntimeError('COMMIT_OUTCOME_UNKNOWN_READ_EXACT_ASSIGNMENTS_NO_RETRY') from None
        raise
    else:connection.close()
    independent=connection_factory()
    try:
        c=independent.cursor();c.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
        for role,row in expected.items():
            c.execute('SELECT * FROM cerebro_bk11_service_assignments WHERE assignment_ref=%s',(row['assignment_ref'],))
            actual=c.fetchone();need(actual is not None and digest(dict(actual))==digest(row),'COMMITTED_SCOPE_READBACK_CHANGED_NO_RETRY')
        independent.rollback()
    finally:independent.close()
    return {'result':'PROJECT_SERVICE_SCOPE_COMMITTED_INDEPENDENT_READBACK_PASS',
        'scope_fingerprint':digest(expected),'new_credentials':False,'service_start':False,'per_actor_bootstrap':False}
