"""Apply governed migrations and provision a distinct least-privilege runtime role."""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONTEXT_DIR = ROOT / "tooling" / "context"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(CONTEXT_DIR) not in sys.path:
    sys.path.insert(0, str(CONTEXT_DIR))

import psycopg  # noqa: E402
from psycopg import sql  # noqa: E402
from control_context_state_postgres import (  # noqa: E402
    apply_postgres_migrations,
    make_psycopg_connection_factory,
)


ROLE = re.compile(r"^[a-z][a-z0-9_]{2,30}$")


def _restore_bk11_membranes(cursor, role: str) -> None:
    """Reprovision cannot widen already installed BK11 tables. No schema creation."""
    cursor.execute('SET LOCAL search_path = pg_catalog, public, pg_temp')
    # Preserve RouteB runtime/operator separation after any later ordinary provisioning.
    cursor.execute("SELECT to_regclass('public.cerebro_worker_method_owner_authorization_revisions'), to_regclass('public.cerebro_worker_method_read_acknowledgments')")
    worker_tables=cursor.fetchone()
    if any(v is not None for v in worker_tables):
        if not all(v is not None for v in worker_tables):
            raise RuntimeError('worker-method-partial-schema-reprovision-refused')
        from deployment.worker_method_owner_migration import qualify_worker_method_runtime
        qualify_worker_method_runtime(cursor,role)

    cursor.execute("SELECT set_config('cerebro.install_runtime_role', %s, true)", (role,))
    cursor.execute("SELECT to_regclass('public.cerebro_pm_owner_d1_outbox')")
    if cursor.fetchone()[0] is not None:
        cursor.execute((ROOT / 'deployment/proposals/bk11_pm_owner_d1_outbox_role_binding.sql').read_text(encoding='utf-8'))
    names = ['cerebro_bk11_service_assignments', 'cerebro_bk11_service_leases',
             'cerebro_bk11_operation_attempts', 'cerebro_bk11_backend_dispositions']
    cursor.execute("SELECT to_regclass('public.' || unnest(%s::text[]))", (names,))
    present = [r[0] is not None for r in cursor.fetchall()]
    if any(present):
        if not all(present):
            raise RuntimeError('BK11-partial-schema-reprovision-refused')
        from deployment.bk11_schema_qualification import qualify
        qualify(cursor, ROOT, role)
        proposal = (ROOT / 'deployment/proposals/bk11_backend_service_role_binding.sql').read_text(encoding='utf-8')
        # Only the idempotent grant membrane, never repeat CREATE POLICY.
        cursor.execute(proposal.split('$binding$;', 1)[0] + '$binding$;')


def _required(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"required-environment-variable-missing:{name}")
    return value


def _provision_runtime_role(admin_dsn: str, role: str, password: str) -> None:
    if not ROLE.fullmatch(role):
        raise RuntimeError("CEREBRO_RUNTIME_DB_USER-invalid")
    if len(password) < 32:
        raise RuntimeError("CEREBRO_RUNTIME_DB_PASSWORD-too-short")
    with psycopg.connect(admin_dsn, autocommit=False) as connection:
        with connection.cursor() as cursor:
            cursor.execute("SELECT rolname FROM pg_roles WHERE rolname = %s", (role,))
            identifier = sql.Identifier(role)
            if cursor.fetchone() is None:
                cursor.execute(
                    sql.SQL("CREATE ROLE {} LOGIN").format(identifier)
                )
            cursor.execute(
                sql.SQL(
                    "ALTER ROLE {} WITH LOGIN PASSWORD {} NOSUPERUSER NOCREATEDB "
                    "NOCREATEROLE NOREPLICATION NOBYPASSRLS"
                ).format(identifier, sql.Literal(password))
            )
            cursor.execute(
                sql.SQL("REVOKE ALL ON SCHEMA public FROM {}").format(identifier)
            )
            cursor.execute(
                sql.SQL("GRANT USAGE ON SCHEMA public TO {}").format(identifier)
            )
            cursor.execute(
                sql.SQL(
                    "GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO {}"
                ).format(identifier)
            )
            cursor.execute(
                sql.SQL(
                    "GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO {}"
                ).format(identifier)
            )
            cursor.execute(
                sql.SQL(
                    "ALTER DEFAULT PRIVILEGES IN SCHEMA public "
                    "GRANT SELECT, INSERT, UPDATE ON TABLES TO {}"
                ).format(identifier)
            )
            cursor.execute(
                sql.SQL(
                    "ALTER DEFAULT PRIVILEGES IN SCHEMA public "
                    "GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO {}"
                ).format(identifier)
            )
            cursor.execute(
                "SELECT rolsuper, rolcreaterole, rolcreatedb, rolbypassrls "
                "FROM pg_roles WHERE rolname = %s",
                (role,),
            )
            privileges = cursor.fetchone()
            if privileges != (False, False, False, False):
                raise RuntimeError("runtime-database-role-is-overprivileged")
            _restore_bk11_membranes(cursor, role)


def main() -> int:
    admin_dsn = _required("CEREBRO_MIGRATION_DATABASE_URL")
    from deployment.bk11_currentbase_migration import apply_current8_migrations
    result = apply_current8_migrations(
        make_psycopg_connection_factory(
            admin_dsn,
            application_name="cerebro-control-context-migration",
        ),
        _required("CEREBRO_RUNTIME_DB_USER"),
    )
    _provision_runtime_role(
        admin_dsn,
        _required("CEREBRO_RUNTIME_DB_USER"),
        _required("CEREBRO_RUNTIME_DB_PASSWORD"),
    )
    print(
        json.dumps(
            {
                "result": result["result"],
                "applied": result["applied"],
                "already_applied": result["already_applied"],
                "runtime_role": "PROVISIONED_DISTINCT_NON_OWNER_NO_BYPASSRLS",
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        # Sanctioned operator output must not serialize private DSN/account/SQL
        # exception chains. Callable tests/owners retain typed failure internally.
        print(json.dumps({"result":"REFUSED", "reason":"BK11_CURRENT8_QUALIFICATION_OR_APPLY_FAILED",
                          "error_class":type(error).__name__, "credentials":"NOT_EXPOSED"}))
        raise SystemExit(2) from None
