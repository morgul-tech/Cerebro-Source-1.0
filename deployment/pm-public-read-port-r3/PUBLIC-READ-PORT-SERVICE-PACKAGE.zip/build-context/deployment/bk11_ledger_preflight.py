"""Read-only BK11 composition preflight; NEVER applies migrations or emits credentials.

Run only in the actual qualified service custody with its existing least-privileged
connection factory. A branch manifest is expected Source, not a running-image proof.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Callable

SCHEMA = "cerebro-bk11-readonly-ledger-preflight/v1"
MAX_MIGRATIONS = 128
HEX64 = re.compile(r"\A[a-f0-9]{64}\Z")
MIGRATION = re.compile(r"\A[0-9]{4}-[a-z0-9-]+\Z")

class LedgerPreflightError(ValueError):
    pass


def runtime_connection_parameters(environ) -> dict:
    """Match existing deployment/app.py custody without importing/starting that app."""
    explicit = environ.get('CEREBRO_RUNTIME_DATABASE_URL','').strip()
    if explicit:
        return {'conninfo':explicit}
    names={'host':'PGHOST','port':'PGPORT','dbname':'PGDATABASE',
           'user':'CEREBRO_RUNTIME_DB_USER','password':'CEREBRO_RUNTIME_DB_PASSWORD'}
    result={key:environ.get(ref,'').strip() for key,ref in names.items()}
    if not all(result.values()):raise LedgerPreflightError('EXISTING_RUNTIME_DATABASE_CUSTODY_REQUIRED')
    try:port=int(result['port'])
    except ValueError:raise LedgerPreflightError('EXISTING_RUNTIME_DATABASE_CUSTODY_REQUIRED') from None
    if not 1<=port<=65535:raise LedgerPreflightError('EXISTING_RUNTIME_DATABASE_CUSTODY_REQUIRED')
    return result

def _need(ok: bool, code: str) -> None:
    if not ok: raise LedgerPreflightError(code)

def load_expected_manifest(path: Path) -> list[dict[str, str]]:
    path = path.resolve()
    _need(path.stat().st_size <= 65536, "MANIFEST_SIZE")
    value = json.loads(path.read_text(encoding="utf-8"))
    _need(value.get("schema") == "cerebro-control-context-postgres-migrations/v1", "MANIFEST_SCHEMA")
    items = value.get("migrations")
    _need(type(items) is list and 0 < len(items) <= MAX_MIGRATIONS, "MANIFEST_BOUND")
    out = []; seen = set()
    for row in items:
        _need(type(row) is dict and set(row) == {"migration_id", "schema_version", "path", "checksum_sha256"}, "MANIFEST_ENTRY")
        mid, version, checksum, filename = (row[k] for k in ("migration_id", "schema_version", "checksum_sha256", "path"))
        _need(type(mid) is str and MIGRATION.fullmatch(mid) is not None and mid not in seen, "MANIFEST_ID")
        _need(type(version) is str and 0 < len(version) <= 256, "MANIFEST_VERSION")
        _need(type(checksum) is str and HEX64.fullmatch(checksum) is not None, "MANIFEST_CHECKSUM")
        _need(type(filename) is str and Path(filename).name == filename and not Path(filename).is_absolute(), "MANIFEST_PATH")
        source = path.parent / filename
        _need(not source.is_symlink() and not source.is_junction() and source.resolve().parent == path.parent, "MANIFEST_PATH")
        _need(hashlib.sha256(source.read_bytes()).hexdigest() == checksum, "EXPECTED_SQL_CHECKSUM_DRIFT")
        seen.add(mid); out.append({"migration_id":mid,"schema_version":version,"checksum_sha256":checksum})
    return out

def compare_ledger(expected: list[dict[str, str]], observed: list[dict[str, str]]) -> dict[str, Any]:
    _need(len(expected) <= MAX_MIGRATIONS and len(observed) <= MAX_MIGRATIONS, "LEDGER_BOUND")
    def index(rows):
        found = {}
        for row in rows:
            _need(type(row) is dict and set(row) == {"migration_id", "schema_version", "checksum_sha256"}, "LEDGER_ROW")
            mid = row["migration_id"]
            _need(type(mid) is str and MIGRATION.fullmatch(mid) is not None and mid not in found, "LEDGER_ID")
            _need(type(row["checksum_sha256"]) is str and HEX64.fullmatch(row["checksum_sha256"]) is not None, "LEDGER_CHECKSUM")
            _need(type(row["schema_version"]) is str and 0 < len(row["schema_version"]) <= 256, "LEDGER_VERSION")
            found[mid] = row
        return found
    wanted, actual = index(expected), index(observed)
    drift = [mid for mid in actual if mid in wanted and actual[mid] != wanted[mid]]
    unknown = [mid for mid in actual if mid not in wanted]
    missing = [row["migration_id"] for row in expected if row["migration_id"] not in actual]
    encountered_missing = False; hole = False
    for row in expected:
        if row["migration_id"] not in actual: encountered_missing = True
        elif encountered_missing: hole = True
    if drift or unknown or hole: status = "REFUSE_COMPOSITION_DRIFT_OR_UNQUALIFIED_LEDGER"
    elif missing: status = "EXPECTED_SUFFIX_NOT_INSTALLED_NO_APPLY_AUTHORITY"
    else: status = "EXPECTED_LEDGER_MATCH_READ_ONLY"
    return {"schema":SCHEMA,"status":status,"observed_migrations":observed,"checksum_or_version_drift":drift,
            "unqualified_installed_ids":unknown,"expected_not_installed":missing,"prefix_hole":hole,
            "migration_apply":False,"running_image_attested":False,"production_enabled":False}

def inspect_ledger(connection_factory: Callable[[], Any], expected: list[dict[str, str]], *,
                   existing_migration_custody_read_only: bool = False) -> dict[str, Any]:
    connection = cursor = None
    try:
        connection = connection_factory(); cursor = connection.cursor()
        cursor.execute("SET TRANSACTION READ ONLY")
        cursor.execute("SET LOCAL statement_timeout = '5000ms'")
        cursor.execute("SELECT rolsuper, rolbypassrls, rolcreaterole, rolcreatedb FROM pg_roles WHERE rolname = current_user")
        capabilities = cursor.fetchone()
        _need(capabilities is not None and len(capabilities) == 4
              and all(type(v) is bool for v in capabilities), "READER_ROLE_METADATA_INVALID")
        _need(all(v is False for v in capabilities) or existing_migration_custody_read_only is True,
              "LEAST_PRIVILEGED_READER_REQUIRED")
        cursor.execute("SELECT to_regclass('public.cerebro_schema_migrations')")
        relation = cursor.fetchone()
        _need(relation is not None and relation[0] is not None, "MIGRATION_LEDGER_NOT_PRESENT")
        cursor.execute("SELECT migration_id, schema_version, checksum_sha256 FROM public.cerebro_schema_migrations ORDER BY migration_id LIMIT %s", (MAX_MIGRATIONS+1,))
        rows = cursor.fetchall(); _need(len(rows) <= MAX_MIGRATIONS, "LEDGER_BOUND")
        observed = [{"migration_id":r[0],"schema_version":r[1],"checksum_sha256":r[2]} for r in rows]
        result = compare_ledger(expected, observed)
        result.update({"connection_mode":"READ_ONLY_TRANSACTION_ROLLED_BACK",
                       "existing_migration_custody_read_only":existing_migration_custody_read_only,
                       "database_identity_names":"NOT_EXPOSED","credentials":"NOT_EXPOSED"})
        return result
    except LedgerPreflightError:
        raise
    except Exception:
        raise LedgerPreflightError("READ_ONLY_SERVICE_LEDGER_UNAVAILABLE") from None
    finally:
        if connection is not None:
            try: connection.rollback()
            except Exception: pass
        if cursor is not None:
            try: cursor.close()
            except Exception: pass
        if connection is not None:
            try: connection.close()
            except Exception: pass

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, default=Path(__file__).resolve().parents[1]/"tooling/context/control_context_postgres_migrations.json")
    parser.add_argument("--inspect-existing-service-ledger", action="store_true")
    parser.add_argument("--existing-migration-custody-read-only", action="store_true")
    options = parser.parse_args()
    try:
        expected = load_expected_manifest(options.manifest)
        if not options.inspect_existing_service_ledger:
            report = {"schema":SCHEMA,"status":"STATIC_EXPECTED_MANIFEST_ONLY","expected":expected,"live_ledger_read":False,"migration_apply":False}
        else:
            # Explicit qualified in-service migration custody is a read-only fallback,
            # not permission to export its credential or apply any migration.
            if options.existing_migration_custody_read_only:
                dsn=os.environ.get('CEREBRO_MIGRATION_DATABASE_URL','').strip()
                _need(bool(dsn),'EXISTING_RUNTIME_DATABASE_CUSTODY_REQUIRED')
                parameters={'conninfo':dsn}
            else:parameters=runtime_connection_parameters(os.environ)
            import psycopg
            report = inspect_ledger(lambda:psycopg.connect(**parameters,connect_timeout=5), expected,
                      existing_migration_custody_read_only=options.existing_migration_custody_read_only)
        print(json.dumps(report, indent=2))
        return 0 if report["status"] in ("STATIC_EXPECTED_MANIFEST_ONLY","EXPECTED_LEDGER_MATCH_READ_ONLY") else 2
    except Exception as exc:
        code = str(exc) if isinstance(exc, LedgerPreflightError) else "READ_ONLY_PREFLIGHT_INPUT_UNAVAILABLE"
        print(json.dumps({"schema":SCHEMA,"status":"REFUSED_READ_ONLY_PREFLIGHT","reason":code,"migration_apply":False}))
        return 2

if __name__ == "__main__": raise SystemExit(main())
