# PM owner ready custody in the Context host

This candidate registers two normal MCP operations in the existing Context service:
`commit_pm_owner_ready` (`project_state:transition`) and `read_pm_owner_ready`
(`project_state:read`). Both require the caller's current OAuth identity and its
persisted `openai/session` to match one constructor-bound PM assignment. The
service rechecks that session and its project revision inside every PostgreSQL
transaction. A caller cannot select its own PM role, owner, tenant or workspace.
Reads use one repeatable-read snapshot. Commits lock the assigned session and
project in the existing Context order before the owner head and current pointer;
a concurrent change or serialization conflict fails closed. The owner must
reconcile the original idempotency key and receipt rather than blindly retry.

The deployment owner must first apply checksum-locked migration
`0006-pm-owner-ready-custody` through the existing migration connection. The
runtime continues to apply no migrations. The migration creates an append-only
receipt ledger, an owner sequence head and an atomic current-referent pointer
in the existing Context database. No record is seeded. Readiness requires all
three relations, so an incomplete migration prevents a green health check.

The host's nonsecret `CEREBRO_PM_OWNER_ASSIGNMENT_JSON` must be provided by the
actual PM owner/installation authority. Its exact keys are `owner_ref`,
`tenant_ref`, `workspace_ref`, `project_ref`, `principal_ref`, `consumer_ref`,
`session_ref`, and `session_binding_id`. The selected PM session must be
freshly checked before configuration; its mutable revisions and fingerprint
are checked against current provider state on every operation, not frozen in
deployment policy. An absent assignment leaves both operations closed. This
policy is not a token, grant, session creation, or evidence of a READY packet.

The PM actor calls `commit_pm_owner_ready` from its own authenticated Context
session after a genuine work transition, supplying `idempotency_key`,
`referent_id` (`pm-ready:...`), `claim_ref`, `packet_ref`, `queue_ref`, the three
JSON objects `claim_body`, `packet_body`, `queue_body`, `ready_state`
(`BIND_AVAILABLE` or `MATERIAL_READY`), nonempty `way_home`, and
`expected_current_receipt_ref` (null for the first cut). `packet_body` contains
`material` and may contain `active_hold`. The server assigns the immutable
receipt/event/sequence/revisions, computes packet/material/snapshot hashes,
and commits all three bodies and the current pointer in one transaction. A
retry with the same key and exact input returns the original receipt; a changed
input or stale current pointer fails closed. This operation must never be
called with a reconstructed historical Sheet row or a synthetic READY packet.

The PM actor calls `read_pm_owner_ready` with exactly one of `receipt_ref` or
`referent_id`. It returns the immutable record and projection from one
transaction; a current-referent read resolves the pointer in that transaction.
The returned record has the PR85 `PmReadyRecord` fields, and the projection
contains `material_sha256`, `source_cut`, and `active_hold`. Normal PM owner
delivery can use these nonsecret coordinates to bind the later in-process
PR85 consumer after its own host, credential getter, X9 receiver and NATS
route are qualified. No first BK07 event follows from installing this ledger.
