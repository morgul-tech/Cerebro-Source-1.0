"""Fixed-input, service-local administrative writer under qualified OWN custody.

No public admin switch, arbitrary SQL, credential lookup/export or actor loan.
Reuses the existing migration-connection factory/identity qualification. Nothing
is executed on import/startup. Actual current permission/release is required.
"""
import argparse,hashlib,json,os,stat,sys,time
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'mcp'),str(ROOT/'tooling/context'),str(ROOT)]
from actor_admission_model import digest,need
from actor_admission_host import ActorAdmissionHost,_OwnerInvocation,_OWNER_PORT_KEY
from worker_method_operator_custody import database_identity,_operator_uid
from control_context_state_postgres import PostgresControlContextStatePort,make_psycopg_connection_factory,_fetchall
INPUT=Path('/run/cerebro/actor-admission-owner-operation.json')
APPOINTMENT='117db49fb1aafe0625bfc84a68d90688901c1bc9c0c00ba91d1a137e7beed218'
CRITICAL=('mcp/actor_admission_model.py','mcp/actor_admission_store.py','mcp/actor_admission_host.py',
    'mcp/actor_material_provider.py','mcp/actor_service_room_scope.py',
    'mcp/room_return_d1_outbox.py','mcp/room_return_actor_reader.py','mcp/bk11_service_custody.py',
    'mcp/control_context_tools.py','mcp/control_context_remote_service.py','mcp/control_context_mcp_sdk.py','deployment/app.py',
    'deployment/room_return_actor_migration.py','deployment/actor_admission_issuer_port.py',
    'tooling/context/actor_admission_owner_operator.py','tooling/context/control_context_state_postgres.py',
    'tooling/context/control_context_postgres_migrations.json',
    'tooling/context/control_context_state_postgres_0013_room_return_actor_read.sql',
    'tooling/context/control_context_state_postgres_0014_actor_admission_owner.sql')
def package_fingerprint():return digest({p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in CRITICAL})
def factory():
    value=os.environ.get('CEREBRO_MIGRATION_DATABASE_URL','')
    need(bool(value),'EXISTING_OWN_ADMIN_CONNECTION_CUSTODY_UNAVAILABLE')
    return make_psycopg_connection_factory(value,application_name='cerebro-actor-admission-owner')
def qualify(connect):
    connection=connect()
    try:
        c=connection.cursor();c.execute('SET TRANSACTION READ ONLY');identity=database_identity(c)
        c.execute('SELECT migration_id,schema_version,checksum_sha256 FROM cerebro_schema_migrations ORDER BY migration_id')
        ledger=_fetchall(c);connection.rollback()
    finally:connection.close()
    return {'result':'READONLY_EXISTING_OWNER_PORT_OBSERVED','os_uid':_operator_uid(),
            'database_identity':identity,'qualification_fingerprint':digest(identity),
            'ledger':ledger,'package_fingerprint':package_fingerprint(),'authority':'NONE_FROM_OBSERVATION'}
def private_input():
    need(os.name=='posix' and os.geteuid()==0,'EXISTING_OWN_ROOT_OPERATOR_REQUIRED')
    for p in (INPUT,*INPUT.parents):
        info=p.lstat();need(not stat.S_ISLNK(info.st_mode) and info.st_uid==0
            and not info.st_mode&0o022,'FIXED_INPUT_ROOT_CUSTODY_REQUIRED')
    info=INPUT.lstat();need(stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode)==0o600
        and 0<info.st_size<=262144,'BOUNDED_PRIVATE_OPERATION0600_REQUIRED')
    raw=INPUT.read_bytes();return json.loads(raw),hashlib.sha256(raw).hexdigest()

def administrative_audit_session(value,basis):
    """Stable administrative namespace for ONE protected finite release.

    Not an input digest, chat identity, supplied session ID or borrowed actor.
    The root-protected operation input carries the actual release provenance;
    release, holder, own namespace, selected project and window all bind the key.
    Every distinct operation input is still independently hash/guard qualified.
    """
    from actor_admission_model import reference,HEX
    reference(value['release_ref'])
    need(type(value['release_sha256'])is str and HEX.fullmatch(value['release_sha256']) is not None,
         'ACTUAL_PROTECTED_RELEASE_PROVENANCE_REQUIRED')
    project=reference(value['arguments']['project_ref'])
    scope={'schema':'cerebro-administrative-audit-session/v1',
        **{k:value[k] for k in ('release_ref','release_sha256','holder_ref','appointment_sha256','not_before','expires_at')},
        'project_ref':project,'own_namespace':{k:basis[k] for k in
            ('tenant_ref','workspace_ref','principal_ref','consumer_ref','signed_client_ref')}}
    need(type(value['not_before']) in (int,float) and type(value['expires_at']) in (int,float)
         and value['expires_at']>value['not_before'],'ACTUAL_FINITE_AUDIT_RELEASE_REQUIRED')
    return 'operator:'+digest(scope)[:40]
def execute(value,input_sha,connect,*,commit=False):
    need(value.get('schema')=='cerebro-qualified-actor-owner-operation/v1'
         and value.get('holder_ref')=='SAME_E2_D52C3E1A'
         and value.get('appointment_sha256')==APPOINTMENT,'APPROVED_APPOINTED_TECHNICAL_HOLDER_REQUIRED')
    def guard():
        need(_operator_uid()==0 and value['not_before']<=time.time()<value['expires_at'],'ORIGINAL_FINITE_OWN_OPERATOR_WINDOW')
        current,current_sha=private_input()
        need(current_sha==input_sha and current==value,'ORIGINAL_PRIVATE_INPUT_OR_CUSTODY_CHANGED')
        need(package_fingerprint()==value['package_fingerprint'],'EXACT_OWNER_PACKAGE_DRIFT')
        observed=qualify(connect)
        need(observed['qualification_fingerprint']==value['qualification_fingerprint'],'ACTUAL_OWNER_DB_IDENTITY_DRIFT')
    guard();operation=value['operation'];need(operation in value['allowed_operations'],'OPERATION_NOT_RELEASED')
    if operation=='MIGRATE':
        need(commit,'EXPLICIT_INSTALL_COMMIT_REQUIRED')
        from deployment.room_return_actor_migration import apply_actor_read_policy
        result=apply_actor_read_policy(connect,runtime_role=os.environ.get('CEREBRO_RUNTIME_DB_USER',''),
            before_commit=lambda c:guard())
        return {'result':'OWNER_POLICY_MIGRATION_RETURNED','receipt':result,'retry_allowed':False}
    if operation=='PROJECT_SERVICE_SCOPE':
        need(commit,'EXPLICIT_SHARED_SCOPE_COMMIT_REQUIRED')
        from deployment.actor_admission_issuer_port import qualify_project_service_scope
        return qualify_project_service_scope(connect,inputs=value['scope_inputs'],release=value['scope_release'],before_commit=lambda c:guard())
    need(operation=='OWNER_RECORD','EXACT_SUPPORTED_OWNER_OPERATION_REQUIRED')
    args=value['arguments'];need(args['op'] in ('preview_round','select_round','admit_actor','owner_read','set_access_window'),
                              'OWNER_ENTRY_OPERATION_UNSUPPORTED')
    need(commit or args['op'] in ('preview_round','owner_read'),'EXPLICIT_OWNER_DATA_COMMIT_REQUIRED')
    basis=value['own_caller_basis']
    need(basis['schema']=='cerebro-authenticated-binding-basis/v1' and basis['read_eligible'] is True
         and basis['transition_eligible'] is True,'ACTUAL_OWN_CALLER_BASIS_REQUIRED_NOT_BORROWED')
    policy=value['issuer_policy'];need(policy['appointment_sha256']==APPOINTMENT
        and all(policy[k]==basis[k] for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref','signed_client_ref')),
        'OWN_NAMESPACE_AND_ISSUER_SCOPE_MISMATCH')
    # Stable across distinct protected inputs for this actual qualified release.
    # Each input's own byte hash is still checked by guard(), not used as session.
    identity=SimpleNamespace(**{k:basis[k] for k in ('tenant_ref','workspace_ref','principal_ref','consumer_ref')},
        state_scopes={'project_state:read','project_state:transition'},validate=lambda:None)
    audit_session=administrative_audit_session(value,basis)
    context=SimpleNamespace(identity=identity,transport_session=lambda:{'session_ref':audit_session},
        owner_invocation=_OwnerInvocation(_OWNER_PORT_KEY,digest(args),guard))
    host=ActorAdmissionHost(PostgresControlContextStatePort(connect),issuer=policy)
    return host.call(args,context)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--qualify',action='store_true');p.add_argument('--commit',action='store_true');a=p.parse_args()
    if a.qualify:result=qualify(factory())
    else:
        value,fp=private_input();result=execute(value,fp,factory(),commit=a.commit)
    # This stdout belongs to the existing protected operator capture, never a
    # public chat log. No DSN/token/key is returned by this module.
    print(json.dumps(result,sort_keys=True,separators=(',',':'),default=str))
