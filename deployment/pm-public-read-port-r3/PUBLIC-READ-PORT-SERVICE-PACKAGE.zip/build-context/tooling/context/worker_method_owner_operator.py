"""Route B narrow service-local operator; no public mutation or credential output.

python -I -B tooling/context/worker_method_owner_operator.py --qualify
python -I -B tooling/context/worker_method_owner_operator.py --commit
python -I -B tooling/context/worker_method_owner_operator.py --reconcile
Private operation/release input is fixed root-owned0600; never on argv or stdout.
--qualify is readonly and uses no operation input. No migration at startup.
"""
from __future__ import annotations
import argparse,hashlib,json,os,sys,copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'mcp'),str(ROOT/'tooling/context')]
from worker_method_adoption import digest,need,WorkerMethodCommitUnknown
from worker_method_owner import PostgresWorkerMethodOwner
from worker_method_operator_custody import (private_input,database_identity,qualify_permit,require_window,_operator_uid)
from control_context_state_postgres import make_psycopg_connection_factory,_fetchall

CRITICAL=('mcp/worker_method_adoption.py','mcp/worker_method_owner.py','mcp/worker_method_operator_custody.py','mcp/worker_method_operator_input.py','mcp/worker_method_runtime_observation.py',
 'tooling/context/worker_method_owner_operator.py','tooling/context/control_context_state_postgres.py',
 'tooling/context/control_context_registry.py','deployment/worker_method_owner_migration.py',
 'tooling/context/control_context_state_postgres_0012_worker_method_owner.sql',
 'tooling/context/control_context_postgres_migrations.json','deployment/proposals/worker_method_owner_base_manifest.json')
def package_fingerprint():
    return digest({p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in CRITICAL})

def factory():
    dsn=os.environ.get('CEREBRO_MIGRATION_DATABASE_URL','')
    need(bool(dsn),'method-operator-existing-migration-custody-unavailable')
    return make_psycopg_connection_factory(dsn,application_name='cerebro-worker-method-owner-operator')

def qualify(connect):
    connection=connect()
    try:
        cursor=connection.cursor()
        try:
            cursor.execute('SET TRANSACTION READ ONLY')
            identity=database_identity(cursor)
            cursor.execute('SELECT migration_id,schema_version,checksum_sha256 FROM cerebro_schema_migrations ORDER BY migration_id')
            ledger=_fetchall(cursor)
        finally:cursor.close();connection.rollback()
    finally:connection.close()
    return {'result':'READ_ONLY_QUALIFIED_OBSERVATION','actual_os_uid':_operator_uid(),
            'database_identity':identity,'qualification_fingerprint':digest(identity),'ledger':ledger,'package_fingerprint':package_fingerprint(),
            'limits':'Actual observation only; no effect authority, publication or role is granted'}

def execute(value,connect,*,commit=False):
    require_window(value)
    need(value['package_fingerprint']==package_fingerprint(),'method-operator-package-drift')
    operation=value['operation']
    if operation=='MIGRATE':
        need(commit,'method-operator-migration-explicit-commit-required')
        before=qualify(connect)
        need(before['actual_os_uid']==0 and before['qualification_fingerprint']==value['qualification_fingerprint']
             and before['database_identity']['schema_privilege']is True,'method-operator-migration-access-drift')
        # Exact existing runtime role from service environment; no password/role creation.
        sys.path.insert(0,str(ROOT))
        from deployment.worker_method_owner_migration import apply_worker_method_owner_migration
        def final_guard(cursor):
            require_window(value)
            need(value['package_fingerprint']==package_fingerprint(),'method-operator-migration-package-drift')
            need(database_identity(cursor)==before['database_identity'],'method-operator-migration-db-drift')
        require_window(value)
        result=apply_worker_method_owner_migration(connect,os.environ.get('CEREBRO_RUNTIME_DB_USER',''),final_guard=final_guard)
        return {'result':'MIGRATION_RETURNED','receipt':result}
    if operation=='RECONCILE' and value['arguments'].get('kind')=='MIGRATION':
        actual=qualify(connect)
        need(actual['actual_os_uid']==0 and actual['qualification_fingerprint']==value['qualification_fingerprint'],'migration-reconcile-target-drift')
        manifest=json.loads((ROOT/'tooling/context/control_context_postgres_migrations.json').read_bytes())['migrations']
        expected=[{k:m[k] for k in ('migration_id','schema_version','checksum_sha256')} for m in manifest]
        return {'result':'RECONCILE_EXACT_MIGRATION_STATE_NO_RETRY' if actual['ledger']==expected else 'RECONCILE_MIGRATION_STATE_NOT_MATCHED_NO_RETRY',
                'ledger_fingerprint':digest(actual['ledger']),'retry_allowed':False}
    owner=PostgresWorkerMethodOwner(connect,value['policy'],value['standing_owner_identity'])
    permit=qualify_permit(connect,value)
    args=value['arguments']
    if operation=='RECONCILE':
        b=next((b for b in owner.policy['generation_bindings'] if b['generation_ref']==args['generation_ref']),None)
        need(b is not None,'method-operator-reconcile-generation-unbound')
        with owner._transaction(b['identity']) as cursor:
            owner._lock(cursor,b['identity'],b['generation_ref'])
            record=owner._latest(cursor,b['identity'],b['generation_ref'])
        expected=args.get('expected_record_fingerprint')
        matched=record is not None and expected is not None and digest(record)==expected
        return {'result':'RECONCILE_EXACT_RECORD_MATCH_NO_RETRY' if matched else ('RECONCILE_ABSENT_NO_RETRY' if record is None else 'RECONCILE_RECORD_PRESENT_NO_RETRY'),
                'record_fingerprint':digest(record) if record else None,
                'revision':record['revision'] if record else None,'retry_allowed':False}
    if operation not in ('PUBLISH','REVOKE'):need(commit,'method-operator-explicit-commit-required')
    if operation=='PUBLISH':
        args={**args,'decision_material':value['decision_material']}
        def read_birth(who,gen):
            return owner.port.read_pre_role_generation(tenant_ref=who['tenant_ref'],workspace_ref=who['workspace_ref'],
                generation_ref=gen,principal_ref=who['principal_ref'],scopes={'project_state:read'})
        return owner.publish_operator(args,permit,read_birth,preview=not commit)
    if operation=='REVOKE':return owner.revoke_operator(args,permit,preview=not commit)
    raise ValueError('method-operator-operation-not-selected')

def reconcile_original(connect,expected_input_sha,kind,expected_record=None):
    # Keep the held original file unchanged; only the read-only in-memory view differs.
    original=private_input()
    from worker_method_operator_custody import INPUT
    need(hashlib.sha256(INPUT.read_bytes()).hexdigest()==expected_input_sha,'original-private-input-changed')
    operation='MIGRATE' if kind=='MIGRATION' else kind
    need(operation in ('MIGRATE','PUBLISH','REVOKE') and original['operation']==operation,
         'original-operation-reconcile-kind-mismatch')
    need('RECONCILE' in original['allowed_operations'],'readonly-reconcile-not-released')
    if kind!='MIGRATION':need(type(expected_record)is str and len(expected_record)==64,'expected-exact-record-required')
    value=copy.deepcopy(original);value['operation']='RECONCILE'
    value['arguments']=({'kind':'MIGRATION'} if kind=='MIGRATION' else
        {'generation_ref':original['arguments']['generation_ref'],'expected_record_fingerprint':expected_record})
    return execute(value,connect,commit=False)

def main():
    p=argparse.ArgumentParser(description=__doc__);m=p.add_mutually_exclusive_group()
    m.add_argument('--qualify',action='store_true');m.add_argument('--commit',action='store_true');m.add_argument('--reconcile',action='store_true')
    m.add_argument('--install-input',action='store_true');m.add_argument('--input-status',action='store_true')
    m.add_argument('--compare-host-policy',action='store_true');m.add_argument('--reconcile-original',action='store_true');m.add_argument('--verify-runtime',action='store_true')
    p.add_argument('--expected-input-sha256');p.add_argument('--reconcile-kind',choices=['MIGRATION','PUBLISH','REVOKE'])
    p.add_argument('--expected-record-fingerprint')
    p.add_argument('--expected-transport-sha256');p.add_argument('--previous-input-sha256')
    a=p.parse_args()
    effect_attempted=False
    try:
        from worker_method_operator_input import install,input_status,actual_host_grant
        if a.compare_host_policy:
            policy=json.loads(sys.stdin.buffer.read(65537))
            grant=actual_host_grant(policy)
            print(json.dumps({'result':'EXISTING_HOST_GRANT_MATCHED','grant_fingerprint':digest(grant),'policy_fingerprint':digest(policy)}));return 0
        if a.input_status:print(json.dumps(input_status()));return 0
        if a.install_input:
            effect_attempted=True
            result=install(sys.stdin.buffer.read(1048577),transport_sha=a.expected_transport_sha256,previous_sha=a.previous_input_sha256,package_fp=package_fingerprint())
            print(json.dumps(result));return 0
        connect=factory()
        if a.verify_runtime:
            from worker_method_runtime_observation import observe
            print(json.dumps(observe(ROOT,connect,json.loads(sys.stdin.buffer.read(65537)))));return 0
        if a.qualify:
            # Qualification detail is private operator output; launcher captures it privately.
            print(json.dumps(qualify(connect),sort_keys=True));return 0
        if a.reconcile_original:
            result=reconcile_original(connect,a.expected_input_sha256,a.reconcile_kind,a.expected_record_fingerprint)
            print(json.dumps(result));return 0
        value=private_input()
        if a.reconcile:need(value['operation']=='RECONCILE','method-operator-reconcile-input-required')
        if not a.commit and not a.reconcile:
            result=execute(value,connect,commit=False)
            print(json.dumps(result));return 0
        effect_attempted=a.commit
        result=execute(value,connect,commit=a.commit)
        # Raw originals, DB identity and reviewer/operator provenance never leave this path.
        print(json.dumps({'result':result['result'],'receipt_fingerprint':digest(result),
                          'revision':result.get('revision'),'retry_allowed':False}));return 0
    except WorkerMethodCommitUnknown:
        print(json.dumps({'result':'COMMIT_OUTCOME_UNKNOWN','retry_allowed':False}));return 4
    except Exception:
        print(json.dumps({'result':'OPERATOR_EFFECT_OUTCOME_UNRESOLVED' if effect_attempted else 'REFUSED_OR_UNQUALIFIED','retry_allowed':False,'private_details':'NOT_EXPORTED'}));return 2

if __name__=='__main__':raise SystemExit(main())
