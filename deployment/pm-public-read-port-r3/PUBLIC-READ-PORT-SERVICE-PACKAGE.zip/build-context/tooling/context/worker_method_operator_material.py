"""Prepare exact owner-reviewed original bytes for the protected MCP publication.

Local capture only; this command never authenticates, sends, signs Human intent or
invents publisher identity. Existing authenticated operator invokes the resulting
publish_worker_method_authorization input on its normal owner control surface.
"""
from pathlib import Path
import argparse,base64,hashlib,json

def capture(review_path):
    review=json.loads(Path(review_path).read_bytes())
    result={'reviewer':review['reviewer_actor'],'review_note':review['review_result'],'materials':[]}
    for m in review['materials']:
        raw=Path(m['path']).read_bytes()
        if not (m.get('complete_material_read_by_reviewer') is True or m.get('complete_material_read_by_E1') is True) or len(raw)!=m['bytes'] or hashlib.sha256(raw).hexdigest()!=m['sha256']:
            raise ValueError('operator-reviewed-original-drift')
        result['materials'].append({'kind':m['kind'],'provenance':m['path'],
            'bytes_b64':base64.b64encode(raw).decode('ascii'),'sha256':m['sha256'],'bytes':len(raw)})
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--actual-review',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();out=Path(a.output)
    # Exclusive create preserves prior captures. Operator supplies this as decision_material.
    with out.open('x',encoding='utf-8') as f:json.dump(capture(a.actual_review),f,ensure_ascii=False,indent=2)
