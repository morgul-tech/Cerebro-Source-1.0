#!/usr/bin/env python3
"""Protected one-shot owner operation for a fresh Assistant READY_UNBOUND candidate.

Default mode validates only and rolls back. --commit is required to insert the
0008 Assistant policy+decision pair. The operation never creates a Boot
generation, seals an overlay, attaches a role, or reads credentials.

Runtime input is fixed at /tmp/cerebro-assistant-owner-input.json and output at
/tmp/cerebro-assistant-owner-receipt.json. Database custody stays inside the
Railway service through CEREBRO_MIGRATION_DATABASE_URL.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import stat
from pathlib import Path
from typing import Any

import psycopg


INPUT_PATH = Path("/tmp/cerebro-assistant-owner-input.json")
OUTPUT_PATH = Path("/tmp/cerebro-assistant-owner-receipt.json")
INPUT_SCHEMA = "cerebro-assistant-owner-operation-input/v1"
CONNECTOR_INPUT_SCHEMA = "cerebro-assistant-owner-connector-input/v1"
CAPTURE_INTAKE_SCHEMA = "cerebro-assistant-protected-capture-intake/v1"
OUTPUT_SCHEMA = "cerebro-assistant-owner-operation-receipt/v1"
FORBIDDEN_OLD_GENERATION = "CEREBRO-BOOT-WORKER-20261004-2025-02"
ASSISTANT_GENERATION = re.compile(r"^CEREBRO-BOOT-ASS-[A-Z0-9-]{8,96}$")
REF = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.@:-]{0,255}$")
SHA256 = re.compile(r"^[0-9a-f]{64}$")
HEX40 = re.compile(r"^[0-9a-f]{40}$")


class OwnerOperationError(RuntimeError):
    pass


class OwnerOperationOutcome(RuntimeError):
    """Stable nonsecret machine outcome; never carries raw provider exceptions."""

    def __init__(self, code: str, *, result: str, committed: bool | None, retry_allowed: bool):
        super().__init__(code)
        self.code = code
        self.result = result
        self.committed = committed
        self.retry_allowed = retry_allowed


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise OwnerOperationError(message)


def _text(value: Any, field: str, *, ref: bool = False) -> str:
    _require(isinstance(value, str) and value == value.strip() and bool(value), f"{field}-required")
    if ref:
        _require(REF.fullmatch(value) is not None, f"{field}-invalid")
    return value


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


class _ProtectedConnectorInput(dict):
    """In-process custody result, never a client-supplied JSON trust flag."""


def _protected_bytes(path: Path) -> bytes:
    _require(os.name == "posix" and os.geteuid() == 0, "connector-capture-root-custodian-required")
    for parent in path.parents:
        info = parent.lstat()
        _require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode)
                 and info.st_uid == 0 and not info.st_mode & 0o022,
                 "connector-capture-parent-custody-invalid")
    parent = path.parent.lstat()
    _require(stat.S_IMODE(parent.st_mode) == 0o700, "connector-capture-private-parent-required")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(descriptor)
        _require(stat.S_ISREG(info.st_mode) and info.st_uid == 0
                 and stat.S_IMODE(info.st_mode) == 0o600 and info.st_nlink == 1
                 and 0 < info.st_size <= 2 * 1024 * 1024,
                 "connector-capture-file-custody-invalid")
        with os.fdopen(os.dup(descriptor), "rb") as stream:
            body = stream.read(2 * 1024 * 1024 + 1)
        _require(len(body) == info.st_size, "connector-capture-file-changed")
        return body
    finally:
        os.close(descriptor)


def _qualify_connector_input(value: dict[str, Any], path: Path, raw_input: bytes) -> _ProtectedConnectorInput:
    """Accept only a rightfully prepared private owner intake, not raw JSON alone.

    Root custody is the existing privileged publisher boundary. Its operation
    must separately bind the actual Human owner original and candidate capture
    provenance. This does not attest an exporter or recover hidden MCP metadata.
    """
    _require(_protected_bytes(path) == raw_input, "connector-input-custody-or-bytes-changed")
    intake = json.loads(_protected_bytes(path.parent / "capture-intake.json"))
    fields = {"raw_sha256", "authorization_sha256", "source_thread_ref", "source_tool", "source_call_ref"}
    _require(type(intake) is dict and set(intake) == fields | {"schema", "operation_ref"}
             and intake.get("schema") == CAPTURE_INTAKE_SCHEMA,
             "protected-capture-intake-exact-fields-required")
    descriptor = value.get("connector_capture")
    _require(type(descriptor) is dict and set(descriptor) == fields
             and descriptor == {key: intake[key] for key in fields},
             "connector-capture-protected-intake-mismatch")
    _text(intake.get("operation_ref"), "capture-operation-ref", ref=True)
    for field in ("source_thread_ref", "source_call_ref"):
        _text(intake.get(field), "capture-" + field, ref=True)
    _require(intake.get("source_tool") == "read_boot_generation_state", "capture-source-tool-invalid")
    for field in ("raw_sha256", "authorization_sha256"):
        _require(type(intake[field]) is str and SHA256.fullmatch(intake[field]) is not None,
                 "capture-original-hash-invalid")
    raw = _protected_bytes(path.parent / "native-response.raw.json")
    owner_raw = _protected_bytes(path.parent / "owner-decision.original.json")
    _require(hashlib.sha256(raw).hexdigest() == intake["raw_sha256"]
             and hashlib.sha256(owner_raw).hexdigest() == intake["authorization_sha256"],
             "capture-original-bytes-mismatch")
    wrapper = json.loads(raw)
    _require(_canonical(wrapper) == _canonical(value.get("native_read_wrapper")), "connector-wrapper-original-mismatch")
    owner = json.loads(owner_raw)
    _require(type(owner) is dict
             and owner.get("schema") == "p24-human-selected-assistant-successor-decision/v2"
             and owner.get("task") == intake["operation_ref"]
             and owner.get("human_owner_authorization") == value.get("human_owner_authorization"),
             "capture-owner-original-mapping-mismatch")
    selected = owner.get("selected_successor")
    native = wrapper.get("structuredContent") if type(wrapper) is dict else None
    pre = native.get("pre_role_generation") if type(native) is dict else None
    _require(type(selected) is dict and type(pre) is dict
             and selected.get("thread") == intake["source_thread_ref"]
             and selected.get("generation_ref") == pre.get("generation_ref")
             and selected.get("source_revision") == pre.get("source_revision")
             and selected.get("birth_revision") == pre.get("revision")
             and selected.get("requested_native_role") == "ASSISTANT",
             "capture-candidate-owner-basis-mismatch")
    qualified = _ProtectedConnectorInput(value)
    qualified._capture_provenance = {
        **descriptor, "operation_ref": intake["operation_ref"],
        "input_fingerprint": _sha(value),
        "basis": "ROOT_CUSTODIAN_ACCEPTED_OWNER_ORIGINAL_AND_PROTECTED_CONNECTOR_CAPTURE",
        "exporter_attested": False,
    }
    return qualified


def load_input(path: Path = INPUT_PATH) -> dict[str, Any]:
    try:
        raw = path.read_bytes()
        value = json.loads(raw.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise OwnerOperationError("operator-input-unreadable") from exc
    _require(isinstance(value, dict), "operator-input-object-required")
    if value.get("schema") == INPUT_SCHEMA:
        _require(set(value) == {"schema", "native_read_wrapper", "human_owner_authorization"},
                 "operator-input-exact-fields-required")
        return value
    _require(value.get("schema") == CONNECTOR_INPUT_SCHEMA
             and set(value) == {"schema", "native_read_wrapper", "human_owner_authorization", "connector_capture"},
             "operator-input-schema-or-fields-mismatch")
    return _qualify_connector_input(value, path, raw)


def validate_input(value: dict[str, Any]) -> dict[str, Any]:
    wrapper = value.get("native_read_wrapper")
    auth = value.get("human_owner_authorization")
    connector = value.get("schema") == CONNECTOR_INPUT_SCHEMA
    if connector:
        _require(type(value) is _ProtectedConnectorInput
                 and type(getattr(value, "_capture_provenance", None)) is dict
                 and value._capture_provenance.get("input_fingerprint") == _sha(value),
                 "protected-connector-capture-provenance-required")
        _require(type(wrapper) is dict and set(wrapper) in (
                     {"content", "structuredContent", "isError"},
                     {"content", "structuredContent", "isError", "_meta"}),
                 "connector-native-return-exact-fields-required")
        content = wrapper.get("content")
        _require(wrapper.get("isError") is False and type(content) is list and len(content) == 1
                 and type(content[0]) is dict and set(content[0]) == {"type", "text"}
                 and content[0].get("type") == "text" and type(content[0].get("text")) is str,
                 "connector-native-content-shape-invalid")
        try:
            text_value = json.loads(content[0]["text"])
        except (ValueError, TypeError):
            raise OwnerOperationError("connector-native-text-not-json") from None
        _require(_canonical(text_value) == _canonical(wrapper.get("structuredContent")), "connector-native-content-conflict")
    else:
        _require(value.get("schema") == INPUT_SCHEMA
                 and isinstance(wrapper, dict) and set(wrapper) == {"structuredContent", "_meta"},
                 "native-read-wrapper-exact-fields-required")
    meta_present = "_meta" in wrapper
    meta = wrapper.get("_meta")
    if not connector or meta_present:
        _require(isinstance(meta, dict) and set(meta) == {
                 "cerebro/repositoryPermissionRequired",
                 "cerebro/sessionCorrelationPresent",
                 "cerebro/subjectCorrelationPresent",
             }
             and meta.get("cerebro/repositoryPermissionRequired") is False
             and meta.get("cerebro/sessionCorrelationPresent") is True
             and isinstance(meta.get("cerebro/subjectCorrelationPresent"), bool),
                 "native-read-wrapper-meta-invalid")
    native = wrapper.get("structuredContent")
    _require(isinstance(native, dict) and set(native) == {
        "pre_role_generation", "authenticated_binding", "repository_permission_required",
    }, "native-read-structured-content-exact-fields-required")
    _require(native.get("repository_permission_required") is False,
             "native-read-repository-permission-mismatch")
    pre = native.get("pre_role_generation")
    binding = native.get("authenticated_binding")
    _require(isinstance(pre, dict), "native-pre-role-object-required")
    _require(isinstance(binding, dict) and set(binding) == {
        "tenant_ref", "workspace_ref", "principal_ref", "consumer_ref", "session_ref",
    }, "native-authenticated-binding-exact-fields-required")
    for field in ("tenant_ref", "workspace_ref", "principal_ref", "consumer_ref", "session_ref"):
        _text(binding.get(field), "authenticated-binding-" + field)

    generation_ref = _text(pre.get("generation_ref"), "generation-ref")
    _require(generation_ref != FORBIDDEN_OLD_GENERATION, "old-a1-generation-forbidden-as-fresh-assistant")
    _require(ASSISTANT_GENERATION.fullmatch(generation_ref) is not None,
             "fresh-assistant-generation-ref-required")
    _require(pre.get("lifecycle") == "READY_UNBOUND", "ready-unbound-lifecycle-required")
    _require(pre.get("role_overlay") is None, "fresh-assistant-role-overlay-must-be-null")
    _require(type(pre.get("revision")) is int and pre["revision"] >= 2, "generation-revision-invalid")
    source_revision = pre.get("source_revision")
    _require(isinstance(source_revision, str) and HEX40.fullmatch(source_revision) is not None,
             "generation-source-revision-invalid")
    fingerprint = pre.get("fingerprint")
    _require(isinstance(fingerprint, str) and SHA256.fullmatch(fingerprint) is not None,
             "generation-fingerprint-invalid")
    _require(pre.get("tenant_ref") == binding["tenant_ref"]
             and pre.get("workspace_ref") == binding["workspace_ref"],
             "native-binding-generation-scope-mismatch")

    authority = pre.get("authority_envelope")
    _require(isinstance(authority, dict)
             and authority.get("role") is None
             and authority.get("state") == "UNBOUND"
             and authority.get("grants_claim") is False
             and authority.get("grants_live_authority") is False
             and authority.get("grants_scheduler_authority") is False,
             "fresh-assistant-authority-envelope-invalid")
    identity = pre.get("identity_envelope")
    _require(isinstance(identity, dict)
             and identity.get("generation_ref") == generation_ref
             and identity.get("predecessor_generation_ref") is None
             and identity.get("predecessor_live_state_inherited") is False
             and identity.get("predecessor_claims_inherited") is False
             and identity.get("private_state_inherited") is False,
             "fresh-assistant-identity-envelope-invalid")

    fresh = pre.get("fresh_world")
    _require(isinstance(fresh, dict)
             and fresh.get("verified") is True
             and fresh.get("currentness") == "CURRENT"
             and fresh.get("source_revision") == source_revision,
             "fresh-world-current-readback-required")
    method = pre.get("civilization_method_attestation")
    _require(isinstance(method, dict)
             and method.get("attested") is True
             and method.get("currentness") == "CURRENT"
             and isinstance(method.get("method_fingerprint"), str)
             and SHA256.fullmatch(method["method_fingerprint"]) is not None,
             "civilization-method-current-attestation-required")
    receipt = pre.get("ready_unbound_receipt")
    _require(isinstance(receipt, dict)
             and receipt.get("durable") is True
             and receipt.get("post_state_readback_verified") is True
             and receipt.get("generation_ref") == generation_ref
             and receipt.get("source_revision") == source_revision,
             "durable-ready-readback-required")
    receipt_ref = _text(receipt.get("receipt_ref"), "ready-receipt-ref", ref=True)
    receipt_fp = receipt.get("receipt_fingerprint")
    _require(isinstance(receipt_fp, str) and SHA256.fullmatch(receipt_fp) is not None,
             "ready-receipt-fingerprint-invalid")

    _require(isinstance(auth, dict) and set(auth) == {
        "authorization_ref", "policy_ref", "decision_ref", "overlay_ref",
        "actor_ref", "actor_generation_ref",
    }, "human-owner-authorization-exact-fields-required")
    authorization_ref = _text(auth.get("authorization_ref"), "authorization-ref", ref=True)
    policy_ref = _text(auth.get("policy_ref"), "policy-ref", ref=True)
    decision_ref = _text(auth.get("decision_ref"), "decision-ref", ref=True)
    overlay_ref = _text(auth.get("overlay_ref"), "overlay-ref", ref=True)
    actor_ref = _text(auth.get("actor_ref"), "actor-ref", ref=True)
    actor_generation_ref = _text(auth.get("actor_generation_ref"), "actor-generation-ref", ref=True)

    normalized = {
        "binding": copy.deepcopy(binding),
        "generation_ref": generation_ref,
        "generation_revision": pre["revision"],
        "source_revision": source_revision,
        "generation_fingerprint": fingerprint,
        "ready_receipt_ref": receipt_ref,
        "ready_receipt_fingerprint": receipt_fp,
        "method_fingerprint": _text(method.get("method_fingerprint"), "method-fingerprint"),
        "authorization_ref": authorization_ref,
        "policy_ref": policy_ref,
        "decision_ref": decision_ref,
        "overlay_ref": overlay_ref,
        "actor_ref": actor_ref,
        "actor_generation_ref": actor_generation_ref,
        "native_read_wrapper_fingerprint": _sha(wrapper),
        "input_fingerprint": _sha(value),
    }
    if connector:
        normalized["connector_capture_provenance"] = copy.deepcopy(value._capture_provenance)
        normalized["native_meta_evidence"] = "PRESENT_VALIDATED" if meta_present else "NOT_EXPOSED"
    return normalized


def _row(cursor: Any) -> dict[str, Any] | None:
    result = cursor.fetchone()
    if result is None:
        return None
    names = [item.name if hasattr(item, "name") else item[0] for item in cursor.description]
    return dict(zip(names, result))


def _set_transaction_scope(cursor: Any, normalized: dict[str, Any]) -> None:
    b = normalized["binding"]
    cursor.execute("SELECT set_config('cerebro.tenant_ref', %s, true)", (b["tenant_ref"],))
    cursor.execute("SELECT set_config('cerebro.workspace_ref', %s, true)", (b["workspace_ref"],))


def _begin_read_snapshot(cursor: Any, normalized: dict[str, Any]) -> None:
    cursor.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
    cursor.execute("SET LOCAL statement_timeout = '5s'")
    _set_transaction_scope(cursor, normalized)


def _begin_write_transaction(cursor: Any, normalized: dict[str, Any]) -> None:
    cursor.execute("SET LOCAL statement_timeout = '5s'")
    _set_transaction_scope(cursor, normalized)


def _load_generation(cursor: Any, normalized: dict[str, Any], *, lock: bool) -> dict[str, Any]:
    b = normalized["binding"]
    cursor.execute(
        """
        SELECT tenant_ref, workspace_ref, generation_ref, lifecycle, source_revision,
               aggregate_revision, aggregate_fingerprint, generation_payload
          FROM cerebro_pre_role_generation_heads
         WHERE tenant_ref=%s AND workspace_ref=%s AND generation_ref=%s
        """ + (" FOR SHARE" if lock else ""),
        (b["tenant_ref"], b["workspace_ref"], normalized["generation_ref"]),
    )
    row = _row(cursor)
    _require(row is not None, "fresh-generation-not-found")
    payload = row["generation_payload"]
    _require(isinstance(payload, dict), "persisted-generation-payload-invalid")
    _require(row["lifecycle"] == "READY_UNBOUND", "persisted-generation-not-ready-unbound")
    _require(row["source_revision"] == normalized["source_revision"], "persisted-generation-source-mismatch")
    _require(row["aggregate_revision"] == normalized["generation_revision"]
             == payload.get("revision"), "persisted-generation-revision-mismatch")
    _require(row["aggregate_fingerprint"] == normalized["generation_fingerprint"]
             == payload.get("fingerprint"), "persisted-generation-fingerprint-mismatch")
    _require(payload.get("role_overlay") is None, "persisted-generation-already-role-attached")
    authority = payload.get("authority_envelope")
    _require(isinstance(authority, dict) and authority.get("role") is None
             and authority.get("state") == "UNBOUND"
             and authority.get("grants_claim") is False
             and authority.get("grants_live_authority") is False
             and authority.get("grants_scheduler_authority") is False,
             "persisted-generation-authority-mismatch")
    identity = payload.get("identity_envelope")
    _require(isinstance(identity, dict)
             and identity.get("generation_ref") == normalized["generation_ref"]
             and identity.get("predecessor_generation_ref") is None
             and identity.get("predecessor_live_state_inherited") is False
             and identity.get("predecessor_claims_inherited") is False
             and identity.get("private_state_inherited") is False,
             "persisted-generation-identity-mismatch")
    method = payload.get("civilization_method_attestation")
    _require(isinstance(method, dict)
             and method.get("attested") is True
             and method.get("currentness") == "CURRENT"
             and method.get("method_fingerprint") == normalized["method_fingerprint"],
             "persisted-generation-method-mismatch")
    receipt = payload.get("ready_unbound_receipt")
    _require(isinstance(receipt, dict)
             and receipt.get("durable") is True
             and receipt.get("post_state_readback_verified") is True
             and receipt.get("receipt_ref") == normalized["ready_receipt_ref"]
             and receipt.get("receipt_fingerprint") == normalized["ready_receipt_fingerprint"]
             and receipt.get("generation_ref") == normalized["generation_ref"]
             and receipt.get("source_revision") == normalized["source_revision"],
             "persisted-ready-receipt-mismatch")
    fresh = payload.get("fresh_world")
    _require(isinstance(fresh, dict)
             and fresh.get("verified") is True
             and fresh.get("currentness") == "CURRENT"
             and fresh.get("source_revision") == normalized["source_revision"],
             "persisted-fresh-world-not-current")
    return row


def _assert_absent(cursor: Any, normalized: dict[str, Any]) -> None:
    b = normalized["binding"]
    cursor.execute(
        """
        SELECT policy_ref, policy_revision, current, revoked
          FROM cerebro_assistant_overlay_policy_heads
         WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s
           AND consumer_ref=%s AND session_ref=%s AND policy_ref=%s
         FOR UPDATE
        """,
        (b["tenant_ref"], b["workspace_ref"], b["principal_ref"], b["consumer_ref"],
         b["session_ref"], normalized["policy_ref"]),
    )
    _require(cursor.fetchone() is None, "assistant-policy-already-exists-no-auto-rebind")
    cursor.execute(
        """
        SELECT decision_ref, owner_revision, current, revoked
          FROM cerebro_assistant_overlay_decision_heads
         WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s
           AND consumer_ref=%s AND session_ref=%s AND generation_ref=%s
         FOR UPDATE
        """,
        (b["tenant_ref"], b["workspace_ref"], b["principal_ref"], b["consumer_ref"],
         b["session_ref"], normalized["generation_ref"]),
    )
    _require(cursor.fetchone() is None, "assistant-decision-already-exists-no-auto-rebind")
    cursor.execute(
        """
        SELECT generation_ref
          FROM cerebro_assistant_overlay_decision_heads
         WHERE tenant_ref=%s AND workspace_ref=%s AND decision_ref=%s
         FOR UPDATE
        """,
        (b["tenant_ref"], b["workspace_ref"], normalized["decision_ref"]),
    )
    _require(cursor.fetchone() is None, "assistant-decision-ref-already-used")


def _policy_row(normalized: dict[str, Any]) -> dict[str, Any]:
    b = normalized["binding"]
    return {
        **b,
        "policy_ref": normalized["policy_ref"],
        "policy_revision": 1,
        "current": True,
        "revoked": False,
        "owner_authorization_ref": normalized["authorization_ref"],
        "allowed_role": "ASSISTANT",
        "source_revision": normalized["source_revision"],
    }


def _decision_row(normalized: dict[str, Any]) -> dict[str, Any]:
    b = normalized["binding"]
    return {
        **b,
        "generation_ref": normalized["generation_ref"],
        "decision_ref": normalized["decision_ref"],
        "policy_ref": normalized["policy_ref"],
        "policy_revision": 1,
        "owner_revision": 1,
        "current": True,
        "revoked": False,
        "pre_role_fingerprint": normalized["generation_fingerprint"],
        "ready_unbound_receipt_fingerprint": normalized["ready_receipt_fingerprint"],
        "expected_revision": normalized["generation_revision"],
        "source_revision": normalized["source_revision"],
        "overlay_ref": normalized["overlay_ref"],
        "actor_ref": normalized["actor_ref"],
        "actor_generation_ref": normalized["actor_generation_ref"],
    }


def _insert(cursor: Any, normalized: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    policy = _policy_row(normalized)
    decision = _decision_row(normalized)
    cursor.execute(
        """
        INSERT INTO cerebro_assistant_overlay_policy_heads (
            tenant_ref,workspace_ref,principal_ref,consumer_ref,session_ref,
            policy_ref,policy_revision,current,revoked,owner_authorization_ref,
            allowed_role,source_revision
        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """,
        tuple(policy[k] for k in (
            "tenant_ref","workspace_ref","principal_ref","consumer_ref","session_ref",
            "policy_ref","policy_revision","current","revoked","owner_authorization_ref",
            "allowed_role","source_revision",
        )),
    )
    cursor.execute(
        """
        INSERT INTO cerebro_assistant_overlay_decision_heads (
            tenant_ref,workspace_ref,principal_ref,consumer_ref,session_ref,
            generation_ref,decision_ref,policy_ref,policy_revision,owner_revision,current,revoked,
            pre_role_fingerprint,ready_unbound_receipt_fingerprint,expected_revision,
            source_revision,overlay_ref,actor_ref,actor_generation_ref
        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """,
        tuple(decision[k] for k in (
            "tenant_ref","workspace_ref","principal_ref","consumer_ref","session_ref",
            "generation_ref","decision_ref","policy_ref","policy_revision","owner_revision",
            "current","revoked","pre_role_fingerprint","ready_unbound_receipt_fingerprint",
            "expected_revision","source_revision","overlay_ref","actor_ref","actor_generation_ref",
        )),
    )
    return policy, decision


def _read_pair_state(
    cursor: Any, normalized: dict[str, Any], *, lock: bool,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, str]:
    b = normalized["binding"]
    cursor.execute(
        """
        SELECT tenant_ref,workspace_ref,principal_ref,consumer_ref,session_ref,
               policy_ref,policy_revision,current,revoked,owner_authorization_ref,
               allowed_role,source_revision
          FROM cerebro_assistant_overlay_policy_heads
         WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s
           AND consumer_ref=%s AND session_ref=%s AND policy_ref=%s
        """ + (" FOR SHARE" if lock else ""),
        (b["tenant_ref"], b["workspace_ref"], b["principal_ref"], b["consumer_ref"],
         b["session_ref"], normalized["policy_ref"]),
    )
    policy = _row(cursor)
    cursor.execute(
        """
        SELECT tenant_ref,workspace_ref,principal_ref,consumer_ref,session_ref,
               generation_ref,decision_ref,policy_ref,policy_revision,owner_revision,current,revoked,
               pre_role_fingerprint,ready_unbound_receipt_fingerprint,expected_revision,
               source_revision,overlay_ref,actor_ref,actor_generation_ref
          FROM cerebro_assistant_overlay_decision_heads
         WHERE tenant_ref=%s AND workspace_ref=%s AND principal_ref=%s
           AND consumer_ref=%s AND session_ref=%s AND generation_ref=%s
        """ + (" FOR SHARE" if lock else ""),
        (b["tenant_ref"], b["workspace_ref"], b["principal_ref"], b["consumer_ref"],
         b["session_ref"], normalized["generation_ref"]),
    )
    decision = _row(cursor)
    if policy is None and decision is None:
        return None, None, "BOTH_ABSENT"
    if policy is None or decision is None:
        return policy, decision, "PARTIAL"
    if policy != _policy_row(normalized) or decision != _decision_row(normalized):
        return policy, decision, "MISMATCH"
    return policy, decision, "EXACT"


def _read_pair(
    cursor: Any, normalized: dict[str, Any], *, lock: bool,
) -> tuple[dict[str, Any], dict[str, Any]]:
    policy, decision, state = _read_pair_state(cursor, normalized, lock=lock)
    _require(state == "EXACT", "committed-pair-not-exact:" + state)
    assert policy is not None and decision is not None
    return policy, decision


def _public_receipt(
    normalized: dict[str, Any],
    *,
    result: str,
    committed: bool | None,
    retry_allowed: bool,
    policy: dict[str, Any] | None = None,
    decision: dict[str, Any] | None = None,
    error_code: str | None = None,
) -> dict[str, Any]:
    value: dict[str, Any] = {
        "schema": OUTPUT_SCHEMA,
        "result": result,
        "committed": committed,
        "retry_allowed": retry_allowed,
        "input_fingerprint": normalized["input_fingerprint"],
        "native_read_wrapper_fingerprint": normalized["native_read_wrapper_fingerprint"],
        "authenticated_binding_fingerprint": _sha(normalized["binding"]),
        "generation_ref": normalized["generation_ref"],
        "policy_ref": normalized["policy_ref"],
        "decision_ref": normalized["decision_ref"],
    }
    if error_code is not None:
        value["error_code"] = error_code
    if "connector_capture_provenance" in normalized:
        proof = normalized["connector_capture_provenance"]
        value["input_evidence"] = {
            "native_meta": normalized["native_meta_evidence"],
            "capture_sha256": proof["raw_sha256"],
            "owner_original_sha256": proof["authorization_sha256"],
            "source_tool": proof["source_tool"],
            "source_thread_ref": proof["source_thread_ref"],
            "source_call_ref": proof["source_call_ref"],
            "basis": proof["basis"],
            "exporter_attested": False,
            "native_caller_authority": "REQUIRES_ACTUAL_MATCH_AT_SUPPORTED_RESUME",
        }
    if policy is not None and decision is not None:
        value.update(
            policy_revision=policy["policy_revision"],
            policy_fingerprint=_sha(policy),
            owner_revision=decision["owner_revision"],
            decision_fingerprint=_sha(decision),
        )
    return value


def _safe_close(connection: Any) -> None:
    if connection is None:
        return
    try:
        connection.close()
    except BaseException:
        pass


def _safe_rollback_close(connection: Any) -> None:
    if connection is None:
        return
    try:
        connection.rollback()
    except BaseException:
        pass
    _safe_close(connection)


def execute(value: dict[str, Any], *, mode: str, connect=psycopg.connect) -> dict[str, Any]:
    """Run DRY_RUN, COMMIT, or RECONCILE with explicit post-commit semantics."""
    try:
        _require(mode in {"DRY_RUN", "COMMIT", "RECONCILE"}, "operator-mode-invalid")
        normalized = validate_input(value)
        dsn = os.environ.get("CEREBRO_MIGRATION_DATABASE_URL", "").strip()
        _require(bool(dsn), "CEREBRO_MIGRATION_DATABASE_URL-missing")
    except OwnerOperationError:
        raise OwnerOperationOutcome(
            "PRECOMMIT_INPUT_VALIDATION_FAILED", result="BLOCK_PRECOMMIT_NO_WRITE",
            committed=False, retry_allowed=True,
        ) from None

    if mode == "RECONCILE":
        connection = None
        try:
            connection = connect(dsn)
            with connection.cursor() as cursor:
                _begin_read_snapshot(cursor, normalized)
                _load_generation(cursor, normalized, lock=False)
                policy, decision, pair_state = _read_pair_state(cursor, normalized, lock=False)
            connection.rollback()
        except OwnerOperationError:
            _safe_rollback_close(connection)
            raise OwnerOperationOutcome(
                "RECONCILE_GENERATION_BASIS_FAILED", result="RECONCILE_FAILED_NO_RETRY",
                committed=None, retry_allowed=False,
            ) from None
        except BaseException:
            _safe_rollback_close(connection)
            raise OwnerOperationOutcome(
                "RECONCILE_PROVIDER_READ_FAILED", result="RECONCILE_FAILED_NO_RETRY",
                committed=None, retry_allowed=False,
            ) from None
        else:
            _safe_close(connection)
            if pair_state == "BOTH_ABSENT":
                return _public_receipt(
                    normalized, result="RECONCILE_PAIR_ABSENT_NO_RETRY",
                    committed=False, retry_allowed=False, error_code="RECONCILE_EXACT_PAIR_ABSENT",
                )
            if pair_state in {"PARTIAL", "MISMATCH"}:
                return _public_receipt(
                    normalized, result="RECONCILE_MISMATCH_NO_RETRY",
                    committed=None, retry_allowed=False,
                    error_code="RECONCILE_PARTIAL_OR_MISMATCH",
                )
            assert policy is not None and decision is not None
            out = _public_receipt(
                normalized, result="RECONCILE_COMMITTED_READBACK_PASS",
                committed=True, retry_allowed=False, policy=policy, decision=decision,
            )
            out["readback"] = "REPEATABLE_READ_READ_ONLY_SNAPSHOT_EXACT_MATCH"
            out["snapshot_boundary"] = (
                "EVIDENCE_AT_RECONCILE_TRANSACTION_SNAPSHOT;"
                "NATIVE_CURRENT_FENCE_REQUIRED_BEFORE_RESUME"
            )
            out["next"] = "resume_ready_unbound_assistant_overlay_ONCE_THEN_NATIVE_READBACK"
            return out

    # PRECOMMIT: everything before connection.commit() is safe to reject as no-write.
    connection = None
    try:
        connection = connect(dsn)
        with connection.cursor() as cursor:
            _begin_write_transaction(cursor, normalized)
            _load_generation(cursor, normalized, lock=True)
            _assert_absent(cursor, normalized)
            if mode == "DRY_RUN":
                connection.rollback()
                out = _public_receipt(
                    normalized, result="DRY_RUN_VALIDATED",
                    committed=False, retry_allowed=False,
                )
                out["authorization_ref"] = normalized["authorization_ref"]
                out["next"] = "HUMAN_FINAL_RUN_REQUIRED_BEFORE_--commit"
                _safe_close(connection)
                return out
            _insert(cursor, normalized)
            _read_pair(cursor, normalized, lock=True)
    except OwnerOperationError:
        _safe_rollback_close(connection)
        raise OwnerOperationOutcome(
            "PRECOMMIT_VALIDATION_FAILED", result="BLOCK_PRECOMMIT_NO_WRITE",
            committed=False, retry_allowed=True,
        ) from None
    except BaseException:
        _safe_rollback_close(connection)
        raise OwnerOperationOutcome(
            "PRECOMMIT_PROVIDER_FAILED", result="BLOCK_PRECOMMIT_NO_WRITE",
            committed=False, retry_allowed=True,
        ) from None

    # COMMIT ATTEMPT: once commit() is called, any exception is ambiguous and MUST NOT retry.
    try:
        connection.commit()
    except BaseException:
        _safe_close(connection)
        raise OwnerOperationOutcome(
            "COMMIT_OUTCOME_UNKNOWN", result="UNKNOWN_NO_RETRY",
            committed=None, retry_allowed=False,
        ) from None
    _safe_close(connection)

    # COMMIT returned success. A second connection must independently prove exact persisted state.
    readback_connection = None
    try:
        readback_connection = connect(dsn)
        with readback_connection.cursor() as cursor:
            _begin_read_snapshot(cursor, normalized)
            _load_generation(cursor, normalized, lock=False)
            policy, decision, pair_state = _read_pair_state(cursor, normalized, lock=False)
            _require(pair_state == "EXACT", "postcommit-pair-not-exact")
        readback_connection.rollback()
    except BaseException:
        _safe_rollback_close(readback_connection)
        raise OwnerOperationOutcome(
            "POSTCOMMIT_READBACK_FAILED", result="COMMITTED_READBACK_FAILED",
            committed=True, retry_allowed=False,
        ) from None
    _safe_close(readback_connection)

    out = _public_receipt(
        normalized, result="COMMITTED_READBACK_PASS",
        committed=True, retry_allowed=False, policy=policy, decision=decision,
    )
    out["readback"] = "REPEATABLE_READ_READ_ONLY_SNAPSHOT_EXACT_MATCH"
    out["snapshot_boundary"] = "EVIDENCE_AT_POSTCOMMIT_TRANSACTION_SNAPSHOT;NATIVE_CURRENT_FENCE_REQUIRED_BEFORE_RESUME"
    out["next"] = "resume_ready_unbound_assistant_overlay_ONCE_THEN_NATIVE_READBACK"
    return out


def write_receipt(result: dict[str, Any], path: Path = OUTPUT_PATH) -> None:
    path.write_bytes(_canonical(result) + b"\n")


def _stable_failure(exc: BaseException) -> dict[str, Any]:
    if isinstance(exc, OwnerOperationOutcome):
        return {
            "schema": OUTPUT_SCHEMA,
            "result": exc.result,
            "committed": exc.committed,
            "retry_allowed": exc.retry_allowed,
            "error_code": exc.code,
        }
    if isinstance(exc, OwnerOperationError):
        return {
            "schema": OUTPUT_SCHEMA,
            "result": "BLOCK_PRECOMMIT_NO_WRITE",
            "committed": False,
            "retry_allowed": True,
            "error_code": "INPUT_OR_PRECOMMIT_VALIDATION_FAILED",
        }
    return {
        "schema": OUTPUT_SCHEMA,
        "result": "BLOCK_PRECOMMIT_NO_WRITE",
        "committed": False,
        "retry_allowed": True,
        "error_code": "PRECOMMIT_UNCLASSIFIED_FAILURE",
    }


def _write_or_report_receipt(result: dict[str, Any]) -> tuple[dict[str, Any], int]:
    try:
        write_receipt(result)
        return result, 0
    except BaseException:
        committed = result.get("committed")
        if committed is True:
            fallback = copy.deepcopy(result)
            fallback["result"] = "COMMITTED_READBACK_PASS_RECEIPT_WRITE_FAILED"
            fallback["retry_allowed"] = False
            fallback["receipt_error_code"] = "RECEIPT_WRITE_FAILED_AFTER_COMMITTED_READBACK"
            return fallback, 3
        if committed is None or result.get("result") in {
            "UNKNOWN_NO_RETRY", "COMMITTED_READBACK_FAILED",
            "RECONCILE_FAILED_NO_RETRY", "RECONCILE_MISMATCH_NO_RETRY",
            "RECONCILE_BASIS_ABSENT_NO_RETRY",
        }:
            fallback = copy.deepcopy(result)
            fallback["retry_allowed"] = False
            fallback["receipt_error_code"] = "RECEIPT_WRITE_FAILED_NO_RETRY"
            return fallback, 3
        fallback = copy.deepcopy(result)
        fallback["receipt_error_code"] = "RECEIPT_WRITE_FAILED_PRECOMMIT"
        return fallback, 3


def main() -> int:
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--commit", action="store_true",
                       help="Persist the exact policy+decision pair. Never retry after UNKNOWN_NO_RETRY.")
    modes.add_argument("--reconcile", action="store_true",
                       help="Read-only reconciliation of the same immutable input after unknown outcome.")
    args = parser.parse_args()
    mode = "COMMIT" if args.commit else "RECONCILE" if args.reconcile else "DRY_RUN"
    try:
        value = load_input()
        result = execute(value, mode=mode)
    except BaseException as exc:
        result = _stable_failure(exc)
        shown, _ = _write_or_report_receipt(result)
        print(json.dumps(shown, sort_keys=True, separators=(",", ":"), ensure_ascii=False))
        return 2 if shown.get("retry_allowed") is not False else 4
    shown, receipt_status = _write_or_report_receipt(result)
    print(json.dumps(shown, sort_keys=True, separators=(",", ":"), ensure_ascii=False))
    return receipt_status


if __name__ == "__main__":
    raise SystemExit(main())
