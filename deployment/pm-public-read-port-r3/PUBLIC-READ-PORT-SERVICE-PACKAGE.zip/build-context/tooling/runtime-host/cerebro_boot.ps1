Set-StrictMode -Version Latest

function Get-CerebroBootSha256Text {
    param(
        [Parameter(Mandatory)]
        [string]$Text
    )

    $sha = [Security.Cryptography.SHA256]::Create()

    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Text)

        return (
            [BitConverter]::ToString(
                $sha.ComputeHash($bytes)
            )
        ).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
    }
}

function Get-CerebroBootExecutionValue {
    param(
        [Parameter(Mandatory)]
        [string]$Roadmap,

        [Parameter(Mandatory)]
        [ValidateSet('current', 'next')]
        [string]$Section,

        [Parameter(Mandatory)]
        [string]$Name
    )

    $lines = $Roadmap -split "\r?\n"
    $executionFound = $false
    $sectionFound = $false
    $sectionLine = ('    {0}:' -f $Section)
    $namePrefix = ('      {0}:' -f $Name)

    foreach ($line in $lines) {
        if (-not $executionFound) {
            if ($line -eq '  execution:') {
                $executionFound = $true
            }
            continue
        }

        if (-not $sectionFound) {
            if ($line -eq $sectionLine) {
                $sectionFound = $true
                continue
            }
            if ($line -match '^\s{0,2}\S') {
                break
            }
            continue
        }

        if ($line.StartsWith($namePrefix)) {
            $raw = $line.Substring($namePrefix.Length).Trim()
            if ($raw -match '^"(?<value>[^"]*)"$') {
                return $Matches['value']
            }
            $comment = $raw.IndexOf('#')
            if ($comment -ge 0) {
                $raw = $raw.Substring(0, $comment).Trim()
            }
            if (-not [string]::IsNullOrWhiteSpace($raw)) {
                return $raw
            }
        }

        if ($line -match '^\s{0,4}\S') {
            break
        }
    }

    if (-not $sectionFound) {
        throw "BOOT_EXECUTION_SECTION_NOT_FOUND:$Section"
    }
    throw "BOOT_EXECUTION_VALUE_NOT_FOUND:$Section`:$Name"
}

function Get-CerebroBootRoadmapStatus {
    param(
        [Parameter(Mandatory)]
        [string]$Roadmap
    )

    $match = [regex]::Match(
        $Roadmap,
        '(?m)^  status:\s*(?:"([^"]*)"|([^\r\n#]+))\s*$'
    )

    if (-not $match.Success) {
        throw 'BOOT_ROADMAP_STATUS_NOT_FOUND'
    }

    if ($match.Groups[1].Success) {
        return $match.Groups[1].Value
    }

    return $match.Groups[2].Value.Trim()
}

function Test-CerebroBootTerminalNoContinuation {
    param(
        [Parameter(Mandatory)]
        [string]$Roadmap
    )

    $status = Get-CerebroBootRoadmapStatus -Roadmap $Roadmap
    $currentIsNull = [regex]::IsMatch(
        $Roadmap,
        '(?m)^    current:\s*null\s*(?:#.*)?$'
    )
    $nextIsNull = [regex]::IsMatch(
        $Roadmap,
        '(?m)^    next:\s*null\s*(?:#.*)?$'
    )

    if ($status -eq 'COMPLETED') {
        if ($currentIsNull -and $nextIsNull) {
            return $true
        }

        throw 'BOOT_COMPLETED_EXECUTION_CONFLICT'
    }

    return $false
}

function Test-CerebroBootRequiredTokens {
    param(
        [Parameter(Mandatory)]
        [string]$Path,

        [Parameter(Mandatory)]
        [string[]]$Tokens,

        [Parameter(Mandatory)]
        [string]$FailurePrefix
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "$FailurePrefix`_FILE_MISSING:$Path"
    }

    $content = [IO.File]::ReadAllText($Path)

    foreach ($token in $Tokens) {
        if (-not $content.Contains($token)) {
            throw "$FailurePrefix`_TOKEN_MISSING:$token"
        }
    }

    return $content
}

function Write-CerebroBootRuntimeState {
    param(
        [Parameter(Mandatory)]
        [string]$Path,

        [Parameter(Mandatory)]
        [object]$RuntimeState
    )

    $directory = Split-Path -Parent $Path

    [IO.Directory]::CreateDirectory($directory) |
        Out-Null

    $temporary = Join-Path `
        $directory `
        (
            '.CEREBRO_RUNTIME_STATE_v1.tmp-' +
            [guid]::NewGuid().ToString('N') +
            '.json'
        )

    try {
        $json = $RuntimeState |
            ConvertTo-Json -Depth 16

        [IO.File]::WriteAllText(
            $temporary,
            $json + "`n",
            [Text.UTF8Encoding]::new($false)
        )

        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            $backup = (
                $Path +
                '.backup-' +
                (Get-Date -Format 'yyyyMMdd-HHmmss')
            )

            [IO.File]::Replace(
                $temporary,
                $Path,
                $backup,
                $true
            )
        }
        else {
            [IO.File]::Move(
                $temporary,
                $Path
            )
        }
    }
    finally {
        if (Test-Path -LiteralPath $temporary) {
            Remove-Item `
                -LiteralPath $temporary `
                -Force `
                -ErrorAction SilentlyContinue
        }
    }
}

function Invoke-CerebroFreshWorldOperationalPulse {
    [CmdletBinding()]
    param(
        [scriptblock]$ProviderTailReader,
        [string]$ActorRole = 'PROJECT_MANAGER',
        [string]$ObjectiveRef = 'BOOT'
    )

    if ($null -eq $ProviderTailReader) {
        return [ordered]@{
            schema = 'cerebro-operational-pulse-consumption/v1'
            stage = 'FRESH_WORLD'
            result = 'UNKNOWN_HOLD'
            currentness = 'UNKNOWN'
            exact_blocker = 'PROVIDER_TAIL_READER_UNBOUND'
        }
    }

    $observed = & $ProviderTailReader ([ordered]@{
        stage = 'FRESH_WORLD'
        actor_role = $ActorRole
        objective_ref = $ObjectiveRef
    })
    if ($null -eq $observed -or $null -eq $observed.control -or $null -eq $observed.protobox) {
        return [ordered]@{
            schema = 'cerebro-operational-pulse-consumption/v1'
            stage = 'FRESH_WORLD'
            result = 'UNKNOWN_HOLD'
            currentness = 'UNKNOWN'
            exact_blocker = 'ADMINPULSE_BOTH_PROVIDER_TAILS_REQUIRED'
        }
    }

    $controlCurrent = [string]$observed.control.currentness
    $protoCurrent = [string]$observed.protobox.currentness
    $exact = (
        -not [string]::IsNullOrWhiteSpace([string]$observed.control.carrier_ref) -and
        $null -ne $observed.control.provider_revision -and
        -not [string]::IsNullOrWhiteSpace([string]$observed.control.event_frontier) -and
        -not [string]::IsNullOrWhiteSpace([string]$observed.protobox.channel_ref) -and
        $null -ne $observed.protobox.observed_revision
    )
    if (-not $exact -or $controlCurrent -ne 'CURRENT' -or $protoCurrent -ne 'CURRENT') {
        return [ordered]@{
            schema = 'cerebro-operational-pulse-consumption/v1'
            stage = 'FRESH_WORLD'
            result = 'UNKNOWN_HOLD'
            currentness = $(if ('STALE' -in @($controlCurrent, $protoCurrent)) { 'STALE' } else { 'UNKNOWN' })
            exact_blocker = 'ADMINPULSE_CURRENT_EXACT_WATERMARKS_REQUIRED'
        }
    }

    return [ordered]@{
        schema = 'cerebro-operational-pulse-consumption/v1'
        stage = 'FRESH_WORLD'
        result = 'PASS'
        currentness = 'CURRENT'
        watermarks = [ordered]@{
            control = [ordered]@{
                carrier_ref = [string]$observed.control.carrier_ref
                provider_revision = $observed.control.provider_revision
                event_frontier = [string]$observed.control.event_frontier
            }
            protobox = [ordered]@{
                channel_ref = [string]$observed.protobox.channel_ref
                observed_revision = $observed.protobox.observed_revision
            }
        }
    }
}

function ConvertTo-CerebroCanonicalObject {
    param([Parameter(Mandatory)][AllowNull()]$Value)
    if ($Value -is [Collections.IDictionary]) {
        $ordered = [ordered]@{}
        foreach ($key in @($Value.Keys | Sort-Object)) {
            if ([string]$key -ne 'permit_fingerprint') {
                $ordered[[string]$key] = ConvertTo-CerebroCanonicalObject $Value[$key]
            }
        }
        return $ordered
    }
    if ($Value -is [pscustomobject]) {
        $ordered = [ordered]@{}
        foreach ($property in @($Value.PSObject.Properties | Sort-Object Name)) {
            if ($property.Name -ne 'permit_fingerprint') {
                $ordered[$property.Name] = ConvertTo-CerebroCanonicalObject $property.Value
            }
        }
        return $ordered
    }
    if ($Value -is [Collections.IEnumerable] -and $Value -isnot [string]) {
        return @($Value | ForEach-Object { ConvertTo-CerebroCanonicalObject $_ })
    }
    return $Value
}

function Test-CerebroPrincipalSuccessionPermit {
    [CmdletBinding()]
    param(
        [scriptblock]$PermitReader,
        [scriptblock]$MachineDiaryEffectVerifier,
        [object]$ObservedEventFrontier,
        [string]$PredecessorGenerationId,
        [string]$SuccessorGenerationId,
        [string]$PermitRef,
        [string]$PermitFingerprint,
        [Parameter(Mandatory)][string]$SourceHead
    )
    function Assert-PermitFields($Value, [string[]]$Required, [string[]]$Optional = @()) {
        if ($Value -is [Collections.IDictionary]) { $keys = @($Value.Keys) }
        elseif ($Value -is [pscustomobject]) { $keys = @($Value.PSObject.Properties.Name) }
        else { throw 'PRINCIPAL_SUCCESSION_OBJECT_REQUIRED' }
        foreach ($key in $Required) {
            if ($keys -cnotcontains $key) { throw ('PRINCIPAL_SUCCESSION_FIELD_REQUIRED:' + $key) }
        }
        foreach ($key in $keys) {
            if ($Required -cnotcontains $key -and $Optional -cnotcontains $key) {
                throw 'PRINCIPAL_SUCCESSION_PRIVATE_CONTENT_OR_LOCATOR_PROHIBITED'
            }
        }
    }
    function Assert-PermitId($Value) {
        if ($Value -isnot [string] -or $Value -cnotmatch '^[A-Za-z0-9][A-Za-z0-9_.@-]{0,255}\z' -or
            $Value -match '(?i)diary|stambok') {
            throw 'PRINCIPAL_SUCCESSION_PRIVATE_CONTENT_OR_LOCATOR_PROHIBITED'
        }
    }
    function Assert-PermitInteger($Value) {
        if (($Value -isnot [int] -and $Value -isnot [long] -and $Value -isnot [bigint]) -or $Value -lt 0) {
            throw 'PRINCIPAL_SUCCESSION_NONNEGATIVE_INTEGER_REQUIRED'
        }
    }
    function Assert-PermitReceipt($Value, [bool]$PassRequired = $false) {
        $fields = @('receipt_ref','receipt_fingerprint','durable','readback_verified')
        if ($PassRequired) { $fields += 'result' }
        Assert-PermitFields $Value $fields
        Assert-PermitId $Value.receipt_ref
        if ($Value.receipt_fingerprint -isnot [string] -or $Value.receipt_fingerprint -cnotmatch '^[0-9a-f]{64}$' -or
            $Value.durable -isnot [bool] -or $Value.durable -ne $true -or
            $Value.readback_verified -isnot [bool] -or $Value.readback_verified -ne $true) {
            throw 'PRINCIPAL_SUCCESSION_EVIDENCE_INCOMPLETE'
        }
        if ($PassRequired -and $Value.result -cne 'PASS') {
            throw 'PRINCIPAL_SUCCESSION_COLD_SUCCESSOR_CANARY_NONPASS'
        }
    }
    $requested = @(@(
        $PredecessorGenerationId, $SuccessorGenerationId, $PermitRef, $PermitFingerprint
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($requested.Count -eq 0) {
        return [ordered]@{ schema='cerebro-principal-succession-verification/v1'; applicable=$false; result='PASS_NON_PRINCIPAL_UNCHANGED' }
    }
    if ($requested.Count -ne 4 -or $null -eq $PermitReader) {
        throw 'PRINCIPAL_SUCCESSION_BOUND_READER_AND_EXACT_BINDING_REQUIRED'
    }
    Assert-PermitInteger $ObservedEventFrontier
    $permit = & $PermitReader ([ordered]@{
        permit_ref=$PermitRef; predecessor_generation_id=$PredecessorGenerationId
        successor_generation_id=$SuccessorGenerationId; source_head=$SourceHead
    })
    Assert-PermitFields $permit @('schema','permit_id','predecessor_generation_id','successor_generation_id',
        'source_head','currentness','provider_revision','covered_through_frontier','principal_continuity_baseline',
        'lived_continuity','evidence','post_state_readback_verified','permit_fingerprint')
    if ($permit.schema -cne 'cerebro-principal-succession-permit/v1') {
        throw 'PRINCIPAL_SUCCESSION_PERMIT_SCHEMA_REQUIRED'
    }
    foreach ($value in @($permit.permit_id,$permit.predecessor_generation_id,$permit.successor_generation_id)) {
        Assert-PermitId $value
    }
    if ($permit.permit_id -cne $PermitRef -or $permit.predecessor_generation_id -cne $PredecessorGenerationId -or
        $permit.successor_generation_id -cne $SuccessorGenerationId) {
        throw 'PRINCIPAL_SUCCESSION_PERMIT_BINDING_MISMATCH'
    }
    if ($permit.currentness -cne 'CURRENT' -or $permit.source_head -cne $SourceHead -or
        $permit.source_head -isnot [string] -or $permit.source_head -cnotmatch '^[0-9a-f]{40}$' -or
        $permit.post_state_readback_verified -isnot [bool] -or $permit.post_state_readback_verified -ne $true) {
        throw 'PRINCIPAL_SUCCESSION_PERMIT_CURRENT_READBACK_REQUIRED'
    }
    Assert-PermitInteger $permit.provider_revision
    Assert-PermitInteger $permit.covered_through_frontier
    if ($permit.covered_through_frontier -lt $ObservedEventFrontier) {
        throw 'PRINCIPAL_SUCCESSION_PERMIT_FRONTIER_BEHIND_OBSERVED'
    }
    $baseline = $permit.principal_continuity_baseline
    Assert-PermitFields $baseline @('schema','generation_ref','source_head','ready_epoch','currentness',
        'provider_revision','covered_through_frontier','diary_bound','living_ledger_baseline',
        'livspuls_baseline','post_state_readback_verified','baseline_fingerprint')
    if ($baseline.schema -cne 'cerebro-principal-continuity-baseline/v1') {
        throw 'PRINCIPAL_CONTINUITY_BASELINE_SCHEMA_REQUIRED'
    }
    Assert-PermitId $baseline.generation_ref
    Assert-PermitInteger $baseline.ready_epoch
    Assert-PermitInteger $baseline.provider_revision
    Assert-PermitInteger $baseline.covered_through_frontier
    if ($baseline.ready_epoch -lt 1) {
        throw 'PRINCIPAL_CONTINUITY_BASELINE_READY_EPOCH_REQUIRED'
    }
    if ($baseline.generation_ref -cne $SuccessorGenerationId) {
        throw 'PRINCIPAL_CONTINUITY_BASELINE_SUCCESSOR_GENERATION_MISMATCH'
    }
    if ($baseline.source_head -cne $SourceHead -or $baseline.source_head -isnot [string] -or
        $baseline.source_head -cnotmatch '^[0-9a-f]{40}$' -or $baseline.currentness -cne 'CURRENT' -or
        $baseline.post_state_readback_verified -isnot [bool] -or
        $baseline.post_state_readback_verified -ne $true) {
        throw 'PRINCIPAL_CONTINUITY_BASELINE_CURRENT_READBACK_REQUIRED'
    }
    if ($baseline.provider_revision -ne $permit.provider_revision -or
        $baseline.covered_through_frontier -ne $permit.covered_through_frontier -or
        $baseline.covered_through_frontier -lt $ObservedEventFrontier) {
        throw 'PRINCIPAL_CONTINUITY_BASELINE_PERMIT_CURRENTNESS_MISMATCH'
    }
    foreach ($name in @('diary_bound','living_ledger_baseline','livspuls_baseline')) {
        Assert-PermitReceipt $baseline.$name
    }
    $baselineSubject = [ordered]@{}
    if ($baseline -is [Collections.IDictionary]) {
        foreach ($key in @($baseline.Keys | Sort-Object)) {
            if ([string]$key -ne 'baseline_fingerprint') {
                $baselineSubject[[string]$key] = ConvertTo-CerebroCanonicalObject $baseline[$key]
            }
        }
    } else {
        foreach ($property in @($baseline.PSObject.Properties | Sort-Object Name)) {
            if ($property.Name -ne 'baseline_fingerprint') {
                $baselineSubject[$property.Name] = ConvertTo-CerebroCanonicalObject $property.Value
            }
        }
    }
    $actualBaselineFingerprint = Get-CerebroBootSha256Text (
        $baselineSubject | ConvertTo-Json -Compress -Depth 32
    )
    if ($baseline.baseline_fingerprint -isnot [string] -or
        $baseline.baseline_fingerprint -cnotmatch '^[0-9a-f]{64}$' -or
        $baseline.baseline_fingerprint -cne $actualBaselineFingerprint) {
        throw 'PRINCIPAL_CONTINUITY_BASELINE_FINGERPRINT_MISMATCH'
    }
    $canonical = ConvertTo-CerebroCanonicalObject $permit
    $actualFingerprint = Get-CerebroBootSha256Text ($canonical | ConvertTo-Json -Compress -Depth 32)
    if ($PermitFingerprint -cnotmatch '^[0-9a-f]{64}$' -or
        $permit.permit_fingerprint -cne $PermitFingerprint -or $actualFingerprint -cne $PermitFingerprint) {
        throw 'PRINCIPAL_SUCCESSION_PERMIT_FINGERPRINT_MISMATCH'
    }
    $lived = $permit.lived_continuity
    Assert-PermitFields $lived @('event_id','event_fingerprint','qualification','debt_state') @('machine_diary_effect_receipt')
    Assert-PermitId $lived.event_id
    if ($lived.event_fingerprint -isnot [string] -or $lived.event_fingerprint -cnotmatch '^[0-9a-f]{64}$' -or
        $lived.debt_state -cne 'CLEAR' -or $lived.qualification -cnotin @('CAPTURE','NO_CAPTURE')) {
        throw 'PRINCIPAL_SUCCESSION_LIVED_CONTINUITY_DEBT_BLOCK'
    }
    $hasDiary = if ($lived -is [Collections.IDictionary]) {
        @($lived.Keys) -ccontains 'machine_diary_effect_receipt'
    } else { $null -ne $lived.PSObject.Properties['machine_diary_effect_receipt'] }
    if ($lived.qualification -ceq 'CAPTURE') {
        if (-not $hasDiary -or $null -eq $MachineDiaryEffectVerifier) {
            throw 'PRINCIPAL_SUCCESSION_BOUND_MACHINE_DIARY_EFFECT_VERIFIER_REQUIRED'
        }
        Assert-PermitReceipt $lived.machine_diary_effect_receipt
        $verifiedDiary = & $MachineDiaryEffectVerifier ([ordered]@{
            event=$lived; receipt=$lived.machine_diary_effect_receipt
        })
        if ($null -eq $verifiedDiary -or $verifiedDiary.result -cne 'PASS') {
            throw 'PRINCIPAL_SUCCESSION_MACHINE_DIARY_EFFECT_VERIFICATION_NONPASS'
        }
    } elseif ($hasDiary) {
        throw 'PRINCIPAL_SUCCESSION_MACHINE_DIARY_EFFECT_MISMATCH'
    }
    $names = @('living_ledger','livspuls','etterklang_review','stambok_seal','gjenklang_publication',
        'human_readability','predecessor_closeout','cold_successor_canary')
    Assert-PermitFields $permit.evidence $names
    foreach ($name in $names) {
        Assert-PermitReceipt $permit.evidence.$name ($name -ceq 'cold_successor_canary')
    }
    return [ordered]@{
        schema='cerebro-principal-succession-verification/v1'; applicable=$true; result='PASS'
        permit_ref=$PermitRef; permit_fingerprint=$PermitFingerprint
        provider_revision=$permit.provider_revision; post_state_readback_verified=$true
        covered_through_frontier=$permit.covered_through_frontier
        ready_epoch=$baseline.ready_epoch
        continuity_baseline_fingerprint=$baseline.baseline_fingerprint
    }
}

function Resolve-CerebroCivilizationMethod {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SourceRoot,
        [Parameter(Mandatory)][string]$SourceHead,
        [Parameter(Mandatory)][string]$ActorRole
    )
    if ($SourceHead -cnotmatch '^[0-9a-f]{40}$' -or $ActorRole -cnotmatch '^[A-Z][A-Z0-9_]{0,63}$') {
        throw 'CIVILIZATION_METHOD_EXACT_SOURCE_AND_ROLE_REQUIRED'
    }
    $head = @(& git -C $SourceRoot rev-parse HEAD)
    if ($LASTEXITCODE -ne 0 -or $head.Count -ne 1 -or $head[0] -cne $SourceHead) {
        throw 'CIVILIZATION_METHOD_STALE_SOURCE'
    }
    function Get-PinnedMethodFile([string]$RelativePath) {
        $path = Join-Path $SourceRoot $RelativePath
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw ('CIVILIZATION_METHOD_FILE_MISSING:' + $RelativePath)
        }
        $blob = @(& git -C $SourceRoot rev-parse ($SourceHead + ':' + $RelativePath))
        if ($LASTEXITCODE -ne 0 -or $blob.Count -ne 1 -or $blob[0] -cnotmatch '^[0-9a-f]{40}$') {
            throw 'CIVILIZATION_METHOD_PINNED_BLOB_REQUIRED'
        }
        $actual = @(& git -C $SourceRoot hash-object --no-filters -- $path)
        if ($LASTEXITCODE -ne 0 -or $actual.Count -ne 1 -or $actual[0] -cne $blob[0]) {
            throw ('CIVILIZATION_METHOD_SOURCE_BLOB_MISMATCH:' + $RelativePath)
        }
        return (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
    }
    $owner = 'standards/boot-critical-path-architecture.yaml'
    $ownerHash = Get-PinnedMethodFile $owner
    $text = [IO.File]::ReadAllText((Join-Path $SourceRoot $owner))
    $owners = [regex]::Matches($text, '(?m)^  current_civilization_method_profile:\s*([^\r\n]+)$')
    if ($owners.Count -ne 1) { throw 'CIVILIZATION_METHOD_SINGLE_OWNER_REQUIRED' }
    $profileText = $owners[0].Groups[1].Value
    $profile = $profileText | ConvertFrom-Json
    $keys = @('id','version','authority','durable_method','contract_refs')
    if (@($profile.PSObject.Properties).Count -ne $keys.Count) {
        throw 'CIVILIZATION_METHOD_PRIVATE_OR_EXTRA_FIELD'
    }
    foreach ($key in $keys) {
        if ($null -eq $profile.PSObject.Properties[$key] -or
            [regex]::Matches($profileText, ('"' + $key + '"\s*:')).Count -ne 1) {
            throw 'CIVILIZATION_METHOD_EXACT_FIELDS_REQUIRED'
        }
    }
    if ($profile.id -cne 'CURRENT_CIVILIZATION_METHOD_PROFILE' -or
        $profile.version -isnot [string] -or $profile.version -cne '1.0' -or
        $profile.authority -cne 'NONE') {
        throw 'CIVILIZATION_METHOD_ID_VERSION_AUTHORITY_INVALID'
    }
    $methods = @('CURRENTNESS_FIRST','METHOD_NE_AUTHORITY','NO_LIVE_STATE_INHERITANCE',
        'VERIFY_LOAD_CONSUME_READBACK','TASK_SEMANTICS_ON_DEMAND')
    $refs = @('mcp/constitution.yaml','mcp/boot-architecture-control.yaml',
        'engines/presentation/component.yaml','engines/presentation/rules.yaml')
    # A closed durable vocabulary prevents task/private data hiding in free text.
    if (($profile.durable_method | ConvertTo-Json -Compress) -cne ($methods | ConvertTo-Json -Compress) -or
        ($profile.contract_refs | ConvertTo-Json -Compress) -cne ($refs | ConvertTo-Json -Compress)) {
        throw 'CIVILIZATION_METHOD_DURABLE_CONTRACT_REQUIRED'
    }
    $material = @($owner + '|' + $ownerHash)
    foreach ($ref in $refs) { $material += $ref + '|' + (Get-PinnedMethodFile $ref) }
    $fingerprint = Get-CerebroBootSha256Text (
        @($profile.id, $profile.version, $SourceHead, ($methods -join '|'), ($material -join '|')) -join '|'
    )
    $current = [ordered]@{
        id=$profile.id; version=$profile.version; source_head=$SourceHead; fingerprint=$fingerprint
        authority='NONE'; durable_method=$methods; contract_refs=$refs; verified=$true; loaded=$true
    }
    $projection = [ordered]@{
        id='ROLE_METHOD_PROJECTION'; role=$ActorRole; source_head=$SourceHead
        method_profile_fingerprint=$fingerprint; durable_method=$methods; authority='NONE'
    }
    $projection.fingerprint = Get-CerebroBootSha256Text ($projection | ConvertTo-Json -Compress -Depth 8)
    return [ordered]@{ method_profile=$current; role_method_projection=$projection }
}

function New-CerebroAwakeningReceipt {
    param(
        [Parameter(Mandatory)][object]$Binding,
        [Parameter(Mandatory)][string]$SourceRoot,
        [Parameter(Mandatory)][string]$SourceHead,
        [Parameter(Mandatory)][string]$ActorRole
    )
    $fresh = Resolve-CerebroCivilizationMethod -SourceRoot $SourceRoot -SourceHead $SourceHead -ActorRole $ActorRole
    if (($Binding | ConvertTo-Json -Compress -Depth 12) -cne ($fresh | ConvertTo-Json -Compress -Depth 12)) {
        throw 'CIVILIZATION_METHOD_BINDING_MISMATCH'
    }
    $receipt = [ordered]@{
        kind='AWAKENING_RECEIPT'; source_head=$SourceHead
        method_profile=$fresh.method_profile; role_method_projection=$fresh.role_method_projection
        activated=$true; consumed=$true
    }
    $receipt.fingerprint = Get-CerebroBootSha256Text ($receipt | ConvertTo-Json -Compress -Depth 12)
    return $receipt
}

function Test-CerebroPreRoleReadyUnbound {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$PreRoleState,
        [Parameter(Mandatory)][string]$SourceRoot,
        [Parameter(Mandatory)][string]$SourceHead
    )
    if ($PreRoleState.schema -cne 'cerebro-pre-role-generation/v1' -or
        $PreRoleState.lifecycle -cne 'READY_UNBOUND' -or
        $PreRoleState.source_revision -cne $SourceHead) {
        throw 'PRE_ROLE_READY_UNBOUND_CURRENT_STATE_REQUIRED'
    }
    if ($PreRoleState.authority_envelope.state -cne 'UNBOUND' -or
        $null -ne $PreRoleState.authority_envelope.role -or
        $PreRoleState.authority_envelope.grants_live_authority -ne $false -or
        $PreRoleState.authority_envelope.grants_claim -ne $false -or
        $PreRoleState.authority_envelope.grants_scheduler_authority -ne $false) {
        throw 'PRE_ROLE_UNBOUND_AUTHORITY_ENVELOPE_REQUIRED'
    }
    if ($null -ne $PreRoleState.identity_envelope.predecessor_generation_ref -or
        $PreRoleState.identity_envelope.predecessor_live_state_inherited -ne $false -or
        $PreRoleState.identity_envelope.predecessor_claims_inherited -ne $false -or
        $PreRoleState.identity_envelope.private_state_inherited -ne $false) {
        throw 'PRE_ROLE_FRESH_WORLD_ZERO_INHERITANCE_REQUIRED'
    }
    $method = Resolve-CerebroCivilizationMethod -SourceRoot $SourceRoot -SourceHead $SourceHead -ActorRole 'PRE_ROLE_UNBOUND'
    if ($PreRoleState.civilization_method_attestation.method_fingerprint -cne
        $method.method_profile.fingerprint -or
        $PreRoleState.civilization_method_attestation.currentness -cne 'CURRENT' -or
        $PreRoleState.civilization_method_attestation.attested -ne $true) {
        throw 'PRE_ROLE_CURRENT_CIVILIZATION_METHOD_ATTESTATION_REQUIRED'
    }
    if ($PreRoleState.fresh_world.currentness -cne 'CURRENT' -or
        $PreRoleState.fresh_world.verified -ne $true -or
        $PreRoleState.fresh_world.source_revision -cne $SourceHead) {
        throw 'PRE_ROLE_FRESH_WORLD_CURRENTNESS_REQUIRED'
    }
    $canaries = @($PreRoleState.generic_capability_canaries)
    if ($canaries.Count -lt 1 -or @($canaries | Where-Object result -cne 'PASS').Count -ne 0) {
        throw 'PRE_ROLE_GENERIC_CAPABILITY_CANARIES_PASS_REQUIRED'
    }
    $receipt = $PreRoleState.ready_unbound_receipt
    if ($null -eq $receipt -or $receipt.schema -cne 'cerebro-ready-unbound-receipt/v1' -or
        $receipt.generation_ref -cne $PreRoleState.generation_ref -or
        $receipt.source_revision -cne $SourceHead -or
        $receipt.method_fingerprint -cne $method.method_profile.fingerprint -or
        $receipt.durable -ne $true -or $receipt.post_state_readback_verified -ne $true) {
        throw 'PRE_ROLE_READY_UNBOUND_RECEIPT_REQUIRED'
    }
    return [ordered]@{
        result='PASS'; lifecycle='READY_UNBOUND'; role=$null; authority='UNBOUND'
        generation_ref=$PreRoleState.generation_ref; source_head=$SourceHead
        method_profile_fingerprint=$method.method_profile.fingerprint
        canary_count=$canaries.Count; ready_unbound_receipt_ref=$receipt.receipt_ref
        post_state_readback_verified=$true
    }
}

function Test-CerebroAwakeningReadback {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][object]$RuntimeState,
        [Parameter(Mandatory)][string]$SourceRoot,
        [Parameter(Mandatory)][string]$SourceHead,
        [Parameter(Mandatory)][string]$ActorRole
    )
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw 'AWAKENING_PERSISTED_READBACK_MISSING'
    }
    $actualText = [IO.File]::ReadAllText($Path)
    $expectedText = ($RuntimeState | ConvertTo-Json -Depth 16) + "`n"
    $persistedFingerprint = Get-CerebroBootSha256Text $actualText
    if ($persistedFingerprint -cne (Get-CerebroBootSha256Text $expectedText)) {
        throw 'AWAKENING_PERSISTED_STATE_MISMATCH'
    }
    $persisted = $actualText | ConvertFrom-Json
    $binding = Resolve-CerebroCivilizationMethod -SourceRoot $SourceRoot -SourceHead $SourceHead -ActorRole $ActorRole
    $expectedReceipt = New-CerebroAwakeningReceipt -Binding $binding -SourceRoot $SourceRoot -SourceHead $SourceHead -ActorRole $ActorRole
    if (($persisted.runtime.awakening_receipt | ConvertTo-Json -Compress -Depth 12) -cne
        ($expectedReceipt | ConvertTo-Json -Compress -Depth 12)) {
        throw 'AWAKENING_CONSUMPTION_READBACK_MISMATCH'
    }
    return [ordered]@{
        result='PASS'; currentness='CURRENT'; persisted_state_fingerprint=$persistedFingerprint
        method_profile_fingerprint=$binding.method_profile.fingerprint
        projection_fingerprint=$binding.role_method_projection.fingerprint
        receipt_fingerprint=$expectedReceipt.fingerprint
    }
}

function Invoke-CerebroBootCore {
    [CmdletBinding()]
    param(
        [string]$WorkingSourcePath =
            'D:\Cerebro\Source\Cerebro_Source_v1.0',

        [string]$Remote = 'origin',

        [string]$Branch = 'main',

        [string]$BootEngineUrl =
            'https://raw.githubusercontent.com/morgul-tech/B/main/BootEngine',

        [string]$HandoffPath =
            'D:\Cerebro\Run\handoff\CEREBRO_SESSION_HANDOFF_v1.json',

        [string]$RuntimeStatePath =
            'D:\Cerebro\Run\State\Active\CEREBRO_BOOTSTRAP_STATE_v1.json',

        [scriptblock]$OperationalPulseReader,

        [string]$OperationalPulseActorRole = 'PROJECT_MANAGER',

        [string]$OperationalPulseObjectiveRef = 'BOOT',

        [scriptblock]$PrincipalSuccessionPermitReader,

        [scriptblock]$PrincipalMachineDiaryEffectVerifier,

        [string]$PredecessorPrincipalGenerationId,

        [string]$PrincipalSuccessorGenerationId,

        [string]$PrincipalSuccessionPermitRef,

        [string]$PrincipalSuccessionPermitFingerprint,

        [switch]$SkipHandoff
    )

    $ErrorActionPreference = 'Stop'

    $bootState = 'IDLE'
    $failureStage = 'NONE'
    $failureCode = 'NONE'

    $runtimeProfile =
        'cerebro-controlled-session/v0.1'

    $bootEngineHash = $null
    $localCommit = $null
    $authoritativeCommit = $null
    $alignmentState = $null
    $handoffState = 'NONE'
    $handoffId = $null
    $resumeReceipt = $null
    $currentPatch = $null
    $nextPatch = $null
    $canonicalCommand = $null

    try {
        $bootState = 'FETCHING'
        $failureStage = 'BOOTENGINE_FETCH'

        try {
            $bootResponse = Invoke-WebRequest `
                -Uri $BootEngineUrl `
                -UseBasicParsing `
                -TimeoutSec 30
        }
        catch {
            throw (
                'BOOTENGINE_FETCH_FAILED:' +
                $_.Exception.Message
            )
        }

        if ($bootResponse.StatusCode -ne 200) {
            throw (
                'BOOTENGINE_HTTP_FAILURE:' +
                $bootResponse.StatusCode
            )
        }

        $bootEngine = [string]$bootResponse.Content

        if ([string]::IsNullOrWhiteSpace($bootEngine)) {
            throw 'BOOTENGINE_EMPTY'
        }

        foreach ($token in @(
            'BOOTSTRAP ENGINE',
            'Configuration := IMMUTABLE',
            'CurrentMaster.Repository := morgul-tech/Cerebro-Source-1.0',
            'CurrentMaster.Branch := main',
            'CurrentMaster.Path := cerebro.yaml',
            'Command.NaturalLanguageAlias := boot cerebro',
            'Authority.First := github:morgul-tech/Cerebro-Source-1.0/main/cerebro.yaml',
            'FilenameMarker.CURRENT.Authority := NONE',
            'StaleDerivedState.Action := REJECT_INPUT_CONTINUE_CURRENT_SOURCE',
            'OperationalClaim.Requires := ACTIVE_CONTROL_TRANSFERRED_RECEIPT_AT_CURRENT_SOURCE_COMMIT',
            'IDLE',
            'FETCHING',
            'VERIFYING',
            'ANALYZING',
            'ACTIVATING',
            'COMPLETE',
            'FAILED',
            'UndefinedTransition',
            'FORBIDDEN'
        )) {
            if (-not $bootEngine.Contains($token)) {
                throw "BOOTENGINE_TOKEN_MISSING:$token"
            }
        }

        $bootEngineHash =
            Get-CerebroBootSha256Text $bootEngine

        $failureStage = 'AUTHORITATIVE_SOURCE_FETCH'

        if (
            -not (
                Test-Path `
                    -LiteralPath $WorkingSourcePath `
                    -PathType Container
            )
        ) {
            throw "WORKING_SOURCE_NOT_FOUND:$WorkingSourcePath"
        }

        Push-Location -LiteralPath $WorkingSourcePath

        try {
            if (
                (git rev-parse --is-inside-work-tree).Trim() -ne
                'true'
            ) {
                throw 'WORKING_SOURCE_NOT_GIT_REPOSITORY'
            }

            $bootState = 'VERIFYING'
            $failureStage = 'WORKING_SOURCE_VERIFY'

            $currentBranch = (
                git branch --show-current
            ).Trim()

            if ([string]::IsNullOrWhiteSpace($currentBranch)) {
                throw 'WORKING_SOURCE_DETACHED_HEAD'
            }

            if ($currentBranch -ne $Branch) {
                throw (
                    "WORKING_SOURCE_BRANCH_INVALID:" +
                    "EXPECTED=$Branch`:ACTUAL=$currentBranch"
                )
            }

            $status = @(
                git status --porcelain --untracked-files=all
            )

            if ($status.Count -ne 0) {
                throw (
                    'WORKING_SOURCE_NOT_CLEAN:' +
                    ($status -join '|')
                )
            }

            git remote get-url $Remote 2>$null |
                Out-Null

            if ($LASTEXITCODE -ne 0) {
                throw "AUTHORITATIVE_REMOTE_MISSING:$Remote"
            }

            $remoteUrl = (
                git remote get-url $Remote
            ).Trim()

            if (
                $remoteUrl -notmatch
                'morgul-tech/Cerebro-Source-1\.0'
            ) {
                throw "AUTHORITATIVE_REMOTE_INVALID:$remoteUrl"
            }

            git fetch `
                $Remote `
                $Branch `
                --prune

            if ($LASTEXITCODE -ne 0) {
                throw 'AUTHORITATIVE_SOURCE_FETCH_FAILED'
            }

            $authoritativeRef = "$Remote/$Branch"

            $localCommit = (
                git rev-parse HEAD
            ).Trim()

            $authoritativeCommit = (
                git rev-parse $authoritativeRef
            ).Trim()

            if ($localCommit -eq $authoritativeCommit) {
                $alignmentState = 'ALIGNED'
            }
            else {
                git merge-base `
                    --is-ancestor `
                    $localCommit `
                    $authoritativeCommit

                $localIsAncestor = (
                    $LASTEXITCODE -eq 0
                )

                git merge-base `
                    --is-ancestor `
                    $authoritativeCommit `
                    $localCommit

                $remoteIsAncestor = (
                    $LASTEXITCODE -eq 0
                )

                if (
                    $localIsAncestor -and
                    -not $remoteIsAncestor
                ) {
                    $failureStage =
                        'WORKING_SOURCE_FAST_FORWARD'

                    git merge `
                        --ff-only `
                        $authoritativeRef

                    if ($LASTEXITCODE -ne 0) {
                        throw 'WORKING_SOURCE_FAST_FORWARD_FAILED'
                    }

                    $localCommit = (
                        git rev-parse HEAD
                    ).Trim()

                    if (
                        $localCommit -ne
                        $authoritativeCommit
                    ) {
                        throw 'WORKING_SOURCE_FAST_FORWARD_INCOMPLETE'
                    }

                    $alignmentState =
                        'FAST_FORWARDED_AND_ALIGNED'
                }
                elseif (
                    $remoteIsAncestor -and
                    -not $localIsAncestor
                ) {
                    throw (
                        'WORKING_SOURCE_LOCAL_AHEAD:' +
                        "LOCAL=${localCommit}:" +
                        "AUTHORITATIVE=$authoritativeCommit"
                    )
                }
                else {
                    throw (
                        'WORKING_SOURCE_DIVERGED:' +
                        "LOCAL=${localCommit}:" +
                        "AUTHORITATIVE=$authoritativeCommit"
                    )
                }
            }

            $postAlignmentStatus = @(
                git status --porcelain --untracked-files=all
            )

            if ($postAlignmentStatus.Count -ne 0) {
                throw 'WORKING_SOURCE_NOT_CLEAN_AFTER_ALIGNMENT'
            }

            $bootState = 'ANALYZING'
            $failureStage = 'SOURCE_COMPONENT_VALIDATION'

            $requiredRelativePaths = @(
                'cerebro.yaml',
                'mcp/activation.yaml',
                'standards/runtime/minimal-runtime-bootstrap.yaml',
                'standards/runtime/handboot.yaml',
                'standards/runtime/handboot-bootstrap-state-schema.yaml',
                'standards/session-handoff.yaml',
                'standards/session-handoff-schema.yaml',
                'engines/context/working-context.yaml',
                'engines/project/roadmap.yaml',
                'tooling/builder/templates/pshell/Cerebro.Tools.psd1',
                'tooling/builder/templates/pshell/Cerebro.Tools.psm1',
                'tooling/builder/templates/pshell/cerebro_handoff.ps1',
                'tooling/runtime-host/cerebro_resume.ps1',
                'tooling/runtime-host/cerebro_boot.ps1',
                'tooling/runtime-host/cerebro_machine_proof.ps1',
                'tooling/validator/checks.yaml'
            )

            foreach ($relativePath in $requiredRelativePaths) {
                $absolutePath = Join-Path `
                    $WorkingSourcePath `
                    ($relativePath -replace '/', '\')

                if (
                    -not (
                        Test-Path `
                            -LiteralPath $absolutePath `
                            -PathType Leaf
                    )
                ) {
                    throw "REQUIRED_COMPONENT_MISSING:$relativePath"
                }
            }

            $manifestPath = Join-Path `
                $WorkingSourcePath `
                'cerebro.yaml'

            $manifest = Test-CerebroBootRequiredTokens `
                -Path $manifestPath `
                -Tokens @(
                    'schema: cerebro-manifest/v1',
                    'cerebro:',
                    'source:',
                    'mcp:',
                    'engines:',
                    'modules:',
                    'standards:',
                    'tooling:',
                    'governance:',
                    'integrity:',
                    'source_status:'
                ) `
                -FailurePrefix 'MANIFEST_CONTRACT'

            $activationPath = Join-Path `
                $WorkingSourcePath `
                'mcp\activation.yaml'

            Test-CerebroBootRequiredTokens `
                -Path $activationPath `
                -Tokens @(
                    'external_protocol: Oppstartsprotokoll',
                    'entrypoint: cerebro.yaml',
                    'fetch_manifest',
                    'verify_source',
                    'verify_release',
                    'load_mcp',
                    'load_required_engines',
                    'load_required_modules',
                    'initialize_runtime',
                    'activate'
                ) `
                -FailurePrefix 'ACTIVATION_CONTRACT' |
                Out-Null

            $bootstrapPath = Join-Path `
                $WorkingSourcePath `
                'standards\runtime\minimal-runtime-bootstrap.yaml'

            Test-CerebroBootRequiredTokens `
                -Path $bootstrapPath `
                -Tokens @(
                    'persistent_authority: "Cerebro Source"',
                    'boot_authority: "orchestration_only"',
                    'resolve_authoritative_source',
                    'validate_required_contracts',
                    'construct_derived_runtime_state',
                    'activate_runtime',
                    'transfer_control'
                ) `
                -FailurePrefix 'BOOTSTRAP_CONTRACT' |
                Out-Null

            $roadmapPath = Join-Path `
                $WorkingSourcePath `
                'engines\project\roadmap.yaml'

            $roadmap = [IO.File]::ReadAllText(
                $roadmapPath
            )

            if (-not (
                Test-CerebroBootTerminalNoContinuation `
                    -Roadmap $roadmap
            )) {
                $currentPatch =
                    Get-CerebroBootExecutionValue `
                        -Roadmap $roadmap `
                        -Section current `
                        -Name patch_ref

                $nextPatch =
                    Get-CerebroBootExecutionValue `
                        -Roadmap $roadmap `
                        -Section next `
                        -Name patch_ref

                $canonicalCommand =
                    Get-CerebroBootExecutionValue `
                        -Roadmap $roadmap `
                        -Section current `
                        -Name canonical_command
            }

            $bootState = 'ACTIVATING'
            $failureStage = 'RUNTIME_CONSTRUCTION'

            $createdAt =
                [DateTime]::UtcNow.ToString('o')

            $runtimeIdMaterial = (
                '{0}|{1}|{2}|{3}' -f
                $runtimeProfile,
                $localCommit,
                $bootEngineHash,
                $currentPatch
            )

            $runtimeId = (
                'RUNTIME-' +
                (
                    Get-CerebroBootSha256Text `
                        $runtimeIdMaterial
                ).Substring(0, 24)
            )

            $hmiKernelId = 'CEREBRO-HMI-BIRTH-KERNEL-001'
            $hmiKernelVersion = '1.0'
            $hmiKernelRefs = @(
                'standards/human-continuation-surface.yaml',
                'standards/continuation-surface-system-policy.yaml',
                'engines/presentation/human-admin-projection.schema.json'
            )
            $hmiKernelMaterial = (
                $hmiKernelRefs | ForEach-Object {
                    $kernelPath = Join-Path $WorkingSourcePath $_
                    '{0}|{1}' -f $_, (Get-FileHash -Algorithm SHA256 -LiteralPath $kernelPath).Hash.ToLowerInvariant()
                }
            ) -join "`n"
            $hmiKernelFingerprint = Get-CerebroBootSha256Text (
                '{0}|{1}|{2}' -f $hmiKernelId, $hmiKernelVersion, $hmiKernelMaterial
            )

            $failureStage = 'CIVILIZATION_METHOD_BINDING'
            $methodBinding = Resolve-CerebroCivilizationMethod `
                -SourceRoot $WorkingSourcePath -SourceHead $localCommit -ActorRole $OperationalPulseActorRole
            $awakeningReceipt = New-CerebroAwakeningReceipt -Binding $methodBinding `
                -SourceRoot $WorkingSourcePath -SourceHead $localCommit -ActorRole $OperationalPulseActorRole

            $roleKernelId = 'CEREBRO-ROLE-BIRTH-KERNEL-001'
            $roleKernelVersion = '1.0'
            $roleKernelRefs = @(
                'engines/presentation/component.yaml',
                'engines/presentation/rules.yaml'
            )
            $roleKernelMaterial = (
                $roleKernelRefs | ForEach-Object {
                    $kernelPath = Join-Path $WorkingSourcePath $_
                    '{0}|{1}' -f $_, (Get-FileHash -Algorithm SHA256 -LiteralPath $kernelPath).Hash.ToLowerInvariant()
                }
            ) -join "`n"
            $roleKernelFingerprint = Get-CerebroBootSha256Text (
                '{0}|{1}|{2}|{3}' -f $roleKernelId, $roleKernelVersion, $roleKernelMaterial,
                $methodBinding.role_method_projection.fingerprint
            )

            $successionOrder = @(
                'identity',
                'HMI-birth-kernel',
                'CURRENT_CIVILIZATION_METHOD_PROFILE',
                'ROLE_METHOD_PROJECTION',
                'ROLE-birth-kernel',
                'Fresh-World-currentness',
                'lineage-wisdom',
                'reconcile',
                'canaries',
                'Arvetone-last',
                'AWAKENING_RECEIPT-readback',
                'Identitetshilsen',
                'READY'
            )
            $successionFingerprint = Get-CerebroBootSha256Text ($successionOrder -join '|')
            $operationalPulse = Invoke-CerebroFreshWorldOperationalPulse `
                -ProviderTailReader $OperationalPulseReader `
                -ActorRole $OperationalPulseActorRole `
                -ObjectiveRef $OperationalPulseObjectiveRef
            $principalObservedFrontier = $null
            $pulseWatermarks = $null
            if ($operationalPulse -is [Collections.IDictionary] -and $operationalPulse.Contains('watermarks')) {
                $pulseWatermarks = $operationalPulse['watermarks']
            }
            if (
                $null -ne $pulseWatermarks -and
                $pulseWatermarks -is [Collections.IDictionary] -and
                $pulseWatermarks.Contains('control') -and
                $null -ne $pulseWatermarks['control'] -and
                $pulseWatermarks['control'] -is [Collections.IDictionary] -and
                $pulseWatermarks['control'].Contains('event_frontier')
            ) {
                $frontierText = [string]$pulseWatermarks['control']['event_frontier']
                $parsedFrontier = 0L
                if ($frontierText -cmatch '^[0-9]+$' -and [long]::TryParse($frontierText, [ref]$parsedFrontier)) {
                    $principalObservedFrontier = $parsedFrontier
                }
            }
            $principalSuccession = Test-CerebroPrincipalSuccessionPermit `
                -PermitReader $PrincipalSuccessionPermitReader `
                -MachineDiaryEffectVerifier $PrincipalMachineDiaryEffectVerifier `
                -ObservedEventFrontier $principalObservedFrontier `
                -PredecessorGenerationId $PredecessorPrincipalGenerationId `
                -SuccessorGenerationId $PrincipalSuccessorGenerationId `
                -PermitRef $PrincipalSuccessionPermitRef `
                -PermitFingerprint $PrincipalSuccessionPermitFingerprint `
                -SourceHead $authoritativeCommit

            $runtimeState = [ordered]@{
                schema =
                    'cerebro-handboot-runtime-state/v0.1'

                runtime = [ordered]@{
                    runtime_id = $runtimeId
                    profile = $runtimeProfile
                    created_at_utc = $createdAt
                    activated_at_utc = $null
                    state = 'CONSTRUCTED_INACTIVE'
                    operational = $false

                    authority = [ordered]@{
                        persistent_authority =
                            'github:morgul-tech/Cerebro-Source-1.0/main'

                        boot_authority =
                            'external_orchestration_only'

                        runtime_authority =
                            'derived_non_authoritative'

                        handoff_authority =
                            'derived_non_authoritative'
                    }

                    bootengine = [ordered]@{
                        source = $BootEngineUrl
                        sha256 = $bootEngineHash
                        validation_state = 'VERIFIED'
                    }

                    working_source = [ordered]@{
                        path = $WorkingSourcePath
                        branch = $currentBranch
                        commit = $localCommit
                        worktree_state = 'CLEAN'
                        alignment_state = $alignmentState
                    }

                    authoritative_source = [ordered]@{
                        repository =
                            'morgul-tech/Cerebro-Source-1.0'

                        remote = $Remote
                        branch = $Branch
                        commit = $authoritativeCommit
                        fetch_state = 'FETCHED'
                    }

                    source_validation = [ordered]@{
                        manifest_state = 'VERIFIED'
                        activation_contract_state = 'VERIFIED'
                        bootstrap_contract_state = 'VERIFIED'
                        required_components_state = 'VERIFIED'
                    }

                    components = [ordered]@{
                        required = $requiredRelativePaths
                        loaded_profile =
                            'controlled-session-minimum'
                    }

                    execution = [ordered]@{
                        current_patch = $currentPatch
                        next_patch = $nextPatch
                        canonical_command = $canonicalCommand
                    }

                    birth_kernels = [ordered]@{
                        HMI = [ordered]@{
                            id = $hmiKernelId
                            version = $hmiKernelVersion
                            fingerprint = $hmiKernelFingerprint
                            consumed = $true
                        }
                        ROLE = [ordered]@{
                            id = $roleKernelId
                            version = $roleKernelVersion
                            fingerprint = $roleKernelFingerprint
                            consumed = $true
                        }
                    }

                    awakening_receipt = $awakeningReceipt
                    awakening_readback = $null

                    succession = [ordered]@{
                        zero_live_state_inheritance = $true
                        order = $successionOrder
                        order_fingerprint = $successionFingerprint
                        operational_pulse = $operationalPulse
                        currentness_gate = $operationalPulse.result
                        principal_permit = $principalSuccession
                        completed = $false
                        final_state = 'AWAITING_AWAKENING_READBACK'
                    }

                    handoff = [ordered]@{
                        requested = (
                            -not $SkipHandoff
                        )

                        path = $HandoffPath
                        state = 'PENDING'
                        handoff_id = $null
                        resume_receipt = $null
                    }

                    control = [ordered]@{
                        runtime_constructed = $true
                        runtime_activated = $false
                        control_transferred = $false
                        failure_stage = 'NONE'
                        failure_code = 'NONE'
                    }

                    receipt = [ordered]@{
                        algorithm = 'sha256'
                        value = $null
                        material_version =
                            'handboot-receipt/v0.2'
                    }
                }
            }

            $failureStage = 'AWAKENING_PERSIST_AND_READBACK'
            Write-CerebroBootRuntimeState -Path $RuntimeStatePath -RuntimeState $runtimeState
            $runtimeState.runtime.awakening_readback = Test-CerebroAwakeningReadback `
                -Path $RuntimeStatePath -RuntimeState $runtimeState `
                -SourceRoot $WorkingSourcePath -SourceHead $localCommit -ActorRole $OperationalPulseActorRole
            $runtimeState.runtime.succession.completed = ($principalSuccession.result -in @('PASS','PASS_NON_PRINCIPAL_UNCHANGED'))
            $runtimeState.runtime.succession.final_state = $(if ($principalSuccession.result -in @('PASS','PASS_NON_PRINCIPAL_UNCHANGED')) { 'READY' } else { 'HOLD' })

            $failureStage = 'RUNTIME_ACTIVATION'

            $runtimeState.runtime.state = 'ACTIVE'
            $runtimeState.runtime.activated_at_utc =
                [DateTime]::UtcNow.ToString('o')

            $runtimeState.runtime.control.runtime_activated =
                $true

            Write-CerebroBootRuntimeState `
                -Path $RuntimeStatePath `
                -RuntimeState $runtimeState

            $failureStage = 'HANDOFF_PROCESSING'

            if ($SkipHandoff) {
                $handoffState = 'SKIPPED_EXPLICITLY'
            }
            elseif (
                Test-Path `
                    -LiteralPath $HandoffPath `
                    -PathType Leaf
            ) {
                $resumeScriptPath = Join-Path `
                    $WorkingSourcePath `
                    'tooling\runtime-host\cerebro_resume.ps1'

                . $resumeScriptPath

                $resumeResult = Invoke-CerebroResumeCore `
                    -HandoffPath $HandoffPath `
                    -RepoPath $WorkingSourcePath

                if ($resumeResult.state -eq 'SUCCESS_READY') {
                    $handoffState = 'RESUMED'
                    $handoffId = $resumeResult.handoff_id
                    $resumeReceipt = $resumeResult.receipt

                    $currentPatch =
                        $resumeResult.current_patch

                    $nextPatch =
                        $resumeResult.next_patch

                    $canonicalCommand =
                        $resumeResult.canonical_command
                }
                elseif ($resumeResult.state -eq 'STALE_REJECTED') {
                    $handoffState = 'STALE_REJECTED'
                    $handoffId = $resumeResult.handoff_id
                    $resumeReceipt = $null

                    Write-Host (
                        (
                            'CEREBRO_BOOT HANDOFF=STALE_REJECTED ' +
                            'ACTION=CONTINUE_CURRENT_SOURCE ' +
                            'CURRENT_SOURCE_COMMIT={0}'
                        ) -f
                        $localCommit
                    )
                }
                else {
                    throw (
                        'HANDOFF_RESUME_STATE_INVALID:' +
                        $resumeResult.state
                    )
                }
            }
            else {
                $handoffState = 'NONE'
            }

            $failureStage = 'CONTROL_TRANSFER'

            $receiptMaterial = (
                '{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}|{10}|{11}' -f
                'bootCerebro',
                $bootEngineHash,
                $localCommit,
                $runtimeProfile,
                'ACTIVE_CONTROL_TRANSFERRED',
                $handoffState,
                $currentPatch,
                $canonicalCommand,
                $hmiKernelFingerprint,
                $roleKernelFingerprint,
                $successionFingerprint,
                $awakeningReceipt.fingerprint
            )

            $receipt =
                Get-CerebroBootSha256Text `
                    $receiptMaterial

            $runtimeState.runtime.state =
                'ACTIVE_CONTROL_TRANSFERRED'

            $runtimeState.runtime.operational =
                $true

            $runtimeState.runtime.execution.current_patch =
                $currentPatch

            $runtimeState.runtime.execution.next_patch =
                $nextPatch

            $runtimeState.runtime.execution.canonical_command =
                $canonicalCommand

            $runtimeState.runtime.handoff.state =
                $handoffState

            $runtimeState.runtime.handoff.handoff_id =
                $handoffId

            $runtimeState.runtime.handoff.resume_receipt =
                $resumeReceipt

            $runtimeState.runtime.control.control_transferred =
                $true

            $runtimeState.runtime.receipt.value =
                $receipt

            Write-CerebroBootRuntimeState `
                -Path $RuntimeStatePath `
                -RuntimeState $runtimeState

            $failureStage = 'AWAKENING_FINAL_READBACK'
            $finalAwakeningReadback = Test-CerebroAwakeningReadback `
                -Path $RuntimeStatePath -RuntimeState $runtimeState `
                -SourceRoot $WorkingSourcePath -SourceHead $localCommit -ActorRole $OperationalPulseActorRole
            $bootState = 'COMPLETE'
            $failureStage = 'NONE'
            $failureCode = 'NONE'

            Write-Host ''
            Write-Host '======================================================'
            Write-Host 'CEREBRO HANDBOOT RESULT'
            Write-Host '======================================================'
            Write-Host 'command:                bootCerebro'
            Write-Host 'state:                  ACTIVE_CONTROL_TRANSFERRED'
            Write-Host 'bootengine:             VERIFIED'
            Write-Host 'authoritative_source:   VERIFIED'
            Write-Host (
                'working_source:         {0}' -f
                $alignmentState
            )
            Write-Host (
                'source_commit:          {0}' -f
                $localCommit
            )
            Write-Host 'manifest:               VERIFIED'
            Write-Host 'components:             VERIFIED'
            Write-Host 'runtime:                ACTIVE'
            Write-Host (
                'birth_kernels:          HMI={0} ROLE={1}' -f
                $hmiKernelFingerprint,
                $roleKernelFingerprint
            )
            Write-Host (
                'succession:             READY {0}' -f
                $successionFingerprint
            )
            Write-Host (
                'handoff:                {0}' -f
                $handoffState
            )
            Write-Host (
                'current_patch:          {0}' -f
                $currentPatch
            )
            Write-Host (
                'canonical_command:      {0}' -f
                $canonicalCommand
            )
            Write-Host 'operational:            TRUE'
            Write-Host (
                'runtime_state_path:     {0}' -f
                $RuntimeStatePath
            )
            Write-Host (
                'receipt:                {0}' -f
                $receipt
            )
            Write-Host '======================================================'

            Write-Host (
                (
                    'CEREBRO_BOOT COMMAND=bootCerebro ' +
                    'STATE=ACTIVE_CONTROL_TRANSFERRED ' +
                    'BOOTENGINE=VERIFIED ' +
                    'AUTHORITATIVE_SOURCE=VERIFIED ' +
                    'WORKING_SOURCE={0} ' +
                    'SOURCE_COMMIT={1} ' +
                    'MANIFEST=VERIFIED COMPONENTS=VERIFIED ' +
                    'RUNTIME=ACTIVE HANDOFF={2} ' +
                    'CURRENT_PATCH={3} OPERATIONAL=TRUE ' +
                    'RECEIPT={4}'
                ) -f
                $alignmentState,
                $localCommit,
                $handoffState,
                $currentPatch,
                $receipt
            )

            return [pscustomobject]@{
                command = 'bootCerebro'
                state = 'ACTIVE_CONTROL_TRANSFERRED'
                bootengine = 'VERIFIED'
                authoritative_source = 'VERIFIED'
                working_source = $alignmentState
                source_commit = $localCommit
                manifest = 'VERIFIED'
                components = 'VERIFIED'
                runtime = 'ACTIVE'
                birth_kernels = $runtimeState.runtime.birth_kernels
                succession = $runtimeState.runtime.succession
                awakening_receipt = $runtimeState.runtime.awakening_receipt
                awakening_readback = $finalAwakeningReadback
                handoff = $handoffState
                handoff_id = $handoffId
                resume_receipt = $resumeReceipt
                current_patch = $currentPatch
                next_patch = $nextPatch
                canonical_command = $canonicalCommand
                operational = $true
                runtime_state_path = $RuntimeStatePath
                receipt = $receipt
            }
        }
        finally {
            Pop-Location
        }
    }
    catch {
        $failureCode = $_.Exception.Message
        $bootState = 'FAILED'

        $failedRuntimeState = [ordered]@{
            schema =
                'cerebro-handboot-runtime-state/v0.1'

            runtime = [ordered]@{
                runtime_id = $null
                profile = $runtimeProfile
                created_at_utc =
                    [DateTime]::UtcNow.ToString('o')

                activated_at_utc = $null
                state = 'INACTIVE_CONTROL_RETAINED'
                operational = $false

                authority = [ordered]@{
                    persistent_authority =
                        'github:morgul-tech/Cerebro-Source-1.0/main'

                    boot_authority =
                        'external_orchestration_only'

                    runtime_authority =
                        'derived_non_authoritative'

                    handoff_authority =
                        'derived_non_authoritative'
                }

                bootengine = [ordered]@{
                    source = $BootEngineUrl
                    sha256 = $bootEngineHash
                    validation_state = $(
                        if ($bootEngineHash) {
                            'VERIFIED'
                        }
                        else {
                            'FAILED'
                        }
                    )
                }

                working_source = [ordered]@{
                    path = $WorkingSourcePath
                    branch = $Branch
                    commit = $localCommit
                    worktree_state = 'UNKNOWN'
                    alignment_state = $alignmentState
                }

                authoritative_source = [ordered]@{
                    repository =
                        'morgul-tech/Cerebro-Source-1.0'

                    remote = $Remote
                    branch = $Branch
                    commit = $authoritativeCommit
                    fetch_state = 'UNKNOWN'
                }

                source_validation = [ordered]@{
                    manifest_state = 'UNKNOWN'
                    activation_contract_state = 'UNKNOWN'
                    bootstrap_contract_state = 'UNKNOWN'
                    required_components_state = 'UNKNOWN'
                }

                components = [ordered]@{
                    required = @()
                    loaded_profile = $null
                }

                execution = [ordered]@{
                    current_patch = $currentPatch
                    next_patch = $nextPatch
                    canonical_command = $canonicalCommand
                }

                handoff = [ordered]@{
                    requested = (-not $SkipHandoff)
                    path = $HandoffPath
                    state = 'FAILED'
                    handoff_id = $handoffId
                    resume_receipt = $resumeReceipt
                }

                control = [ordered]@{
                    runtime_constructed = $false
                    runtime_activated = $false
                    control_transferred = $false
                    failure_stage = $failureStage
                    failure_code = $failureCode
                }

                receipt = [ordered]@{
                    algorithm = 'sha256'
                    value = $null
                    material_version =
                        'handboot-receipt/v0.1'
                }
            }
        }

        try {
            Write-CerebroBootRuntimeState `
                -Path $RuntimeStatePath `
                -RuntimeState $failedRuntimeState
        }
        catch {
            # Preserve original boot failure.
        }

        Write-Host (
            (
                'CEREBRO_BOOT COMMAND=bootCerebro ' +
                'STATE=INACTIVE_CONTROL_RETAINED ' +
                'FAILURE_STAGE={0} FAILURE_CODE={1} ' +
                'OPERATIONAL=FALSE'
            ) -f
            ($failureStage -replace '\s+', '_'),
            ($failureCode -replace '\s+', '_')
        )

        throw
    }
}
