"""The provider bootstrap has no caller-supplied identity or session input."""

from __future__ import annotations

import unittest
from types import SimpleNamespace
from unittest.mock import Mock

from deployment.runtime_session_bootstrap import (
    RuntimeSessionBootstrapError, bind_configured_session,
)
from control_context_remote_service import LocalRuntimeOAuthBinding


class RuntimeSessionBootstrapTests(unittest.TestCase):
    def setUp(self):
        self.binding = LocalRuntimeOAuthBinding(
            "https://auth.cerebro.invalid", "client:runtime", "tenant:1", "workspace:1",
            "project:1", "client:runtime@clients",
            "https://mcp.cerebro.invalid/bk07-runtime", "local:liv-current", False)
        self.port = Mock()
        self.port.read_session.side_effect = self._read_session

    def _runtime(self, binding=None):
        config = SimpleNamespace(service=SimpleNamespace(
            local_runtime_binding=self.binding if binding is None else binding))
        return SimpleNamespace(config=config, state_port=self.port)

    def _read_session(self, **kwargs):
        return {"project_ref": "project:1", "session_binding_id":
                self.port.bind_session.call_args.kwargs["session_binding_id"],
                "session_revision": 1, "fingerprint": "f" * 64, "project_revision": 1}

    def test_exact_provider_binding_and_persisted_readback(self):
        receipt = bind_configured_session(self._runtime())
        self.assertEqual(receipt["session_ref"], "local:liv-current")
        self.assertEqual(receipt["session_binding_id"],
                         self.port.bind_session.call_args.kwargs["session_binding_id"])
        self.assertEqual(self.port.bind_session.call_args.kwargs["scopes"],
                         {"project_state:transition"})
        self.assertEqual(self.port.bind_session.call_args.kwargs["consumer_ref"],
                         "LOCAL_CEREBRO_RUNTIME")
        self.assertEqual(self.port.read_session.call_args.kwargs["scopes"],
                         {"project_state:read"})
        self.assertEqual(bind_configured_session(self._runtime()), receipt)

    def test_disabled_config_and_exact_principal_required(self):
        for binding in (
            None,
            LocalRuntimeOAuthBinding(**{**self.binding.__dict__, "enabled": True}),
            LocalRuntimeOAuthBinding(**{**self.binding.__dict__, "principal_ref": "other@clients"}),
            LocalRuntimeOAuthBinding(**{**self.binding.__dict__, "session_ref": "local:"}),
        ):
            runtime = self._runtime(binding)
            if binding is None:
                runtime.config.service.local_runtime_binding = None
            with self.assertRaises(RuntimeSessionBootstrapError):
                bind_configured_session(runtime)
        self.port.bind_session.assert_not_called()

    def test_mismatched_readback_never_reports_success(self):
        self.port.read_session.side_effect = lambda **kwargs: {
            "project_ref": "project:1", "session_binding_id": "CSB-WRONG"}
        with self.assertRaisesRegex(RuntimeSessionBootstrapError,
                                    "RUNTIME_SESSION_READBACK_MISMATCH"):
            bind_configured_session(self._runtime())


if __name__ == "__main__":
    unittest.main()
