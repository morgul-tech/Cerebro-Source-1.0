#!/usr/bin/env python3
"""Exercise the production-shaped standing grant and native birth attach path."""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for path in (ROOT / "mcp", ROOT / "tooling" / "context"):
    sys.path.insert(0, str(path))

from control_context_state_port import InMemoryControlContextStatePort  # noqa: E402
from control_context_tools import (  # noqa: E402
    ControlContextMcpTools, ControlContextToolAuthorizationError,
    HmacControlResolutionAttestor, McpToolCallContext, VerifiedMcpIdentity,
)

HEAD = "5" * 40
GENERATION = "CEREBRO-BOOT-WORKER-20261004-2025-02"
SOURCE = {
    "source_revision": HEAD, "method_ref": "CURRENT_CIVILIZATION_METHOD_PROFILE",
    "method_version": "1.0", "method_fingerprint": "6" * 64,
    "provider_frontier_ref": "GITHUB_SOURCE_MAIN_" + HEAD,
    "provider_revision": 1791210000,
}
GRANT = {
    "schema": "cerebro-standing-worker-grant/v1",
    "grant_id": "HUMAN-WORKER-ATTACH-001",
    "issuer_principal_ref": "HUMAN-1", "tenant_ref": "TENANT-1",
    "workspace_ref": "WORKSPACE-1", "scope": "WORKER_ATTACH",
    "revision": 1, "current": True, "revoked": False,
}


def context(principal: str = "HUMAN-1", workspace: str = "WORKSPACE-1") -> McpToolCallContext:
    return McpToolCallContext(
        identity=VerifiedMcpIdentity(
            tenant_ref="TENANT-1", workspace_ref=workspace,
            principal_ref=principal,
            scopes=frozenset({"project_state:read", "project_state:transition"}),
            token_verified=True,
        ), request_meta={"openai/session": "CURRENT-HUMAN-SESSION"},
    )


def rejects(fn) -> bool:
    try:
        fn()
    except ControlContextToolAuthorizationError:
        return True
    return False


def main() -> int:
    checks = {}
    port = InMemoryControlContextStatePort()
    attestor = HmacControlResolutionAttestor(key_id="test-key", secret=b"x" * 32)
    tool = ControlContextMcpTools(
        port, attestor, boot_birth_source_verifier=lambda head: copy.deepcopy(SOURCE),
        boot_birth_attestation_issuer=attestor, standing_worker_grant=GRANT,
    )
    birth = tool.create_ready_unbound_boot_generation(
        {"boot_attempt_id": GENERATION, "source_revision": HEAD}, context(),
    )["structuredContent"]["pre_role_generation"]
    checks["native-birth-readback"] = birth["lifecycle"] == "READY_UNBOUND" and birth["revision"] == 2
    args = {"generation_ref": GENERATION, "expected_revision": 2,
            "source_revision": HEAD, "destination_ref": "A1"}
    checks["wrong-human-rejected"] = rejects(
        lambda: tool.attach_worker_from_standing_grant(args, context(principal="OTHER")))
    checks["wrong-workspace-rejected"] = rejects(
        lambda: tool.attach_worker_from_standing_grant(args, context(workspace="OTHER")))
    revoked = copy.deepcopy(GRANT)
    revoked["revoked"] = True
    revoked_tool = ControlContextMcpTools(
        port, attestor, boot_birth_source_verifier=lambda head: copy.deepcopy(SOURCE),
        boot_birth_attestation_issuer=attestor, standing_worker_grant=revoked,
    )
    checks["revoked-grant-rejected"] = rejects(
        lambda: revoked_tool.attach_worker_from_standing_grant(args, context()))
    result = tool.attach_worker_from_standing_grant(args, context())["structuredContent"]
    checks["one-native-worker-attach"] = (
        result["pre_role_generation"]["lifecycle"] == "ROLE_ATTACHED"
        and result["actor_generation_shadow"]["role"] == "WORKER"
        and result["actor_generation_shadow"]["authority"] == "SHADOW_ONLY"
        and result["standing_grant_id"] == GRANT["grant_id"]
    )
    checks["replay-rejected"] = rejects(
        lambda: tool.attach_worker_from_standing_grant(args, context()))
    print(json.dumps({"result": "PASS" if all(checks.values()) else "FAIL", "checks": checks}, sort_keys=True))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
