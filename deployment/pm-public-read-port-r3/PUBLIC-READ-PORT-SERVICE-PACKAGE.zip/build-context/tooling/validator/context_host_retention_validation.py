"""Focused, dependency-free check of the production Context bootstrap handoff."""

from __future__ import annotations

import ast
import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable


source = (Path(__file__).resolve().parents[2] / "deployment" / "app.py").read_text()
tree = ast.parse(source)
nodes = [node for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef))
         and node.name in {"OAuthBootstrapMiddleware", "_build_app"}]
assert len(nodes) == 2
module = ast.Module(body=nodes, type_ignores=[])
code = compile(module, "deployment/app.py", "exec")

calls: dict[str, Any] = {}
config = SimpleNamespace(
    postgres_connect_timeout_seconds=10,
    postgres_application_name="context-state",
    service=SimpleNamespace(resource_documentation="https://context.example"),
)


class Config:
    @staticmethod
    def from_mapping(mapping: dict[str, Any]) -> Any:
        calls["config_mapping"] = mapping
        return config


class Verifier:
    def __init__(self, **kwargs: Any) -> None:
        calls["verifier_kwargs"] = kwargs


class Attestor:
    def __init__(self, **kwargs: Any) -> None:
        calls["attestor_kwargs"] = kwargs


def factory_builder(dsn: str, **kwargs: Any) -> Callable[[], Any]:
    calls["factory_builds"] = calls.get("factory_builds", 0) + 1
    calls["factory_kwargs"] = kwargs
    assert dsn == "test-dsn"
    return lambda: None


async def inner_app(scope: dict[str, Any], receive: Any, send: Any) -> None:
    calls["forwarded_scope"] = scope


def assembler(**kwargs: Any) -> Any:
    calls["assembly"] = kwargs
    runtime = SimpleNamespace(app=inner_app, state_port=SimpleNamespace(
        _connection_factory=kwargs["connection_factory"]),
        service=SimpleNamespace(_authenticator=SimpleNamespace(
            _token_verifier=kwargs["token_verifier"])))
    calls["runtime"] = runtime
    return runtime


scope: dict[str, Any] = {
    "Any": Any,
    "Callable": Callable,
    "json": json,
    "os": SimpleNamespace(environ={}),
    "ControlContextRemoteRuntimeConfig": Config,
    "JwksBearerTokenVerifier": Verifier,
    "HmacControlResolutionAttestor": Attestor,
    "make_psycopg_connection_factory": factory_builder,
    "assemble_postgres_control_context_remote_runtime_from_connection_factory": assembler,
    "_public_resource": lambda: ("https://context.example", "context.example"),
    "_required": lambda name: "https://issuer.example" if name == "CEREBRO_OAUTH_ISSUER" else None,
    "_csv": lambda name: [],
    "_attestation_secret": lambda: b"test-secret-not-for-output",
    "_runtime_dsn": lambda: "test-dsn",
    "_standing_worker_grant": lambda: {"test": "existing-grant"},
    "_pm_owner_assignment": lambda: None,
    "_x9_custody_configuration": lambda: None,
}
exec(code, scope)
app = scope["_build_app"]()
runtime = calls["runtime"]
factory = calls["assembly"]["connection_factory"]
assert calls["factory_builds"] == 1
assert app._context_runtime is runtime
assert app._context_connection_factory is factory
assert runtime.state_port._connection_factory is factory
assert runtime.service._authenticator._token_verifier is calls["assembly"]["token_verifier"]
assert calls["assembly"]["standing_worker_grant"] == {"test": "existing-grant"}
assert calls["assembly"]["boot_birth_attestation_issuer"] is calls["assembly"]["resolution_attestation_verifier"]
assert calls["config_mapping"]["postgres"]["runtime_applies_migrations"] is False
assert "test-secret-not-for-output" not in json.dumps(app._protected_resource_metadata)


async def exercise_transport() -> None:
    sent: list[dict[str, Any]] = []

    async def send(message: dict[str, Any]) -> None:
        sent.append(message)

    await app({"type": "http", "method": "GET", "path": "/mcp", "headers": []}, None, send)
    assert sent[0]["status"] == 401
    sent.clear()
    request = {"type": "http", "method": "GET", "path": "/mcp",
               "headers": [(b"authorization", b"Bearer test")]}
    await app(request, None, send)
    assert calls["forwarded_scope"] is request


asyncio.run(exercise_transport())
print("PASS: one provider factory/runtime retained; grant, verifier, attestor and OAuth forwarding preserved")
