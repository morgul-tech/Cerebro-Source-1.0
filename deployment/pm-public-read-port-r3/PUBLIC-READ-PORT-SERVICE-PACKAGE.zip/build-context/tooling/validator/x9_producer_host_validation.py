"""Focused offline proof of the normal PM producer host path."""
from __future__ import annotations

import sys
import copy
import unittest
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "mcp"), str(ROOT / "tooling" / "context"),
                str(ROOT / "tooling" / "validator")]

from adapters.x9_channel_ingress import CHANNEL, ChannelIdentity, PointerContext, Readback, X9ChannelIngress
from control_context_tools import McpToolCallContext, VerifiedMcpIdentity
from pm_owner_atomic import _hash
from control_context_remote_service import OAuthBearerAuthenticator
from providers.x9_postgres_custody import CustodyUnavailable
from x9_producer_host import X9ProducerError, X9ProducerHost
from x9_receiver_host_validation import fixture


def receipt_rows(*, current=True, ready=True, material_hash_valid=True):
    packet = {"material": {"work": "genuine PM owner material"}}
    projection = {"material_sha256": _hash(packet["material"]),
                  "source_cut": "pm-cut:test1", "active_hold": None}
    if not material_hash_valid:
        projection["material_sha256"] = "f" * 64
    record = {
        "owner_ref": "owner:pm", "receipt_ref": "pm-receipt:test1",
        "event_id": "pm-event:test1", "referent_id": "pm-ready:test1",
        "owner_seq": 1, "revision_after": "pm-revision:test1",
        "claim_ref": "claim:test1", "packet_ref": "packet:test1",
        "packet_sha256": _hash(packet), "queue_ref": "queue:test1",
        "ready_state": "MATERIAL_READY" if ready else "BIND_AVAILABLE",
        "commit_ref": "pm-commit:test1",
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "way_home": ["way:pm", "way:x9"],
    }
    record["snapshot_sha256"] = _hash(record)
    receipt = {"record_payload": record, "snapshot_sha256": record["snapshot_sha256"],
               "projection_payload": projection, "packet_payload": packet}
    return [receipt, {"receipt_ref": "pm-receipt:test1" if current else "pm-receipt:other"}, receipt]


class Cursor:
    def __init__(self, rows):
        self.rows = rows
        self.calls = []

    def execute(self, sql, params):
        self.calls.append((sql, params))

    def fetchone(self):
        return self.rows.pop(0)


class API:
    def __init__(self, config, cursor):
        self.config, self.cursor = config, cursor

    @contextmanager
    def _transaction(self, *, write=False):
        assert not write
        yield (self.cursor, SimpleNamespace(principal_ref="principal:pm"), None,
               self.config, self.config.producer)


class Channel:
    def __init__(self, *, unknown=False, drop=False, principal="principal:pm"):
        self.pointer = None
        self.sends = 0
        self.unknown, self.drop = unknown, drop
        self.principal = principal

    def identity(self):
        return ChannelIdentity(CHANNEL, self.principal, True, True, True)

    def read_pointer_by_event_id(self, event_id):
        if self.pointer is None or self.pointer.event_id != event_id:
            return None
        return Readback(self.pointer, self.pointer.content_sha256,
                        "principal:pm", "x9pg:1")

    def append_pointer_once(self, pointer):
        self.sends += 1
        if not self.drop:
            self.pointer = pointer
        return "UNKNOWN_SEND" if self.unknown else "ACCEPTED"


class ProducerTests(unittest.TestCase):
    def setUp(self):
        self.config, self.owner, _pointer = fixture()
        self.host = X9ProducerHost(config=self.config, pm_owner_assignment=self.owner,
                                   authenticator=object(), connection_factory=lambda: None)
        self.identity = VerifiedMcpIdentity("tenant:1", "workspace:1", "principal:pm",
                                            frozenset({"project_state:read", "project_state:transition"}), True)

    def context(self, session="session:producer"):
        return McpToolCallContext(self.identity, {"openai/session": session},
                                  {"authorization": "Bearer offline-test"})

    def append(self, *, rows=None, channel=None):
        cursor = Cursor(rows or receipt_rows())
        channel = channel or Channel()
        with patch.object(self.host, "_channel", return_value=(channel, API(self.config, cursor))):
            value = self.host.append_pointer({"receipt_ref": "pm-receipt:test1"}, self.context())
        return value, channel, cursor

    def test_wrong_session_fails_before_provider_access(self):
        with self.assertRaisesRegex(X9ProducerError, "X9_CURRENT_PRODUCER_SESSION_REQUIRED"):
            self.host._channel(self.context("session:wrong"))

    def test_transition_only_token_is_accepted_for_internal_producer_reads(self):
        class TransitionOnly(OAuthBearerAuthenticator):
            def __init__(self):
                self.scopes = []

            def authenticate(self, headers, *, required_scope):
                self.scopes.append(required_scope)
                if required_scope != "project_state:transition":
                    raise ValueError("read scope was incorrectly required")
                return VerifiedMcpIdentity("tenant:1", "workspace:1", "principal:pm",
                                           frozenset({"project_state:transition"}), True)

        authenticator = TransitionOnly()
        host = X9ProducerHost(config=self.config, pm_owner_assignment=self.owner,
                              authenticator=authenticator,
                              connection_factory=lambda: (_ for _ in ()).throw(ValueError("stop before DB")))
        context = McpToolCallContext(
            VerifiedMcpIdentity("tenant:1", "workspace:1", "principal:pm",
                                frozenset({"project_state:transition"}), True),
            {"openai/session": "session:producer"}, {"authorization": "Bearer transition-only"})
        with patch.object(McpToolCallContext, "transport_session",
                          return_value={"session_ref": "session:producer"}):
            channel, api = host._channel(context)
        self.assertIsNotNone(channel)
        with self.assertRaises(CustodyUnavailable):
            with api._transaction(write=False):
                pass
        self.assertEqual(authenticator.scopes, ["project_state:transition"])

    def test_real_oauth_principal_shape_is_valid_only_as_principal(self):
        principal = "google-oauth2|100121055053136597062"
        channel = Channel(principal=principal)
        ingress = X9ChannelIngress(enabled=True, channel=channel,
                                  producer_principal=principal,
                                  x9_principal=principal,
                                  x9_session_ref="chatgpt:v1/receiver")
        self.assertTrue(ingress._identity(producer=True))
        pointer = PointerContext(
            event_id="pm-event:test1", attempt_id="pm-commit:test1",
            owner_ref="owner:pm", referent_type="PM_READY_HINT",
            revision="pm-revision:test1", expected_sha256="a" * 64,
            claim_ref="C1179", packet_ref="P1793-BK07", packet_sha256="b" * 64,
            queue_ref="Q674", producer_id=principal,
            receiver_ref="chatgpt:v1/receiver", source_cut="pm-cut:test1",
            expires_at="2099-01-01T00:00:00+00:00",
            way_home=("PM_PRINCIPAL_CHANNEL",), referent_id="pm-ready:test1",
            owner_seq=1)
        self.assertTrue(pointer.valid())
        self.assertFalse(PointerContext(**{**pointer.__dict__, "event_id": "bad|event"}).valid())

    def test_caller_cannot_supply_event_or_owner_claim(self):
        with self.assertRaisesRegex(X9ProducerError, "X9_PRODUCER_RECEIPT_REF_ONLY"):
            self.host.append_pointer({"receipt_ref": "pm-receipt:test1", "owner_seq": 7}, self.context())

    def test_current_material_receipt_derives_durable_pointer(self):
        rows = receipt_rows()
        expected_snapshot = rows[0]["record_payload"]["snapshot_sha256"]
        value, channel, cursor = self.append(rows=rows)
        self.assertEqual(value["state"], "DEPOSITED_READBACK")
        self.assertEqual(channel.sends, 1)
        self.assertEqual(len(cursor.calls), 3)
        self.assertEqual(channel.pointer.event_id, "pm-event:test1")
        self.assertEqual(channel.pointer.referent_id, "pm-ready:test1")
        self.assertEqual(channel.pointer.owner_seq, 1)
        self.assertEqual(channel.pointer.receiver_ref, "session:receiver")
        self.assertEqual(channel.pointer.expected_sha256, expected_snapshot)

    def test_stale_receipt_never_appends(self):
        with self.assertRaisesRegex(X9ProducerError, "X9_PM_RECEIPT_NOT_CURRENT"):
            self.append(rows=receipt_rows(current=False))

    def test_material_hash_mismatch_never_appends(self):
        with self.assertRaisesRegex(X9ProducerError, "X9_PM_MATERIAL_HASH_MISMATCH"):
            self.append(rows=receipt_rows(material_hash_valid=False))

    def test_bind_available_is_not_sent(self):
        with self.assertRaisesRegex(X9ProducerError, "X9_PM_MATERIAL_NOT_READY"):
            self.append(rows=receipt_rows(ready=False))

    def test_unknown_send_exact_original_readback_is_confirmed(self):
        value, channel, _cursor = self.append(channel=Channel(unknown=True))
        self.assertEqual(value["state"], "DEPOSITED_READBACK")
        self.assertEqual(channel.sends, 1)

    def test_unknown_send_without_readback_never_replays_in_host(self):
        channel = Channel(unknown=True, drop=True)
        rows = receipt_rows()
        first, channel, _cursor = self.append(rows=copy.deepcopy(rows), channel=channel)
        self.assertEqual(first["reason"], "UNKNOWN_SEND_NO_REPLAY")
        second, channel, _cursor = self.append(rows=copy.deepcopy(rows), channel=channel)
        self.assertEqual(second["reason"], "UNKNOWN_SEND_NO_REPLAY")
        self.assertEqual(channel.sends, 1)

    def test_existing_pointer_is_read_back_without_second_append(self):
        channel = Channel()
        rows = receipt_rows()
        first, channel, _cursor = self.append(rows=copy.deepcopy(rows), channel=channel)
        second, channel, _cursor = self.append(rows=copy.deepcopy(rows), channel=channel)
        self.assertEqual(first["state"], "DEPOSITED_READBACK")
        self.assertEqual(second["reason"], "DUPLICATE_SAME_EVENT")
        self.assertEqual(channel.sends, 1)


if __name__ == "__main__":
    unittest.main()
