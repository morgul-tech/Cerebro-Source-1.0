"""Focused receiver-host tests; all provider rows below are offline test doubles."""
from __future__ import annotations

import sys
import hashlib
import tempfile
import unittest
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "mcp"), str(ROOT / "tooling" / "context")]

from adapters.x9_channel_ingress import (CHANNEL, SCHEMA, ChannelIdentity, PointerRecord,
                                         Readback, MATERIAL, STALE)
from control_context_tools import McpToolCallContext, VerifiedMcpIdentity
from control_context_remote_runtime import _file_sha256
from pm_owner_atomic import PmOwnerAssignment, _hash
from x9_receiver_host import X9ReceiverHost, configuration_from_mapping, X9ReceiverError


def fixture():
    common = {"tenant_ref": "tenant:1", "workspace_ref": "workspace:1",
              "consumer_ref": "CHATGPT_REMOTE_MCP", "project_ref": "project:1",
              "project_revision": 1, "session_revision": 1,
              "session_fingerprint": "a" * 64}
    def role(name, principal):
        return {"role": name, "assignment_ref": "assignment:" + name,
                "source_ref": "owner:policy", "identity": {**common,
                    "principal_ref": principal, "session_ref": "session:" + name,
                    "session_binding_id": "binding:" + name}}
    config = configuration_from_mapping({"config_ref": "config:x9", "channel": CHANNEL,
                                         "producer": role("producer", "principal:pm"),
                                         "receiver": role("receiver", "principal:x9")})
    owner = PmOwnerAssignment(owner_ref="owner:pm", tenant_ref="tenant:1",
                              workspace_ref="workspace:1", project_ref="project:1",
                              principal_ref="principal:pm", consumer_ref="CHATGPT_REMOTE_MCP",
                              session_ref="session:producer", session_binding_id="binding:producer")
    pointer = PointerRecord(SCHEMA, "closure:1", "event:1", "attempt:1", "owner:pm",
                            "PM_READY_HINT", "revision:1", "b" * 64, "claim:1", "packet:1",
                            "c" * 64, "queue:1", "principal:pm", "session:receiver",
                            "cut:1", "2099-01-01T00:00:00Z", ("way:home",), "pm-ready:1", 1)
    return config, owner, pointer


class Cursor:
    def __init__(self, pointer, *, seq=1, ready=True, active_hold=None):
        self.queries = []
        self.index = 0
        record = {"owner_ref": pointer.owner_ref, "referent_id": pointer.referent_id,
                  "receipt_ref": "receipt:1", "owner_seq": seq,
                  "claim_ref": pointer.claim_ref, "packet_ref": pointer.packet_ref,
                  "packet_sha256": pointer.packet_sha256, "queue_ref": pointer.queue_ref,
                  "revision_after": pointer.revision if seq == 1 else "revision:2",
                  "ready_state": "MATERIAL_READY" if ready else "BIND_AVAILABLE"}
        record["snapshot_sha256"] = _hash(record)
        projection = {"material_sha256": "d" * 64,
                      "source_cut": pointer.source_cut if seq == 1 else "cut:2",
                      "active_hold": active_hold}
        receipt = {"record_payload": record, "snapshot_sha256": record["snapshot_sha256"],
                   "projection_payload": projection}
        self.rows = [{"receipt_ref": "receipt:1"}, receipt, receipt]

    def execute(self, sql, params):
        self.queries.append((sql, params))

    def fetchone(self):
        value = self.rows[self.index]
        self.index += 1
        return value


class API:
    def __init__(self, config, cursor):
        self.config, self.cursor = config, cursor

    @contextmanager
    def _transaction(self, *, write=False):
        assert not write
        yield (self.cursor, SimpleNamespace(principal_ref="principal:x9"), None,
               self.config, self.config.receiver)


class Channel:
    def __init__(self, pointer, *, bad_hash=False, unknown=False):
        self.pointer = pointer
        self.bad_hash = bad_hash
        self.unknown = unknown
        self.disposition = None
        self.sends = 0

    def identity(self):
        return ChannelIdentity(CHANNEL, "principal:x9", True, True, True)

    def read_pointer_by_event_id(self, event_id):
        if event_id != self.pointer.event_id:
            return None
        return Readback(self.pointer, "f" * 64 if self.bad_hash else self.pointer.content_sha256,
                        "principal:pm", "revision:channel")

    def read_disposition_by_event_id(self, event_id):
        if self.disposition is None or event_id != self.pointer.event_id:
            return None
        return Readback(self.disposition, self.disposition.content_sha256,
                        "principal:x9", "revision:disposition")

    def append_disposition_once(self, record):
        self.sends += 1
        self.disposition = record
        return "UNKNOWN_SEND" if self.unknown else "ACCEPTED"


class HostTests(unittest.TestCase):
    def setUp(self):
        self.config, self.owner, self.pointer = fixture()
        self.host = X9ReceiverHost(config=self.config, authenticator=object(),
                                   connection_factory=lambda: None, pm_owner_assignment=self.owner)
        self.identity = VerifiedMcpIdentity("tenant:1", "workspace:1", "principal:x9",
                                            frozenset({"project_state:read", "project_state:transition"}),
                                            True)

    def context(self, session="session:receiver"):
        return McpToolCallContext(self.identity, {"openai/session": session},
                                  {"authorization": "Bearer offline-test"})

    def consume(self, *, seq=1, bad_hash=False, unknown=False, channel=None, active_hold=None):
        cursor = Cursor(self.pointer, seq=seq, active_hold=active_hold)
        channel = channel or Channel(self.pointer, bad_hash=bad_hash, unknown=unknown)
        with patch.object(self.host, "_channel", return_value=(channel, API(self.config, cursor))):
            value = self.host.consume({"event_id": "event:1"}, self.context())
        return value, channel, cursor

    def test_wrong_session_fails_before_custody_access(self):
        with self.assertRaisesRegex(X9ReceiverError, "X9_CURRENT_RECEIVER_SESSION_REQUIRED"):
            self.host._channel(self.context("session:other"))

    def test_receiver_read_and_consume_use_their_advertised_scopes(self):
        from control_context_remote_service import OAuthBearerAuthenticator
        from providers.x9_postgres_custody import PostgresX9SessionAPI
        self.host._authenticator = object.__new__(OAuthBearerAuthenticator)
        with patch.object(McpToolCallContext, "transport_session",
                          return_value={"session_ref": "session:receiver"}):
            with patch("x9_receiver_host.PostgresX9SessionAPI", wraps=PostgresX9SessionAPI) as api_type:
                self.host._channel(self.context())
                self.assertEqual(api_type.call_args.kwargs["required_scope"], "project_state:read")
                self.host._channel(self.context(), required_scope="project_state:transition")
                self.assertEqual(api_type.call_args.kwargs["required_scope"], "project_state:transition")

    def test_windows_crlf_migration_matches_governed_lf_checksum(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "migration.sql"
            path.write_bytes(b"SELECT 1;\r\nSELECT 2;\r\n")
            self.assertEqual(_file_sha256(path),
                             hashlib.sha256(b"SELECT 1;\nSELECT 2;\n").hexdigest())

    def test_forged_disposition_fields_are_not_accepted(self):
        with self.assertRaisesRegex(X9ReceiverError, "X9_CONSUME_EVENT_ID_REQUIRED"):
            self.host.consume({"event_id": "event:1", "disposition": MATERIAL}, self.context())

    def test_wrong_pointer_hash_never_reads_pm_or_appends(self):
        value, channel, cursor = self.consume(bad_hash=True)
        self.assertNotEqual(value["state"], "DISPOSITION_READBACK")
        self.assertEqual(channel.sends, 0)
        self.assertEqual(cursor.queries, [])

    def test_fresh_owner_material_and_scoped_queries(self):
        value, channel, cursor = self.consume()
        self.assertEqual(value["state"], "DISPOSITION_READBACK")
        self.assertEqual(value["disposition"]["disposition"], MATERIAL)
        self.assertEqual(channel.sends, 1)
        self.assertEqual(len(cursor.queries), 3)
        self.assertTrue(all("pm-ready:1" in params for _sql, params in cursor.queries))

    def test_exact_legacy_transition_marker_means_no_active_hold(self):
        marker = {"sender_use": "AFTER_OWNER_RECEIPT_READBACK",
                  "x9_consume": "NOT_YET_CLAIMED"}
        value, channel, _cursor = self.consume(active_hold=marker)
        self.assertEqual(value["state"], "DISPOSITION_READBACK")
        self.assertEqual(value["reason"], "NEW_CURRENT_PM_MATERIAL")
        self.assertEqual(channel.sends, 1)

    def test_nonexact_legacy_markers_remain_invalid(self):
        marker = {"sender_use": "AFTER_OWNER_RECEIPT_READBACK",
                  "x9_consume": "NOT_YET_CLAIMED"}
        variants = (
            {**marker, "other": "present"},
            {"sender_use": marker["sender_use"]},
            {"x9_consume": marker["x9_consume"]},
            {**marker, "sender_use": "BEFORE_OWNER_RECEIPT_READBACK"},
            {**marker, "x9_consume": "CLAIMED"},
        )
        for variant in variants:
            with self.subTest(variant=variant):
                value, channel, _cursor = self.consume(active_hold=variant)
                self.assertEqual(value["state"], "HOLD_UNREADABLE")
                self.assertEqual(value["reason"], "PM_ACTIVE_HOLD_BINDING_INVALID")
                self.assertEqual(channel.sends, 0)

    def test_canonical_active_hold_remains_action_due(self):
        canonical = {"blocked_edge": "edge:1", "first_observed_at": "2026-10-07T10:00:00Z",
                     "owner_ref": "owner:pm", "next_action": "CHECK", "next_check": "CHECK",
                     "escalation_to": "P22", "next_check_due": True, "orphaned": False}
        value, channel, _cursor = self.consume(active_hold=canonical)
        self.assertEqual(value["state"], "DISPOSITION_READBACK")
        self.assertEqual(value["reason"], "ACTIVE_HOLD_ACTION_OR_ESCALATION_DUE")
        self.assertEqual(channel.sends, 1)

    def test_superseded_owner_is_stale(self):
        value, channel, _cursor = self.consume(seq=2)
        self.assertEqual(value["disposition"]["disposition"], STALE)
        self.assertEqual(channel.sends, 1)

    def test_prior_receipt_is_idempotent_without_fresh_pm_read(self):
        channel = Channel(self.pointer)
        first, channel, _cursor = self.consume(channel=channel)
        self.assertEqual(first["state"], "DISPOSITION_READBACK")
        second, channel, cursor = self.consume(channel=channel)
        self.assertEqual(second["state"], "ALREADY_DISPOSED")
        self.assertEqual(channel.sends, 1)
        self.assertEqual(cursor.queries, [])

    def test_unknown_send_exact_readback_is_confirmed_without_retry(self):
        value, channel, _cursor = self.consume(unknown=True)
        self.assertEqual(value["state"], "DISPOSITION_READBACK")
        self.assertEqual(channel.sends, 1)


if __name__ == "__main__":
    unittest.main()
