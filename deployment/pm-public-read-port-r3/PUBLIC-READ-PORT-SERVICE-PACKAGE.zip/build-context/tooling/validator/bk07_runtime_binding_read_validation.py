#!/usr/bin/env python3
"""Exact read-only BK07 binding route checks; no live credential or provider write."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "mcp"))
sys.path.insert(0, str(ROOT / "tooling" / "context"))

from control_context_remote_service import (  # noqa: E402
    ControlContextRemoteMcpService, LocalRuntimeOAuthBinding,
    RemoteMcpServiceConfig, VerifiedBearerToken,
)
from control_context_tools import (  # noqa: E402
    ControlContextMcpTools, ControlContextToolAuthorizationError,
)

RESOURCE = "https://context.example.invalid"
ISSUER = "https://auth.example.invalid"
CLIENT = "bk07-client"
REF = "local:fixed-session"


class Verifier:
    def __init__(self, claims):
        self.claims = claims

    def verify(self, _token):
        return VerifiedBearerToken(self.claims, True)


class Port:
    def __init__(self):
        self.calls = []
        self.project = {"project_ref": "PROJECT", "revision": 1, "project_status": "ACTIVE"}
        self.session = {
            "tenant_ref": "TENANT", "workspace_ref": "WORKSPACE", "project_ref": "PROJECT",
            "principal_ref": CLIENT + "@clients", "consumer_ref": "LOCAL_CEREBRO_RUNTIME",
            "session_ref": REF, "session_binding_id": "CSB-ONE", "project_revision": 1,
            "session_revision": 1, "fingerprint": "a" * 64,
        }

    def read_project(self, **kw):
        self.calls.append(("project", kw))
        return dict(self.project)

    def read_session(self, **kw):
        self.calls.append(("session", kw))
        return dict(self.session)


class RuntimeBindingReadTests(unittest.TestCase):
    def setUp(self):
        self.port = Port()
        self.binding = LocalRuntimeOAuthBinding(
            issuer=ISSUER, client_id=CLIENT, tenant_ref="TENANT",
            workspace_ref="WORKSPACE", project_ref="PROJECT",
            principal_ref=CLIENT + "@clients", runtime_audience=RESOURCE + "/bk07-runtime",
            session_ref=REF, enabled=False)
        self.claims = {
            "iss": ISSUER, "aud": RESOURCE + "/bk07-runtime", "azp": CLIENT,
            "sub": CLIENT + "@clients", "gty": "client-credentials",
            "scope": "project_state:read", "iat": 950, "exp": 1200,
            "cerebro_tenant": "TENANT", "cerebro_workspace": "WORKSPACE",
            "cerebro_project": "PROJECT",
        }

    def service(self):
        config = RemoteMcpServiceConfig(
            resource=RESOURCE, authorization_servers=(ISSUER,),
            resource_documentation=RESOURCE + "/docs", local_runtime_binding=self.binding)
        tools = ControlContextMcpTools(
            self.port, type("Attestor", (), {"verify": lambda *a: None})(),
            local_runtime_binding=self.binding)
        return ControlContextRemoteMcpService(
            config=config, tools=tools, token_verifier=Verifier(self.claims),
            readiness_probe=lambda: True, clock=lambda: 1000)

    def call(self, name="read_local_runtime_binding_v1", args=None):
        return self.service().invoke(
            tool_name=name, args={} if args is None else args,
            headers={"Authorization": "Bearer synthetic"}, request_meta={})

    def test_off_read_is_exact_and_resolve_remains_disabled(self):
        value = self.call()["structuredContent"]
        self.assertEqual(value["currentness"], "CURRENT")
        self.assertEqual(value["binding"], {
            "binding_id": "CSB-ONE", "binding_fingerprint": "a" * 64,
            "project_revision": 1, "session_revision": 1, "session_ref": REF,
            "issuer": ISSUER, "client_id": CLIENT, "audience": RESOURCE + "/bk07-runtime",
            "tenant": "TENANT", "workspace": "WORKSPACE", "project": "PROJECT",
            "principal": CLIENT + "@clients", "enabled": False,
        })
        self.assertEqual(self.port.calls[1][1]["session_ref"], REF)
        self.assertEqual(self.port.calls[1][1]["consumer_ref"], "LOCAL_CEREBRO_RUNTIME")
        self.assertTrue(self.call("transport_resolve_signalvev_notice_v1",
                                  {"event_id": "pm-event:one"})["isError"])

    def test_no_caller_tuple_or_other_tool(self):
        with self.assertRaisesRegex(ControlContextToolAuthorizationError, "arguments-prohibited"):
            self.call(args={"session_ref": "local:forged"})
        with self.assertRaisesRegex(ControlContextToolAuthorizationError, "NO_ARGUMENTS"):
            self.call(args={"selector": "forged"})
        self.assertEqual(self.port.calls, [])
        self.assertTrue(self.call("read_project_control_state",
                                  {"project_ref": "PROJECT"})["isError"])

    def test_wrong_credential_is_denied_before_state_access(self):
        baseline = dict(self.claims)
        for change in ({"iss": "https://other.example.invalid"}, {"aud": RESOURCE},
                       {"azp": "other"}, {"sub": "other@clients"},
                       {"scope": "project_state:read project_state:transition"},
                       {"cerebro_tenant": "OTHER"}, {"cerebro_workspace": "OTHER"},
                       {"cerebro_project": "OTHER"}, {"exp": 1301}):
            with self.subTest(change=change):
                self.claims = dict(baseline, **change)
                self.assertTrue(self.call()["isError"])
                self.assertEqual(self.port.calls, [])
        self.claims = baseline

    def test_stale_or_wrong_persisted_binding_is_denied(self):
        for target, change in (("project", {"project_status": "PAUSED"}),
                               ("session", {"project_revision": 2}),
                               ("session", {"session_ref": "local:wrong"}),
                               ("session", {"consumer_ref": "CHATGPT_REMOTE_MCP"})):
            with self.subTest(change=change):
                current = getattr(self.port, target)
                setattr(self.port, target, dict(current, **change))
                with self.assertRaisesRegex(ControlContextToolAuthorizationError,
                                            "RUNTIME_BINDING_NOT_CURRENT"):
                    self.call()
                setattr(self.port, target, current)


if __name__ == "__main__":
    unittest.main()
