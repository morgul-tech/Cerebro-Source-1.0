"""Real Context service/tool classes around the versioned PM notice bridge.

Only the database/channel effects are replaced; this is not a live credential
or NATS test. The existing X9ProducerHost validation covers those effects.
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest import TestCase
from unittest.mock import patch
from datetime import datetime, timezone
from dataclasses import asdict, replace

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "mcp"), str(ROOT / "tooling" / "validator")]

from control_context_remote_service import (  # noqa: E402
    ControlContextRemoteMcpService, RemoteMcpServiceConfig, VerifiedBearerToken,
    LocalRuntimeOAuthBinding,
    OAuthBearerAuthenticator, RemoteMcpAuthenticationError,
)
from control_context_state_port import InMemoryControlContextStatePort  # noqa: E402
from control_context_tools import (  # noqa: E402
    ControlContextMcpTools, ControlContextToolAuthorizationError,
    HmacControlResolutionAttestor, McpToolCallContext,
)
from x9_producer_host import X9ProducerHost  # noqa: E402
from x9_receiver_host import X9ReceiverHost  # noqa: E402
from x9_receiver_host_validation import API as ReceiverAPI, Channel as ReceiverChannel, Cursor as ReceiverCursor  # noqa: E402
from x9_receiver_host_validation import fixture  # noqa: E402
from pm_owner_atomic import _hash  # noqa: E402
from signalvev_runtime_resolution import (  # noqa: E402
    RuntimeBinding, RuntimeResolutionHost, PostgresRuntimeNoticeReader, RuntimeResolutionError,
)
from adapters.x9_channel_ingress import PMOwnerCut, Readback  # noqa: E402


class Verifier:
    def verify(self, token):
        if token not in {"pm-token", "x9-token", "runtime-token", "runtime-wide-token"}:
            return VerifiedBearerToken(claims={}, signature_verified=False)
        receiver = token == "x9-token"
        runtime = token.startswith("runtime-")
        return VerifiedBearerToken(claims={
            "iss": "https://auth.cerebro.invalid",
            "aud": "https://mcp.cerebro.invalid/bk07-runtime" if runtime
                   else "https://mcp.cerebro.invalid",
            "exp": 2_000_000_300 if runtime else 2_000_003_600,
            "iat": 2_000_000_000 if runtime else 1_999_999_000,
            "nbf": 1_999_999_940,
            "scope": "project_state:read project_state:transition" if token == "runtime-wide-token"
                     else "project_state:read" if receiver or runtime else "project_state:transition",
            "sub": "client:runtime@clients" if runtime else "principal:x9" if receiver else "principal:pm",
            "azp": "client:runtime" if runtime else "client:other",
            "gty": "client-credentials" if runtime else "authorization_code",
            "cerebro_project": "project:1" if runtime else "project:other",
            "cerebro_tenant": "tenant:1",
            "cerebro_workspace": "workspace:1",
        }, signature_verified=True)


class ReaderFixture(PostgresRuntimeNoticeReader):
    def __init__(self, binding, callback):
        self._binding, self._callback = binding, callback

    def read_current(self, event_id):
        return self._callback(event_id)


class CustodyCursor:
    def __init__(self, *, pointer, config, original, current, projection,
                 tamper=False, missing=False):
        self.pointer, self.config = pointer, config
        self.original, self.current, self.projection = original, current, projection
        self.tamper, self.missing = tamper, missing
        self.queries, self.rows = [], []

    def execute(self, sql, params=None):
        self.queries.append(sql)
        self.rows = []
        if "FROM cerebro_control_session_bindings s JOIN" in sql:
            self.rows = [{"session_binding_id": "binding:runtime", "session_revision": 1,
                          "session_fingerprint": "f" * 64, "project_revision": 1,
                          "aggregate_revision": 1, "project_status": "ACTIVE"}]
        elif "FROM cerebro_x9_channel_records" in sql and not self.missing:
            producer, receiver = self.config.producer, self.config.receiver
            self.rows = [{"record_payload": asdict(self.pointer),
                "content_sha256": "0" * 64 if self.tamper else self.pointer.content_sha256,
                "writer_principal": producer.identity.principal_ref,
                "writer_consumer": producer.identity.consumer_ref,
                "writer_session": producer.identity.session_ref,
                "writer_role": producer.role, "writer_assignment_ref": producer.assignment_ref,
                "peer_role": receiver.role, "peer_assignment_ref": receiver.assignment_ref,
                "peer_session_ref": receiver.identity.session_ref,
                "config_ref": self.config.config_ref, "provider_revision": 1}]
        elif "record_payload->>'commit_ref'" in sql:
            self.rows = [{"record_payload": self.original,
                          "snapshot_sha256": self.original["snapshot_sha256"],
                          "projection_payload": self.projection}]
        elif "FROM cerebro_pm_owner_current" in sql:
            self.rows = [{"receipt_ref": self.current["receipt_ref"]}]
        elif "FROM cerebro_pm_owner_receipts" in sql:
            self.rows = [{"record_payload": self.current,
                          "snapshot_sha256": self.current["snapshot_sha256"],
                          "projection_payload": self.projection}]

    def fetchone(self):
        return self.rows.pop(0) if self.rows else None

    def close(self):
        pass


class CustodyConnection:
    autocommit = False
    def __init__(self, cursor):
        self._cursor, self.rolled_back = cursor, False
    def cursor(self):
        return self._cursor
    def rollback(self):
        self.rolled_back = True
    def close(self):
        pass


class NoticeBridgeTests(TestCase):
    def setUp(self):
        config, owner, self.pointer = fixture()
        self.producer = X9ProducerHost(config=config, pm_owner_assignment=owner,
                                       authenticator=object(), connection_factory=lambda: None)
        self.receiver = X9ReceiverHost(config=config, pm_owner_assignment=owner,
                                       authenticator=object(), connection_factory=lambda: None)
        tools = ControlContextMcpTools(
            InMemoryControlContextStatePort(),
            HmacControlResolutionAttestor(key_id="test", secret=b"test-secret-for-bridge-000000000000"),
        )
        tools.bind_x9_producer(self.producer)
        tools.bind_x9_receiver(self.receiver)
        self.tools = tools
        self.service = ControlContextRemoteMcpService(
            config=RemoteMcpServiceConfig(
                resource="https://mcp.cerebro.invalid",
                authorization_servers=("https://auth.cerebro.invalid",),
                resource_documentation="https://docs.cerebro.invalid/bridge"),
            tools=tools, token_verifier=Verifier(), readiness_probe=lambda: True,
            clock=lambda: 2_000_000_000.0,
        )
        self.record = {"receipt_ref": "pm-receipt:test1", "event_id": "pm-event:test1",
                       "ready_state": "MATERIAL_READY", "owner_ref": "owner:pm",
                       "referent_id": "pm-ready:test1", "owner_seq": 1,
                       "revision_after": "pm-revision:test1", "revision_before": None,
                       "claim_ref": "claim:test1", "packet_ref": "packet:test1",
                       "queue_ref": "queue:test1", "packet_sha256": "c" * 64,
                       "commit_ref": "pm-commit:test1", "snapshot_ref": "pm-snapshot:test1",
                       "readback_ref": "pm-readback:test1",
                       "observed_at": datetime.now(timezone.utc).isoformat(),
                       "way_home": ["way:pm", "way:x9"]}
        self.record["snapshot_sha256"] = _hash(self.record)
        self.projection = {"source_cut": "pm-cut:test1", "material_sha256": "a" * 64}

    def invoke(self, args, token="pm-token"):
        return self.service.invoke(
            tool_name="prepare_signalvev_notice_v1", args=args,
            headers={"authorization": "Bearer " + token},
            request_meta={"openai/session": "session:producer"},
        )

    def test_exact_receipt_current_response_shape(self):
        def append(args, context):
            self.assertIs(type(context), McpToolCallContext)
            self.assertEqual(context.transport_session()["session_ref"], "chatgpt:session:producer")
            self.assertEqual(context.identity.principal_ref, "principal:pm")
            self.assertEqual(args, {"receipt_ref": "pm-receipt:test1"})
            return {"state": "DEPOSITED_READBACK", "event_id": "pm-event:test1",
                    "pointer_sha256": "b" * 64}
        with (patch.object(self.producer, "append_pointer", side_effect=append),
              patch.object(self.producer, "_channel", return_value=(object(), object())),
              patch.object(self.producer, "_receipt", return_value=(self.record, self.projection))):
            result = self.invoke({"receipt_ref": "pm-receipt:test1"})
        value = result["structuredContent"]
        self.assertEqual(value["schema"], "cerebro-signalvev-notice-preparation/v1")
        self.assertEqual(value["state"], "DEPOSITED_READBACK")
        self.assertEqual(value["record"], self.record)
        self.assertEqual(value["projection"], self.projection)
        self.assertFalse(value["repository_permission_required"])

    def test_changed_receipt_after_deposit_fails_closed(self):
        with (patch.object(self.producer, "append_pointer", return_value={
                  "state": "DEPOSITED_READBACK", "event_id": "pm-event:test1"}),
              patch.object(self.producer, "_channel", return_value=(object(), object())),
              patch.object(self.producer, "_receipt", return_value=(
                  {**self.record, "receipt_ref": "pm-receipt:changed"}, self.projection))):
            with self.assertRaisesRegex(ControlContextToolAuthorizationError,
                                        "SIGNALVEV_OWNER_CHANGED_AFTER_DEPOSIT"):
                self.invoke({"receipt_ref": "pm-receipt:test1"})

    def test_non_deposited_result_never_claims_notice_ready(self):
        with patch.object(self.producer, "append_pointer", return_value={
            "state": "HOLD_UNREADABLE", "event_id": "pm-event:test1"}):
            value = self.invoke({"receipt_ref": "pm-receipt:test1"})["structuredContent"]
        self.assertEqual(value["state"], "HOLD_UNREADABLE")
        self.assertNotIn("record", value)

    def test_extra_caller_fields_and_wrong_token_fail_before_effect(self):
        with patch.object(self.producer, "append_pointer") as append:
            with self.assertRaisesRegex(ControlContextToolAuthorizationError, "SIGNALVEV_RECEIPT_REF_ONLY"):
                self.invoke({"receipt_ref": "pm-receipt:test1", "role": "producer"})
            self.assertTrue(self.invoke({"receipt_ref": "pm-receipt:test1"}, token="bad")["isError"])
            append.assert_not_called()

    def test_receiver_observes_fresh_pm_cut_without_disposition(self):
        channel = ReceiverChannel(self.pointer)
        cursor = ReceiverCursor(self.pointer)
        with patch.object(self.receiver, "_channel", return_value=(
                channel, ReceiverAPI(self.receiver._config, cursor))):
            result = self.service.invoke(
                tool_name="observe_signalvev_notice_v1",
                args={"event_id": self.pointer.event_id},
                headers={"authorization": "Bearer x9-token"},
                request_meta={"openai/session": "session:receiver"},
            )
        value = result["structuredContent"]
        self.assertEqual(value["schema"], "cerebro-signalvev-notice-observation/v1")
        self.assertEqual(value["state"], "CURRENT_READBACK")
        self.assertEqual(value["event_id"], self.pointer.event_id)
        self.assertEqual(value["pm_current_cut"]["relation_to_hint"], "SAME")
        self.assertIsNone(channel.disposition)
        self.assertEqual(channel.sends, 0)

    def test_receiver_wrong_scope_fails_before_read(self):
        with patch.object(self.receiver, "observe_signalvev_notice") as observe:
            result = self.service.invoke(
                tool_name="observe_signalvev_notice_v1",
                args={"event_id": self.pointer.event_id},
                headers={"authorization": "Bearer pm-token"},
                request_meta={"openai/session": "session:producer"},
            )
        # A PM token has transition scope but not read scope; no X9 effect.
        self.assertTrue(result["isError"])
        observe.assert_not_called()

    def test_runtime_resolve_is_default_off_and_resolve_only(self):
        self.pointer = replace(self.pointer, event_id="pm-event:test1")
        reader = __import__("unittest.mock", fromlist=["Mock"]).Mock(return_value=None)
        binding_ref = RuntimeBinding("tenant:1", "workspace:1", "project:1",
                                     "client:runtime@clients", "session:runtime")
        self.tools.bind_runtime_notice_resolver(RuntimeResolutionHost(
            binding=binding_ref, reader=ReaderFixture(binding_ref, reader), enabled=True))
        args = {"event_id": self.pointer.event_id}
        invoke = lambda tool, token: self.service.invoke(
            tool_name=tool, args=args, headers={"authorization": "Bearer " + token},
            request_meta={})
        self.assertTrue(invoke("transport_resolve_signalvev_notice_v1", "runtime-token")["isError"])
        self.assertTrue(invoke("transport_resolve_signalvev_notice_v1", "x9-token")["isError"])
        reader.assert_not_called()
        binding = LocalRuntimeOAuthBinding("https://auth.cerebro.invalid", "client:runtime",
                                           "tenant:1", "workspace:1", "project:1", "client:runtime@clients",
                                           "https://mcp.cerebro.invalid/bk07-runtime",
                                           "session:runtime", True)
        service = ControlContextRemoteMcpService(
            config=RemoteMcpServiceConfig("https://mcp.cerebro.invalid",
                                          ("https://auth.cerebro.invalid",),
                                          "https://docs.cerebro.invalid/bridge",
                                          local_runtime_binding=binding),
            tools=self.tools, token_verifier=Verifier(), readiness_probe=lambda: True,
            clock=lambda: 2_000_000_000.0)
        call = lambda tool, token: service.invoke(tool_name=tool, args=args,
            headers={"authorization": "Bearer " + token}, request_meta={})
        self.assertTrue(call("read_x9_pointer", "runtime-token")["isError"])
        shared_runtime_claims = dict(Verifier().verify("runtime-token").claims)
        shared_runtime_claims["aud"] = "https://mcp.cerebro.invalid"
        shared_runtime_verifier = type("SharedRuntimeVerifier", (), {
            "verify": lambda self, token: VerifiedBearerToken(
                claims=shared_runtime_claims, signature_verified=True)})()
        shared_runtime_auth = OAuthBearerAuthenticator(
            config=service._config, token_verifier=shared_runtime_verifier,
            clock=lambda: 2_000_000_000.0)
        with self.assertRaises(RemoteMcpAuthenticationError):
            shared_runtime_auth.authenticate({"authorization": "Bearer runtime-token"},
                required_scope="project_state:read", tool_name="read_x9_pointer")
        self.assertTrue(call("transport_resolve_signalvev_notice_v1", "x9-token")["isError"])
        self.assertTrue(call("transport_resolve_signalvev_notice_v1", "runtime-wide-token")["isError"])
        self.assertEqual(call("transport_resolve_signalvev_notice_v1", "runtime-token")
                         ["structuredContent"]["state"], "UNKNOWN")
        reader.assert_called_once_with(self.pointer.event_id)

    def test_runtime_resolve_server_derives_hash_and_fresh_relation(self):
        self.pointer = replace(self.pointer, event_id="pm-event:test1")
        cut = PMOwnerCut(owner_ref=self.pointer.owner_ref, claim_ref=self.pointer.claim_ref,
                         packet_ref=self.pointer.packet_ref, packet_sha256=self.pointer.packet_sha256,
                         queue_ref=self.pointer.queue_ref, revision=self.pointer.revision,
                         relation_to_hint="SAME", material_sha256="a" * 64,
                         source_cut=self.pointer.source_cut, committed_readback=True,
                         authenticated=True, material_ready=True)
        stored = Readback(self.pointer, self.pointer.content_sha256,
                          self.pointer.producer_id, "x9pg:1")
        samples = [(stored, cut), (Readback(self.pointer, "0" * 64,
                                           self.pointer.producer_id, "x9pg:1"), cut), None]
        def read(event_id):
            self.assertEqual(event_id, self.pointer.event_id)
            return samples.pop(0)
        binding_ref = RuntimeBinding("tenant:1", "workspace:1", "project:1",
                                     "client:runtime@clients", "session:runtime")
        resolver = RuntimeResolutionHost(binding=binding_ref,
                                         reader=ReaderFixture(binding_ref, read), enabled=True)
        identity = type("Identity", (), {"tenant_ref": "tenant:1", "workspace_ref": "workspace:1",
            "principal_ref": "client:runtime@clients", "consumer_ref": "LOCAL_CEREBRO_RUNTIME",
            "state_scopes": frozenset({"project_state:read"})})()
        args = {"event_id": self.pointer.event_id}
        first = resolver.resolve(args, identity)
        self.assertEqual(first["state"], "SAME")
        self.assertEqual(first["pointer_sha256"], self.pointer.content_sha256)
        self.assertEqual(resolver.resolve(args, identity)["state"], "UNKNOWN")
        self.assertEqual(resolver.resolve(args, identity)["state"], "UNKNOWN")
        tampered = RuntimeResolutionHost(binding=binding_ref,
            reader=ReaderFixture(binding_ref, lambda event_id: (_ for _ in ()).throw(
                RuntimeResolutionError("POINTER_CUSTODY_MISMATCH"))), enabled=True)
        self.assertEqual(tampered.resolve(args, identity)["state"], "UNKNOWN")

    def test_postgres_runtime_reader_current_stale_missing_and_tamper(self):
        config, owner, _ = fixture()
        original = {"owner_ref": owner.owner_ref, "referent_id": "pm-ready:1",
                    "receipt_ref": "pm-receipt:1", "event_id": "pm-event:1",
                    "owner_seq": 1, "claim_ref": "claim:1", "packet_ref": "packet:1",
                    "packet_sha256": "c" * 64, "queue_ref": "queue:1",
                    "revision_after": "revision:1", "commit_ref": "commit:1",
                    "ready_state": "MATERIAL_READY"}
        original["snapshot_sha256"] = _hash(original)
        pointer = replace(self.pointer, event_id=original["event_id"],
                          attempt_id=original["commit_ref"],
                          expected_sha256=original["snapshot_sha256"],
                          referent_id=original["referent_id"],
                          revision=original["revision_after"])
        projection = {"source_cut": pointer.source_cut, "material_sha256": "a" * 64}
        binding = RuntimeBinding("tenant:1", "workspace:1", "project:1",
                                 "principal:runtime", "session:runtime")
        for stale, missing, tamper, expected in (
                (False, False, False, "SAME"), (True, False, False, "SUPERSEDED"),
                (False, True, False, None), (False, False, True, "ERROR")):
            current = dict(original)
            if stale:
                current.update(receipt_ref="pm-receipt:2", owner_seq=2,
                               revision_after="revision:2")
                current["snapshot_sha256"] = _hash({k:v for k,v in current.items()
                                                      if k != "snapshot_sha256"})
            cursor = CustodyCursor(pointer=pointer, config=config, original=original,
                                   current=current, projection=projection,
                                   missing=missing, tamper=tamper)
            conn = CustodyConnection(cursor)
            reader = PostgresRuntimeNoticeReader(binding=binding, pm_owner=owner,
                x9_config=config, connection_factory=lambda: conn)
            if expected == "ERROR":
                with self.assertRaisesRegex(ValueError, "POINTER_CUSTODY_MISMATCH"):
                    reader.read_current(pointer.event_id)
            else:
                result = reader.read_current(pointer.event_id)
                self.assertEqual(None if result is None else result[1].relation_to_hint,
                                 expected)
            self.assertTrue(conn.rolled_back)
            self.assertTrue(any("READ ONLY" in q for q in cursor.queries))
            self.assertFalse(any(q.lstrip().startswith(("INSERT", "UPDATE", "DELETE"))
                                 for q in cursor.queries))

    def test_runtime_oauth_rejects_cross_client_project_and_long_token(self):
        binding = LocalRuntimeOAuthBinding("https://auth.cerebro.invalid", "client:runtime",
            "tenant:1", "workspace:1", "project:1", "client:runtime@clients",
            "https://mcp.cerebro.invalid/bk07-runtime",
            "session:runtime", True)
        config = RemoteMcpServiceConfig("https://mcp.cerebro.invalid",
            ("https://auth.cerebro.invalid",), "https://docs.cerebro.invalid/bridge",
            local_runtime_binding=binding)
        base = dict(Verifier().verify("runtime-token").claims)
        for change in ({"aud": "https://mcp.cerebro.invalid"},
                       {"aud": ["https://mcp.cerebro.invalid/bk07-runtime",
                                "https://mcp.cerebro.invalid"]},
                       {"aud": ["https://mcp.cerebro.invalid/bk07-runtime",
                                "https://mcp.cerebro.invalid/bk07-runtime"]},
                       {"azp": "client:other"}, {"gty": "authorization_code"},
                       {"sub": "user:other"}, {"cerebro_project": "project:other"},
                       {"exp": 2_000_000_301}, {"cerebro_tenant": "tenant:other"},
                       {"scope": "project_state:read project_state:transition"}):
            claims = {**base, **change}
            verifier = type("ClaimVerifier", (), {"verify": lambda self, token: VerifiedBearerToken(
                claims=claims, signature_verified=True)})()
            auth = OAuthBearerAuthenticator(config=config, token_verifier=verifier,
                                            clock=lambda: 2_000_000_000.0)
            with self.assertRaises(RemoteMcpAuthenticationError):
                auth.authenticate({"authorization": "Bearer runtime-token"},
                    required_scope="project_state:read",
                    tool_name="transport_resolve_signalvev_notice_v1")

    def test_runtime_audience_must_be_dedicated_resource(self):
        binding = LocalRuntimeOAuthBinding("https://auth.cerebro.invalid", "client:runtime",
            "tenant:1", "workspace:1", "project:1", "client:runtime@clients",
            "https://mcp.cerebro.invalid", "session:runtime", True)
        with self.assertRaisesRegex(Exception, "runtime-audience-must-match-dedicated-resource"):
            RemoteMcpServiceConfig("https://mcp.cerebro.invalid",
                ("https://auth.cerebro.invalid",), "https://docs.cerebro.invalid/bridge",
                local_runtime_binding=binding)
