#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path
from typing import Any, Callable


SOURCE_ROOT = Path(__file__).resolve().parents[2]
CONTEXT_TOOLING = SOURCE_ROOT / "tooling" / "context"
MCP_ROOT = SOURCE_ROOT / "mcp"
if str(CONTEXT_TOOLING) not in sys.path:
    sys.path.insert(0, str(CONTEXT_TOOLING))
if str(MCP_ROOT) not in sys.path:
    sys.path.insert(0, str(MCP_ROOT))

from control_context_registry import (  # noqa: E402
    DIRECTIVE_SCHEMA,
    ControlContextError,
    ancestor_chain,
    apply_transition,
    actor_generation_shadow_fingerprint,
    bind_control_session,
    bootstrap_actor_generation_shadow,
    bootstrap_project_state,
    bootstrap_work_claim_shadow,
    lowest_common_ancestor,
    principal_continuity_baseline_fingerprint,
    provider_allocation_receipt_fingerprint,
    requalify_principal_generation_shadow,
    refresh_project_fingerprints,
    refresh_session_fingerprint,
    transition_actor_generation_shadow,
    transition_work_claim_shadow,
    validate_actor_generation_shadow,
    validate_principal_continuity_baseline,
    validate_project_state,
    validate_session_state,
    validate_trusted_role_generation_binding,
    validate_work_claim_allocation_dedup,
    validate_work_claim_shadow,
    validate_transition_receipt,
    stable_unknown_fingerprint,
    work_claim_shadow_fingerprint,
)
from control_context_state_port import (  # noqa: E402
    BEGIN_SCHEMA,
    InMemoryControlContextStatePort,
    StateAuthorizationError,
    StateBindingError,
    StateConflict,
    StatePortError,
    StateServiceUnavailable,
)
from control_owner_effect_receipt import build_owner_effect_receipt  # noqa: E402


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("json-object-required")
    return value


def _write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _root() -> dict[str, Any]:
    return {
        "context_id": "CTX-ROOT",
        "human_label": "Hovedspor",
        "objective_ref": "OBJ-ROOT",
        "scope_ref": "SCOPE-ROOT",
        "basis_refs": ["BASIS-ROOT"],
        "project_basis_ref": "PROJECT-BASIS-1",
        "quality_trace_ref": "QUALITY-DEEP-1",
        "completion_criteria_refs": ["ROOT-DONE"],
    }


def _child(context_id: str, parent: str, objective: str | None = None) -> dict[str, Any]:
    return {
        "operation": "CREATE_CHILD",
        "parent_context_ref": parent,
        "context_id": context_id,
        "human_label": context_id.replace("CTX-", "Gren "),
        "objective_ref": objective or f"OBJ-{context_id}",
        "scope_ref": f"SCOPE-{context_id}",
        "basis_refs": [f"BASIS-{context_id}"],
        "project_basis_ref": "PROJECT-BASIS-1",
        "quality_trace_ref": "QUALITY-DEEP-1",
        "completion_criteria_refs": [f"DONE-{context_id}"],
    }


def _binding(context_ref: str, binding_id: str | None = None, alias: str = "Fortsett denne grenen") -> dict[str, Any]:
    return {
        "binding_id": binding_id or f"BIND-{context_ref}",
        "surface_kind": "HNS",
        "alias": alias,
        "operation": "CONTINUE_CURRENT",
        "target_ref": context_ref,
        "context_ref": context_ref,
    }


def _return_operation(begin: dict[str, Any], context_ref: str, result_ref: str) -> dict[str, Any]:
    context = next(item for item in begin["project"]["contexts"] if item["context_id"] == context_ref)
    return {
        "operation": "RETURN_CONTEXT",
        "context_ref": context_ref,
        "result_ref": result_ref,
        "evidence_refs": [f"EVIDENCE-{context_ref}"],
        "unresolved_refs": [],
        "completion_proof_ref": f"COMPLETION-{context_ref}",
        "completion_criteria_satisfied": True,
        "child_basis_fingerprint": context["basis_fingerprint"],
    }


def _join_and_close(context_ref: str, disposition: str, owner_receipt_ref: str) -> list[dict[str, Any]]:
    return [
        {
            "operation": "APPLY_JOIN_DISPOSITION",
            "context_ref": context_ref,
            "disposition": disposition,
            "dependent_owner_state_current": True,
            "owner_effect_receipt_ref": owner_receipt_ref,
        },
        {"operation": "CLOSE_CONTEXT", "context_ref": context_ref},
    ]


def _begin(port: InMemoryControlContextStatePort, chat: str, event_id: str, key: str) -> dict[str, Any]:
    return port.begin_event(
        {
            "schema": BEGIN_SCHEMA,
            "tenant_ref": "TENANT-1",
            "workspace_ref": "WORKSPACE-1",
            "principal_ref": "ADMIN-1",
            "consumer_ref": "CHATGPT",
            "session_ref": chat,
            "event_id": event_id,
            "idempotency_key": key,
        },
        scopes={"project_state:read", "project_state:transition"},
    )


def _directive(
    begin: dict[str, Any],
    event_id: str,
    project_operations: list[dict[str, Any]] | None = None,
    session_operations: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    return {
        "schema": DIRECTIVE_SCHEMA,
        "event_id": event_id,
        "decision_ref": f"DEC-{event_id}",
        "expected_project_revision": begin["expected_project_revision"],
        "expected_project_fingerprint": begin["expected_project_fingerprint"],
        "expected_session_revision": begin["expected_session_revision"],
        "expected_session_fingerprint": begin["expected_session_fingerprint"],
        "project_operations": project_operations or [],
        "session_operations": session_operations or [],
    }


def _complete(
    port: InMemoryControlContextStatePort,
    chat: str,
    event_id: str,
    directive: dict[str, Any],
    *,
    owner_effect_candidate: dict[str, Any] | None = None,
) -> dict[str, Any]:
    request = {
        "tenant_ref": "TENANT-1",
        "workspace_ref": "WORKSPACE-1",
        "principal_ref": "ADMIN-1",
        "consumer_ref": "CHATGPT",
        "session_ref": chat,
        "event_id": event_id,
        "directive": directive,
    }
    if owner_effect_candidate is not None:
        request["owner_effect_candidate"] = owner_effect_candidate
    return port.complete_event(
        request,
        scopes={"project_state:read", "project_state:transition"},
    )


def _expect_error(function: Callable[[], Any], expected: type[BaseException]) -> bool:
    try:
        function()
    except expected:
        return True
    return False


def selftest() -> dict[str, Any]:
    tests: list[dict[str, Any]] = []

    def check(name: str, condition: bool, evidence: Any = None) -> None:
        tests.append({"name": name, "result": "PASS" if condition else "FAIL", "evidence": evidence})

    scopes = {"project_state:read", "project_state:transition"}
    port = InMemoryControlContextStatePort()
    boot = port.bootstrap_project(
        tenant_ref="TENANT-1",
        workspace_ref="WORKSPACE-1",
        principal_ref="ADMIN-1",
        project_ref="TOTAL_MCP_REVISION",
        aggregate_id="AGG-TOTAL-MCP-REVISION",
        source_revision="b49110d16f363f58d1cd79432acb236ab3ac3014",
        event_id="E00",
        decision_ref="DEC-PROJECT-START",
        root=_root(),
        scopes=scopes,
    )
    project = boot["project"]
    check("R02-new-project-has-exactly-one-root", validate_project_state(project)["context_count"] == 1)
    check("R60-new-project-keeps-distinct-identity", project["project_ref"] != "CEREBRO-WORKPLAN")

    for chat in ("CHAT-A", "CHAT-B"):
        port.bind_session(
            tenant_ref="TENANT-1",
            workspace_ref="WORKSPACE-1",
            principal_ref="ADMIN-1",
            consumer_ref="CHATGPT",
            session_ref=chat,
            session_binding_id=f"SESSION-{chat}",
            scopes=scopes,
        )

    begin_a = _begin(port, "CHAT-A", "E01", "K01")
    create_a = _directive(
        begin_a,
        "E01",
        [_child("CTX-A", "CTX-ROOT")],
        [
            {"operation": "SET_ACTIVE", "context_ref": "CTX-A"},
            {"operation": "SET_CONTINUATION_BINDING", "binding": _binding("CTX-A", "BIND-A")},
        ],
    )
    complete_a = _complete(port, "CHAT-A", "E01", create_a)
    check("R08-material-fork-creates-one-child", len(complete_a["project"]["contexts"]) == 2)
    check("R13-switch-is-session-scoped", complete_a["session"]["active_context_ref"] == "CTX-A")
    check("R55-transition-needs-no-repository-permission", complete_a["repository_permission_required"] is False)
    check(
        "R36-transition-receipt-is-valid-and-effect-bound",
        validate_transition_receipt(complete_a["receipt"])["mutated"] is True
        and complete_a["receipt"]["active_context_ref_after"] == "CTX-A",
    )

    check(
        "stale-read-does-not-silently-mutate-session",
        _expect_error(
            lambda: port.read_session(
                tenant_ref="TENANT-1",
                workspace_ref="WORKSPACE-1",
                principal_ref="ADMIN-1",
                consumer_ref="CHATGPT",
                session_ref="CHAT-B",
                scopes=scopes,
            ),
            StateBindingError,
        ),
    )
    begin_b = _begin(port, "CHAT-B", "E02", "K02")
    check("R54A-other-session-focus-unchanged", begin_b["session"]["active_context_ref"] == "CTX-ROOT")
    check("stale-session-rehydration-is-receipted", isinstance(begin_b["rehydration_receipt"], dict))

    before_detour = copy.deepcopy(complete_a["session"])
    begin_detour = _begin(port, "CHAT-A", "E03", "K03")
    detour = _complete(port, "CHAT-A", "E03", _directive(begin_detour, "E03"))
    check("R06-ordinary-question-keeps-context", detour["session"]["active_context_ref"] == "CTX-A")
    check("R07-transient-detour-does-not-mutate-tree", detour["receipt"]["project_revision_before"] == detour["receipt"]["project_revision_after"])
    check("R52-detour-preserves-binding", detour["session"] == before_detour)

    begin_grandchild = _begin(port, "CHAT-A", "E04", "K04")
    grandchild = _complete(
        port,
        "CHAT-A",
        "E04",
        _directive(
            begin_grandchild,
            "E04",
            [_child("CTX-A1", "CTX-A")],
            [
                {"operation": "SET_ACTIVE", "context_ref": "CTX-A1"},
                {"operation": "SET_CONTINUATION_BINDING", "binding": _binding("CTX-A1", "BIND-A1")},
            ],
        ),
    )
    check("R09-grandchild-parent-chain", ancestor_chain(grandchild["project"], "CTX-A1") == ["CTX-A1", "CTX-A", "CTX-ROOT"])

    begin_bad_return = _begin(port, "CHAT-A", "E05", "K05")
    bad_return = _directive(
        begin_bad_return,
        "E05",
        [_return_operation(begin_bad_return, "CTX-A", "RESULT-A")],
        [],
    )
    check("R18-return-with-open-descendant-blocks", _expect_error(lambda: _complete(port, "CHAT-A", "E05", bad_return), StateConflict))

    begin_return_a1 = _begin(port, "CHAT-A", "E06", "K06")
    returned_a1 = _complete(
        port,
        "CHAT-A",
        "E06",
        _directive(
            begin_return_a1,
            "E06",
            [_return_operation(begin_return_a1, "CTX-A1", "RESULT-A1")],
            [
                {"operation": "SET_ACTIVE", "context_ref": "CTX-A"},
                {"operation": "SET_CONTINUATION_BINDING", "binding": _binding("CTX-A", "BIND-A-RETURN")},
            ],
        ),
    )
    mapping = {item["context_id"]: item for item in returned_a1["project"]["contexts"]}
    check("R20-valid-return-is-pending-join", mapping["CTX-A1"]["lifecycle"] == "RETURNED" and mapping["CTX-A1"]["disposition"] == "PENDING_JOIN")
    parent_before_return = next(item for item in begin_return_a1["project"]["contexts"] if item["context_id"] == "CTX-A")
    check(
        "R51-child-return-does-not-silently-redefine-parent",
        mapping["CTX-A"] == parent_before_return,
    )
    invalid_active = copy.deepcopy(returned_a1["session"])
    invalid_active["active_context_ref"] = "CTX-A1"
    invalid_active = refresh_session_fingerprint(invalid_active)
    check(
        "R21-active-context-cannot-point-to-returned",
        _expect_error(lambda: validate_session_state(invalid_active, returned_a1["project"]), ControlContextError),
    )

    begin_pending = _begin(port, "CHAT-A", "E07", "K07")
    pending_return = _directive(
        begin_pending,
        "E07",
        [_return_operation(begin_pending, "CTX-A", "RESULT-A")],
        [],
    )
    check("R19-return-with-pending-descendant-blocks", _expect_error(lambda: _complete(port, "CHAT-A", "E07", pending_return), StateConflict))

    begin_close = _begin(port, "CHAT-A", "E08", "K08")
    closed = _complete(
        port,
        "CHAT-A",
        "E08",
        _directive(
            begin_close,
            "E08",
            _join_and_close("CTX-A1", "INCORPORATED", "OWNER-RECEIPT-A1"),
            [],
        ),
    )
    check("returned-child-closes-with-explicit-disposition", {item["context_id"]: item for item in closed["project"]["contexts"]}["CTX-A1"]["disposition"] == "INCORPORATED")

    begin_other_active = _begin(port, "CHAT-B", "E09", "K09")
    switched_b = _complete(
        port,
        "CHAT-B",
        "E09",
        _directive(begin_other_active, "E09", [], [{"operation": "SET_ACTIVE", "context_ref": "CTX-A"}]),
    )
    check("focus-only-switch-does-not-change-project-revision", switched_b["receipt"]["project_revision_before"] == switched_b["receipt"]["project_revision_after"])

    begin_return_a = _begin(port, "CHAT-A", "E10", "K10")
    return_a = _directive(
        begin_return_a,
        "E10",
        [_return_operation(begin_return_a, "CTX-A", "RESULT-A")],
        [
            {"operation": "SET_ACTIVE", "context_ref": "CTX-ROOT"},
            {"operation": "SET_CONTINUATION_BINDING", "binding": _binding("CTX-ROOT", "BIND-ROOT")},
        ],
    )
    check("other-session-active-context-blocks-return", _expect_error(lambda: _complete(port, "CHAT-A", "E10", return_a), StateConflict))

    begin_b_root = _begin(port, "CHAT-B", "E11", "K11")
    _complete(port, "CHAT-B", "E11", _directive(begin_b_root, "E11", [], [{"operation": "SET_ACTIVE", "context_ref": "CTX-ROOT"}]))
    begin_return_a2 = _begin(port, "CHAT-A", "E12", "K12")
    returned_a = _complete(port, "CHAT-A", "E12", _directive(begin_return_a2, "E12", return_a["project_operations"], return_a["session_operations"]))
    check("R20-valid-parent-return-after-clean-descendants", {item["context_id"]: item for item in returned_a["project"]["contexts"]}["CTX-A"]["lifecycle"] == "RETURNED")

    begin_close_a = _begin(port, "CHAT-A", "E13", "K13")
    _complete(
        port,
        "CHAT-A",
        "E13",
        _directive(begin_close_a, "E13", _join_and_close("CTX-A", "PRESERVED", "OWNER-RECEIPT-A"), []),
    )
    begin_derived = _begin(port, "CHAT-A", "E14", "K14")
    derived_op = _child("CTX-A2", "CTX-ROOT", "OBJ-DERIVED")
    derived_op["operation"] = "CREATE_DERIVED_CONTEXT"
    derived_op["derived_from_context_ref"] = "CTX-A"
    derived = _complete(
        port,
        "CHAT-A",
        "E14",
        _directive(
            begin_derived,
            "E14",
            [derived_op],
            [
                {"operation": "SET_ACTIVE", "context_ref": "CTX-A2"},
                {"operation": "SET_CONTINUATION_BINDING", "binding": _binding("CTX-A2", "BIND-A2")},
            ],
        ),
    )
    check("R22-historical-reopen-creates-derived-context", {item["context_id"]: item for item in derived["project"]["contexts"]}["CTX-A2"]["derived_from_context_ref"] == "CTX-A")

    tampered = copy.deepcopy(derived["project"])
    mapping = {item["context_id"]: item for item in tampered["contexts"]}
    mapping["CTX-ROOT"]["parent_context_ref"] = "CTX-A2"
    tampered = refresh_project_fingerprints(tampered)
    check("R11-cycle-is-rejected", _expect_error(lambda: validate_project_state(tampered), ControlContextError))
    check("R26-lca-is-deterministic", lowest_common_ancestor(derived["project"], ["CTX-A1", "CTX-A2"]) == "CTX-ROOT")

    before_invalid = port.read_project(tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", project_ref="TOTAL_MCP_REVISION", scopes=scopes)
    begin_invalid = _begin(port, "CHAT-A", "E15", "K15")
    invalid = _directive(begin_invalid, "E15", [{"operation": "UNKNOWN"}], [])
    check("R35-invalid-directive-blocks", _expect_error(lambda: _complete(port, "CHAT-A", "E15", invalid), StateConflict))
    after_invalid = port.read_project(tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", project_ref="TOTAL_MCP_REVISION", scopes=scopes)
    check("R35-invalid-directive-is-atomic", before_invalid == after_invalid)

    begin_duplicate = _begin(port, "CHAT-A", "E16", "K16")
    first = _complete(port, "CHAT-A", "E16", _directive(begin_duplicate, "E16"))
    second = _complete(port, "CHAT-A", "E16", _directive(begin_duplicate, "E16"))
    check("R58-duplicate-event-is-idempotent", first == second)
    altered_completion = _directive(begin_duplicate, "E16")
    altered_completion["decision_ref"] = "DEC-DIFFERENT"
    check(
        "R58-idempotency-does-not-hide-a-different-completion",
        _expect_error(lambda: _complete(port, "CHAT-A", "E16", altered_completion), StateConflict),
    )
    check(
        "R58-idempotency-key-reuse-with-different-begin-request-conflicts",
        _expect_error(lambda: _begin(port, "CHAT-A", "E16-OTHER", "K16"), StateConflict),
    )

    begin_c1 = _begin(port, "CHAT-A", "E17", "K17")
    begin_c2 = _begin(port, "CHAT-B", "E18", "K18")
    create_c1 = _child("CTX-C1", "CTX-ROOT")
    create_c2 = _child("CTX-C2", "CTX-ROOT")
    _complete(port, "CHAT-A", "E17", _directive(begin_c1, "E17", [create_c1], []))
    check(
        "R54-concurrent-project-write-conflicts",
        _expect_error(lambda: _complete(port, "CHAT-B", "E18", _directive(begin_c2, "E18", [create_c2], [])), StateConflict),
    )

    begin_deep = _begin(port, "CHAT-A", "E20", "K20")
    deep_operations: list[dict[str, Any]] = []
    deep_parent = "CTX-C1"
    for depth in range(2, 9):
        context_id = f"CTX-DEEP-{depth}"
        deep_operations.append(_child(context_id, deep_parent))
        deep_parent = context_id
    deep = _complete(port, "CHAT-A", "E20", _directive(begin_deep, "E20", deep_operations, []))
    check(
        "R10-deep-nesting-uses-one-parent-link-algorithm",
        len(ancestor_chain(deep["project"], "CTX-DEEP-8")) == 9
        and ancestor_chain(deep["project"], "CTX-DEEP-8")[-1] == "CTX-ROOT",
    )

    begin_equivalent = _begin(port, "CHAT-A", "E21", "K21")
    existing_c1 = next(item for item in begin_equivalent["project"]["contexts"] if item["context_id"] == "CTX-C1")
    equivalent = {
        "operation": "CREATE_CHILD",
        "parent_context_ref": existing_c1["parent_context_ref"],
        "context_id": "CTX-C1-EQUIVALENT",
        "human_label": "Lik gren",
        "objective_ref": existing_c1["objective_ref"],
        "scope_ref": existing_c1["scope_ref"],
        "basis_refs": existing_c1["basis_refs"],
        "project_basis_ref": existing_c1["project_basis_ref"],
        "quality_trace_ref": existing_c1["quality_trace_ref"],
        "completion_criteria_refs": ["DONE-EQUIVALENT"],
    }
    project_before_equivalent = copy.deepcopy(begin_equivalent["project"])
    check(
        "R12-equivalent-fork-without-material-delta-is-rejected",
        _expect_error(
            lambda: _complete(port, "CHAT-A", "E21", _directive(begin_equivalent, "E21", [equivalent], [])),
            StateConflict,
        ),
    )
    project_after_equivalent = port.read_project(
        tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", project_ref="TOTAL_MCP_REVISION", scopes=scopes
    )
    check("R12-equivalent-fork-rejection-is-atomic", project_after_equivalent == project_before_equivalent)
    begin_recursive = _begin(port, "CHAT-A", "E21A", "K21A")
    recursive = copy.deepcopy(equivalent)
    recursive.update(context_id="CTX-C1-RECURSIVE", parent_context_ref="CTX-C1", human_label="Rekursiv gren")
    check(
        "R12-equivalent-ancestor-recursion-is-rejected",
        _expect_error(
            lambda: _complete(port, "CHAT-A", "E21A", _directive(begin_recursive, "E21A", [recursive], [])),
            StateConflict,
        ),
    )

    session_before_correction = port.read_session(
        tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", principal_ref="ADMIN-1",
        consumer_ref="CHATGPT", session_ref="CHAT-A", scopes=scopes,
    )
    begin_correction = _begin(port, "CHAT-A", "E22", "K22")
    corrected = _complete(
        port,
        "CHAT-A",
        "E22",
        _directive(
            begin_correction,
            "E22",
            [],
            [{
                "operation": "SET_CONTINUATION_BINDING",
                "binding": _binding(
                    session_before_correction["active_context_ref"],
                    "BIND-CORRECTED",
                    "Fortsett korrigert gren",
                ),
            }],
        ),
    )
    check(
        "R53-material-correction-replaces-binding-atomically",
        corrected["project"] == begin_correction["project"]
        and corrected["session"]["active_continuation_binding"]["binding_id"] == "BIND-CORRECTED"
        and corrected["session"]["fingerprint"] != session_before_correction["fingerprint"],
    )

    active_ref = corrected["session"]["active_context_ref"]
    condition_states: dict[str, dict[str, Any]] = {}
    for event_number, condition in ((23, "PAUSED_BY_USER"), (24, "WAITING_HUMAN"), (25, "STALLED"), (26, "SAFE_HOLD"), (27, "READY")):
        event_id = f"E{event_number}"
        begin_condition = _begin(port, "CHAT-A", event_id, f"K{event_number}")
        condition_states[condition] = _complete(
            port,
            "CHAT-A",
            event_id,
            _directive(
                begin_condition,
                event_id,
                [{
                    "operation": "SET_CONTROL_CONDITION",
                    "context_ref": active_ref,
                    "control_condition": condition,
                }],
                [],
            ),
        )
    check(
        "R14-paused-by-user-preserves-open-context",
        next(item for item in condition_states["PAUSED_BY_USER"]["project"]["contexts"] if item["context_id"] == active_ref)["lifecycle"] == "OPEN",
    )
    check(
        "R15-waiting-human-remains-active-session-focus",
        condition_states["WAITING_HUMAN"]["session"]["active_context_ref"] == active_ref
        and next(item for item in condition_states["WAITING_HUMAN"]["project"]["contexts"] if item["context_id"] == active_ref)["control_condition"] == "WAITING_HUMAN",
    )
    check(
        "R17-safe-hold-preserves-state-until-verified-resume",
        next(item for item in condition_states["SAFE_HOLD"]["project"]["contexts"] if item["context_id"] == active_ref)["control_condition"] == "SAFE_HOLD"
        and next(item for item in condition_states["READY"]["project"]["contexts"] if item["context_id"] == active_ref)["control_condition"] == "READY",
    )

    begin_refresh = _begin(port, "CHAT-A", "E28", "K28")
    active_before_refresh = next(item for item in begin_refresh["project"]["contexts"] if item["context_id"] == active_ref)
    refreshed = _complete(
        port,
        "CHAT-A",
        "E28",
        _directive(
            begin_refresh,
            "E28",
            [{
                "operation": "REFRESH_GOVERNING_REFS",
                "context_ref": active_ref,
                "project_basis_ref": "PROJECT-BASIS-2",
                "quality_trace_ref": "QUALITY-DEEP-2",
                "basis_refs": ["BASIS-REFRESHED"],
            }],
            [],
        ),
    )
    active_after_refresh = next(item for item in refreshed["project"]["contexts"] if item["context_id"] == active_ref)
    check(
        "R34-material-owner-revision-refreshes-governing-context-refs",
        active_after_refresh["project_basis_ref"] == "PROJECT-BASIS-2"
        and active_after_refresh["quality_trace_ref"] == "QUALITY-DEEP-2"
        and active_after_refresh["basis_fingerprint"] != active_before_refresh["basis_fingerprint"],
    )

    begin_bound_refresh = _begin(port, "CHAT-A", "E28B", "K28B")
    bound_refresh_directive = _directive(
        begin_bound_refresh,
        "E28B",
        [{
            "operation": "REFRESH_GOVERNING_REFS",
            "context_ref": active_ref,
            "project_basis_ref": "PROJECT-BASIS-3",
            "quality_trace_ref": "QUALITY-DEEP-3",
            "basis_refs": ["BASIS-REFRESHED-3"],
        }],
        [],
    )
    predicted_project, _, predicted_transition = apply_transition(
        begin_bound_refresh["project"],
        begin_bound_refresh["session"],
        bound_refresh_directive,
    )
    candidate_args = {
        "owner": "context",
        "control_decision_ref": bound_refresh_directive["decision_ref"],
        "consolidation_result_ref": "CCR-AAAAAAAAAAAAAAAAAAAAAAAA",
        "effect": "REFRESH_GOVERNING_REFS",
        "input_state_ref": begin_bound_refresh["project"]["project_ref"],
        "input_state_fingerprint": begin_bound_refresh["project"]["fingerprint"],
        "output_state_ref": predicted_project["project_ref"],
        "output_state_fingerprint": predicted_project["fingerprint"],
        "evidence_refs": [predicted_transition["receipt_id"]],
        "unaffected_state_preserved": True,
        "state_mutated": True,
    }
    wrong_candidate = build_owner_effect_receipt(
        **candidate_args,
        affected_refs=["CTX-NOT-TARGET"],
    )
    rejected_wrong_candidate = _expect_error(
        lambda: _complete(
            port,
            "CHAT-A",
            "E28B",
            bound_refresh_directive,
            owner_effect_candidate=wrong_candidate,
        ),
        StatePortError,
    )
    project_after_rejection = port.read_project(
        tenant_ref="TENANT-1",
        workspace_ref="WORKSPACE-1",
        principal_ref="ADMIN-1",
        project_ref="TOTAL_MCP_REVISION",
        scopes={"project_state:read"},
    )
    check(
        "validly-fingerprinted-wrong-context-candidate-is-atomic-in-memory",
        rejected_wrong_candidate
        and project_after_rejection["fingerprint"] == begin_bound_refresh["project"]["fingerprint"],
    )
    correct_candidate = build_owner_effect_receipt(
        **candidate_args,
        affected_refs=[active_ref],
    )
    bound_refresh = _complete(
        port,
        "CHAT-A",
        "E28B",
        bound_refresh_directive,
        owner_effect_candidate=correct_candidate,
    )
    check(
        "exact-context-candidate-is-accepted-before-in-memory-mutation",
        bound_refresh["project"]["fingerprint"] == predicted_project["fingerprint"],
    )

    final_mapping = {item["context_id"]: item for item in bound_refresh["project"]["contexts"]}
    check(
        "R50-no-created-branch-disappears-without-lifecycle-and-disposition",
        {"CTX-A", "CTX-A1", "CTX-A2", "CTX-C1"}.issubset(final_mapping)
        and final_mapping["CTX-A"]["lifecycle"] == "CLOSED"
        and final_mapping["CTX-A"]["disposition"] == "PRESERVED"
        and final_mapping["CTX-A1"]["lifecycle"] == "CLOSED"
        and final_mapping["CTX-A1"]["disposition"] == "INCORPORATED"
        and final_mapping["CTX-A2"]["lifecycle"] == "OPEN",
    )

    port.set_available(False)
    check("R57-outage-fails-closed", _expect_error(lambda: _begin(port, "CHAT-A", "E29", "K29"), StateServiceUnavailable))
    port.set_available(True)
    check(
        "state-write-requires-bounded-scope",
        _expect_error(
            lambda: port.set_default_project(
                tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", principal_ref="ADMIN-1",
                project_ref="TOTAL_MCP_REVISION", scopes=set()
            ),
            StateAuthorizationError,
        ),
    )

    shadow_port = InMemoryControlContextStatePort()
    actor_ready = bootstrap_actor_generation_shadow(
        tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", actor_ref="IMPLEMENTER",
        role="IMPLEMENTER", generation_ref="ACCCBBFC", source_revision="bf4f",
    )
    check("B1-actor-generation-shadow-valid", validate_actor_generation_shadow(actor_ready)["result"] == "PASS")
    shadow_port.write_actor_generation_shadow(actor_ready, expected_revision=0, scopes=scopes)
    actor_active = transition_actor_generation_shadow(actor_ready, lifecycle="ACTIVE", source_revision="bf4f")
    shadow_port.write_actor_generation_shadow(actor_active, expected_revision=1, scopes=scopes)
    claim_prestart = bootstrap_work_claim_shadow(
        tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", claim_ref="WORK_CLAIMS:767",
        project_ref="CEREBRO_FACTORY_PROGRAM", actor_generation=actor_active,
        scope_ref="B1-ACTOR-CLAIM-SHADOW", mode="MATERIAL_IMPLEMENTATION_WORKMODE_REQUIRED_ONE_JOB",
        source_revision="bf4f",
    )
    shadow_port.write_work_claim_shadow(claim_prestart, expected_revision=0, scopes=scopes)
    claim_active = transition_work_claim_shadow(
        claim_prestart, actor_active, lifecycle="ACTIVE", source_revision="bf4f",
    )
    shadow_port.write_work_claim_shadow(claim_active, expected_revision=1, scopes=scopes)
    check(
        "B1-work-claim-shadow-roundtrip-remains-non-live",
        shadow_port.read_work_claim_shadow(
            tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", claim_ref="WORK_CLAIMS:767",
            scopes={"project_state:read"},
        ) == claim_active and claim_active["authority"] == "SHADOW_ONLY" and claim_active["live_claim"] is False,
    )
    claim_released = transition_work_claim_shadow(
        claim_active, actor_active, lifecycle="RELEASED", source_revision="bf4f",
    )
    shadow_port.write_work_claim_shadow(claim_released, expected_revision=2, scopes=scopes)
    actor_ready_after_job = transition_actor_generation_shadow(
        actor_active, lifecycle="READY", source_revision="bf4f",
    )
    shadow_port.write_actor_generation_shadow(actor_ready_after_job, expected_revision=2, scopes=scopes)
    check(
        "B1-ordinary-success-releases-claim-and-preserves-generation-ready",
        claim_released["lifecycle"] == "RELEASED"
        and actor_ready_after_job["lifecycle"] == "READY"
        and actor_ready_after_job["generation_ref"] == actor_active["generation_ref"]
        and validate_work_claim_shadow(claim_released, actor_ready_after_job)["result"] == "PASS",
    )
    check(
        "B1-ready-generation-cannot-carry-active-claim",
        _expect_error(
            lambda: validate_work_claim_shadow(claim_active, actor_ready_after_job),
            ControlContextError,
        ),
    )
    actor_retired = transition_actor_generation_shadow(
        actor_active, lifecycle="RETIRED", source_revision="bf4f",
    )
    check(
        "B1-retired-generation-remains-terminal-sink",
        _expect_error(
            lambda: transition_actor_generation_shadow(
                actor_retired, lifecycle="READY", source_revision="bf4f",
            ),
            ControlContextError,
        ),
    )
    check(
        "B1-claim-generation-mismatch-fails-closed",
        _expect_error(
            lambda: validate_work_claim_shadow(
                claim_active,
                bootstrap_actor_generation_shadow(
                    tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", actor_ref="IMPLEMENTER",
                    role="IMPLEMENTER", generation_ref="PREDECESSOR", source_revision="bf4f", lifecycle="ACTIVE",
                ),
            ),
            ControlContextError,
        ),
    )
    principal_source = "b" * 40
    principal = bootstrap_actor_generation_shadow(
        tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", actor_ref="PRINCIPAL",
        role="PRINCIPAL", generation_ref="7B925FEA", source_revision=principal_source, lifecycle="ACTIVE",
        principal_continuity_baseline=(lambda value: (
            value.update(baseline_fingerprint=principal_continuity_baseline_fingerprint(value)) or value
        ))({
            "schema": "cerebro-principal-continuity-baseline/v1",
            "generation_ref": "7B925FEA", "source_head": principal_source, "ready_epoch": 1,
            "currentness": "CURRENT", "provider_revision": 9, "covered_through_frontier": 77,
            "diary_bound": {"receipt_ref": "R-BASE", "receipt_fingerprint": "6" * 64,
                              "durable": True, "readback_verified": True},
            "living_ledger_baseline": {"receipt_ref": "R-BASE", "receipt_fingerprint": "6" * 64,
                                         "durable": True, "readback_verified": True},
            "livspuls_baseline": {"receipt_ref": "R-BASE", "receipt_fingerprint": "6" * 64,
                                    "durable": True, "readback_verified": True},
            "post_state_readback_verified": True, "baseline_fingerprint": "",
        }),
    )
    check(
        "B1-Packet533-current-principal-role-generation-composes",
        validate_trusted_role_generation_binding(
            principal, required_role="PRINCIPAL", generation_ref="7B925FEA",
        )["authority"] == "SHADOW_ONLY",
    )
    check(
        "B1-Packet533-predecessor-and-non-principal-rejected",
        _expect_error(
            lambda: validate_trusted_role_generation_binding(
                principal, required_role="PRINCIPAL", generation_ref="PREDECESSOR",
            ),
            ControlContextError,
        )
        and _expect_error(
            lambda: validate_trusted_role_generation_binding(
                actor_active, required_role="PRINCIPAL", generation_ref="ACCCBBFC",
            ),
            ControlContextError,
        ),
    )
    legacy_principal = bootstrap_actor_generation_shadow(
        tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", actor_ref="LEGACY-PRINCIPAL",
        role="PRINCIPAL", generation_ref="LEGACY-PRINCIPAL", source_revision=principal_source,
    )
    check(
        "D1-principal-missing-baseline-is-hold-not-ready",
        legacy_principal["lifecycle"] == "HOLD"
        and validate_actor_generation_shadow(legacy_principal)["effective_readiness"] == "HOLD_CONTINUITY_BASELINE",
    )
    legacy_active_without_baseline = {**legacy_principal, "lifecycle": "ACTIVE"}
    legacy_active_without_baseline["fingerprint"] = actor_generation_shadow_fingerprint(
        legacy_active_without_baseline
    )
    check(
        "D1-principal-missing-baseline-cannot-bind-as-current",
        _expect_error(
            lambda: validate_trusted_role_generation_binding(
                legacy_active_without_baseline,
                required_role="PRINCIPAL",
                generation_ref="LEGACY-PRINCIPAL",
            ),
            ControlContextError,
        ),
    )
    late_receipt = {"receipt_ref": "R-LATE", "receipt_fingerprint": "7" * 64,
                    "durable": True, "readback_verified": True}
    late_baseline = {
        "schema": "cerebro-principal-continuity-baseline/v1",
        "generation_ref": "LEGACY-PRINCIPAL", "source_head": principal_source, "ready_epoch": 2,
        "currentness": "CURRENT", "provider_revision": 10, "covered_through_frontier": 78,
        "diary_bound": copy.deepcopy(late_receipt),
        "living_ledger_baseline": copy.deepcopy(late_receipt),
        "livspuls_baseline": copy.deepcopy(late_receipt),
        "post_state_readback_verified": True, "baseline_fingerprint": "",
    }
    late_baseline["baseline_fingerprint"] = principal_continuity_baseline_fingerprint(late_baseline)
    requalified = requalify_principal_generation_shadow(
        legacy_principal, baseline=late_baseline, source_revision=principal_source,
    )
    check(
        "D3-late-baseline-creates-new-prospective-ready-epoch",
        requalified["revision"] == 2 and requalified["principal_continuity_baseline"]["ready_epoch"] == 2
        and legacy_principal["lifecycle"] == "HOLD",
    )
    continuity_port = InMemoryControlContextStatePort()
    continuity_port.write_actor_generation_shadow(legacy_principal, expected_revision=0, scopes=scopes)
    continuity_port.write_actor_generation_shadow(requalified, expected_revision=1, scopes=scopes)
    check(
        "D2-principal-baseline-CAS-readback-exact",
        continuity_port.read_actor_generation_shadow(
            tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", role="PRINCIPAL",
            generation_ref="LEGACY-PRINCIPAL", scopes={"project_state:read"},
        ) == requalified,
    )
    regressed = copy.deepcopy(requalified)
    regressed["revision"] = 3
    regressed["principal_continuity_baseline"]["ready_epoch"] = 3
    regressed["principal_continuity_baseline"]["provider_revision"] = 9
    regressed["principal_continuity_baseline"]["covered_through_frontier"] = 77
    regressed["principal_continuity_baseline"]["baseline_fingerprint"] = (
        principal_continuity_baseline_fingerprint(regressed["principal_continuity_baseline"])
    )
    regressed["fingerprint"] = actor_generation_shadow_fingerprint(regressed)
    check(
        "D4-principal-baseline-provider-frontier-regression-blocks",
        _expect_error(
            lambda: continuity_port.write_actor_generation_shadow(
                regressed, expected_revision=2, scopes=scopes,
            ),
            StateConflict,
        ),
    )
    removed = copy.deepcopy(requalified)
    removed.update(lifecycle="HOLD", revision=3)
    removed.pop("principal_continuity_baseline")
    removed["fingerprint"] = actor_generation_shadow_fingerprint(removed)
    check(
        "D4-principal-baseline-removal-blocks",
        _expect_error(
            lambda: continuity_port.write_actor_generation_shadow(
                removed, expected_revision=2, scopes=scopes,
            ),
            StateConflict,
        ),
    )
    stale_baseline = copy.deepcopy(late_baseline)
    stale_baseline["ready_epoch"] = 1
    stale_baseline["baseline_fingerprint"] = principal_continuity_baseline_fingerprint(stale_baseline)
    check(
        "D3-ready-epoch-cannot-retroactively-repair",
        _expect_error(
            lambda: requalify_principal_generation_shadow(
                legacy_principal, baseline=stale_baseline, source_revision=principal_source,
            ),
            ControlContextError,
        ),
    )
    private_baseline = copy.deepcopy(late_baseline)
    private_baseline["diary_bound"]["receipt_ref"] = "file:private"
    private_baseline["baseline_fingerprint"] = principal_continuity_baseline_fingerprint(private_baseline)
    check(
        "D5-private-baseline-locator-rejected",
        _expect_error(lambda: validate_principal_continuity_baseline(private_baseline), ControlContextError),
    )
    allocation_receipt = {
        "schema": "cerebro-provider-allocation-receipt/v1", "receipt_ref": "ALLOC-767",
        "receipt_fingerprint": "", "claim_ref": "WORK_CLAIMS:768",
        "actor_generation_ref": actor_active["generation_ref"], "provider_ref": "SHARED_PROVIDER",
        "provider_frontier_ref": "FRONTIER-100", "provider_revision": 100,
    }
    allocation_receipt["receipt_fingerprint"] = provider_allocation_receipt_fingerprint(allocation_receipt)
    allocated_claim = bootstrap_work_claim_shadow(
        tenant_ref="TENANT-1", workspace_ref="WORKSPACE-1", claim_ref="WORK_CLAIMS:768",
        project_ref="CEREBRO_FACTORY_PROGRAM", actor_generation=actor_active, scope_ref="ALLOCATED-SHADOW",
        mode="READ_ONLY", source_revision="bf4f", provider_allocation_receipt=allocation_receipt,
    )
    check("K154-provider-allocation-receipt-roundtrip-and-fingerprint",
          allocated_claim["provider_allocation_receipt"] == allocation_receipt
          and validate_work_claim_shadow(allocated_claim, actor_active)["result"] == "PASS")
    wrong_binding = copy.deepcopy(allocated_claim)
    wrong_binding["provider_allocation_receipt"]["claim_ref"] = "WORK_CLAIMS:OTHER"
    wrong_binding["provider_allocation_receipt"]["receipt_fingerprint"] = provider_allocation_receipt_fingerprint(wrong_binding["provider_allocation_receipt"])
    wrong_binding["fingerprint"] = work_claim_shadow_fingerprint(wrong_binding)
    check("K154-provider-allocation-receipt-exact-claim-binding",
          _expect_error(lambda: validate_work_claim_shadow(wrong_binding, actor_active), ControlContextError))
    duplicate_claim = copy.deepcopy(allocated_claim)
    duplicate_claim["claim_ref"] = "WORK_CLAIMS:769"
    duplicate_claim["provider_allocation_receipt"]["claim_ref"] = "WORK_CLAIMS:769"
    duplicate_claim["provider_allocation_receipt"]["receipt_fingerprint"] = provider_allocation_receipt_fingerprint(duplicate_claim["provider_allocation_receipt"])
    duplicate_claim["fingerprint"] = work_claim_shadow_fingerprint(duplicate_claim)
    check("K154-same-allocation-ref-cannot-bind-two-live-claims",
          _expect_error(lambda: validate_work_claim_allocation_dedup([allocated_claim, duplicate_claim]), ControlContextError))

    stable_unknown = {
        "schema":"cerebro-stable-unknown-envelope/v1","work_ref":"WORK-PREVIOUS","claim_ref":"WORK_CLAIMS:700",
        "owner_ref":"PM","basis_fingerprint":"a"*64,"unknown_fingerprint":"","reopen_condition":"FRESH_PROVIDER_TERMINAL",
        "required_evidence_delta_ref":"EVIDENCE-DELTA-1","release_route_ref":"PM-RELEASE","late_receipt_route_ref":"OLD-CLAIM-ONLY",
        "provider_frontier_ref":"FRONTIER-700","provider_revision":700,"frame_strain_evidence_refs":["FRAME-1"],
    }
    stable_unknown["unknown_fingerprint"] = stable_unknown_fingerprint(stable_unknown)
    stable_project, _ = bootstrap_project_state(
        aggregate_id="AGG-STABLE",tenant_ref="TENANT-1",workspace_ref="WORKSPACE-1",project_ref="PROJECT-STABLE",
        source_revision="bf4f",event_id="EV-STABLE-0",decision_ref="DEC-STABLE-0",
        root={"context_id":"CTX-STABLE","human_label":"Stable unknown","objective_ref":"OBJ-STABLE","scope_ref":"SCOPE-STABLE",
              "basis_refs":["BASIS-STABLE"],"project_basis_ref":"PB-STABLE","quality_trace_ref":"QT-STABLE","completion_criteria_refs":["DONE"]},
    )
    stable_session = bind_control_session(stable_project,session_binding_id="SESSION-STABLE-BIND",principal_ref="ADMIN-1",consumer_ref="CONSUMER-STABLE",session_ref="SESSION-STABLE")
    def stable_directive(event_id, decision_ref, project, session, operation):
        return {"schema":DIRECTIVE_SCHEMA,"event_id":event_id,"decision_ref":decision_ref,
                "expected_project_revision":project["revision"],"expected_project_fingerprint":project["fingerprint"],
                "expected_session_revision":session["session_revision"],"expected_session_fingerprint":session["fingerprint"],
                "project_operations":[operation],"session_operations":[]}
    park_op={"operation":"PARK_STABLE_UNKNOWN","context_ref":"CTX-STABLE","stable_unknown":stable_unknown}
    parked_project, parked_session, _ = apply_transition(stable_project, stable_session, stable_directive("EV-STABLE-1","DEC-STABLE-1",stable_project,stable_session,park_op))
    parked = next(x for x in parked_project["contexts"] if x["context_id"]=="CTX-STABLE")
    check("K154-stable-unknown-parks-in-existing-safe-hold-vocabulary", parked["control_condition"]=="SAFE_HOLD" and parked["stable_unknown"]["unknown_fingerprint"]==stable_unknown["unknown_fingerprint"])
    check("K154-unchanged-stable-unknown-does-not-replay",
          _expect_error(lambda: apply_transition(parked_project,parked_session,stable_directive("EV-STABLE-2","DEC-STABLE-2",parked_project,parked_session,park_op)),ControlContextError))
    unchanged_op={"operation":"REOPEN_STABLE_UNKNOWN","context_ref":"CTX-STABLE","unknown_fingerprint":stable_unknown["unknown_fingerprint"],"evidence_delta_ref":"EVIDENCE-DELTA-1","evidence_delta_fingerprint":"a"*64}
    check("K154-unchanged-evidence-cannot-reopen-stable-unknown",
          _expect_error(lambda: apply_transition(parked_project,parked_session,stable_directive("EV-STABLE-3","DEC-STABLE-3",parked_project,parked_session,unchanged_op)),ControlContextError))
    changed_op=copy.deepcopy(unchanged_op); changed_op["evidence_delta_fingerprint"]="b"*64
    reopened_project, _, _ = apply_transition(parked_project,parked_session,stable_directive("EV-STABLE-4","DEC-STABLE-4",parked_project,parked_session,changed_op))
    reopened=next(x for x in reopened_project["contexts"] if x["context_id"]=="CTX-STABLE")
    check("K154-changed-required-evidence-reopens-stable-unknown", reopened["control_condition"]=="READY" and "stable_unknown" not in reopened and reopened["basis_fingerprint"]=="b"*64)

    check(
        "B1-terminal-claim-cannot-resurrect",
        _expect_error(
            lambda: transition_work_claim_shadow(
                transition_work_claim_shadow(
                    claim_active, actor_active, lifecycle="TERMINAL_PASS", source_revision="bf4f",
                ),
                actor_active,
                lifecycle="ACTIVE",
                source_revision="bf4f",
            ),
            ControlContextError,
        ),
    )

    manifest = _read_json(SOURCE_ROOT / "tooling/validator/control_context_scenarios.json")
    required_ids = manifest.get("required_scenario_ids", [])
    implemented_ids = set(manifest.get("implemented_selftest_bindings", {}))
    pending_ids = set(manifest.get("pending_integration_or_owner_scenarios", {}))
    check("scenario-manifest-ids-are-unique", len(required_ids) == len(set(required_ids)))
    check("scenario-manifest-has-no-claim-gap", set(required_ids) == implemented_ids | pending_ids)
    check("scenario-manifest-statuses-do-not-overlap", not implemented_ids.intersection(pending_ids))

    return {
        "schema": "cerebro-control-context-validation-selftest/v1",
        "result": "PASS" if all(item["result"] == "PASS" for item in tests) else "FAIL",
        "test_count": len(tests),
        "failures": [item for item in tests if item["result"] != "PASS"],
        "tests": tests,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p_project = sub.add_parser("validate-project")
    p_project.add_argument("--project", required=True)
    p_project.add_argument("--output")
    p_session = sub.add_parser("validate-session")
    p_session.add_argument("--project", required=True)
    p_session.add_argument("--session", required=True)
    p_session.add_argument("--output")
    p_transition = sub.add_parser("validate-transition")
    p_transition.add_argument("--project", required=True)
    p_transition.add_argument("--session", required=True)
    p_transition.add_argument("--directive", required=True)
    p_transition.add_argument("--output")
    p_selftest = sub.add_parser("selftest")
    p_selftest.add_argument("--output")
    args = parser.parse_args()
    try:
        if args.command == "validate-project":
            result = validate_project_state(_read_json(Path(args.project)))
        elif args.command == "validate-session":
            project = _read_json(Path(args.project))
            result = validate_session_state(_read_json(Path(args.session)), project)
        elif args.command == "validate-transition":
            project = _read_json(Path(args.project))
            session = _read_json(Path(args.session))
            project_after, session_after, receipt = apply_transition(project, session, _read_json(Path(args.directive)))
            result = {"result": "PASS", "project": project_after, "session": session_after, "receipt": receipt}
        else:
            result = selftest()
        output = getattr(args, "output", None)
        if output:
            _write_json(Path(output), result)
        else:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result.get("result") == "PASS" else 1
    except Exception as exc:
        result = {"result": "BLOCK", "error": str(exc)}
        output = getattr(args, "output", None)
        if output:
            _write_json(Path(output), result)
        else:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
