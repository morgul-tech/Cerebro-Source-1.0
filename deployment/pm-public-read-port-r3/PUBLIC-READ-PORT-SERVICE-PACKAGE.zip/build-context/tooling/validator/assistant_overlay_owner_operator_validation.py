#!/usr/bin/env python3
from __future__ import annotations

import copy
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
CTX = ROOT / "tooling" / "context"
if str(CTX) not in sys.path:
    sys.path.insert(0, str(CTX))

import assistant_overlay_owner_operator as op


GEN = "CEREBRO-BOOT-ASS-20261009-ABCDEF01"
SRC = "a" * 40
FP = "b" * 64
RFP = "c" * 64

STRUCTURED = {
    "pre_role_generation": {
        "schema": "cerebro-pre-role-generation/v1",
        "revision": 2,
        "lifecycle": "READY_UNBOUND",
        "tenant_ref": "TENANT",
        "workspace_ref": "WORKSPACE",
        "generation_ref": GEN,
        "source_revision": SRC,
        "fingerprint": FP,
        "role_overlay": None,
        "authority_envelope": {
            "role": None,
            "state": "UNBOUND",
            "grants_claim": False,
            "grants_live_authority": False,
            "grants_scheduler_authority": False,
        },
        "identity_envelope": {
            "generation_ref": GEN,
            "predecessor_generation_ref": None,
            "predecessor_live_state_inherited": False,
            "predecessor_claims_inherited": False,
            "private_state_inherited": False,
        },
        "fresh_world": {
            "verified": True,
            "currentness": "CURRENT",
            "source_revision": SRC,
        },
        "civilization_method_attestation": {
            "attested": True,
            "currentness": "CURRENT",
            "method_fingerprint": "d" * 64,
        },
        "ready_unbound_receipt": {
            "durable": True,
            "post_state_readback_verified": True,
            "receipt_ref": "READY-" + GEN,
            "receipt_fingerprint": RFP,
            "generation_ref": GEN,
            "source_revision": SRC,
        },
    },
    "authenticated_binding": {
        "tenant_ref": "TENANT",
        "workspace_ref": "WORKSPACE",
        "principal_ref": "HUMAN",
        "consumer_ref": "CHATGPT_REMOTE_MCP",
        "session_ref": "chatgpt:SESSION",
    },
    "repository_permission_required": False,
}

WRAPPER = {
    "structuredContent": copy.deepcopy(STRUCTURED),
    "_meta": {
        "cerebro/repositoryPermissionRequired": False,
        "cerebro/sessionCorrelationPresent": True,
        "cerebro/subjectCorrelationPresent": True,
    },
}

INPUT = {
    "schema": op.INPUT_SCHEMA,
    "native_read_wrapper": WRAPPER,
    "human_owner_authorization": {
        "authorization_ref": "HUMAN-ASSISTANT-CHOICE-001",
        "policy_ref": "ASSISTANT-POLICY-001",
        "decision_ref": "ASSISTANT-DECISION-001",
        "overlay_ref": "ASSISTANT-OVERLAY-001",
        "actor_ref": "ASSISTANT_AD1_NEW",
        "actor_generation_ref": "ASSISTANT_AD1_NEW_GEN",
    },
}


class DB:
    def __init__(self):
        self.policy = None
        self.decision = None
        self.commits = 0
        self.rollbacks = 0
        self.closes = 0
        self.commit_raises = False
        self.scope_sets = []
        self.snapshot_begins = 0
        self.mutate_after_policy_read = False
        self.generation = {
            "tenant_ref": "TENANT",
            "workspace_ref": "WORKSPACE",
            "generation_ref": GEN,
            "lifecycle": "READY_UNBOUND",
            "source_revision": SRC,
            "aggregate_revision": 2,
            "aggregate_fingerprint": FP,
            "generation_payload": copy.deepcopy(STRUCTURED["pre_role_generation"]),
        }


class Cur:
    def __init__(self, db):
        self.db = db
        self.description = []
        self.kind = "none"
        self.params = None
        self.scope = {}
        self.snapshot_policy = None
        self.snapshot_decision = None
        self.snapshot_active = False

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def execute(self, sql, params=None):
        self.sql = sql
        self.params = params
        if sql.startswith("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY"):
            self.snapshot_active = True
            self.snapshot_policy = copy.deepcopy(self.db.policy)
            self.snapshot_decision = copy.deepcopy(self.db.decision)
            self.db.snapshot_begins += 1
            self.kind = "none"
            return
        if "set_config('cerebro.tenant_ref'" in sql:
            self.scope["tenant_ref"] = params[0]
            self.db.scope_sets.append(("tenant_ref", params[0]))
            self.kind = "none"
            return
        if "set_config('cerebro.workspace_ref'" in sql:
            self.scope["workspace_ref"] = params[0]
            self.db.scope_sets.append(("workspace_ref", params[0]))
            self.kind = "none"
            return
        if "SET LOCAL statement_timeout" in sql:
            self.kind = "none"
            return

        if "FROM cerebro_pre_role_generation_heads" in sql:
            self.kind = "generation"
            row = self.db.generation if self.scope == {
                "tenant_ref": "TENANT", "workspace_ref": "WORKSPACE"
            } else None
        elif "FROM cerebro_assistant_overlay_policy_heads" in sql:
            self.kind = "policy"
            row = (
                self.snapshot_policy
                if self.snapshot_active
                else self.db.policy if self.db.policy is not None else getattr(self.db, "_pending_policy", None)
            )
        elif "FROM cerebro_assistant_overlay_decision_heads" in sql and "decision_ref=%s" in sql:
            self.kind = "decision_ref"
            row = (
                self.snapshot_decision
                if self.snapshot_active
                else self.db.decision if self.db.decision is not None else getattr(self.db, "_pending_decision", None)
            )
        elif "FROM cerebro_assistant_overlay_decision_heads" in sql:
            self.kind = "decision"
            row = (
                self.snapshot_decision
                if self.snapshot_active
                else self.db.decision if self.db.decision is not None else getattr(self.db, "_pending_decision", None)
            )
        elif "INSERT INTO cerebro_assistant_overlay_policy_heads" in sql:
            keys = (
                "tenant_ref","workspace_ref","principal_ref","consumer_ref","session_ref",
                "policy_ref","policy_revision","current","revoked","owner_authorization_ref",
                "allowed_role","source_revision",
            )
            self.db._pending_policy = dict(zip(keys, params))
            self.kind = "none"
            return
        elif "INSERT INTO cerebro_assistant_overlay_decision_heads" in sql:
            keys = (
                "tenant_ref","workspace_ref","principal_ref","consumer_ref","session_ref",
                "generation_ref","decision_ref","policy_ref","policy_revision","owner_revision",
                "current","revoked","pre_role_fingerprint","ready_unbound_receipt_fingerprint",
                "expected_revision","source_revision","overlay_ref","actor_ref","actor_generation_ref",
            )
            self.db._pending_decision = dict(zip(keys, params))
            self.kind = "none"
            return
        else:
            self.kind = "none"
            return
        if row is not None:
            self.description = [SimpleNamespace(name=k) for k in row]
        else:
            self.description = []

    def fetchone(self):
        if self.kind == "generation":
            row = self.db.generation if self.scope == {
                "tenant_ref": "TENANT", "workspace_ref": "WORKSPACE"
            } else None
        elif self.kind == "policy":
            row = self.snapshot_policy if self.snapshot_active else (
                self.db.policy if self.db.policy is not None else getattr(self.db, "_pending_policy", None)
            )
            if row is not None and self.db.mutate_after_policy_read:
                # Simulate a concurrent revoke after the policy SELECT.
                if self.db.decision is not None:
                    self.db.decision["revoked"] = True
        elif self.kind in ("decision", "decision_ref"):
            row = self.snapshot_decision if self.snapshot_active else (
                self.db.decision if self.db.decision is not None else getattr(self.db, "_pending_decision", None)
            )
        else:
            return None
        if row is None:
            return None
        return tuple(row[k] for k in row)


class Conn:
    def __init__(self, db):
        self.db = db

    def cursor(self):
        return Cur(self.db)

    def commit(self):
        self.db.commits += 1
        if getattr(self.db, "_pending_policy", None) is not None:
            self.db.policy = copy.deepcopy(self.db._pending_policy)
        if getattr(self.db, "_pending_decision", None) is not None:
            self.db.decision = copy.deepcopy(self.db._pending_decision)
        if self.db.commit_raises:
            raise RuntimeError("raw-commit-provider-error secret=SHOULD_NOT_LEAK")

    def rollback(self):
        self.db.rollbacks += 1
        self.db._pending_policy = None
        self.db._pending_decision = None

    def close(self):
        self.db.closes += 1


class Connect:
    def __init__(self, db, fail_calls=None):
        self.db = db
        self.calls = 0
        self.fail_calls = set(fail_calls or [])

    def __call__(self, dsn):
        self.calls += 1
        if self.calls in self.fail_calls:
            raise RuntimeError("raw-connect-error dsn=" + dsn)
        return Conn(self.db)


def outcome(call):
    try:
        return "RETURN", call()
    except op.OwnerOperationOutcome as exc:
        return "OUTCOME", exc
    except Exception as exc:
        return "OTHER", exc


def json_text(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def exact_rows(db):
    n = op.validate_input(copy.deepcopy(INPUT))
    db.policy = op._policy_row(n)
    db.decision = op._decision_row(n)
    return n


def main():
    os.environ["CEREBRO_MIGRATION_DATABASE_URL"] = "postgresql://inside-service-only"
    checks = []

    def ck(name, condition):
        checks.append((name, bool(condition)))

    # Actual wrapper required; manual structuredContent substitution is rejected precommit.
    reconstructed = {
        "schema": op.INPUT_SCHEMA,
        "native_read": copy.deepcopy(STRUCTURED),
        "human_owner_authorization": copy.deepcopy(INPUT["human_owner_authorization"]),
    }
    db = DB()
    kind, val = outcome(lambda: op.execute(reconstructed, mode="COMMIT", connect=Connect(db)))
    ck(
        "manual-provider-read-reconstruction-rejected-no-write",
        kind == "OUTCOME"
        and val.result == "BLOCK_PRECOMMIT_NO_WRITE"
        and db.commits == 0,
    )

    # RLS scope is required by fake FORCE-RLS generation visibility.
    db = DB()
    out = op.execute(copy.deepcopy(INPUT), mode="DRY_RUN", connect=Connect(db))
    ck(
        "dry-run-sets-exact-rls-scope-no-write",
        out["result"] == "DRY_RUN_VALIDATED"
        and db.scope_sets == [("tenant_ref", "TENANT"), ("workspace_ref", "WORKSPACE")]
        and db.commits == 0,
    )

    db = DB()
    out = op.execute(copy.deepcopy(INPUT), mode="COMMIT", connect=Connect(db))
    ck(
        "commit-and-postread-set-rls-scope",
        out["result"] == "COMMITTED_READBACK_PASS"
        and db.scope_sets.count(("tenant_ref", "TENANT")) == 2
        and db.scope_sets.count(("workspace_ref", "WORKSPACE")) == 2
        and db.snapshot_begins == 1,
    )

    # Commit ambiguity/readback semantics retained.
    db = DB()
    kind, val = outcome(lambda: op.execute(copy.deepcopy(INPUT), mode="COMMIT", connect=Connect(db, fail_calls={2})))
    ck(
        "commit-success-second-connect-fail-no-retry",
        kind == "OUTCOME"
        and val.result == "COMMITTED_READBACK_FAILED"
        and val.committed is True
        and val.retry_allowed is False,
    )

    db = DB()
    db.commit_raises = True
    kind, val = outcome(lambda: op.execute(copy.deepcopy(INPUT), mode="COMMIT", connect=Connect(db)))
    ck(
        "ambiguous-commit-no-retry",
        kind == "OUTCOME"
        and val.result == "UNKNOWN_NO_RETRY"
        and val.committed is None
        and val.retry_allowed is False,
    )

    # Reconcile exact pair uses one coherent read-only REPEATABLE READ snapshot.
    db = DB()
    exact_rows(db)
    db.mutate_after_policy_read = True
    out = op.execute(copy.deepcopy(INPUT), mode="RECONCILE", connect=Connect(db))
    ck(
        "reconcile-coherent-repeatable-read-snapshot",
        out["result"] == "RECONCILE_COMMITTED_READBACK_PASS"
        and db.snapshot_begins == 1
        and out["readback"] == "REPEATABLE_READ_READ_ONLY_SNAPSHOT_EXACT_MATCH"
        and "NATIVE_CURRENT_FENCE_REQUIRED_BEFORE_RESUME" in out["snapshot_boundary"],
    )

    # Partial states are never BOTH_ABSENT/committed=false.
    db = DB()
    n = op.validate_input(copy.deepcopy(INPUT))
    db.policy = op._policy_row(n)
    out = op.execute(copy.deepcopy(INPUT), mode="RECONCILE", connect=Connect(db))
    ck(
        "reconcile-policy-only-is-unknown-mismatch-no-retry",
        out["result"] == "RECONCILE_MISMATCH_NO_RETRY"
        and out["committed"] is None
        and out["retry_allowed"] is False,
    )

    db = DB()
    db.decision = op._decision_row(n)
    out = op.execute(copy.deepcopy(INPUT), mode="RECONCILE", connect=Connect(db))
    ck(
        "reconcile-decision-only-is-unknown-mismatch-no-retry",
        out["result"] == "RECONCILE_MISMATCH_NO_RETRY"
        and out["committed"] is None
        and out["retry_allowed"] is False,
    )

    db = DB()
    out = op.execute(copy.deepcopy(INPUT), mode="RECONCILE", connect=Connect(db))
    ck(
        "reconcile-both-absent-is-explicit-absent",
        out["result"] == "RECONCILE_PAIR_ABSENT_NO_RETRY"
        and out["committed"] is False
        and out["retry_allowed"] is False,
    )

    # Receipt failure never leaks raw provider text or changes known committed state.
    db = DB()
    committed = op.execute(copy.deepcopy(INPUT), mode="COMMIT", connect=Connect(db))
    original_write = op.write_receipt
    try:
        def fail_write(_result, _path=op.OUTPUT_PATH):
            raise OSError("raw-path-provider-error secret=SHOULD_NOT_LEAK")
        op.write_receipt = fail_write
        shown, status = op._write_or_report_receipt(committed)
    finally:
        op.write_receipt = original_write
    ck(
        "receipt-write-fail-preserves-state-and-sanitizes",
        status == 3
        and shown["committed"] is True
        and shown["retry_allowed"] is False
        and "secret" not in json_text(shown),
    )

    for name, ok in checks:
        print("PASS" if ok else "FAIL", name)
    print("SUMMARY", sum(ok for _, ok in checks), "/", len(checks), "PASS")
    return 0 if all(ok for _, ok in checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
