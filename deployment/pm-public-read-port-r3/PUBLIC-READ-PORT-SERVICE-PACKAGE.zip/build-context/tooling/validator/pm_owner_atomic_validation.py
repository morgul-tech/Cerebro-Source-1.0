"""Focused PM owner transaction and authorization checks without live provider IO."""

from __future__ import annotations

import sys
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "mcp"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tooling" / "context"))
from pm_owner_atomic import PmOwnerAssignment, PmOwnerError, PostgresPmOwner  # noqa: E402
from control_context_state_postgres import PostgresControlContextStatePort  # noqa: E402


class Cursor:
    def __init__(self) -> None:
        self.head = None
        self.receipts = {}
        self.idempotency = {}
        self.current = {}
        self.result = None

    def execute(self, sql, params) -> None:
        sql = " ".join(sql.lower().split())
        self.result = None
        if sql.startswith("insert into cerebro_pm_owner_heads"):
            if self.head is None:
                self.head = {"next_seq": 1}
        elif sql.startswith("select next_seq from cerebro_pm_owner_heads"):
            self.result = dict(self.head)
        elif "from cerebro_pm_owner_receipts" in sql and "idempotency_key=%s" in sql:
            self.result = self.idempotency.get(params[-1])
        elif sql.startswith("select receipt_ref from cerebro_pm_owner_current"):
            ref = self.current.get(params[-1])
            self.result = {"receipt_ref": ref} if ref else None
        elif "from cerebro_pm_owner_receipts" in sql and "receipt_ref=%s" in sql:
            self.result = self.receipts.get(params[-1])
        elif sql.startswith("insert into cerebro_pm_owner_receipts"):
            record = {"record_payload": params[9], "snapshot_sha256": params[8],
                      "request_fingerprint": params[7], "projection_payload": params[10]}
            self.receipts[params[4]] = record
            self.idempotency[params[6]] = record
        elif sql.startswith("insert into cerebro_pm_owner_current"):
            self.current[params[3]] = params[4]
        elif sql.startswith("update cerebro_pm_owner_heads"):
            self.head["next_seq"] += 1
        else:
            raise AssertionError("unrecognized SQL in focused fake")

    def fetchone(self):
        return self.result


class State:
    def __init__(self) -> None:
        self.cursor = Cursor()
        self.opened = 0
        self.project_revision = 1
        self.session_project_revision = 1
        self.operations = []

    @contextmanager
    def _transaction(self, **kwargs):
        self.opened += 1
        assert kwargs["repeatable_read"] is True
        assert kwargs["passthrough_errors"] == (PmOwnerError,)
        self.operations = []
        yield self.cursor

    def _load_session(self, cursor, **kwargs):
        self.operations.append(("session", kwargs["for_update"]))
        return {"project_ref": "project", "project_revision": self.session_project_revision,
                "session_binding_id": "binding", "session_revision": 1,
                "fingerprint": "a" * 64}

    def _load_project(self, cursor, **kwargs):
        self.operations.append(("project", kwargs["for_update"]))
        return {"revision": self.project_revision, "project_status": "ACTIVE"}


assignment = PmOwnerAssignment.from_mapping({
    "owner_ref": "owner:PM", "tenant_ref": "tenant", "workspace_ref": "workspace",
    "project_ref": "project", "principal_ref": "principal", "consumer_ref": "consumer",
    "session_ref": "session:PM", "session_binding_id": "binding",
})
state = State()
provider = PostgresPmOwner(state_port=state, assignment=assignment)
identity = SimpleNamespace(tenant_ref="tenant", workspace_ref="workspace",
                           principal_ref="principal", consumer_ref="consumer",
                           state_scopes={"project_state:read", "project_state:transition"})
session = {"session_ref": "session:PM"}
args = {"idempotency_key": "work-transition-1", "referent_id": "pm-ready:work-1",
        "claim_ref": "WORK_CLAIMS:1", "packet_ref": "PACKETS:1", "queue_ref": "QUEUE:1",
        "claim_body": {"claim": "normal PM work"},
        "packet_body": {"material": {"work": "actual caller supplies this"}, "active_hold": None},
        "queue_body": {"queue": "normal PM work"},
        "ready_state": "MATERIAL_READY", "way_home": ["owner:PM"],
        "expected_current_receipt_ref": None}

def rejected(fn, code):
    try:
        fn()
    except PmOwnerError as exc:
        assert str(exc) == code
    else:
        raise AssertionError("operation unexpectedly accepted")


rejected(lambda: provider.commit(args, identity, {"session_ref": "session:X9"}),
         "PM_OWNER_HOST_SESSION_REQUIRED")
assert state.cursor.receipts == {}
first = provider.commit(args, identity, session)
assert state.operations == [("session", True), ("project", True)]
assert first["replayed"] is False
assert first["record"]["owner_seq"] == 1
assert state.cursor.head["next_seq"] == 2
assert provider.commit(args, identity, session) == {"record": first["record"], "replayed": True}
assert len(state.cursor.receipts) == 1 and state.cursor.head["next_seq"] == 2
assert provider.read({"receipt_ref": first["record"]["receipt_ref"]}, identity, session)["record"] == first["record"]
assert state.operations == [("session", False), ("project", False)]
assert provider.read({"referent_id": "pm-ready:work-1"}, identity, session)["current"] is True
rejected(lambda: provider.commit({**args, "packet_ref": "PACKETS:other"}, identity, session),
         "PM_OWNER_IDEMPOTENCY_CONFLICT")
rejected(lambda: provider.commit({**args, "idempotency_key": "work-transition-2"}, identity, session),
         "PM_OWNER_CURRENT_CAS_CONFLICT")
state.project_revision = state.session_project_revision = 2
assert provider.read({"referent_id": "pm-ready:work-1"}, identity, session)["current"] is True
state.project_revision = 3
rejected(lambda: provider.read({"referent_id": "pm-ready:work-1"}, identity, session),
         "PM_OWNER_STALE_SESSION_OR_PROJECT")


class Connection:
    def __init__(self):
        self.sql = []
        self.rolled_back = False

    def cursor(self):
        return self

    def execute(self, sql, params=None):
        self.sql.append(sql)

    def rollback(self):
        self.rolled_back = True

    def commit(self):
        pass

    def close(self):
        pass


connection = Connection()
port = object.__new__(PostgresControlContextStatePort)
port._connection_factory = lambda: connection
with port._transaction(tenant_ref="tenant", workspace_ref="workspace", principal_ref="principal",
                       read_only=True, repeatable_read=True, passthrough_errors=(PmOwnerError,)):
    pass
assert connection.sql[:2] == ["SET TRANSACTION ISOLATION LEVEL REPEATABLE READ",
                              "SET TRANSACTION READ ONLY"]
connection = Connection()
try:
    with port._transaction(tenant_ref="tenant", workspace_ref="workspace", principal_ref="principal",
                           repeatable_read=True, passthrough_errors=(PmOwnerError,)):
        raise PmOwnerError("PM_OWNER_CURRENT_CAS_CONFLICT")
except PmOwnerError as exc:
    assert str(exc) == "PM_OWNER_CURRENT_CAS_CONFLICT"
else:
    raise AssertionError("typed owner conflict was lost")
assert connection.rolled_back is True
print("PASS: assigned session, atomic receipt, idempotency, current CAS and stale fence")
