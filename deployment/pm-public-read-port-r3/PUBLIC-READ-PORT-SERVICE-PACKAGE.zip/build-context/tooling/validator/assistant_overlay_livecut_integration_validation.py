#!/usr/bin/env python3
"""Focused changed-risk checks for the e416 Assistant overlay integration candidate."""

from __future__ import annotations

import copy
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
MCP = ROOT / "mcp"
if str(MCP) not in sys.path:
    sys.path.insert(0, str(MCP))

from assistant_overlay_owner import (
    AssistantOverlayOwnerError,
    DECISION_FIELDS,
    POLICY_FIELDS,
    PostgresAssistantOverlayDecisionResolver,
)
from control_context_tools import tool_definitions


POLICY = {
    "tenant_ref": "TENANT",
    "workspace_ref": "WORKSPACE",
    "principal_ref": "HUMAN",
    "consumer_ref": "CHATGPT_REMOTE_MCP",
    "session_ref": "chatgpt:SESSION",
    "policy_ref": "P22-SKUMRING-CONSOLIDATION-BOOT-AND-EFFECT-20261009-001",
    "policy_revision": 7,
    "current": True,
    "revoked": False,
    "owner_authorization_ref": "P22-AUTH-ASSISTANT-BOOT-001",
    "allowed_role": "ASSISTANT",
    "source_revision": "3" * 40,
}
DECISION = {
    "tenant_ref": "TENANT",
    "workspace_ref": "WORKSPACE",
    "principal_ref": "HUMAN",
    "consumer_ref": "CHATGPT_REMOTE_MCP",
    "session_ref": "chatgpt:SESSION",
    "generation_ref": "CEREBRO-BOOT-ASS-20261009-CANDIDATE",
    "decision_ref": "P22-ASSISTANT-BOOT-DECISION-001",
    "policy_ref": POLICY["policy_ref"],
    "policy_revision": POLICY["policy_revision"],
    "owner_revision": 3,
    "current": True,
    "revoked": False,
    "pre_role_fingerprint": "1" * 64,
    "ready_unbound_receipt_fingerprint": "2" * 64,
    "expected_revision": 2,
    "source_revision": POLICY["source_revision"],
    "overlay_ref": "ASSISTANT-OVERLAY-CANDIDATE",
    "actor_ref": "ASSISTANT_AD1_CANDIDATE",
    "actor_generation_ref": "ASSISTANT_AD1_CANDIDATE_GEN",
}


class SqlFailure(RuntimeError):
    pass


class FakeCursor:
    def __init__(self, shared):
        self.shared = shared
        self.params = None
        self.kind = None
        self.description = []
        self.closed = False

    def execute(self, sql, params=None):
        self.shared["execute_calls"] += 1
        if self.shared.get("fail_execute") == "timeout" and "SET LOCAL" in sql:
            raise SqlFailure("sql-timeout-entry-failure")
        if "cerebro_assistant_overlay_policy_heads" in sql:
            self.kind = "policy"
            if self.shared.get("fail_execute") == "policy":
                raise SqlFailure("sql-policy-entry-failure")
            self.params = params
            self.description = [SimpleNamespace(name=name) for name in POLICY_FIELDS]
        elif "cerebro_assistant_overlay_decision_heads" in sql:
            self.kind = "decision"
            if self.shared.get("fail_execute") == "decision":
                raise SqlFailure("sql-decision-entry-failure")
            self.params = params
            self.description = [SimpleNamespace(name=name) for name in DECISION_FIELDS]

    def fetchone(self):
        row = self.shared.get(self.kind)
        if row is None:
            return None
        if self.kind == "policy":
            expected = (
                row["tenant_ref"], row["workspace_ref"], row["principal_ref"],
                row["consumer_ref"], row["session_ref"], row["policy_ref"],
            )
            fields = POLICY_FIELDS
        else:
            expected = (
                row["tenant_ref"], row["workspace_ref"], row["principal_ref"],
                row["consumer_ref"], row["session_ref"], row["generation_ref"],
            )
            fields = DECISION_FIELDS
        if self.params != expected:
            return None
        return tuple(row[name] for name in fields)

    def close(self):
        self.shared["cursor_close_calls"] += 1
        self.closed = True
        if self.shared.get("fail_cursor_close"):
            raise RuntimeError("cursor-close-failure")


class FakeConnection:
    def __init__(self, shared):
        self.shared = shared

    def cursor(self):
        self.shared["cursor_calls"] += 1
        if self.shared.get("fail_cursor"):
            raise SqlFailure("cursor-acquisition-failure")
        return FakeCursor(self.shared)

    def rollback(self):
        self.shared["rollback_calls"] += 1
        if self.shared.get("fail_rollback"):
            raise RuntimeError("rollback-failure")

    def close(self):
        self.shared["connection_close_calls"] += 1
        if self.shared.get("fail_connection_close"):
            raise RuntimeError("connection-close-failure")


class Factory:
    def __init__(self, *, policy=POLICY, decision=DECISION):
        self.shared = {
            "policy": copy.deepcopy(policy),
            "decision": copy.deepcopy(decision),
            "execute_calls": 0,
            "cursor_calls": 0,
            "rollback_calls": 0,
            "cursor_close_calls": 0,
            "connection_close_calls": 0,
        }

    def __call__(self):
        self.shared["connection_calls"] = self.shared.get("connection_calls", 0) + 1
        if self.shared.get("fail_connection"):
            raise SqlFailure("connection-acquisition-failure")
        return FakeConnection(self.shared)


def denied(call, *, message=None) -> bool:
    try:
        call()
    except (AssistantOverlayOwnerError, SqlFailure) as exc:
        return message is None or str(exc) == message
    return False


def cleanup_complete(shared) -> bool:
    return (
        shared["rollback_calls"] >= 1
        and shared["cursor_close_calls"] >= 1
        and shared["connection_close_calls"] >= 1
    )


def main() -> int:
    checks = []

    def check(name, condition):
        checks.append({"name": name, "result": "PASS" if condition else "FAIL"})

    identity = SimpleNamespace(
        tenant_ref="TENANT", workspace_ref="WORKSPACE", principal_ref="HUMAN",
        consumer_ref="CHATGPT_REMOTE_MCP",
    )
    pre = {
        "generation_ref": DECISION["generation_ref"],
        "revision": DECISION["expected_revision"],
        "source_revision": DECISION["source_revision"],
        "fingerprint": DECISION["pre_role_fingerprint"],
        "ready_unbound_receipt": {
            "receipt_fingerprint": DECISION["ready_unbound_receipt_fingerprint"],
        },
    }
    verified = {"source_revision": DECISION["source_revision"]}

    factory = Factory()
    resolver = PostgresAssistantOverlayDecisionResolver(factory)
    decision = resolver.resolve(
        pre_role_generation=pre, verified_source=verified,
        identity=identity, session_ref=DECISION["session_ref"],
    )
    check("exact-current-policy-and-decision-yield-assistant-only",
          decision["result"] == "ALLOW"
          and decision["overlay_payload"]["role"] == "ASSISTANT"
          and decision["overlay_payload"]["actor_ref"] == DECISION["actor_ref"])

    fence = resolver.hold_current(decision)
    with fence:
        fence.assert_current()
        factory.shared["decision"]["owner_revision"] += 1
        check("decision-owner-revision-change-fenced",
              denied(fence.assert_current, message="assistant-owner-fence-mismatch:owner_revision"))
        factory.shared["decision"] = copy.deepcopy(DECISION)
        factory.shared["policy"]["policy_revision"] += 1
        check("policy-revision-change-fenced",
              denied(fence.assert_current, message="assistant-owner-policy-fence-mismatch:policy_revision"))
        factory.shared["policy"] = copy.deepcopy(POLICY)

    for name, mutate, expected in (
        ("missing-policy", lambda f: f.shared.__setitem__("policy", None), "assistant-owner-policy-absent"),
        ("noncurrent-policy", lambda f: f.shared["policy"].__setitem__("current", False), "assistant-owner-policy-not-current"),
        ("revoked-policy", lambda f: f.shared["policy"].__setitem__("revoked", True), "assistant-owner-policy-not-current"),
        ("mismatched-policy-revision", lambda f: f.shared["decision"].__setitem__("policy_revision", POLICY["policy_revision"] + 1),
         "assistant-owner-policy-revision-mismatch"),
    ):
        candidate = Factory()
        mutate(candidate)
        check(name+"-denied-before-seal", denied(lambda c=candidate: PostgresAssistantOverlayDecisionResolver(c).resolve(
            pre_role_generation=pre, verified_source=verified, identity=identity,
            session_ref=DECISION["session_ref"],
        ), message=expected))

    stale = Factory()
    stale.shared["decision"]["current"] = False
    stale_resolver = PostgresAssistantOverlayDecisionResolver(stale)
    check("stale-decision-resolve-denied", denied(lambda: stale_resolver.resolve(
        pre_role_generation=pre, verified_source=verified, identity=identity,
        session_ref=DECISION["session_ref"],
    ), message="assistant-owner-decision-not-current"))

    revoked = Factory()
    revoked.shared["decision"]["revoked"] = True
    check("revoked-decision-resolve-denied", denied(lambda: PostgresAssistantOverlayDecisionResolver(revoked).resolve(
        pre_role_generation=pre, verified_source=verified, identity=identity,
        session_ref=DECISION["session_ref"],
    ), message="assistant-owner-decision-not-current"))

    for name, mutate, expected in (
        ("stale-decision-fence-entry", lambda f: f.shared["decision"].__setitem__("current", False),
         "assistant-owner-decision-not-current"),
        ("revoked-decision-fence-entry", lambda f: f.shared["decision"].__setitem__("revoked", True),
         "assistant-owner-decision-not-current"),
    ):
        entry = Factory()
        entry_resolver = PostgresAssistantOverlayDecisionResolver(entry)
        entry_decision = entry_resolver.resolve(
            pre_role_generation=pre, verified_source=verified, identity=identity,
            session_ref=DECISION["session_ref"],
        )
        entry_fence = entry_resolver.hold_current(entry_decision)
        mutate(entry)
        check(name+"-denied-and-cleaned",
              denied(entry_fence.__enter__, message=expected) and cleanup_complete(entry.shared))

    # __enter__ rejection must release all acquired resources, even if cleanup itself fails,
    # and preserve the original policy/decision denial.
    missing_entry = Factory()
    entry_resolver = PostgresAssistantOverlayDecisionResolver(missing_entry)
    entry_decision = entry_resolver.resolve(
        pre_role_generation=pre, verified_source=verified, identity=identity,
        session_ref=DECISION["session_ref"],
    )
    entry_fence = entry_resolver.hold_current(entry_decision)
    missing_entry.shared["policy"] = None
    missing_entry.shared.update(fail_rollback=True, fail_cursor_close=True, fail_connection_close=True)
    check("missing-policy-fence-entry-preserves-original-denial",
          denied(entry_fence.__enter__, message="assistant-owner-policy-absent"))
    check("missing-policy-fence-entry-closes-after-cleanup-failures",
          cleanup_complete(missing_entry.shared))

    sql_entry = Factory()
    sql_resolver = PostgresAssistantOverlayDecisionResolver(sql_entry)
    sql_decision = sql_resolver.resolve(
        pre_role_generation=pre, verified_source=verified, identity=identity,
        session_ref=DECISION["session_ref"],
    )
    sql_fence = sql_resolver.hold_current(sql_decision)
    sql_entry.shared["fail_execute"] = "policy"
    check("sql-fence-entry-preserves-original-error",
          denied(sql_fence.__enter__, message="sql-policy-entry-failure"))
    check("sql-fence-entry-cleans-resources", cleanup_complete(sql_entry.shared))

    acquisition = Factory()
    acquisition.shared["fail_execute"] = "decision"
    check("resolve-sql-acquisition-denied-and-cleaned",
          denied(lambda: PostgresAssistantOverlayDecisionResolver(acquisition).resolve(
              pre_role_generation=pre, verified_source=verified, identity=identity,
              session_ref=DECISION["session_ref"],
          ), message="sql-decision-entry-failure")
          and cleanup_complete(acquisition.shared))

    resume = next(item for item in tool_definitions() if item["name"] == "resume_ready_unbound_assistant_overlay")
    check("caller-cannot-inject-actor-role-overlay-policy-or-signature",
          set(resume["inputSchema"]["properties"]) == {"generation_ref", "expected_revision", "source_revision"})

    tools_text = (ROOT / "mcp" / "control_context_tools.py").read_text(encoding="utf-8")
    service_text = (ROOT / "mcp" / "control_context_remote_service.py").read_text(encoding="utf-8")
    runtime_text = (ROOT / "mcp" / "control_context_remote_runtime.py").read_text(encoding="utf-8")
    app_text = (ROOT / "deployment" / "app.py").read_text(encoding="utf-8")
    owner_text = (ROOT / "mcp" / "assistant_overlay_owner.py").read_text(encoding="utf-8")
    check("private-issuer-output-not-exposed",
          "assistant_overlay_attestation_issuer=attestor" in app_text
          and '"signature"' not in resume["outputSchema"]["properties"])
    check("assistant-policy-and-decision-both-fenced-around-attach",
          "_select_policy" in owner_text
          and "_select_decision" in owner_text
          and "FOR SHARE" in owner_text
          and "with fence:" in tools_text
          and tools_text.index("with fence:") < tools_text.index("issuer.seal(", tools_text.index("with fence:")))

    # Inspect the actual BK07 route locations, not an arbitrary runtime+app concatenation.
    check("selected-bk07-runtime-bindings-preserved",
          all(token in runtime_text + app_text + tools_text + service_text for token in (
              "pm_owner_assignment", "x9_configuration", "runtime_notice_connection_factory",
              "read_local_runtime_binding_v1", "transport_resolve_signalvev_notice_v1",
          ))
          and '"read_local_runtime_binding_v1": "project_state:read"' in service_text
          and '"read_local_runtime_binding_v1": self.read_local_runtime_binding_v1' in tools_text)

    failed = [item for item in checks if item["result"] != "PASS"]
    for item in checks:
        print(item["result"], item["name"])
    print("SUMMARY", len(checks) - len(failed), "/", len(checks), "PASS")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
